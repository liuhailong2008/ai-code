/*
 * Copyright 2026 CloudWeGo Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package summarization

type ActionType string

const (
	ActionTypeBeforeSummarize ActionType = "before_summarize"
	ActionTypeAfterSummarize  ActionType = "after_summarize"
	ActionTypeGenerateSummary ActionType = "generate_summary"
)

const (
	extraKeyContentType       = "_eino_summarization_content_type"
	preserveUserMsgsMaxTokens = 30000
)

type summarizationContentType string

const (
	contentTypeSummary summarizationContentType = "summary"
	contentTypeSkills  summarizationContentType = "skills"
)

type ctxKeyModelInput struct{}
