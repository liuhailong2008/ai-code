-- =====================================================================
-- Groot 数据库最终 Schema（合并自 sql/versions/ 下的历史迁移脚本）
-- 生成日期: 2026-09-17
-- 说明: 本文件为合并后的最终 DDL，建表顺序已按依赖关系整理。
--       历史迁移脚本已归档至 sql/versions/ 目录。
-- =====================================================================


-- ============================================================
-- 一、系统基础表
-- ============================================================

-- 团队表
CREATE TABLE IF NOT EXISTS `sys_teams` (
  `id`            BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `code`          VARCHAR(64)      NOT NULL                 COMMENT '团队编码',
  `name`          VARCHAR(128)     NOT NULL                 COMMENT '团队名称',
  `description`   VARCHAR(254)                                      COMMENT '团队介绍',
  `wechat_id` VARCHAR(128)     DEFAULT NULL             COMMENT '企业微信群编码',
  `team_email` VARCHAR(128)     DEFAULT NULL             COMMENT '团队邮箱',
  `tech_leader`     VARCHAR(64)   DEFAULT   NULL                 COMMENT '专业负责人（员工账号）',
  `team_leader`     VARCHAR(64)    DEFAULT  NULL                 COMMENT '团队负责人（员工账号）',
  `created_by`     VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`     VARCHAR(64)      NULL                 COMMENT '修改人',
  `created_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='团队表';

-- 用户表
CREATE TABLE IF NOT EXISTS `sys_users` (
  `id`            BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `username`      VARCHAR(64)      NOT NULL                 COMMENT '用户名',
  `mobile`        VARCHAR(256)     NOT NULL DEFAULT ''      COMMENT '手机号码（AES 加密）',
  `password`      VARCHAR(256)     NOT NULL                 COMMENT '密码（bcrypt 加密）',
  `display_name`  VARCHAR(64)      NOT NULL                 COMMENT '显示名称',
  `role`          VARCHAR(32)      NOT NULL DEFAULT 'viewer' COMMENT '角色: admin/operator/viewer',
  `created_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- 团队成员关联表
CREATE TABLE IF NOT EXISTS `sys_team_members` (
    `id` BIGINT AUTO_INCREMENT COMMENT '主键',
    `user_id` BIGINT NOT NULL COMMENT '用户ID，关联 sys_users 表',
    `team_id` BIGINT NOT NULL COMMENT '团队ID，关联 sys_teams 表',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    UNIQUE KEY uk_team_to_user (team_id, user_id),
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='团队成员关联表';

-- 大模型配置表
CREATE TABLE IF NOT EXISTS `sys_models` (
  `id`              BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `code`            VARCHAR(128)     NOT NULL                 COMMENT '模型编码（API调用model参数），如 deepseek-chat',
  `name`            VARCHAR(128)     NOT NULL                 COMMENT '模型名称，如 DeepSeek-V4-Flash',
  `provider`        VARCHAR(64)      NOT NULL                 COMMENT '供应商编码：deepseek/volcengine/zhipu',
  `base_url`        VARCHAR(254)     NOT NULL                 COMMENT 'API地址，如 https://api.deepseek.com/v1',
  `api_key`         VARCHAR(254)     NOT NULL                 COMMENT 'API Key（AES加密存储）',
  `purpose`         VARCHAR(32)      NOT NULL                 COMMENT '用途：chat/reasoning/embedding/vision/rerank',
  `is_active`       TINYINT(1)       NOT NULL DEFAULT 0       COMMENT '是否激活（同一用途仅一个激活）',
  `is_enabled`      TINYINT(1)       NOT NULL DEFAULT 1       COMMENT '是否启用（关闭后不参与切换）',
  `priority`        INT              NOT NULL DEFAULT 0       COMMENT '故障转移优先级（0最高）',
  `context_window`  INT              NOT NULL DEFAULT 4096    COMMENT '上下文窗口（tokens）',
  `max_tokens`      INT              NOT NULL DEFAULT 4096    COMMENT '最大输出（tokens）',
  `supports_thinking` TINYINT(1)     NOT NULL DEFAULT 0       COMMENT '支持深度思考',
  `supports_vision`   TINYINT(1)     NOT NULL DEFAULT 0       COMMENT '支持视觉理解',
  `supports_tools`    TINYINT(1)     NOT NULL DEFAULT 0       COMMENT '支持函数调用',
  `supports_json`     TINYINT(1)     NOT NULL DEFAULT 0       COMMENT '支持JSON结构化输出',
  `temperature`     DECIMAL(3,2)     DEFAULT 0.70             COMMENT '默认温度参数',
  `top_p`           DECIMAL(3,2)     DEFAULT 1.00             COMMENT '默认top_p参数',
  `created_by`      VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`      VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`),
  KEY `idx_purpose_active` (`purpose`, `is_active`),
  KEY `idx_purpose_enabled_priority` (`purpose`, `is_enabled`, `priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='大模型配置表';

-- 大字段存储表（所有需要存储长文本的场景统一关联此表）
CREATE TABLE IF NOT EXISTS `sys_texts` (
  `id`              BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `text_content`    TEXT             NOT NULL                 COMMENT '文本内容',
  `created_at`      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='大字段存储表';

-- 数据字典表（parent_id 自关联，parent_id=0 为字典类型，子节点为字典项）
CREATE TABLE IF NOT EXISTS `sys_dict` (
  `id`          BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `parent_id`   BIGINT UNSIGNED  NOT NULL DEFAULT 0       COMMENT '父字典ID(0为字典类型/根)',
  `dict_key`    VARCHAR(128)     NOT NULL                 COMMENT '字典键',
  `dict_value`  VARCHAR(254)     NOT NULL                 COMMENT '字典值',
  `dict_sn`     INT              NOT NULL DEFAULT 0       COMMENT '排序序号',
  `created_at`  DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`  DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_parent_sn` (`parent_id`, `dict_sn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='数据字典表';


-- ============================================================
-- 二、事件中心
-- ============================================================

-- 事件表
CREATE TABLE IF NOT EXISTS `event_records` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `team_id`           BIGINT UNSIGNED  NOT NULL                 COMMENT '所属团队ID',
  `event_title`       VARCHAR(254)     NOT NULL                 COMMENT '事件标题',
  `desc_text_id`      VARCHAR(254)  DEFAULT NULL             COMMENT '事件描述',
  `event_status`      VARCHAR(32)      NOT NULL DEFAULT 'open'  COMMENT '状态: open/in_progress/resolved/closed',
  `event_severity`    VARCHAR(32)      NOT NULL DEFAULT 'medium' COMMENT '严重程度: low/medium/high/critical',
  `event_category`    VARCHAR(64)      NOT NULL                 COMMENT '事件分类，如 消息队列/缓存/存储',
  `idc_name`          VARCHAR(64)      DEFAULT NULL             COMMENT '机房',
  `app_name`          VARCHAR(64)      DEFAULT NULL             COMMENT '中间件类型，如 Redis/Kafka/RocketMQ/MinIO/ZooKeeper',
  `cluster_name`      VARCHAR(128)     DEFAULT NULL             COMMENT '集群名称',
  `event_source`      VARCHAR(32)      NOT NULL DEFAULT 'manual' COMMENT '来源: manual/alert/inspect/ticket',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `uni_no`            VARCHAR(128)     DEFAULT NULL             COMMENT '工单号',
  `ext_ticket_id`     VARCHAR(128)     DEFAULT NULL             COMMENT '关联外部工单ID',
  `event_metadata`    VARCHAR(254)     DEFAULT NULL             COMMENT '扩展元数据',
  `opened_at`         DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '事件打开时间',
  `closed_at`         DATETIME         DEFAULT NULL             COMMENT '事件关闭时间',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_team_status_opened` (`team_id`, `event_status`, `opened_at`),
  KEY `idx_team_created` (`team_id`, `created_at`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='事件表';

-- 事件消息表
CREATE TABLE IF NOT EXISTS `event_messages` (
  `id`                  BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `event_id`            BIGINT UNSIGNED  NOT NULL                 COMMENT '所属事件ID',
  `actor_id`            VARCHAR(64)      NOT NULL                 COMMENT '消息发送者ID',
  `msg_role`            VARCHAR(32)      NOT NULL DEFAULT 'user'  COMMENT '角色: user/agent/system',
  `content_text_id`     BIGINT UNSIGNED  NOT NULL                 COMMENT '消息内容（关联 sys_texts.id）',
  `tool_calls_text_id`  BIGINT UNSIGNED  DEFAULT NULL             COMMENT 'Agent工具调用记录（关联 sys_texts.id）',
  `parent_msg_id`       BIGINT UNSIGNED  DEFAULT NULL             COMMENT '父消息ID（支持话题分支）',
  `created_at`          DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_event_created` (`event_id`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='事件消息表（只追加）';

-- 事件 UIBlock 表
CREATE TABLE IF NOT EXISTS `event_uiblocks` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `event_id`          BIGINT UNSIGNED  NOT NULL                 COMMENT '所属事件ID',
  `msg_id`            BIGINT UNSIGNED  NOT NULL                 COMMENT '关联消息ID',
  `block_type`        VARCHAR(64)      NOT NULL                 COMMENT 'UIBlock类型: dashboard/chart/table/log/approval_card/plan/markdown/code',
  `payload_text_id`   BIGINT UNSIGNED  NOT NULL                 COMMENT 'UIBlock内容载荷（关联 sys_texts.id）',
  `order_idx`         INT              NOT NULL DEFAULT 0       COMMENT '排序序号',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_event_msg` (`event_id`, `msg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='事件UIBlock表';

-- 事件参与者表
CREATE TABLE IF NOT EXISTS `event_participants` (
  `id`              BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `event_id`        BIGINT UNSIGNED  NOT NULL                 COMMENT '事件ID',
  `user_id`         BIGINT UNSIGNED  NOT NULL                 COMMENT '用户ID',
  `user_name`       VARCHAR(64)      NOT NULL                 COMMENT '用户名（冗余，避免JOIN）',
  `user_avatar`     VARCHAR(254)     DEFAULT NULL             COMMENT '用户头像URL（冗余）',
  `participant_role` VARCHAR(32)     NOT NULL DEFAULT 'watcher' COMMENT '参与角色: owner/reviewer/approver/watcher',
  `joined_at`       DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '加入时间',
  `created_at`      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_event_user` (`event_id`, `user_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='事件参与者表';

-- 审批表
CREATE TABLE IF NOT EXISTS `event_approvals` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `event_id`          BIGINT UNSIGNED  NOT NULL                 COMMENT '关联事件ID',
  `approval_type`     VARCHAR(32)      NOT NULL                 COMMENT '审批类型: internal_review(内部双人复核)/external_ticket(外部工单)',
  `tool_call_ref`     VARCHAR(254)     NOT NULL                 COMMENT '关联工具调用引用',
  `approval_status`   VARCHAR(32)      NOT NULL DEFAULT 'pending' COMMENT '状态: pending/approved/rejected/cancelled/expired',
  `submitter_id`      BIGINT UNSIGNED  NOT NULL                 COMMENT '提交人用户ID',
  `decider_id`        BIGINT UNSIGNED  DEFAULT NULL             COMMENT '审批人用户ID',
  `uni_no`     VARCHAR(128)     DEFAULT NULL             COMMENT '外部工单ID',
  `reason_text_id`    BIGINT UNSIGNED  DEFAULT NULL             COMMENT '审批原因/拒绝理由（关联 sys_texts.id）',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `decided_at`        DATETIME         DEFAULT NULL             COMMENT '审批决定时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_event_id` (`event_id`),
  KEY `idx_submitter_id` (`submitter_id`),
  KEY `idx_decider_id` (`decider_id`),
  KEY `idx_approval_status` (`approval_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='审批表（只追加）';

-- 事件用户在线状态表
CREATE TABLE IF NOT EXISTS `event_user_presence` (
  `id`            BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `event_id`      BIGINT UNSIGNED  NOT NULL                 COMMENT '事件ID',
  `user_id`       BIGINT UNSIGNED  NOT NULL                 COMMENT '用户ID',
  `user_name`     VARCHAR(64)      NOT NULL                 COMMENT '用户名（冗余，避免JOIN）',
  `last_seen_at`  DATETIME         NOT NULL                 COMMENT '最后心跳时间',
  `created_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_event_user` (`event_id`, `user_id`),
  KEY `idx_last_seen` (`last_seen_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='事件用户在线状态表';

-- 事件消息 @ 提醒表
CREATE TABLE IF NOT EXISTS `event_message_mentions` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `event_id`          BIGINT UNSIGNED  NOT NULL                 COMMENT '事件ID',
  `message_id`        BIGINT UNSIGNED  NOT NULL                 COMMENT '消息ID（关联 event_messages.id）',
  `mentioned_user`    VARCHAR(64)      NOT NULL                 COMMENT '被 @ 的用户名（与 sys_users.username 一致）',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_message_user` (`message_id`, `mentioned_user`),
  KEY `idx_event_user` (`event_id`, `mentioned_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='事件消息@提醒表';

-- 事件消息已读位点表
CREATE TABLE IF NOT EXISTS `event_message_reads` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `event_id`          BIGINT UNSIGNED  NOT NULL                 COMMENT '事件ID',
  `user_name`         VARCHAR(64)      NOT NULL                 COMMENT '用户名',
  `last_read_msg_id`  BIGINT UNSIGNED  NOT NULL DEFAULT 0       COMMENT '最后已读消息ID',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_event_user` (`event_id`, `user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='事件消息已读位点表';


-- ============================================================
-- 三、中间件与值班
-- ============================================================

-- 中间件配置表
CREATE TABLE IF NOT EXISTS `sop_middleware` (
  `id`            BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `app_name`      VARCHAR(128)     NOT NULL                 COMMENT '应用名称',
  `app_desc`      VARCHAR(254)     NOT NULL                 COMMENT '应用描述',
  `primary_post`  VARCHAR(64)      NOT NULL                 COMMENT '主岗',
  `backup_post`   VARCHAR(64)      NOT NULL                 COMMENT '备岗',
  `created_by`    VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`    VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='中间件配置表';

-- 值班信息表
CREATE TABLE IF NOT EXISTS `sop_duty_schedules` (
  `id`              BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `schedule_date`   VARCHAR(10)      NOT NULL                 COMMENT '值班日期',
  `department`      VARCHAR(128)     NOT NULL                 COMMENT '部门',
  `position_name`   VARCHAR(128)     NOT NULL                 COMMENT '岗位名称',
  `primary_user`   VARCHAR(64)      NOT NULL                 COMMENT '主岗用户名',
  `backup_user`    VARCHAR(64)      NOT NULL                 COMMENT '备岗用户名',
  `created_by`      VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`      VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='值班信息表';


-- ============================================================
-- 四、工具注册表
-- ============================================================

-- 工具注册表（替代历史迁移中的 sop_tools）
CREATE TABLE IF NOT EXISTS `tools` (
  `id`                   BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `tool_name`            VARCHAR(128)     NOT NULL                 COMMENT '工具名称（唯一标识）',
  `display_name`         VARCHAR(128)     NOT NULL                 COMMENT '显示名称',
  `description`          VARCHAR(512)     DEFAULT NULL             COMMENT '工具描述',
  `tool_category`        VARCHAR(64)      NOT NULL DEFAULT 'general' COMMENT '工具分类: filesystem/system/network/redis/kafka',
  `implementation_class` VARCHAR(256)     NOT NULL                 COMMENT '实现类（包路径，如 tools/filesystem）',
  `input_schema`         JSON             DEFAULT NULL             COMMENT '输入参数 Schema',
  `output_schema`        JSON             DEFAULT NULL             COMMENT '输出参数 Schema',
  `is_enabled`           TINYINT(1)       NOT NULL DEFAULT 1       COMMENT '是否启用',
  `created_by`           VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`           VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`           DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`           DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tool_name` (`tool_name`),
  KEY `idx_impl_class` (`implementation_class`),
  KEY `idx_category` (`tool_category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工具注册表';


-- ============================================================
-- 五、SOP 编排
-- ============================================================

-- SOP 定义表
CREATE TABLE IF NOT EXISTS `sop_definitions` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `sop_name`          VARCHAR(128)     NOT NULL                 COMMENT 'SOP 名称，如"拉起Redis服务"',
  `sop_code`          VARCHAR(64)      NOT NULL DEFAULT ''      COMMENT 'SOP 编码，如 SOP-1-MW-COM1',
  `sop_category`      VARCHAR(64)      NOT NULL                 COMMENT '分类，如 redis/kafka/disk/network',
  `sop_desc`          VARCHAR(512)     DEFAULT NULL             COMMENT 'SOP 描述',
  `compose_type`      VARCHAR(16)      NOT NULL DEFAULT 'workflow' COMMENT '编排类型: chain/graph/workflow',
  `input_schema`      JSON             DEFAULT NULL             COMMENT '输入参数 Schema（JSON Schema 格式）',
  `output_schema`     JSON             DEFAULT NULL             COMMENT '输出参数 Schema',
  `status`            VARCHAR(16)      NOT NULL DEFAULT 'draft' COMMENT '状态: draft/published/deprecated',
  `version`           INT              NOT NULL DEFAULT 1       COMMENT '版本号',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sop_name_version` (`sop_name`, `version`),
  UNIQUE KEY `uk_sop_code` (`sop_code`),
  KEY `idx_category` (`sop_category`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='SOP定义表';

-- SOP 节点表（步骤）
CREATE TABLE IF NOT EXISTS `sop_nodes` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `sop_id`            BIGINT UNSIGNED  NOT NULL                 COMMENT '所属 SOP ID',
  `node_name`         VARCHAR(64)      NOT NULL                 COMMENT '节点名称，如"检查Redis状态"',
  `node_key`          VARCHAR(64)      NOT NULL                 COMMENT '节点唯一标识，如"check_status"',
  `step_order`        INT              NOT NULL DEFAULT 0       COMMENT '展示排序',
  `node_type`         VARCHAR(32)      NOT NULL                 COMMENT '节点类型: tool/llm/prompt/lambda/condition/sub_sop',
  `tool_code`         VARCHAR(64)      DEFAULT NULL             COMMENT '工具编码（node_type=tool 时使用，关联工具表）',
  `model_code`        VARCHAR(64)      DEFAULT NULL             COMMENT '模型编码（node_type=llm 时使用）',
  `prompt_text_id`    BIGINT UNSIGNED  DEFAULT NULL             COMMENT '提示词文本ID（node_type=prompt 时使用）',
  `sub_sop_id`        BIGINT UNSIGNED  DEFAULT NULL             COMMENT '子SOP ID（node_type=sub_sop 时使用）',
  `config`            JSON             DEFAULT NULL             COMMENT '节点配置，如工具参数、LLM参数等',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sop_node` (`sop_id`, `node_key`),
  KEY `idx_step_order` (`sop_id`, `step_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='SOP节点表';

-- SOP 边表（控制流 + 数据流）
CREATE TABLE IF NOT EXISTS `sop_edges` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `sop_id`            BIGINT UNSIGNED  NOT NULL                 COMMENT '所属 SOP ID',
  `from_node`         VARCHAR(64)      NOT NULL                 COMMENT '源节点 key（START 表示开始）',
  `to_node`           VARCHAR(64)      NOT NULL                 COMMENT '目标节点 key（END 表示结束）',
  `edge_type`         VARCHAR(16)      NOT NULL DEFAULT 'both'  COMMENT '边类型: control(仅控制流)/data(仅数据流)/both(同时承载)',
  `condition`         JSON             DEFAULT NULL             COMMENT '分支条件（node_type=branch 时使用）',
  `field_mappings`    JSON             DEFAULT NULL             COMMENT '字段映射: [{"from_field":"Output.Content","to_field":"Input.Query"}]',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_sop_from` (`sop_id`, `from_node`),
  KEY `idx_sop_to` (`sop_id`, `to_node`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='SOP边表';

-- SOP 执行记录表
CREATE TABLE IF NOT EXISTS `sop_executions` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `sop_id`            BIGINT UNSIGNED  NOT NULL                 COMMENT 'SOP ID',
  `sop_version`       INT              NOT NULL                 COMMENT '执行时的 SOP 版本号',
  `event_id`          BIGINT UNSIGNED  DEFAULT NULL             COMMENT '关联事件 ID',
  `trigger_by`        VARCHAR(64)      NOT NULL                 COMMENT '触发人',
  `input_data`        JSON             DEFAULT NULL             COMMENT '输入参数',
  `output_data`       JSON             DEFAULT NULL             COMMENT '输出结果',
  `status`            VARCHAR(16)      NOT NULL DEFAULT 'running' COMMENT '状态: running/success/failed/cancelled',
  `started_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '开始时间',
  `finished_at`       DATETIME         DEFAULT NULL             COMMENT '结束时间',
  `error_message`     VARCHAR(1024)    DEFAULT NULL             COMMENT '错误信息',
  PRIMARY KEY (`id`),
  KEY `idx_sop_id` (`sop_id`),
  KEY `idx_event_id` (`event_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='SOP执行记录表';


-- ============================================================
-- 六、MCP 管理
-- ============================================================

-- MCP 配置表
CREATE TABLE IF NOT EXISTS `mcp_configs` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `mcp_name`          VARCHAR(128)     NOT NULL                 COMMENT 'MCP 名称',
  `mcp_code`          VARCHAR(64)      NOT NULL                 COMMENT 'MCP 编码',
  `mcp_type`          VARCHAR(16)      NOT NULL DEFAULT 'sse'   COMMENT '类型: sse/stdio/streamable',
  `base_url`          VARCHAR(512)     NOT NULL                 COMMENT 'MCP 服务地址',
  `api_key`           VARCHAR(256)     DEFAULT NULL             COMMENT 'API Key（按需）',
  `headers`           JSON             DEFAULT NULL             COMMENT '自定义请求头',
  `timeout_ms`        INT              NOT NULL DEFAULT 30000   COMMENT '超时时间（毫秒）',
  `description`       VARCHAR(512)     DEFAULT NULL             COMMENT '描述',
  `is_enabled`        TINYINT(1)       NOT NULL DEFAULT 1       COMMENT '是否启用',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='MCP配置表';

-- MCP 工具表（从 MCP 服务发现的工具）
CREATE TABLE IF NOT EXISTS `mcp_tools` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `mcp_id`            BIGINT UNSIGNED  NOT NULL                 COMMENT '所属 MCP ID',
  `tool_name`         VARCHAR(128)     NOT NULL                 COMMENT '工具名称',
  `tool_desc`         VARCHAR(1024)    DEFAULT NULL             COMMENT '工具描述（可人工编辑）',
  `input_schema`      JSON             DEFAULT NULL             COMMENT '输入参数 Schema',
  `output_desc`       VARCHAR(512)     DEFAULT NULL             COMMENT '输出描述（可人工编辑）',
  `is_enabled`        TINYINT(1)       NOT NULL DEFAULT 1       COMMENT '是否启用',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mcp_tool` (`mcp_id`, `tool_name`),
  KEY `idx_mcp_id` (`mcp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='MCP工具表';


-- ============================================================
-- 七、技能管理
-- ============================================================

-- 技能表
CREATE TABLE IF NOT EXISTS `skills` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `skill_name`        VARCHAR(128)     NOT NULL                 COMMENT '技能名称',
  `skill_code`        VARCHAR(64)      NOT NULL                 COMMENT '技能编码',
  `description`       VARCHAR(512)     DEFAULT NULL             COMMENT '技能描述',
  `version`           VARCHAR(32)      DEFAULT NULL             COMMENT '版本号',
  `file_path`         VARCHAR(254)     NOT NULL                 COMMENT '技能文件相对路径',
  `is_enabled`        TINYINT(1)       NOT NULL DEFAULT 1       COMMENT '是否启用',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_skill_code` (`skill_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='技能表';

-- 技能文件索引表
CREATE TABLE IF NOT EXISTS `skill_files` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `skill_id`          BIGINT UNSIGNED  NOT NULL                 COMMENT '所属技能ID',
  `file_name`         VARCHAR(254)     NOT NULL                 COMMENT '文件名',
  `file_path`         VARCHAR(254)     NOT NULL                 COMMENT '文件相对路径（相对于技能根目录）',
  `file_type`         VARCHAR(16)      NOT NULL DEFAULT 'file'  COMMENT '类型: file/dir',
  `parent_path`       VARCHAR(254)     DEFAULT ''               COMMENT '父目录路径',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_skill_id` (`skill_id`),
  KEY `idx_parent_path` (`skill_id`, `parent_path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='技能文件索引表';


-- ============================================================
-- 八、中间件台账与IDC验收
-- ============================================================
-- 说明: 本模块所有表前缀统一为 ruok_。
--       台账为权威源，通过 MCP 采集生成，反向同步/纠正 CMDB。
--       验收任务通过调用已有 MCP 工具执行检查，DAG 编排用关系表存储。

-- 8.1 IDC台账
CREATE TABLE IF NOT EXISTS `ruok_idcs` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `env_code`          VARCHAR(64)      NOT NULL                 COMMENT '环境(数据字典)',
  `idc_code`          VARCHAR(64)      NOT NULL                 COMMENT 'IDC编号',
  `idc_name`          VARCHAR(128)     NOT NULL                 COMMENT 'IDC名称',
  `is_xinchuang`      VARCHAR(5)       NOT NULL DEFAULT '否'      COMMENT '是否信创',
  `idc_status`        VARCHAR(32)      NOT NULL DEFAULT '新建'   COMMENT 'IDC状态(数据字典): new新建/verify验证/cutover切流/production投产/offline下线',
  `idc_remark`        VARCHAR(254)     DEFAULT NULL             COMMENT '备注',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_idc_code` (`idc_code`),
  KEY `idx_idc_status` (`idc_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='IDC台账表';

-- 8.2 服务台账组件树（component/role/cluster/idc 自关联树）
CREATE TABLE IF NOT EXISTS `ruok_component_tree` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `parent_id`   BIGINT UNSIGNED NOT NULL DEFAULT 0        COMMENT '父节点ID(0为根)',
  `node_type`   VARCHAR(32)     NOT NULL                  COMMENT '节点类型(数据字典): component组件/role二级分类/cluster集群/idc机房',
  `node_code`   VARCHAR(64)     NOT NULL                  COMMENT '节点编码(全树唯一)',
  `node_name`   VARCHAR(128)    NOT NULL                  COMMENT '节点名称',
  `node_idx`    INT             NOT NULL DEFAULT 0        COMMENT '同级排序序号',
  `node_remark` VARCHAR(254)    DEFAULT NULL              COMMENT '备注',
  `access_method`   VARCHAR(64)  DEFAULT NULL             COMMENT '访问方式',
  `access_port`     INT          DEFAULT NULL             COMMENT '访问端口',
  `access_password` VARCHAR(254) DEFAULT NULL             COMMENT '访问密码',
  `created_by`  VARCHAR(64)     NOT NULL                  COMMENT '创建人',
  `updated_by`  VARCHAR(64)     DEFAULT NULL              COMMENT '修改人',
  `created_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_node_code` (`node_code`),
  KEY `idx_parent_idx` (`parent_id`, `node_idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='服务台账组件树表';

-- 8.3 主机台账（集群节点）
CREATE TABLE IF NOT EXISTS `ruok_hosts` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `env_code`          VARCHAR(64)      NOT NULL                 COMMENT '环境(数据字典)',
  `idc_code`          VARCHAR(64)      NOT NULL                 COMMENT 'IDC编号',
  `cluster_code`      VARCHAR(64)     NOT NULL                 COMMENT '集群编码',
  `component_tree_id` BIGINT UNSIGNED DEFAULT NULL             COMMENT '组件树节点ID(机房)',
  `host_ip`           VARCHAR(64)      NOT NULL                 COMMENT '主机IP',
  `leaf_code`           VARCHAR(128)      NOT NULL                 COMMENT 'Leaf',
  `rack_code`           VARCHAR(128)      NOT NULL                 COMMENT '机柜',
  `cpu_cores`         INT              DEFAULT NULL             COMMENT 'CPU核心数',
  `memory_gb`         INT              DEFAULT NULL             COMMENT '内存大小(GB)',
  `disk_gb`           INT              DEFAULT NULL             COMMENT '磁盘大小(GB)',
  `cpu_model`         VARCHAR(128)     DEFAULT NULL             COMMENT 'CPU型号',
  `os_name`           VARCHAR(128)     DEFAULT NULL             COMMENT '操作系统(如 CentOS 7.9)',
  `ssh_port`          INT              DEFAULT NULL             COMMENT 'SSH端口号',
  `ssh_user`          VARCHAR(64)      DEFAULT NULL             COMMENT 'SSH用户',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cluster_code` (`cluster_code`, `host_ip`),
  KEY `idx_cluster_code` (`cluster_code`),
  KEY `idx_component_tree_id` (`component_tree_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='主机台账表(集群节点)';

-- 8.4 域名台账
CREATE TABLE IF NOT EXISTS `ruok_domains` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `env_code`          VARCHAR(64)      NOT NULL                 COMMENT '环境(数据字典): dev开发VDI/prod生产/test测试',
  `idc_code`          VARCHAR(64)      NOT NULL                 COMMENT 'IDC编号',
  `domain_type`       VARCHAR(32)      NOT NULL                 COMMENT '类型(数据字典): global全局/local本地',
  `domain_name`       VARCHAR(254)     NOT NULL                 COMMENT '域名',
  `target_host`       VARCHAR(254)     DEFAULT NULL             COMMENT '目标主机',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_domain_env` (`domain_name`, `env_code`),
  KEY `idx_idc_code` (`idc_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='域名台账表';

-- 8.5 CMDB 同步/对账批次
CREATE TABLE IF NOT EXISTS `ruok_cmdb_sync_diff` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `batch_code`        VARCHAR(64)      NOT NULL                 COMMENT '同步批次号，格式20260919-211901',
  `env_code`          VARCHAR(64)      NOT NULL                 COMMENT '环境(数据字典)',
  `idc_code`          VARCHAR(64)      NOT NULL                 COMMENT 'IDC编号',
  `diff_type`          VARCHAR(10)      NOT NULL                 COMMENT '本地多｜CMDB多｜不一致',
  `cluster_code`       VARCHAR(64)      DEFAULT NULL             COMMENT '集群编码',
  `host_ip`           VARCHAR(64)      DEFAULT NULL             COMMENT '主机IP',
  `diff_status`        VARCHAR(32)      NOT NULL DEFAULT 'running' COMMENT '状态: running/success/failed',
  `sync_remark`        VARCHAR(254)     DEFAULT NULL             COMMENT '备注',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_diff_status` (`diff_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='CMDB同步差异';

-- 8.6 验收标准树（分类 + 验收项，parent_id 自关联，叶子为验收项）
CREATE TABLE IF NOT EXISTS `ruok_acceptance_standards` (
  `id`                    BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `parent_id`             BIGINT UNSIGNED  NOT NULL DEFAULT 0       COMMENT '父节点ID(0为根分类)',
  `standard_code`         VARCHAR(64)      NOT NULL                 COMMENT '编码',
  `standard_name`         VARCHAR(128)     NOT NULL                 COMMENT '名称',
  `node_type`             VARCHAR(16)      NOT NULL DEFAULT 'item'  COMMENT '节点类型: category分类/item验收项',
  `collect_type`          VARCHAR(64)      DEFAULT NULL             COMMENT '采集类型(验收项): cmdb/ssh/prometheus/port/process/middleware',
  `collect_method`        VARCHAR(128)     DEFAULT NULL             COMMENT '采集方式(验收项): MCP工具名',
  `collect_params_text_id` BIGINT UNSIGNED DEFAULT NULL             COMMENT '采集参数(验收项, 关联 sys_texts.id)',
  `judge_criteria_text_id` BIGINT UNSIGNED DEFAULT NULL             COMMENT '判定标准(验收项, 关联 sys_texts.id)',
  `order_idx`             INT              NOT NULL DEFAULT 0       COMMENT '同级排序序号',
  `standard_status`       VARCHAR(32)      NOT NULL DEFAULT 'enabled' COMMENT '状态: enabled/disabled',
  `created_by`            VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`            VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`            DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`            DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_standard_code` (`standard_code`),
  KEY `idx_parent_order` (`parent_id`, `order_idx`),
  KEY `idx_node_type` (`node_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='验收标准树表';

-- 8.7 验收计划（DAG 编排模板）
CREATE TABLE IF NOT EXISTS `ruok_acceptance_plans` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `plan_code`         VARCHAR(64)      NOT NULL                 COMMENT '计划编码',
  `plan_name`         VARCHAR(128)     NOT NULL                 COMMENT '计划名称',
  `plan_status`       VARCHAR(32)      NOT NULL DEFAULT 'draft' COMMENT '状态: draft/published/deprecated',
  `plan_remark`       VARCHAR(254)     DEFAULT NULL             COMMENT '备注',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_plan_code` (`plan_code`),
  KEY `idx_plan_status` (`plan_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='验收计划表';

-- 8.8 验收计划项（DAG 节点，引用验收标准叶子项）
CREATE TABLE IF NOT EXISTS `ruok_acceptance_plan_items` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `parent_id`             BIGINT UNSIGNED  NOT NULL DEFAULT 0       COMMENT '父节点ID(0为根分类)',
  `plan_id`           BIGINT UNSIGNED  NOT NULL                 COMMENT '所属计划ID',
  `standard_id`       BIGINT UNSIGNED  NOT NULL                 COMMENT '验收标准项ID(叶子验收项)',
  `standard_code`         VARCHAR(64)      NOT NULL                 COMMENT '标准编码',
  `standard_name`         VARCHAR(128)     NOT NULL                 COMMENT '标准名称',
  `node_type`             VARCHAR(16)      NOT NULL DEFAULT 'item'  COMMENT '节点类型: category分类/item验收项',
  `collect_type`          VARCHAR(64)      DEFAULT NULL             COMMENT '采集类型(验收项): cmdb/ssh/prometheus/port/process/middleware',
  `collect_method`        VARCHAR(128)     DEFAULT NULL             COMMENT '采集方式(验收项): MCP工具名',
  `collect_params_text_id` BIGINT UNSIGNED DEFAULT NULL             COMMENT '采集参数(验收项, 关联 sys_texts.id)',
  `collect_result_text_id` BIGINT UNSIGNED DEFAULT NULL             COMMENT '采集结果(关联 sys_texts.id)',
  `judge_criteria_text_id` BIGINT UNSIGNED DEFAULT NULL             COMMENT '判定标准(验收项, 关联 sys_texts.id)',
  `order_idx`             INT              NOT NULL DEFAULT 0       COMMENT '同级排序序号',
  `item_status`       VARCHAR(32)      NOT NULL DEFAULT '新建' COMMENT '状态: 新建｜已采集',
  `item_result`       VARCHAR(32)      NOT NULL DEFAULT '未核查' COMMENT '结果: 通过｜未通过',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_plan_item` (`plan_id`, `standard_id`),
  KEY `idx_plan_id` (`plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='验收计划项表';
