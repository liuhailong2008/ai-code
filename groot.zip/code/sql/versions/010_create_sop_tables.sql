-- SOP 编排相关表
-- 创建日期: 2026-06-23
-- 说明: 存储SOP定义、节点和边，支持 Graph/Workflow/Chain 三种编排

-- ============================================================
-- 1. SOP 定义表
-- ============================================================
CREATE TABLE IF NOT EXISTS `sop_definitions` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `sop_name`          VARCHAR(128)     NOT NULL                 COMMENT 'SOP 名称，如"拉起Redis服务"',
  `sop_category`      VARCHAR(64)      NOT NULL                 COMMENT '分类，如 redis/kafka/disk/network',
  `sop_desc`          VARCHAR(512)     DEFAULT NULL             COMMENT 'SOP 描述',
  `compose_type`      VARCHAR(16)      NOT NULL DEFAULT 'workflow' COMMENT '编排类型: chain/graph/workflow',
  `input_schema`      JSON             DEFAULT NULL             COMMENT '输入参数 Schema（JSON Schema 格式）',
  `output_schema`     JSON             DEFAULT NULL             COMMENT '输出参数 Schema',
  `status`            VARCHAR(16)      NOT NULL DEFAULT 'draft' COMMENT '状态: draft/published/deprecated',
  `version`           INT              NOT NULL DEFAULT 1       COMMENT '版本号',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sop_name_version` (`sop_name`, `version`),
  KEY `idx_category` (`sop_category`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='SOP定义表';

-- ============================================================
-- 2. SOP 节点表（步骤）
-- ============================================================
CREATE TABLE IF NOT EXISTS `sop_nodes` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `sop_id`            BIGINT UNSIGNED  NOT NULL                 COMMENT '所属 SOP ID',
  `node_name`         VARCHAR(64)      NOT NULL                 COMMENT '节点名称，如"检查Redis状态"',
  `node_key`          VARCHAR(64)      NOT NULL                 COMMENT '节点唯一标识，如"check_status"',
  `step_order`        INT              NOT NULL DEFAULT 0       COMMENT '展示排序',
  `node_type`         VARCHAR(32)      NOT NULL                 COMMENT '节点类型: tool/llm/prompt/lambda/condition/sub_sop',
  `tool_code`         VARCHAR(64)      DEFAULT NULL             COMMENT '工具编码（node_type=tool 时使用，关联工具表）',
  `model_code`        VARCHAR(64)      DEFAULT NULL             COMMENT '模型编码（node_type=llm 时使用）',
  `prompt_text_id`    BIGINT UNSIGNED  DEFAULT NULL             COMMENT '提示词文本ID（node_type=prompt 时使用）',
  `sub_sop_id`        BIGINT UNSIGNED  DEFAULT NULL             COMMENT '子SOP ID（node_type=sub_sop 时使用）',
  `config`            JSON             DEFAULT NULL             COMMENT '节点配置，如工具参数、LLM参数等',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sop_node` (`sop_id`, `node_key`),
  KEY `idx_step_order` (`sop_id`, `step_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='SOP节点表';

-- ============================================================
-- 3. SOP 边表（控制流 + 数据流）
-- ============================================================
CREATE TABLE IF NOT EXISTS `sop_edges` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `sop_id`            BIGINT UNSIGNED  NOT NULL                 COMMENT '所属 SOP ID',
  `from_node`         VARCHAR(64)      NOT NULL                 COMMENT '源节点 key（START 表示开始）',
  `to_node`           VARCHAR(64)      NOT NULL                 COMMENT '目标节点 key（END 表示结束）',
  `edge_type`         VARCHAR(16)      NOT NULL DEFAULT 'both'  COMMENT '边类型: control(仅控制流)/data(仅数据流)/both(同时承载)',
  `condition`         JSON             DEFAULT NULL             COMMENT '分支条件（node_type=branch 时使用）',
  `field_mappings`    JSON             DEFAULT NULL             COMMENT '字段映射: [{"from_field":"Output.Content","to_field":"Input.Query"}]',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_sop_from` (`sop_id`, `from_node`),
  KEY `idx_sop_to` (`sop_id`, `to_node`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='SOP边表';

-- ============================================================
-- 4. SOP 执行记录表
-- ============================================================
CREATE TABLE IF NOT EXISTS `sop_executions` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `sop_id`            BIGINT UNSIGNED  NOT NULL                 COMMENT 'SOP ID',
  `sop_version`       INT              NOT NULL                 COMMENT '执行时的 SOP 版本号',
  `event_id`          BIGINT UNSIGNED  DEFAULT NULL             COMMENT '关联事件 ID',
  `trigger_by`        VARCHAR(64)      NOT NULL                 COMMENT '触发人',
  `input_data`        JSON             DEFAULT NULL             COMMENT '输入参数',
  `output_data`       JSON             DEFAULT NULL             COMMENT '输出结果',
  `status`            VARCHAR(16)      NOT NULL DEFAULT 'running' COMMENT '状态: running/success/failed/cancelled',
  `started_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '开始时间',
  `finished_at`       DATETIME         DEFAULT NULL             COMMENT '结束时间',
  `error_message`     VARCHAR(1024)    DEFAULT NULL             COMMENT '错误信息',
  PRIMARY KEY (`id`),
  KEY `idx_sop_id` (`sop_id`),
  KEY `idx_event_id` (`event_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='SOP执行记录表';

-- ============================================================
-- 5. 工具注册表
-- ============================================================
CREATE TABLE IF NOT EXISTS `sop_tools` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `tool_code`         VARCHAR(64)      NOT NULL                 COMMENT '工具编码，如"check_redis_status"',
  `tool_name`         VARCHAR(128)     NOT NULL                 COMMENT '工具名称，如"检查Redis状态"',
  `tool_desc`         VARCHAR(512)     DEFAULT NULL             COMMENT '工具描述',
  `tool_category`     VARCHAR(64)      NOT NULL                 COMMENT '工具分类: redis/kafka/system/network',
  `input_schema`      JSON             DEFAULT NULL             COMMENT '输入参数 Schema',
  `output_schema`     JSON             DEFAULT NULL             COMMENT '输出参数 Schema',
  `handler_type`      VARCHAR(16)      NOT NULL DEFAULT 'script' COMMENT '执行方式: script/http/lambda',
  `handler_config`    JSON             DEFAULT NULL             COMMENT '执行配置，如脚本路径、HTTP地址等',
  `status`            VARCHAR(16)      NOT NULL DEFAULT 'enabled' COMMENT '状态: enabled/disabled',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tool_code` (`tool_code`),
  KEY `idx_category` (`tool_category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工具注册表';
