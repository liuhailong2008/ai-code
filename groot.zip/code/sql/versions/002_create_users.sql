-- 用户表
-- 创建日期: 2026-06-18
-- 说明: 存储系统用户信息

CREATE TABLE IF NOT EXISTS `sys_users` (
  `id`            BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `username`      VARCHAR(64)      NOT NULL                 COMMENT '用户名',
  `mobile`        VARCHAR(256)     NOT NULL DEFAULT ''      COMMENT '手机号码（AES 加密）',
  `password`      VARCHAR(256)     NOT NULL                 COMMENT '密码（bcrypt 加密）',
  `display_name`  VARCHAR(64)      NOT NULL                 COMMENT '显示名称',
  `role`          VARCHAR(32)      NOT NULL DEFAULT 'viewer' COMMENT '角色: admin/operator/viewer',
  `created_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';

-- 插入默认管理员
INSERT IGNORE INTO `sys_users` (`username`, `mobile`, `password`, `display_name`, `role`) VALUES
  ('liuhailong', 'EncryptedMobilePlaceholder', '$2a$10$jDSwSnFnodXfyd44AIbhzOka0Oz4HacBIsw51eHF.Fv6axSuCbCEa', '管理员', 'admin');
