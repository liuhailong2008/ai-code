-- 工具表合并：保留 tools 表，删除 sop_tools 表
-- 执行日期: 2026-06-24
-- 说明: tool_category 字段已在 012_create_tools_table.sql 中定义，此处不再重复 ADD COLUMN

-- 删除 sop_tools 表
DROP TABLE IF EXISTS `sop_tools`;
