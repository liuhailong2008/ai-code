-- 中间件服务台账与IDC验收相关表
-- 创建日期: 2026-09-17
-- 说明: 本模块所有表前缀统一为 ruok_。
--       台账为权威源，通过 MCP 采集生成，反向同步/纠正 CMDB。
--       验收任务通过调用已有 MCP 工具执行检查，DAG 编排用关系表存储。
-- 约束: 遵守项目数据库规范——不用关键字/保留字；字符字段长度 <= 254；
--       不用 TEXT/JSON/BLOB，大字段统一关联 sys_texts.id；
--       字段名不使用单个单词，统一加实体前缀（如 status -> idc_status）。

-- ============================================================
-- 一、台账域
-- ============================================================

-- 1. IDC台账
CREATE TABLE IF NOT EXISTS `ruok_idcs` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `env_code`          VARCHAR(64)      NOT NULL                 COMMENT '环境(数据字典)',
  `idc_code`          VARCHAR(64)      NOT NULL                 COMMENT 'IDC编号',
  `idc_name`          VARCHAR(128)     NOT NULL                 COMMENT 'IDC名称',
  `is_xinchuang`      VARCHAR(5)       NOT NULL DEFAULT '否'      COMMENT '是否信创',
  `idc_status`        VARCHAR(32)      NOT NULL DEFAULT '新建'   COMMENT 'IDC状态(数据字典): new新建/verify验证/cutover切流/production投产/offline下线',
  `idc_remark`        VARCHAR(254)     DEFAULT NULL             COMMENT '备注',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_idc_code` (`idc_code`),
  KEY `idx_idc_status` (`idc_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='IDC台账表';

-- 2. 组件集群台账
CREATE TABLE IF NOT EXISTS `ruok_clusters` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `env_code`          VARCHAR(64)      NOT NULL                 COMMENT '环境(数据字典)',
  `idc_code`          VARCHAR(64)      NOT NULL                 COMMENT 'IDC编号',
  `cluster_code`      VARCHAR(64)     NOT NULL                 COMMENT '集群编码',
  `component_type`    VARCHAR(64)      NOT NULL                 COMMENT '组件类型: BVS/CDS/GlusterFS/IAM/Kafka/MinIO/Nginx/NuJob/Paris/Pingmesh/Redis/RocketMQ/Schedule/Zookeeper/Ops',
  `cluster_name`      VARCHAR(128)     NOT NULL                 COMMENT '集群名称',
  `access_method`     VARCHAR(64)      DEFAULT NULL             COMMENT '访问方式',
  `access_port`       INT              DEFAULT NULL             COMMENT '端口',
  `access_password`    VARCHAR(254)     DEFAULT NULL             COMMENT '密码(可选, 加密存储)',
  `biz_owner`         VARCHAR(128)     DEFAULT NULL             COMMENT '业务方(数据字典)',
  `cluster_remark`    VARCHAR(254)     DEFAULT NULL             COMMENT '备注',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_idc_cluster` (`idc_code`, `component_type`, `cluster_code`),
  KEY `idx_idc_code` (`idc_code`),
  KEY `idx_component_type` (`component_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='组件集群台账表';

-- 3. 主机台账（集群节点）
CREATE TABLE IF NOT EXISTS `ruok_hosts` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `env_code`          VARCHAR(64)      NOT NULL                 COMMENT '环境(数据字典)',
  `idc_code`          VARCHAR(64)      NOT NULL                 COMMENT 'IDC编号',
  `cluster_code`      VARCHAR(64)     NOT NULL                 COMMENT '集群编码',
  `host_ip`           VARCHAR(64)      NOT NULL                 COMMENT '主机IP',
  `leaf_code`           VARCHAR(128)      NOT NULL                 COMMENT 'Leaf',
  `rack_code`           VARCHAR(128)      NOT NULL                 COMMENT '机柜',
  `cpu_cores`         INT              DEFAULT NULL             COMMENT 'CPU核心数',
  `memory_gb`         INT              DEFAULT NULL             COMMENT '内存大小(GB)',
  `disk_gb`           INT              DEFAULT NULL             COMMENT '磁盘大小(GB)',
  `cpu_model`         VARCHAR(128)     DEFAULT NULL             COMMENT 'CPU型号',
  `os_name`           VARCHAR(128)     DEFAULT NULL             COMMENT '操作系统(如 CentOS 7.9)',
  `ssh_port`          INT              DEFAULT NULL             COMMENT 'SSH端口号',
  `ssh_user`          VARCHAR(64)      DEFAULT NULL             COMMENT 'SSH用户',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_cluster_code` (`cluster_code`, `host_ip`),
  KEY `idx_cluster_code` (`cluster_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='主机台账表(集群节点)';

-- 4. 域名台账
CREATE TABLE IF NOT EXISTS `ruok_domains` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `env_code`          VARCHAR(64)      NOT NULL                 COMMENT '环境(数据字典): dev开发VDI/prod生产/test测试',
  `idc_code`          VARCHAR(64)      NOT NULL                 COMMENT 'IDC编号',
  `domain_type`       VARCHAR(32)      NOT NULL                 COMMENT '类型(数据字典): global全局/local本地',
  `domain_name`       VARCHAR(254)     NOT NULL                 COMMENT '域名',
  `target_host`       VARCHAR(254)     DEFAULT NULL             COMMENT '目标主机',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_domain_env` (`domain_name`, `env_code`),
  KEY `idx_idc_code` (`idc_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='域名台账表';


-- ============================================================
-- 二、CMDB 同步与对账域
-- ============================================================

-- 5. CMDB 同步/对账批次
CREATE TABLE IF NOT EXISTS `ruok_cmdb_sync_diff` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `batch_code`        VARCHAR(64)      NOT NULL                 COMMENT '同步批次号，格式20260919-211901',
  `env_code`          VARCHAR(64)      NOT NULL                 COMMENT '环境(数据字典)',
  `idc_code`          VARCHAR(64)      NOT NULL                 COMMENT 'IDC编号',
  `diff_type`          VARCHAR(10)      NOT NULL                 COMMENT '本地多｜CMDB多｜不一致',
  `host_ip`           VARCHAR(64)      NOT NULL                 COMMENT '主机IP',
  `diff_status`        VARCHAR(32)      NOT NULL DEFAULT 'running' COMMENT '状态: running/success/failed',
  `sync_remark`        VARCHAR(254)     DEFAULT NULL             COMMENT '备注', 
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_diff_status` (`diff_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='CMDB同步差异';


-- ============================================================
-- 三、验收标准域
-- ============================================================

-- 7. 验收标准树（分类 + 验收项，parent_id 自关联，叶子为验收项）
CREATE TABLE IF NOT EXISTS `ruok_acceptance_standards` (
  `id`                    BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `parent_id`             BIGINT UNSIGNED  NOT NULL DEFAULT 0       COMMENT '父节点ID(0为根分类)',
  `standard_code`         VARCHAR(64)      NOT NULL                 COMMENT '编码',
  `standard_name`         VARCHAR(128)     NOT NULL                 COMMENT '名称',
  `node_type`             VARCHAR(16)      NOT NULL DEFAULT 'item'  COMMENT '节点类型: category分类/item验收项',
  `collect_type`          VARCHAR(64)      DEFAULT NULL             COMMENT '采集类型(验收项): cmdb/ssh/prometheus/port/process/middleware',
  `collect_method`        VARCHAR(128)     DEFAULT NULL             COMMENT '采集方式(验收项): MCP工具名',
  `collect_params_text_id` BIGINT UNSIGNED DEFAULT NULL             COMMENT '采集参数(验收项, 关联 sys_texts.id)',
  `judge_criteria_text_id` BIGINT UNSIGNED DEFAULT NULL             COMMENT '判定标准(验收项, 关联 sys_texts.id)',
  `order_idx`             INT              NOT NULL DEFAULT 0       COMMENT '同级排序序号',
  `standard_status`       VARCHAR(32)      NOT NULL DEFAULT 'enabled' COMMENT '状态: enabled/disabled',
  `created_by`            VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`            VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`            DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`            DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_standard_code` (`standard_code`),
  KEY `idx_parent_order` (`parent_id`, `order_idx`),
  KEY `idx_node_type` (`node_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='验收标准树表';


-- ============================================================
-- 四、验收编排与执行域
-- ============================================================

-- 8. 验收计划（DAG 编排模板）
CREATE TABLE IF NOT EXISTS `ruok_acceptance_plans` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `plan_code`         VARCHAR(64)      NOT NULL                 COMMENT '计划编码',
  `plan_name`         VARCHAR(128)     NOT NULL                 COMMENT '计划名称',
  `plan_status`       VARCHAR(32)      NOT NULL DEFAULT 'draft' COMMENT '状态: draft/published/deprecated',
  `plan_remark`       VARCHAR(254)     DEFAULT NULL             COMMENT '备注',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_plan_code` (`plan_code`),
  KEY `idx_plan_status` (`plan_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='验收计划表';

-- 9. 验收计划项（DAG 节点，引用验收标准叶子项）
CREATE TABLE IF NOT EXISTS `ruok_acceptance_plan_items` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `parent_id`             BIGINT UNSIGNED  NOT NULL DEFAULT 0       COMMENT '父节点ID(0为根分类)',

  `plan_id`           BIGINT UNSIGNED  NOT NULL                 COMMENT '所属计划ID',
  `standard_id`       BIGINT UNSIGNED  NOT NULL                 COMMENT '验收标准项ID(叶子验收项)',

  `standard_code`         VARCHAR(64)      NOT NULL                 COMMENT '标准编码',
  `standard_name`         VARCHAR(128)     NOT NULL                 COMMENT '标准名称',
  `node_type`             VARCHAR(16)      NOT NULL DEFAULT 'item'  COMMENT '节点类型: category分类/item验收项',
  `collect_type`          VARCHAR(64)      DEFAULT NULL             COMMENT '采集类型(验收项): cmdb/ssh/prometheus/port/process/middleware',
  `collect_method`        VARCHAR(128)     DEFAULT NULL             COMMENT '采集方式(验收项): MCP工具名',
  `collect_params_text_id` BIGINT UNSIGNED DEFAULT NULL             COMMENT '采集参数(验收项, 关联 sys_texts.id)',
  `collect_result_text_id` BIGINT UNSIGNED DEFAULT NULL             COMMENT '采集结果(关联 sys_texts.id)',
  `judge_criteria_text_id` BIGINT UNSIGNED DEFAULT NULL             COMMENT '判定标准(验收项, 关联 sys_texts.id)',
  `order_idx`             INT              NOT NULL DEFAULT 0       COMMENT '同级排序序号',

  `item_status`       VARCHAR(32)      NOT NULL DEFAULT '新建' COMMENT '状态: 新建｜已采集｜',

  `item_result`       VARCHAR(32)      NOT NULL DEFAULT '未核查' COMMENT '结果: 通过｜未通过',

  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_plan_item` (`plan_id`, `standard_id`),
  KEY `idx_plan_id` (`plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='验收计划项表';
