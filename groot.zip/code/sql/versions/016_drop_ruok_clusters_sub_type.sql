-- 一次性迁移：移除 ruok_clusters 已存在的 sub_type 列（幂等迁移无法 DROP COLUMN，故此文件仅执行一次后删除）
ALTER TABLE `ruok_clusters` DROP COLUMN `sub_type`;
