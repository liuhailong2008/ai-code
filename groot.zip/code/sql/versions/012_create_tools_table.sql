-- 工具管理表
-- 创建日期: 2026-06-24

CREATE TABLE IF NOT EXISTS `tools` (
  `id`                   BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `tool_name`            VARCHAR(128)     NOT NULL                 COMMENT '工具名称（唯一标识）',
  `display_name`         VARCHAR(128)     NOT NULL                 COMMENT '显示名称',
  `description`          VARCHAR(512)     DEFAULT NULL             COMMENT '工具描述',
  `tool_category`        VARCHAR(64)      NOT NULL DEFAULT 'general' COMMENT '工具分类: filesystem/system/network/redis/kafka',
  `implementation_class` VARCHAR(256)     NOT NULL                 COMMENT '实现类（包路径，如 tools/filesystem）',
  `input_schema`         JSON             DEFAULT NULL             COMMENT '输入参数 Schema',
  `output_schema`        JSON             DEFAULT NULL             COMMENT '输出参数 Schema',
  `is_enabled`           TINYINT(1)       NOT NULL DEFAULT 1       COMMENT '是否启用',
  `created_by`           VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`           VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`           DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`           DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tool_name` (`tool_name`),
  KEY `idx_impl_class` (`implementation_class`),
  KEY `idx_category` (`tool_category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工具注册表';
