-- 技能管理相关表
-- 创建日期: 2026-06-24

-- ============================================================
-- 1. 技能表
-- ============================================================
CREATE TABLE IF NOT EXISTS `skills` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `skill_name`        VARCHAR(128)     NOT NULL                 COMMENT '技能名称',
  `skill_code`        VARCHAR(64)      NOT NULL                 COMMENT '技能编码',
  `description`       VARCHAR(512)     DEFAULT NULL             COMMENT '技能描述',
  `version`           VARCHAR(32)      DEFAULT NULL             COMMENT '版本号',
  `file_path`         VARCHAR(254)     NOT NULL                 COMMENT '技能文件相对路径',
  `is_enabled`        TINYINT(1)       NOT NULL DEFAULT 1       COMMENT '是否启用',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_skill_code` (`skill_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='技能表';

-- ============================================================
-- 2. 技能文件索引表
-- ============================================================
CREATE TABLE IF NOT EXISTS `skill_files` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `skill_id`          BIGINT UNSIGNED  NOT NULL                 COMMENT '所属技能ID',
  `file_name`         VARCHAR(254)     NOT NULL                 COMMENT '文件名',
  `file_path`         VARCHAR(254)     NOT NULL                 COMMENT '文件相对路径（相对于技能根目录）',
  `file_type`         VARCHAR(16)      NOT NULL DEFAULT 'file'  COMMENT '类型: file/dir',
  `parent_path`       VARCHAR(254)     DEFAULT ''               COMMENT '父目录路径',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_skill_id` (`skill_id`),
  KEY `idx_parent_path` (`skill_id`, `parent_path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='技能文件索引表';
