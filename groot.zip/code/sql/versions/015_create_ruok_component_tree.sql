-- 服务台账组件树
-- 创建日期: 2026-09-20
-- 说明: 单一自关联树，承载服务台账的组件层级：
--       component(组件类型) -> role(二级分类,可选) -> cluster(集群) -> idc(机房)。
--       树为层级与节点身份的唯一来源，cluster/idc 节点通过 node_code
--       分别关联 ruok_clusters.cluster_code / ruok_idcs.idc_code。
-- 约束: 遵守项目数据库规范——不用关键字/保留字；字符字段长度 <= 254；
--       不用 TEXT/JSON/BLOB；字段名统一加实体前缀。

CREATE TABLE IF NOT EXISTS `ruok_component_tree` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `parent_id`   BIGINT UNSIGNED NOT NULL DEFAULT 0        COMMENT '父节点ID(0为根)',
  `node_type`   VARCHAR(32)     NOT NULL                  COMMENT '节点类型(数据字典): component组件/role二级分类/cluster集群/idc机房',
  `node_code`   VARCHAR(64)     NOT NULL                  COMMENT '节点编码(全树唯一)',
  `node_name`   VARCHAR(128)    NOT NULL                  COMMENT '节点名称',
  `node_idx`    INT             NOT NULL DEFAULT 0        COMMENT '同级排序序号',
  `node_remark` VARCHAR(254)    DEFAULT NULL              COMMENT '备注',
  `created_by`  VARCHAR(64)     NOT NULL                  COMMENT '创建人',
  `updated_by`  VARCHAR(64)     DEFAULT NULL              COMMENT '修改人',
  `created_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_node_code` (`node_code`),
  KEY `idx_parent_idx` (`parent_id`, `node_idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='服务台账组件树表';
