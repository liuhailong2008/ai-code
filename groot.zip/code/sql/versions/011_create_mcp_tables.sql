-- MCP 管理相关表
-- 创建日期: 2026-06-24

-- ============================================================
-- 1. MCP 配置表
-- ============================================================
CREATE TABLE IF NOT EXISTS `mcp_configs` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `mcp_name`          VARCHAR(128)     NOT NULL                 COMMENT 'MCP 名称',
  `mcp_code`          VARCHAR(64)      NOT NULL                 COMMENT 'MCP 编码',
  `mcp_type`          VARCHAR(16)      NOT NULL DEFAULT 'sse'   COMMENT '类型: sse/stdio/streamable',
  `base_url`          VARCHAR(512)     NOT NULL                 COMMENT 'MCP 服务地址',
  `api_key`           VARCHAR(256)     DEFAULT NULL             COMMENT 'API Key（按需）',
  `headers`           JSON             DEFAULT NULL             COMMENT '自定义请求头',
  `timeout_ms`        INT              NOT NULL DEFAULT 30000   COMMENT '超时时间（毫秒）',
  `description`       VARCHAR(512)     DEFAULT NULL             COMMENT '描述',
  `is_enabled`        TINYINT(1)       NOT NULL DEFAULT 1       COMMENT '是否启用',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='MCP配置表';

-- ============================================================
-- 2. MCP 工具表（从 MCP 服务发现的工具）
-- ============================================================
CREATE TABLE IF NOT EXISTS `mcp_tools` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `mcp_id`            BIGINT UNSIGNED  NOT NULL                 COMMENT '所属 MCP ID',
  `tool_name`         VARCHAR(128)     NOT NULL                 COMMENT '工具名称',
  `tool_desc`         VARCHAR(1024)    DEFAULT NULL             COMMENT '工具描述（可人工编辑）',
  `input_schema`      JSON             DEFAULT NULL             COMMENT '输入参数 Schema',
  `output_desc`       VARCHAR(512)     DEFAULT NULL             COMMENT '输出描述（可人工编辑）',
  `is_enabled`        TINYINT(1)       NOT NULL DEFAULT 1       COMMENT '是否启用',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_mcp_tool` (`mcp_id`, `tool_name`),
  KEY `idx_mcp_id` (`mcp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='MCP工具表';
