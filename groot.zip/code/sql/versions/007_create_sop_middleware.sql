-- 中间件配置表
-- 创建日期: 2026-06-18
-- 说明: 存储中间件应用配置信息

CREATE TABLE IF NOT EXISTS `sop_middleware` (
  `id`            BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `app_name`      VARCHAR(128)     NOT NULL                 COMMENT '应用名称',
  `app_desc`      VARCHAR(254)     NOT NULL                 COMMENT '应用描述',
  `primary_post`  VARCHAR(64)      NOT NULL                 COMMENT '主岗',
  `backup_post`   VARCHAR(64)      NOT NULL                 COMMENT '备岗',
  `created_by`    VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`    VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='中间件配置表';
