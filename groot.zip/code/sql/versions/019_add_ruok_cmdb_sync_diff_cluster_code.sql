-- CMDB同步差异表：新增集群编码字段
-- 创建日期: 2026-09-24
-- 说明: 为 ruok_cmdb_sync_diff 在 host_ip 前增加 cluster_code，关联 ruok_clusters.cluster_code。
--       一次性迁移（非幂等），对已存在库执行一次后删除。
-- 约束: 遵守项目数据库规范——不使用外键，采用逻辑关联；字段长度 <= 254。

ALTER TABLE `ruok_cmdb_sync_diff`
  ADD COLUMN `cluster_code` VARCHAR(64) NOT NULL COMMENT '集群编码' AFTER `diff_type`;
