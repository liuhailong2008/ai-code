-- 服务台账主机表：关联组件树节点
-- 创建日期: 2026-09-20
-- 说明: 为 ruok_hosts 增加 component_tree_id，关联 ruok_component_tree.id（机房节点）。
--       一次性迁移（非幂等），对已存在库执行一次后删除。
-- 约束: 遵守项目数据库规范——不使用外键，采用逻辑关联；字段长度 <= 254。

ALTER TABLE `ruok_hosts`
  ADD COLUMN `component_tree_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '组件树节点ID(机房)',
  ADD KEY `idx_component_tree_id` (`component_tree_id`);
