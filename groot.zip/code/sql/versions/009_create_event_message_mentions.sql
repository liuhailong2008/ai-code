-- 事件消息 @ 提醒相关表
-- 创建日期: 2026-06-19
-- 说明:
--   1) event_message_mentions: 记录每条消息 @ 到的用户，便于后续查询/通知
--   2) event_message_reads:    记录每个用户在某事件下"已读"的最后一条消息ID，用于未读 @ 计数
--   3) 在 sys_users 中插入虚拟用户 groot，使其可被 @

-- ============================================================
-- 1. 事件消息 @ 提醒表
-- ============================================================
CREATE TABLE IF NOT EXISTS `event_message_mentions` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `event_id`          BIGINT UNSIGNED  NOT NULL                 COMMENT '事件ID',
  `message_id`        BIGINT UNSIGNED  NOT NULL                 COMMENT '消息ID（关联 event_messages.id）',
  `mentioned_user`    VARCHAR(64)      NOT NULL                 COMMENT '被 @ 的用户名（与 sys_users.username 一致）',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_message_user` (`message_id`, `mentioned_user`),
  KEY `idx_event_user` (`event_id`, `mentioned_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='事件消息@提醒表';

-- ============================================================
-- 2. 事件消息已读位点表
-- ============================================================
CREATE TABLE IF NOT EXISTS `event_message_reads` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `event_id`          BIGINT UNSIGNED  NOT NULL                 COMMENT '事件ID',
  `user_name`         VARCHAR(64)      NOT NULL                 COMMENT '用户名',
  `last_read_msg_id`  BIGINT UNSIGNED  NOT NULL DEFAULT 0       COMMENT '最后已读消息ID',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_event_user` (`event_id`, `user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='事件消息已读位点表';

-- ============================================================
-- 3. 虚拟用户 groot
--   role 复用 viewer；password 使用占位 bcrypt 串（不可登录）
-- ============================================================
INSERT IGNORE INTO `sys_users` (`username`, `mobile`, `password`, `display_name`, `role`) VALUES
  ('groot', 'EncryptedMobilePlaceholder', '!virtual!groot!cannot!login!', 'Groot 智能助手', 'viewer');
