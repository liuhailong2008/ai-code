-- 团队表
-- 创建日期: 2026-06-18
-- 说明: 存储团队基本信息和负责人信息

CREATE TABLE IF NOT EXISTS `sys_teams` (
  `id`            BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `code`          VARCHAR(64)      NOT NULL                 COMMENT '团队编码',
  `name`          VARCHAR(128)     NOT NULL                 COMMENT '团队名称',
  `description`   VARCHAR(254)                                      COMMENT '团队介绍',
  `wechat_id` VARCHAR(128)     DEFAULT NULL             COMMENT '企业微信群编码',
  `team_email` VARCHAR(128)     DEFAULT NULL             COMMENT '团队邮箱',
  `tech_leader`     VARCHAR(64)   DEFAULT   NULL                 COMMENT '专业负责人（员工账号）',
  `team_leader`     VARCHAR(64)    DEFAULT  NULL                 COMMENT '团队负责人（员工账号）',
  `created_by`     VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`     VARCHAR(64)      NULL                 COMMENT '修改人',
  `created_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='团队表';
