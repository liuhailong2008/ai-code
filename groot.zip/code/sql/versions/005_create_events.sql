-- 事件相关表
-- 创建日期: 2026-06-18
-- 说明: 事件中心核心表，包含事件、消息、UIBlock、参与者和审批
--       大字段统一存储到 sys_texts 表，通过 text_id 关联

-- ============================================================
-- 0. 大字段存储表（所有需要存储长文本的场景统一关联此表）
-- ============================================================
CREATE TABLE IF NOT EXISTS `sys_texts` (
  `id`              BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `text_content`    TEXT             NOT NULL                 COMMENT '文本内容',
  `created_at`      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='大字段存储表';

-- ============================================================
-- 1. 事件表
-- ============================================================
CREATE TABLE IF NOT EXISTS `event_records` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `team_id`           BIGINT UNSIGNED  NOT NULL                 COMMENT '所属团队ID',
  `event_title`       VARCHAR(254)     NOT NULL                 COMMENT '事件标题',
  `desc_text_id`      VARCHAR(254)  DEFAULT NULL             COMMENT '事件描述',
  `event_status`      VARCHAR(32)      NOT NULL DEFAULT 'open'  COMMENT '状态: open/in_progress/resolved/closed',
  `event_severity`    VARCHAR(32)      NOT NULL DEFAULT 'medium' COMMENT '严重程度: low/medium/high/critical',
  `event_category`    VARCHAR(64)      NOT NULL                 COMMENT '事件分类，如 消息队列/缓存/存储',
  `idc_name`          VARCHAR(64)      DEFAULT NULL             COMMENT '机房',
  `app_name`          VARCHAR(64)      DEFAULT NULL             COMMENT '中间件类型，如 Redis/Kafka/RocketMQ/MinIO/ZooKeeper',
  `cluster_name`      VARCHAR(128)     DEFAULT NULL             COMMENT '集群名称',
  `event_source`      VARCHAR(32)      NOT NULL DEFAULT 'manual' COMMENT '来源: manual/alert/inspect/ticket',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `uni_no`            VARCHAR(128)     DEFAULT NULL             COMMENT '工单号',
  `ext_ticket_id`     VARCHAR(128)     DEFAULT NULL             COMMENT '关联外部工单ID',
  `event_metadata`    VARCHAR(254)     DEFAULT NULL             COMMENT '扩展元数据',
  `opened_at`         DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '事件打开时间',
  `closed_at`         DATETIME         DEFAULT NULL             COMMENT '事件关闭时间',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_team_status_opened` (`team_id`, `event_status`, `opened_at`),
  KEY `idx_team_created` (`team_id`, `created_at`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='事件表';

-- ============================================================
-- 2. 事件消息表
-- ============================================================
CREATE TABLE IF NOT EXISTS `event_messages` (
  `id`                  BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `event_id`            BIGINT UNSIGNED  NOT NULL                 COMMENT '所属事件ID',
  `actor_id`            VARCHAR(64)      NOT NULL                 COMMENT '消息发送者ID',
  `msg_role`            VARCHAR(32)      NOT NULL DEFAULT 'user'  COMMENT '角色: user/agent/system',
  `content_text_id`     BIGINT UNSIGNED  NOT NULL                 COMMENT '消息内容（关联 sys_texts.id）',
  `tool_calls_text_id`  BIGINT UNSIGNED  DEFAULT NULL             COMMENT 'Agent工具调用记录（关联 sys_texts.id）',
  `parent_msg_id`       BIGINT UNSIGNED  DEFAULT NULL             COMMENT '父消息ID（支持话题分支）',
  `created_at`          DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_event_created` (`event_id`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='事件消息表（只追加）';

-- ============================================================
-- 3. 事件 UIBlock 表
-- ============================================================
CREATE TABLE IF NOT EXISTS `event_uiblocks` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `event_id`          BIGINT UNSIGNED  NOT NULL                 COMMENT '所属事件ID',
  `msg_id`            BIGINT UNSIGNED  NOT NULL                 COMMENT '关联消息ID',
  `block_type`        VARCHAR(64)      NOT NULL                 COMMENT 'UIBlock类型: dashboard/chart/table/log/approval_card/plan/markdown/code',
  `payload_text_id`   BIGINT UNSIGNED  NOT NULL                 COMMENT 'UIBlock内容载荷（关联 sys_texts.id）',
  `order_idx`         INT              NOT NULL DEFAULT 0       COMMENT '排序序号',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_event_msg` (`event_id`, `msg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='事件UIBlock表';

-- ============================================================
-- 4. 事件参与者表
-- ============================================================
CREATE TABLE IF NOT EXISTS `event_participants` (
  `id`              BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `event_id`        BIGINT UNSIGNED  NOT NULL                 COMMENT '事件ID',
  `user_id`         BIGINT UNSIGNED  NOT NULL                 COMMENT '用户ID',
  `user_name`       VARCHAR(64)      NOT NULL                 COMMENT '用户名（冗余，避免JOIN）',
  `user_avatar`     VARCHAR(254)     DEFAULT NULL             COMMENT '用户头像URL（冗余）',
  `participant_role` VARCHAR(32)     NOT NULL DEFAULT 'watcher' COMMENT '参与角色: owner/reviewer/approver/watcher',
  `joined_at`       DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '加入时间',
  `created_at`      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_event_user` (`event_id`, `user_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='事件参与者表';

-- ============================================================
-- 5. 审批表
-- ============================================================
CREATE TABLE IF NOT EXISTS `event_approvals` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `event_id`          BIGINT UNSIGNED  NOT NULL                 COMMENT '关联事件ID',
  `approval_type`     VARCHAR(32)      NOT NULL                 COMMENT '审批类型: internal_review(内部双人复核)/external_ticket(外部工单)',
  `tool_call_ref`     VARCHAR(254)     NOT NULL                 COMMENT '关联工具调用引用',
  `approval_status`   VARCHAR(32)      NOT NULL DEFAULT 'pending' COMMENT '状态: pending/approved/rejected/cancelled/expired',
  `submitter_id`      BIGINT UNSIGNED  NOT NULL                 COMMENT '提交人用户ID',
  `decider_id`        BIGINT UNSIGNED  DEFAULT NULL             COMMENT '审批人用户ID',
  `uni_no`     VARCHAR(128)     DEFAULT NULL             COMMENT '外部工单ID',
  `reason_text_id`    BIGINT UNSIGNED  DEFAULT NULL             COMMENT '审批原因/拒绝理由（关联 sys_texts.id）',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `decided_at`        DATETIME         DEFAULT NULL             COMMENT '审批决定时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_event_id` (`event_id`),
  KEY `idx_submitter_id` (`submitter_id`),
  KEY `idx_decider_id` (`decider_id`),
  KEY `idx_approval_status` (`approval_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='审批表（只追加）';
