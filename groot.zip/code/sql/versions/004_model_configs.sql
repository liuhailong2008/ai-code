-- 大模型管理表
-- 创建日期: 2026-06-18
-- 说明: 系统通过此表访问大模型。同一用途同时只激活一个模型，优先级控制故障转移顺序。
--       api_key 需 AES 加密存储，加密后不超过 254 字符（32位AES密钥）
-- purpose: chat(通用对话) / reasoning(推理) / embedding(向量化) / vision(视觉) / rerank(重排序)

CREATE TABLE IF NOT EXISTS `sys_models` (
  `id`              BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `code`            VARCHAR(128)     NOT NULL                 COMMENT '模型编码（API调用model参数），如 deepseek-chat',
  `name`            VARCHAR(128)     NOT NULL                 COMMENT '模型名称，如 DeepSeek-V4-Flash',
  `provider`        VARCHAR(64)      NOT NULL                 COMMENT '供应商编码：deepseek/volcengine/zhipu',
  `base_url`        VARCHAR(254)     NOT NULL                 COMMENT 'API地址，如 https://api.deepseek.com/v1',
  `api_key`         VARCHAR(254)     NOT NULL                 COMMENT 'API Key（AES加密存储）',
  `purpose`         VARCHAR(32)      NOT NULL                 COMMENT '用途：chat/reasoning/embedding/vision/rerank',
  `is_active`       TINYINT(1)       NOT NULL DEFAULT 0       COMMENT '是否激活（同一用途仅一个激活）',
  `is_enabled`      TINYINT(1)       NOT NULL DEFAULT 1       COMMENT '是否启用（关闭后不参与切换）',
  `priority`        INT              NOT NULL DEFAULT 0       COMMENT '故障转移优先级（0最高）',
  `context_window`  INT              NOT NULL DEFAULT 4096    COMMENT '上下文窗口（tokens）',
  `max_tokens`      INT              NOT NULL DEFAULT 4096    COMMENT '最大输出（tokens）',
  `supports_thinking` TINYINT(1)     NOT NULL DEFAULT 0       COMMENT '支持深度思考',
  `supports_vision`   TINYINT(1)     NOT NULL DEFAULT 0       COMMENT '支持视觉理解',
  `supports_tools`    TINYINT(1)     NOT NULL DEFAULT 0       COMMENT '支持函数调用',
  `supports_json`     TINYINT(1)     NOT NULL DEFAULT 0       COMMENT '支持JSON结构化输出',
  `temperature`     DECIMAL(3,2)     DEFAULT 0.70             COMMENT '默认温度参数',
  `top_p`           DECIMAL(3,2)     DEFAULT 1.00             COMMENT '默认top_p参数',
  `created_by`      VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`      VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`),
  KEY `idx_purpose_active` (`purpose`, `is_active`),
  KEY `idx_purpose_enabled_priority` (`purpose`, `is_enabled`, `priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='大模型配置表';

-- 预置模型数据
INSERT INTO `sys_models` (`code`, `name`, `provider`, `base_url`, `api_key`, `purpose`, `is_active`, `priority`, `context_window`, `max_tokens`, `supports_thinking`, `supports_vision`, `supports_tools`, `supports_json`, `temperature`, `created_by`) VALUES
-- chat 用途
('deepseek-v4-flash',      'DeepSeek-V4-Flash',      'deepseek',   'https://api.deepseek.com/v1',                     'sk-your-key-here',                 'chat',       1, 0, 128000,  8192, 1, 0, 1, 1, 0.70, 'system'),
('deepseek-v4-pro',        'DeepSeek-V4-Pro',        'deepseek',   'https://api.deepseek.com/v1',                     'sk-your-key-here',                 'chat',       0, 1, 128000,  8192, 1, 0, 1, 1, 0.70, 'system'),
('doubao-seed-1.6',        '豆包Seed-1.6',           'volcengine', 'https://ark.cn-beijing.volces.com/api/v3',        'your-key-here',                    'chat',       1, 0, 256000, 32768, 1, 1, 1, 1, 0.70, 'system'),
('doubao-seed-1.6-flash',  '豆包Seed-1.6-Flash',     'volcengine', 'https://ark.cn-beijing.volces.com/api/v3',        'your-key-here',                    'chat',       0, 1, 256000, 32768, 1, 1, 1, 1, 0.70, 'system'),
('glm-4-plus',             'GLM-4-Plus',             'zhipu',      'https://open.bigmodel.cn/api/paas/v4',            'your-key-here',                    'chat',       1, 0, 128000,  4096, 0, 0, 1, 1, 0.70, 'system'),
('glm-4-flash',            'GLM-4-Flash',            'zhipu',      'https://open.bigmodel.cn/api/paas/v4',            'your-key-here',                    'chat',       0, 1, 128000, 16384, 0, 0, 1, 1, 0.70, 'system'),

-- reasoning 用途
('deepseek-reasoner',      'DeepSeek-R1',            'deepseek',   'https://api.deepseek.com/v1',                     'sk-your-key-here',                 'reasoning',  1, 0, 128000, 65536, 1, 0, 0, 1, 0.70, 'system'),
('doubao-seed-1.6-thinking','豆包Seed-1.6-Thinking',  'volcengine', 'https://ark.cn-beijing.volces.com/api/v3',        'your-key-here',                    'reasoning',  1, 0, 256000, 65536, 1, 1, 1, 1, 0.70, 'system'),

-- embedding 用途
('doubao-embedding-large', '豆包Embedding-Large',    'volcengine', 'https://ark.cn-beijing.volces.com/api/v3',        'your-key-here',                    'embedding',  1, 0,   4096,  2048, 0, 0, 0, 0, 0.70, 'system');
