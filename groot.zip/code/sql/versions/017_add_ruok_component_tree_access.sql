-- 服务台账组件树：机房节点访问信息
-- 创建日期: 2026-09-20
-- 说明: 为 ruok_component_tree 增加访问方式/端口/密码三个字段，作为节点自身属性。
--       一次性迁移（非幂等），对已存在库执行一次后删除。
-- 约束: 遵守项目数据库规范——字符字段长度 <= 254。

ALTER TABLE `ruok_component_tree`
  ADD COLUMN `access_method`   VARCHAR(64)  DEFAULT NULL COMMENT '访问方式',
  ADD COLUMN `access_port`     INT          DEFAULT NULL COMMENT '访问端口',
  ADD COLUMN `access_password` VARCHAR(254) DEFAULT NULL COMMENT '访问密码';
