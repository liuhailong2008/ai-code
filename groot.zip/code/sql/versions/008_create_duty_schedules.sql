-- 值班信息表
-- 创建日期: 2026-06-18
-- 说明: 存储每日值班安排信息

CREATE TABLE IF NOT EXISTS `sop_duty_schedules` (
  `id`              BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `schedule_date`   VARCHAR(10)      NOT NULL                 COMMENT '值班日期',
  `department`      VARCHAR(128)     NOT NULL                 COMMENT '部门',
  `position_name`   VARCHAR(128)     NOT NULL                 COMMENT '岗位名称',
  `primary_user`   VARCHAR(64)      NOT NULL                 COMMENT '主岗用户名',
  `backup_user`    VARCHAR(64)      NOT NULL                 COMMENT '备岗用户名',
  `created_by`      VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`      VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='值班信息表';
