-- CMDB同步差异表：host_ip、cluster_code 调整为可空
-- 创建日期: 2026-09-24
-- 说明: 差异记录中主机IP与集群编码允许为空（如仅按批次/环境维度的差异记录）。
--       一次性迁移（非幂等），对已存在库执行一次后删除。
-- 约束: 遵守项目数据库规范——字段长度 <= 254。

ALTER TABLE `ruok_cmdb_sync_diff`
  MODIFY COLUMN `host_ip`      VARCHAR(64) DEFAULT NULL COMMENT '主机IP',
  MODIFY COLUMN `cluster_code` VARCHAR(64) DEFAULT NULL COMMENT '集群编码';
