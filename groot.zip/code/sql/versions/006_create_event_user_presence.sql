-- 事件用户在线状态表
-- 创建日期: 2026-06-18
-- 说明: 记录用户当前是否打开事件聊天窗口，用于在线状态展示

CREATE TABLE IF NOT EXISTS `event_user_presence` (
  `id`            BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `event_id`      BIGINT UNSIGNED  NOT NULL                 COMMENT '事件ID',
  `user_id`       BIGINT UNSIGNED  NOT NULL                 COMMENT '用户ID',
  `user_name`     VARCHAR(64)      NOT NULL                 COMMENT '用户名（冗余，避免JOIN）',
  `last_seen_at`  DATETIME         NOT NULL                 COMMENT '最后心跳时间',
  `created_at`    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_event_user` (`event_id`, `user_id`),
  KEY `idx_last_seen` (`last_seen_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='事件用户在线状态表';
