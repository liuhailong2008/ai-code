-- 一次性迁移：ruok_hosts 增加 component_tree_id 字段（执行后删除）
ALTER TABLE `ruok_hosts`
  ADD COLUMN `component_tree_id` BIGINT UNSIGNED DEFAULT NULL COMMENT '组件树节点ID(机房)',
  ADD KEY `idx_component_tree_id` (`component_tree_id`);
