package main

import (
	"fmt"
	"log"

	"github.com/gin-gonic/gin"
	"groot-backend/internal/config"
	"groot-backend/internal/db"
	"groot-backend/internal/handler"
	"groot-backend/internal/middleware"
	"groot-backend/internal/router"

	// 导入工具实现以触发 init() 注册
	_ "groot-backend/internal/tools/filesystem"
	_ "groot-backend/internal/tools/readfile"
	_ "groot-backend/internal/tools/writefile"
	_ "groot-backend/internal/tools/editfile"
	_ "groot-backend/internal/tools/globtool"
	_ "groot-backend/internal/tools/greptool"
	_ "groot-backend/internal/tools/execute"
)

func main() {
	cfg := config.Load()

	// 初始化数据库
	db.Init(cfg)
	defer db.Close()

	// 初始化 JWT
	middleware.InitJWT(cfg)

	// 初始化技能目录
	handler.InitSkillsDir(cfg)

	// 初始化 tools 表并扫描注册
	if err := handler.EnsureToolsTable("system"); err != nil {
		log.Printf("warn: ensure tools table: %v", err)
	}

	// 设置 Gin
	r := gin.Default()

	// CORS 中间件
	r.Use(func(c *gin.Context) {
		c.Header("Access-Control-Allow-Origin", "*")
		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Content-Type, Authorization")
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		c.Next()
	})

	// 注册路由
	router.Setup(r)

	addr := fmt.Sprintf(":%s", cfg.ServerPort)
	log.Printf("server starting on %s", addr)
	if err := r.Run(addr); err != nil {
		log.Fatalf("failed to start server: %v", err)
	}
}
