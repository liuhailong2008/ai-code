package main

import (
	"encoding/json"
	"net/http"
)

// Mock MCP server - responds to tools/list JSON-RPC requests

type RPCRequest struct {
	JSONRPC string          `json:"jsonrpc"`
	Method  string          `json:"method"`
	ID      int             `json:"id"`
}

type ToolInputSchema struct {
	Type       string              `json:"type"`
	Properties map[string]Property `json:"properties"`
	Required   []string            `json:"required"`
}

type Property struct {
	Type        string `json:"type"`
	Description string `json:"description"`
}

type Tool struct {
	Name        string           `json:"name"`
	Description string           `json:"description"`
	InputSchema ToolInputSchema  `json:"inputSchema"`
}

type ToolsResult struct {
	Tools []Tool `json:"tools"`
}

type RPCResponse struct {
	JSONRPC string       `json:"jsonrpc"`
	Result  *ToolsResult `json:"result,omitempty"`
	Error   *RPCError    `json:"error,omitempty"`
	ID      int          `json:"id"`
}

type RPCError struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

func main() {
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != "POST" {
			http.Error(w, "only POST", http.StatusMethodNotAllowed)
			return
		}

		var req RPCRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			respErr := RPCResponse{
				JSONRPC: "2.0",
				Error:   &RPCError{Code: -32700, Message: "Parse error"},
				ID:      0,
			}
			json.NewEncoder(w).Encode(respErr)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Headers", "*")

		if r.Method == "OPTIONS" {
			w.WriteHeader(http.StatusOK)
			return
		}

		if req.Method == "tools/list" {
			resp := RPCResponse{
				JSONRPC: "2.0",
				Result: &ToolsResult{
					Tools: []Tool{
						{
							Name:        "query_metrics",
							Description: "查询监控指标数据，支持 PromQL 查询",
							InputSchema: ToolInputSchema{
								Type: "object",
								Properties: map[string]Property{
									"query":    {Type: "string", Description: "PromQL 查询语句"},
									"time_range": {Type: "string", Description: "时间范围，如 5m/1h/1d"},
								},
								Required: []string{"query"},
							},
						},
						{
							Name:        "restart_service",
							Description: "重启指定的中间件服务实例",
							InputSchema: ToolInputSchema{
								Type: "object",
								Properties: map[string]Property{
									"service_name": {Type: "string", Description: "服务名称，如 redis/kafka/zookeeper"},
									"instance_id":  {Type: "string", Description: "实例 ID"},
									"force":        {Type: "boolean", Description: "是否强制重启"},
								},
								Required: []string{"service_name", "instance_id"},
							},
						},
						{
							Name:        "check_cluster_health",
							Description: "检查中间件集群健康状态",
							InputSchema: ToolInputSchema{
								Type: "object",
								Properties: map[string]Property{
									"cluster_name": {Type: "string", Description: "集群名称"},
								},
								Required: []string{"cluster_name"},
							},
						},
					},
				},
				ID: req.ID,
			}
			json.NewEncoder(w).Encode(resp)
			return
		}

		resp := RPCResponse{
			JSONRPC: "2.0",
			Error:   &RPCError{Code: -32601, Message: "Method not found: " + req.Method},
			ID:      req.ID,
		}
		json.NewEncoder(w).Encode(resp)
	})

	println("Mock MCP Server running on http://localhost:9091")
	println("Endpoint: POST / (JSON-RPC)")
	http.ListenAndServe(":9091", nil)
}
