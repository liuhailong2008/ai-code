package repo

import (
	"groot-backend/internal/db"
	"groot-backend/internal/model"
)

// --- MCP Configs ---

func ListMcpConfigs() ([]model.McpConfig, error) {
	rows, err := db.DB.Query(
		`SELECT id, mcp_name, mcp_code, mcp_type, base_url, api_key, headers,
		        timeout_ms, description, is_enabled, created_by, updated_by, created_at, updated_at
		 FROM mcp_configs ORDER BY id DESC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.McpConfig
	for rows.Next() {
		var m model.McpConfig
		if err := rows.Scan(&m.ID, &m.McpName, &m.McpCode, &m.McpType, &m.BaseURL,
			&m.ApiKey, &m.Headers, &m.TimeoutMs, &m.Description, &m.IsEnabled,
			&m.CreatedBy, &m.UpdatedBy, &m.CreatedAt, &m.UpdatedAt); err != nil {
			return nil, err
		}
		normalizeJSONNull(&m.Headers)
		list = append(list, m)
	}
	return list, nil
}

func GetMcpConfig(id int64) (*model.McpConfig, error) {
	var m model.McpConfig
	err := db.DB.QueryRow(
		`SELECT id, mcp_name, mcp_code, mcp_type, base_url, api_key, headers,
		        timeout_ms, description, is_enabled, created_by, updated_by, created_at, updated_at
		 FROM mcp_configs WHERE id = ?`, id).Scan(
		&m.ID, &m.McpName, &m.McpCode, &m.McpType, &m.BaseURL,
		&m.ApiKey, &m.Headers, &m.TimeoutMs, &m.Description, &m.IsEnabled,
		&m.CreatedBy, &m.UpdatedBy, &m.CreatedAt, &m.UpdatedAt)
	if err != nil {
		return nil, err
	}
	normalizeJSONNull(&m.Headers)
	return &m, nil
}

func CreateMcpConfig(req *model.CreateMcpRequest, createdBy string) (*model.McpConfig, error) {
	timeout := 30000
	if req.TimeoutMs != nil {
		timeout = *req.TimeoutMs
	}
	result, err := db.DB.Exec(
		`INSERT INTO mcp_configs (mcp_name, mcp_code, mcp_type, base_url, api_key, headers, timeout_ms, description, created_by)
		 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		req.McpName, req.McpCode, req.McpType, req.BaseURL, req.ApiKey, req.Headers, timeout, req.Description, createdBy)
	if err != nil {
		return nil, err
	}
	id, _ := result.LastInsertId()
	return GetMcpConfig(id)
}

func UpdateMcpConfig(id int64, req *model.UpdateMcpRequest, updatedBy string) (*model.McpConfig, error) {
	_, err := db.DB.Exec(
		`UPDATE mcp_configs SET
			mcp_name = COALESCE(NULLIF(?, ''), mcp_name),
			mcp_code = COALESCE(NULLIF(?, ''), mcp_code),
			mcp_type = COALESCE(NULLIF(?, ''), mcp_type),
			base_url = COALESCE(NULLIF(?, ''), base_url),
			api_key = COALESCE(NULLIF(?, ''), api_key),
			headers = COALESCE(NULLIF(?, ''), headers),
			timeout_ms = COALESCE(?, timeout_ms),
			description = COALESCE(NULLIF(?, ''), description),
			is_enabled = COALESCE(?, is_enabled),
			updated_by = ?
		 WHERE id = ?`,
		req.McpName, req.McpCode, req.McpType, req.BaseURL, req.ApiKey, req.Headers,
		req.TimeoutMs, req.Description, req.IsEnabled, updatedBy, id)
	if err != nil {
		return nil, err
	}
	return GetMcpConfig(id)
}

// --- MCP Tools ---

func ListMcpTools(mcpID int64) ([]model.McpTool, error) {
	rows, err := db.DB.Query(
		`SELECT id, mcp_id, tool_name, tool_desc, input_schema, output_desc, is_enabled, created_at, updated_at
		 FROM mcp_tools WHERE mcp_id = ? ORDER BY tool_name`, mcpID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.McpTool
	for rows.Next() {
		var t model.McpTool
		if err := rows.Scan(&t.ID, &t.McpID, &t.ToolName, &t.ToolDesc, &t.InputSchema, &t.OutputDesc, &t.IsEnabled, &t.CreatedAt, &t.UpdatedAt); err != nil {
			return nil, err
		}
		normalizeJSONNull(&t.InputSchema)
		list = append(list, t)
	}
	return list, nil
}

func UpdateMcpTool(id int64, req *model.UpdateMcpToolRequest) (*model.McpTool, error) {
	_, err := db.DB.Exec(
		`UPDATE mcp_tools SET tool_desc = COALESCE(NULLIF(?, ''), tool_desc), output_desc = COALESCE(NULLIF(?, ''), output_desc)
		 WHERE id = ?`,
		req.ToolDesc, req.OutputDesc, id)
	if err != nil {
		return nil, err
	}
	// fetch updated row
	var t model.McpTool
	err = db.DB.QueryRow(
		`SELECT id, mcp_id, tool_name, tool_desc, input_schema, output_desc, is_enabled, created_at, updated_at
		 FROM mcp_tools WHERE id = ?`, id).Scan(
		&t.ID, &t.McpID, &t.ToolName, &t.ToolDesc, &t.InputSchema, &t.OutputDesc, &t.IsEnabled, &t.CreatedAt, &t.UpdatedAt)
	if err != nil {
		return nil, err
	}
	normalizeJSONNull(&t.InputSchema)
	return &t, nil
}

func UpsertMcpTool(tool *model.McpTool) error {
	_, err := db.DB.Exec(
		`INSERT INTO mcp_tools (mcp_id, tool_name, tool_desc, input_schema)
		 VALUES (?, ?, ?, ?)
		 ON DUPLICATE KEY UPDATE tool_desc = VALUES(tool_desc), input_schema = VALUES(input_schema)`,
		tool.McpID, tool.ToolName, tool.ToolDesc, tool.InputSchema)
	return err
}
