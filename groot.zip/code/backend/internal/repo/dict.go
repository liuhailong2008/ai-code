package repo

import (
	"database/sql"

	"groot-backend/internal/db"
	"groot-backend/internal/model"
)

// ============================================================
// 数据字典
// ============================================================

func ListDicts() ([]model.SysDict, error) {
	rows, err := db.DB.Query(`SELECT id, parent_id, dict_key, dict_value, dict_sn, created_at, updated_at
		FROM sys_dict ORDER BY parent_id, dict_sn, id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.SysDict
	for rows.Next() {
		var d model.SysDict
		if err := rows.Scan(&d.ID, &d.ParentID, &d.DictKey, &d.DictValue, &d.DictSn, &d.CreatedAt, &d.UpdatedAt); err != nil {
			return nil, err
		}
		list = append(list, d)
	}
	if list == nil {
		list = []model.SysDict{}
	}
	return list, rows.Err()
}

func GetDict(id int64) (*model.SysDict, error) {
	var d model.SysDict
	err := db.DB.QueryRow(`SELECT id, parent_id, dict_key, dict_value, dict_sn, created_at, updated_at
		FROM sys_dict WHERE id = ?`, id).
		Scan(&d.ID, &d.ParentID, &d.DictKey, &d.DictValue, &d.DictSn, &d.CreatedAt, &d.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return &d, nil
}

func CreateDict(req *model.CreateDictRequest) (*model.SysDict, error) {
	result, err := db.DB.Exec(`INSERT INTO sys_dict (parent_id, dict_key, dict_value, dict_sn) VALUES (?, ?, ?, ?)`,
		req.ParentID, req.DictKey, req.DictValue, req.DictSn)
	if err != nil {
		return nil, err
	}
	id, _ := result.LastInsertId()
	return GetDict(id)
}

func UpdateDict(id int64, req *model.UpdateDictRequest) (*model.SysDict, error) {
	existing, err := GetDict(id)
	if err != nil || existing == nil {
		return nil, err
	}
	parentID := existing.ParentID
	dictKey := existing.DictKey
	dictValue := existing.DictValue
	dictSn := existing.DictSn
	if req.ParentID != nil {
		parentID = *req.ParentID
	}
	if req.DictKey != nil {
		dictKey = *req.DictKey
	}
	if req.DictValue != nil {
		dictValue = *req.DictValue
	}
	if req.DictSn != nil {
		dictSn = *req.DictSn
	}
	_, err = db.DB.Exec(`UPDATE sys_dict SET parent_id=?, dict_key=?, dict_value=?, dict_sn=? WHERE id=?`,
		parentID, dictKey, dictValue, dictSn, id)
	if err != nil {
		return nil, err
	}
	return GetDict(id)
}

func DeleteDict(id int64) error {
	return deleteByID("sys_dict", id)
}
