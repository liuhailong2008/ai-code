package repo

import (
	"database/sql"

	"groot-backend/internal/db"
	"groot-backend/internal/model"
)

// nullInt64ToPtr 将 sql.NullInt64 转换为 *int64（NULL -> nil）。
func nullInt64ToPtr(n sql.NullInt64) *int64 {
	if n.Valid {
		return &n.Int64
	}
	return nil
}

// insertText 将非空文本写入 sys_texts 并返回 id；空值返回 nil。
func insertText(content *string) (*int64, error) {
	if content == nil || *content == "" {
		return nil, nil
	}
	res, err := db.DB.Exec(`INSERT INTO sys_texts (text_content) VALUES (?)`, *content)
	if err != nil {
		return nil, err
	}
	id, _ := res.LastInsertId()
	return &id, nil
}

// ============================================================
// 验收标准树
// ============================================================

func ListStandards() ([]model.AcceptanceStandard, error) {
	rows, err := db.DB.Query(`SELECT s.id, s.parent_id, s.standard_code, s.standard_name, s.node_type,
		s.collect_type, s.collect_method, cp.text_content, jc.text_content,
		s.order_idx, s.standard_status, s.created_by, s.updated_by, s.created_at, s.updated_at
		FROM ruok_acceptance_standards s
		LEFT JOIN sys_texts cp ON s.collect_params_text_id = cp.id
		LEFT JOIN sys_texts jc ON s.judge_criteria_text_id = jc.id
		ORDER BY s.parent_id, s.order_idx, s.id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.AcceptanceStandard
	for rows.Next() {
		var d model.AcceptanceStandard
		var collectType, collectMethod, collectParams, judgeCriteria, updatedBy sql.NullString
		if err := rows.Scan(&d.ID, &d.ParentID, &d.StandardCode, &d.StandardName, &d.NodeType,
			&collectType, &collectMethod, &collectParams, &judgeCriteria,
			&d.OrderIdx, &d.StandardStatus, &d.CreatedBy, &updatedBy, &d.CreatedAt, &d.UpdatedAt); err != nil {
			return nil, err
		}
		d.CollectType = nullStrToPtr(collectType)
		d.CollectMethod = nullStrToPtr(collectMethod)
		d.CollectParams = nullStrToPtr(collectParams)
		d.JudgeCriteria = nullStrToPtr(judgeCriteria)
		d.UpdatedBy = nullStrToPtr(updatedBy)
		list = append(list, d)
	}
	if list == nil {
		list = []model.AcceptanceStandard{}
	}
	return list, rows.Err()
}

func GetStandard(id int64) (*model.AcceptanceStandard, error) {
	var d model.AcceptanceStandard
	var collectType, collectMethod, collectParams, judgeCriteria, updatedBy sql.NullString
	err := db.DB.QueryRow(`SELECT s.id, s.parent_id, s.standard_code, s.standard_name, s.node_type,
		s.collect_type, s.collect_method, cp.text_content, jc.text_content,
		s.order_idx, s.standard_status, s.created_by, s.updated_by, s.created_at, s.updated_at
		FROM ruok_acceptance_standards s
		LEFT JOIN sys_texts cp ON s.collect_params_text_id = cp.id
		LEFT JOIN sys_texts jc ON s.judge_criteria_text_id = jc.id
		WHERE s.id = ?`, id).
		Scan(&d.ID, &d.ParentID, &d.StandardCode, &d.StandardName, &d.NodeType,
			&collectType, &collectMethod, &collectParams, &judgeCriteria,
			&d.OrderIdx, &d.StandardStatus, &d.CreatedBy, &updatedBy, &d.CreatedAt, &d.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	d.CollectType = nullStrToPtr(collectType)
	d.CollectMethod = nullStrToPtr(collectMethod)
	d.CollectParams = nullStrToPtr(collectParams)
	d.JudgeCriteria = nullStrToPtr(judgeCriteria)
	d.UpdatedBy = nullStrToPtr(updatedBy)
	return &d, nil
}

func CreateStandard(req *model.CreateStandardRequest, createdBy string) (*model.AcceptanceStandard, error) {
	nodeType := req.NodeType
	if nodeType == "" {
		nodeType = "item"
	}
	standardStatus := req.StandardStatus
	if standardStatus == "" {
		standardStatus = "enabled"
	}

	collectParamsID, err := insertText(req.CollectParams)
	if err != nil {
		return nil, err
	}
	judgeCriteriaID, err := insertText(req.JudgeCriteria)
	if err != nil {
		return nil, err
	}

	orderIdx := 0
	if req.OrderIdx != nil {
		orderIdx = *req.OrderIdx
	} else {
		var next int
		if err := db.DB.QueryRow(`SELECT COALESCE(MAX(order_idx), -1) + 1 FROM ruok_acceptance_standards WHERE parent_id = ?`, req.ParentID).Scan(&next); err == nil {
			orderIdx = next
		}
	}

	result, err := db.DB.Exec(`INSERT INTO ruok_acceptance_standards
		(parent_id, standard_code, standard_name, node_type, collect_type, collect_method,
		 collect_params_text_id, judge_criteria_text_id, order_idx, standard_status, created_by)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		req.ParentID, req.StandardCode, req.StandardName, nodeType, req.CollectType, req.CollectMethod,
		collectParamsID, judgeCriteriaID, orderIdx, standardStatus, createdBy)
	if err != nil {
		return nil, err
	}
	id, _ := result.LastInsertId()
	return GetStandard(id)
}

func UpdateStandard(id int64, req *model.UpdateStandardRequest, updatedBy string) (*model.AcceptanceStandard, error) {
	existing, err := GetStandard(id)
	if err != nil || existing == nil {
		return nil, err
	}

	parentID := existing.ParentID
	standardCode := existing.StandardCode
	standardName := existing.StandardName
	nodeType := existing.NodeType
	collectType := existing.CollectType
	collectMethod := existing.CollectMethod
	collectParams := existing.CollectParams
	judgeCriteria := existing.JudgeCriteria
	orderIdx := existing.OrderIdx
	standardStatus := existing.StandardStatus
	if req.ParentID != nil {
		parentID = *req.ParentID
	}
	if req.StandardCode != nil {
		standardCode = *req.StandardCode
	}
	if req.StandardName != nil {
		standardName = *req.StandardName
	}
	if req.NodeType != nil {
		nodeType = *req.NodeType
	}
	if req.CollectType != nil {
		collectType = req.CollectType
	}
	if req.CollectMethod != nil {
		collectMethod = req.CollectMethod
	}
	if req.CollectParams != nil {
		collectParams = req.CollectParams
	}
	if req.JudgeCriteria != nil {
		judgeCriteria = req.JudgeCriteria
	}
	if req.OrderIdx != nil {
		orderIdx = *req.OrderIdx
	}
	if req.StandardStatus != nil {
		standardStatus = *req.StandardStatus
	}

	// 大字段：仅在请求显式携带该字段时重建 sys_texts，否则保留原 text_id
	var curCollectParamsID, curJudgeCriteriaID sql.NullInt64
	if err := db.DB.QueryRow(`SELECT collect_params_text_id, judge_criteria_text_id FROM ruok_acceptance_standards WHERE id = ?`, id).
		Scan(&curCollectParamsID, &curJudgeCriteriaID); err != nil {
		return nil, err
	}
	collectParamsTextID := nullInt64ToPtr(curCollectParamsID)
	if req.CollectParams != nil {
		collectParamsTextID, err = insertText(collectParams)
		if err != nil {
			return nil, err
		}
	}
	judgeCriteriaTextID := nullInt64ToPtr(curJudgeCriteriaID)
	if req.JudgeCriteria != nil {
		judgeCriteriaTextID, err = insertText(judgeCriteria)
		if err != nil {
			return nil, err
		}
	}

	_, err = db.DB.Exec(`UPDATE ruok_acceptance_standards SET parent_id=?, standard_code=?, standard_name=?, node_type=?,
		collect_type=?, collect_method=?, collect_params_text_id=?, judge_criteria_text_id=?,
		order_idx=?, standard_status=?, updated_by=? WHERE id=?`,
		parentID, standardCode, standardName, nodeType,
		collectType, collectMethod, collectParamsTextID, judgeCriteriaTextID,
		orderIdx, standardStatus, updatedBy, id)
	if err != nil {
		return nil, err
	}
	return GetStandard(id)
}

func DeleteStandard(id int64) error {
	return deleteByID("ruok_acceptance_standards", id)
}

// MoveStandard 将节点移动到 parentID 下的 orderIdx 位置，并重排目标父节点下同级顺序。
func MoveStandard(id, parentID int64, orderIdx int) error {
	existing, err := GetStandard(id)
	if err != nil || existing == nil {
		if err == nil {
			return sql.ErrNoRows
		}
		return err
	}

	// 目标父节点下的现有同级（排除自身）
	rows, err := db.DB.Query(`SELECT id FROM ruok_acceptance_standards WHERE parent_id = ? AND id != ? ORDER BY order_idx, id`, parentID, id)
	if err != nil {
		return err
	}
	var siblingIDs []int64
	for rows.Next() {
		var sid int64
		if err := rows.Scan(&sid); err != nil {
			rows.Close()
			return err
		}
		siblingIDs = append(siblingIDs, sid)
	}
	rows.Close()
	if err := rows.Err(); err != nil {
		return err
	}

	// 构造最终顺序：将自身插入指定位置
	if orderIdx < 0 {
		orderIdx = 0
	}
	if orderIdx > len(siblingIDs) {
		orderIdx = len(siblingIDs)
	}
	finalIDs := make([]int64, 0, len(siblingIDs)+1)
	finalIDs = append(finalIDs, siblingIDs[:orderIdx]...)
	finalIDs = append(finalIDs, id)
	finalIDs = append(finalIDs, siblingIDs[orderIdx:]...)

	// 先更新 parent_id
	if _, err := db.DB.Exec(`UPDATE ruok_acceptance_standards SET parent_id = ? WHERE id = ?`, parentID, id); err != nil {
		return err
	}
	// 重排同级顺序
	for i, sid := range finalIDs {
		if _, err := db.DB.Exec(`UPDATE ruok_acceptance_standards SET order_idx = ? WHERE id = ?`, i, sid); err != nil {
			return err
		}
	}
	return nil
}
