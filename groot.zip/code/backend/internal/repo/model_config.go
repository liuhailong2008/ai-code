package repo

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"database/sql"
	"encoding/base64"
	"fmt"
	"io"

	"groot-backend/internal/config"
	"groot-backend/internal/db"
	"groot-backend/internal/model"
)

func aesKey() []byte {
	return config.Load().AESKey()
}

func encryptAPIKey(plaintext string) (string, error) {
	if plaintext == "" {
		return "", nil
	}
	block, err := aes.NewCipher(aesKey())
	if err != nil {
		return "", err
	}
	aesGCM, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, aesGCM.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}
	ciphertext := aesGCM.Seal(nonce, nonce, []byte(plaintext), nil)
	return base64.StdEncoding.EncodeToString(ciphertext), nil
}

func decryptAPIKey(cipherB64 string) (string, error) {
	if cipherB64 == "" {
		return "", nil
	}
	ciphertext, err := base64.StdEncoding.DecodeString(cipherB64)
	if err != nil {
		return "", err
	}
	block, err := aes.NewCipher(aesKey())
	if err != nil {
		return "", err
	}
	aesGCM, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	nonceSize := aesGCM.NonceSize()
	if len(ciphertext) < nonceSize {
		return "", nil
	}
	nonce, ciphertext := ciphertext[:nonceSize], ciphertext[nonceSize:]
	plaintext, err := aesGCM.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return "", err
	}
	return string(plaintext), nil
}

func ListModelConfigs() ([]model.ModelConfig, error) {
	rows, err := db.DB.Query(`SELECT id, code, name, provider, base_url, api_key, purpose, is_active, is_enabled, priority, context_window, max_tokens, supports_thinking, supports_vision, supports_tools, supports_json, temperature, top_p, created_by, updated_by, created_at, updated_at FROM sys_models ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var configs []model.ModelConfig
	for rows.Next() {
		var c model.ModelConfig
		var apiKeyCipher string
		var isActive, isEnabled, supportsThinking, supportsVision, supportsTools, supportsJSON int
		var updatedBy sql.NullString
		if err := rows.Scan(&c.ID, &c.Code, &c.Name, &c.Provider, &c.BaseURL, &apiKeyCipher, &c.Purpose, &isActive, &isEnabled, &c.Priority, &c.ContextWindow, &c.MaxTokens, &supportsThinking, &supportsVision, &supportsTools, &supportsJSON, &c.Temperature, &c.TopP, &c.CreatedBy, &updatedBy, &c.CreatedAt, &c.UpdatedAt); err != nil {
			return nil, err
		}
		c.APIKey = "" // 不回显 API Key
		c.HasApiKey = apiKeyCipher != ""
		c.IsActive = isActive == 1
		c.IsEnabled = isEnabled == 1
		c.SupportsThinking = supportsThinking == 1
		c.SupportsVision = supportsVision == 1
		c.SupportsTools = supportsTools == 1
		c.SupportsJSON = supportsJSON == 1
		if updatedBy.Valid {
			c.UpdatedBy = &updatedBy.String
		}
		configs = append(configs, c)
	}
	return configs, rows.Err()
}

func GetModelConfig(id int64) (*model.ModelConfig, error) {
	var c model.ModelConfig
	var apiKeyCipher string
	var isActive, isEnabled, supportsThinking, supportsVision, supportsTools, supportsJSON int
	var updatedBy sql.NullString
	err := db.DB.QueryRow(`SELECT id, code, name, provider, base_url, api_key, purpose, is_active, is_enabled, priority, context_window, max_tokens, supports_thinking, supports_vision, supports_tools, supports_json, temperature, top_p, created_by, updated_by, created_at, updated_at FROM sys_models WHERE id = ?`, id).
		Scan(&c.ID, &c.Code, &c.Name, &c.Provider, &c.BaseURL, &apiKeyCipher, &c.Purpose, &isActive, &isEnabled, &c.Priority, &c.ContextWindow, &c.MaxTokens, &supportsThinking, &supportsVision, &supportsTools, &supportsJSON, &c.Temperature, &c.TopP, &c.CreatedBy, &updatedBy, &c.CreatedAt, &c.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	c.APIKey = "" // 不回显 API Key
	c.HasApiKey = apiKeyCipher != ""
	c.IsActive = isActive == 1
	c.IsEnabled = isEnabled == 1
	c.SupportsThinking = supportsThinking == 1
	c.SupportsVision = supportsVision == 1
	c.SupportsTools = supportsTools == 1
	c.SupportsJSON = supportsJSON == 1
	if updatedBy.Valid {
		c.UpdatedBy = &updatedBy.String
	}
	return &c, nil
}

// GetModelConfigWithKey 内部使用，返回解密后的 API Key（用于验证等场景）
func GetModelConfigWithKey(id int64) (*model.ModelConfig, error) {
	var c model.ModelConfig
	var apiKeyCipher string
	var isActive, isEnabled, supportsThinking, supportsVision, supportsTools, supportsJSON int
	var updatedBy sql.NullString
	err := db.DB.QueryRow(`SELECT id, code, name, provider, base_url, api_key, purpose, is_active, is_enabled, priority, context_window, max_tokens, supports_thinking, supports_vision, supports_tools, supports_json, temperature, top_p, created_by, updated_by, created_at, updated_at FROM sys_models WHERE id = ?`, id).
		Scan(&c.ID, &c.Code, &c.Name, &c.Provider, &c.BaseURL, &apiKeyCipher, &c.Purpose, &isActive, &isEnabled, &c.Priority, &c.ContextWindow, &c.MaxTokens, &supportsThinking, &supportsVision, &supportsTools, &supportsJSON, &c.Temperature, &c.TopP, &c.CreatedBy, &updatedBy, &c.CreatedAt, &c.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	decrypted, decryptErr := decryptAPIKey(apiKeyCipher)
	if decryptErr != nil {
		return nil, fmt.Errorf("API Key 解密失败，请重新配置 API Key")
	}
	c.APIKey = decrypted
	c.HasApiKey = apiKeyCipher != ""
	c.IsActive = isActive == 1
	c.IsEnabled = isEnabled == 1
	c.SupportsThinking = supportsThinking == 1
	c.SupportsVision = supportsVision == 1
	c.SupportsTools = supportsTools == 1
	c.SupportsJSON = supportsJSON == 1
	if updatedBy.Valid {
		c.UpdatedBy = &updatedBy.String
	}
	return &c, nil
}

func CreateModelConfig(req *model.CreateModelConfigRequest, createdBy string) (*model.ModelConfig, error) {
	encryptedKey, err := encryptAPIKey(req.APIKey)
	if err != nil {
		return nil, err
	}

	isActive := false
	if req.IsActive != nil {
		isActive = *req.IsActive
	}
	isEnabled := true
	if req.IsEnabled != nil {
		isEnabled = *req.IsEnabled
	}
	priority := 0
	if req.Priority != nil {
		priority = *req.Priority
	}
	contextWindow := 4096
	if req.ContextWindow != nil {
		contextWindow = *req.ContextWindow
	}
	maxTokens := 4096
	if req.MaxTokens != nil {
		maxTokens = *req.MaxTokens
	}
	supportsThinking := false
	if req.SupportsThinking != nil {
		supportsThinking = *req.SupportsThinking
	}
	supportsVision := false
	if req.SupportsVision != nil {
		supportsVision = *req.SupportsVision
	}
	supportsTools := false
	if req.SupportsTools != nil {
		supportsTools = *req.SupportsTools
	}
	supportsJSON := false
	if req.SupportsJSON != nil {
		supportsJSON = *req.SupportsJSON
	}

	result, err := db.DB.Exec(`INSERT INTO sys_models (code, name, provider, base_url, api_key, purpose, is_active, is_enabled, priority, context_window, max_tokens, supports_thinking, supports_vision, supports_tools, supports_json, temperature, top_p, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		req.Code, req.Name, req.Provider, req.BaseURL, encryptedKey, req.Purpose, isActive, isEnabled, priority, contextWindow, maxTokens, supportsThinking, supportsVision, supportsTools, supportsJSON, req.Temperature, req.TopP, createdBy)
	if err != nil {
		return nil, err
	}

	id, _ := result.LastInsertId()

	return GetModelConfig(id)
}

func UpdateModelConfig(id int64, req *model.UpdateModelConfigRequest, updatedBy string) (*model.ModelConfig, error) {
	existing, err := GetModelConfig(id)
	if err != nil || existing == nil {
		return nil, err
	}

	code := existing.Code
	name := existing.Name
	provider := existing.Provider
	baseURL := existing.BaseURL
	purpose := existing.Purpose
	isActive := existing.IsActive
	isEnabled := existing.IsEnabled
	priority := existing.Priority
	contextWindow := existing.ContextWindow
	maxTokens := existing.MaxTokens
	supportsThinking := existing.SupportsThinking
	supportsVision := existing.SupportsVision
	supportsTools := existing.SupportsTools
	supportsJSON := existing.SupportsJSON
	temperature := existing.Temperature
	topP := existing.TopP

	if req.Code != nil {
		code = *req.Code
	}
	if req.Name != nil {
		name = *req.Name
	}
	if req.Provider != nil {
		provider = *req.Provider
	}
	if req.BaseURL != nil {
		baseURL = *req.BaseURL
	}
	if req.Purpose != nil {
		purpose = *req.Purpose
	}
	if req.IsActive != nil {
		isActive = *req.IsActive
	}
	if req.IsEnabled != nil {
		isEnabled = *req.IsEnabled
	}
	if req.Priority != nil {
		priority = *req.Priority
	}
	if req.ContextWindow != nil {
		contextWindow = *req.ContextWindow
	}
	if req.MaxTokens != nil {
		maxTokens = *req.MaxTokens
	}
	if req.SupportsThinking != nil {
		supportsThinking = *req.SupportsThinking
	}
	if req.SupportsVision != nil {
		supportsVision = *req.SupportsVision
	}
	if req.SupportsTools != nil {
		supportsTools = *req.SupportsTools
	}
	if req.SupportsJSON != nil {
		supportsJSON = *req.SupportsJSON
	}
	if req.Temperature != nil {
		temperature = req.Temperature
	}
	if req.TopP != nil {
		topP = req.TopP
	}

	// 仅在传入新 APIKey 时才更新加密字段
	if req.APIKey != nil {
		encryptedKey, err := encryptAPIKey(*req.APIKey)
		if err != nil {
			return nil, err
		}
		_, err = db.DB.Exec(`UPDATE sys_models SET code=?, name=?, provider=?, base_url=?, api_key=?, purpose=?, is_active=?, is_enabled=?, priority=?, context_window=?, max_tokens=?, supports_thinking=?, supports_vision=?, supports_tools=?, supports_json=?, temperature=?, top_p=?, updated_by=? WHERE id=?`,
			code, name, provider, baseURL, encryptedKey, purpose, isActive, isEnabled, priority, contextWindow, maxTokens, supportsThinking, supportsVision, supportsTools, supportsJSON, temperature, topP, updatedBy, id)
	} else {
		_, err = db.DB.Exec(`UPDATE sys_models SET code=?, name=?, provider=?, base_url=?, purpose=?, is_active=?, is_enabled=?, priority=?, context_window=?, max_tokens=?, supports_thinking=?, supports_vision=?, supports_tools=?, supports_json=?, temperature=?, top_p=?, updated_by=? WHERE id=?`,
			code, name, provider, baseURL, purpose, isActive, isEnabled, priority, contextWindow, maxTokens, supportsThinking, supportsVision, supportsTools, supportsJSON, temperature, topP, updatedBy, id)
	}
	if err != nil {
		return nil, err
	}

	return GetModelConfig(id)
}

func DeleteModelConfig(id int64) error {
	result, err := db.DB.Exec(`DELETE FROM sys_models WHERE id = ?`, id)
	if err != nil {
		return err
	}
	affected, _ := result.RowsAffected()
	if affected == 0 {
		return sql.ErrNoRows
	}
	return nil
}

// GetActiveChatModel 获取激活的 chat 用途模型（含解密后的 API Key）
func GetActiveChatModel() (*model.ModelConfig, error) {
	var c model.ModelConfig
	var apiKeyCipher string
	var isActive, isEnabled, supportsThinking, supportsVision, supportsTools, supportsJSON int
	var updatedBy sql.NullString
	err := db.DB.QueryRow(`SELECT id, code, name, provider, base_url, api_key, purpose, is_active, is_enabled, priority, context_window, max_tokens, supports_thinking, supports_vision, supports_tools, supports_json, temperature, top_p, created_by, updated_by, created_at, updated_at FROM sys_models WHERE purpose = 'chat' AND is_enabled = 1 ORDER BY is_active DESC, priority ASC LIMIT 1`).
		Scan(&c.ID, &c.Code, &c.Name, &c.Provider, &c.BaseURL, &apiKeyCipher, &c.Purpose, &isActive, &isEnabled, &c.Priority, &c.ContextWindow, &c.MaxTokens, &supportsThinking, &supportsVision, &supportsTools, &supportsJSON, &c.Temperature, &c.TopP, &c.CreatedBy, &updatedBy, &c.CreatedAt, &c.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	decrypted, decryptErr := decryptAPIKey(apiKeyCipher)
	if decryptErr != nil {
		return nil, fmt.Errorf("API Key 解密失败，请重新配置 API Key")
	}
	c.APIKey = decrypted
	c.HasApiKey = apiKeyCipher != ""
	c.IsActive = isActive == 1
	c.IsEnabled = isEnabled == 1
	c.SupportsThinking = supportsThinking == 1
	c.SupportsVision = supportsVision == 1
	c.SupportsTools = supportsTools == 1
	c.SupportsJSON = supportsJSON == 1
	if updatedBy.Valid {
		c.UpdatedBy = &updatedBy.String
	}
	return &c, nil
}

// ListActiveModels 列出指定用途下已激活/启用的模型（不含敏感字段）
func ListActiveModels(purpose string) ([]model.ModelConfig, error) {
	purposeCond := ""
	args := []interface{}{}
	if purpose != "" && purpose != "all" {
		purposeCond = " AND purpose = ?"
		args = append(args, purpose)
	}
	rows, err := db.DB.Query(`
		SELECT id, code, name, provider, base_url, purpose, is_active, is_enabled, priority,
		       context_window, max_tokens, supports_thinking, supports_vision, supports_tools,
		       supports_json, temperature, top_p, created_at, updated_at
		FROM sys_models
		WHERE is_active = 1 AND is_enabled = 1 `+purposeCond+`
		ORDER BY priority ASC, id ASC
	`, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	out := []model.ModelConfig{}
	for rows.Next() {
		var c model.ModelConfig
		var isActive, isEnabled, supportsThinking, supportsVision, supportsTools, supportsJSON int
		err := rows.Scan(&c.ID, &c.Code, &c.Name, &c.Provider, &c.BaseURL, &c.Purpose,
			&isActive, &isEnabled, &c.Priority, &c.ContextWindow, &c.MaxTokens,
			&supportsThinking, &supportsVision, &supportsTools, &supportsJSON,
			&c.Temperature, &c.TopP, &c.CreatedAt, &c.UpdatedAt)
		if err != nil {
			return nil, err
		}
		c.IsActive = isActive == 1
		c.IsEnabled = isEnabled == 1
		c.SupportsThinking = supportsThinking == 1
		c.SupportsVision = supportsVision == 1
		c.SupportsTools = supportsTools == 1
		c.SupportsJSON = supportsJSON == 1
		c.HasApiKey = true
		out = append(out, c)
	}
	return out, nil
}

// GetActiveChatModelByCode 根据 model code 获取激活的 chat 模型（含解密后的 API Key）
func GetActiveChatModelByCode(code string) (*model.ModelConfig, error) {
	if code == "" {
		return GetActiveChatModel()
	}
	var c model.ModelConfig
	var apiKeyCipher string
	var isActive, isEnabled, supportsThinking, supportsVision, supportsTools, supportsJSON int
	var updatedBy sql.NullString
	err := db.DB.QueryRow(`
		SELECT id, code, name, provider, base_url, api_key, purpose, is_active, is_enabled,
		       priority, context_window, max_tokens, supports_thinking, supports_vision,
		       supports_tools, supports_json, temperature, top_p, created_by, updated_by,
		       created_at, updated_at
		FROM sys_models
		WHERE code = ? AND is_active = 1 AND is_enabled = 1
	`, code).Scan(&c.ID, &c.Code, &c.Name, &c.Provider, &c.BaseURL, &apiKeyCipher, &c.Purpose,
		&isActive, &isEnabled, &c.Priority, &c.ContextWindow, &c.MaxTokens,
		&supportsThinking, &supportsVision, &supportsTools, &supportsJSON,
		&c.Temperature, &c.TopP, &c.CreatedBy, &updatedBy, &c.CreatedAt, &c.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	decrypted, decryptErr := decryptAPIKey(apiKeyCipher)
	if decryptErr != nil {
		return nil, fmt.Errorf("API Key 解密失败，请重新配置 API Key")
	}
	c.APIKey = decrypted
	c.HasApiKey = apiKeyCipher != ""
	c.IsActive = isActive == 1
	c.IsEnabled = isEnabled == 1
	c.SupportsThinking = supportsThinking == 1
	c.SupportsVision = supportsVision == 1
	c.SupportsTools = supportsTools == 1
	c.SupportsJSON = supportsJSON == 1
	if updatedBy.Valid {
		c.UpdatedBy = &updatedBy.String
	}
	return &c, nil
}
