package repo

import "groot-backend/internal/db"
import "groot-backend/internal/model"

// ListTools 列出所有工具
func ListTools() ([]model.Tool, error) {
	rows, err := db.DB.Query(
		`SELECT id, tool_name, display_name, description, tool_category, implementation_class,
		        input_schema, output_schema, is_enabled, created_by, updated_by, created_at, updated_at
		 FROM tools ORDER BY tool_category, id ASC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.Tool
	for rows.Next() {
		var t model.Tool
		if err := rows.Scan(&t.ID, &t.ToolName, &t.DisplayName, &t.Description,
			&t.ToolCategory, &t.ImplementationClass, &t.InputSchema, &t.OutputSchema, &t.IsEnabled,
			&t.CreatedBy, &t.UpdatedBy, &t.CreatedAt, &t.UpdatedAt); err != nil {
			return nil, err
		}
		normalizeJSONNull(&t.InputSchema)
		normalizeJSONNull(&t.OutputSchema)
		list = append(list, t)
	}
	return list, nil
}

// GetTool 获取单个工具
func GetTool(id int64) (*model.Tool, error) {
	var t model.Tool
	err := db.DB.QueryRow(
		`SELECT id, tool_name, display_name, description, tool_category, implementation_class,
		        input_schema, output_schema, is_enabled, created_by, updated_by, created_at, updated_at
		 FROM tools WHERE id = ?`, id).Scan(
		&t.ID, &t.ToolName, &t.DisplayName, &t.Description,
		&t.ToolCategory, &t.ImplementationClass, &t.InputSchema, &t.OutputSchema, &t.IsEnabled,
		&t.CreatedBy, &t.UpdatedBy, &t.CreatedAt, &t.UpdatedAt)
	if err != nil {
		return nil, err
	}
	normalizeJSONNull(&t.InputSchema)
	normalizeJSONNull(&t.OutputSchema)
	return &t, nil
}

// GetToolByName 按名称获取工具
func GetToolByName(name string) (*model.Tool, error) {
	var t model.Tool
	err := db.DB.QueryRow(
		`SELECT id, tool_name, display_name, description, tool_category, implementation_class,
		        input_schema, output_schema, is_enabled, created_by, updated_by, created_at, updated_at
		 FROM tools WHERE tool_name = ?`, name).Scan(
		&t.ID, &t.ToolName, &t.DisplayName, &t.Description,
		&t.ToolCategory, &t.ImplementationClass, &t.InputSchema, &t.OutputSchema, &t.IsEnabled,
		&t.CreatedBy, &t.UpdatedBy, &t.CreatedAt, &t.UpdatedAt)
	if err != nil {
		return nil, err
	}
	normalizeJSONNull(&t.InputSchema)
	normalizeJSONNull(&t.OutputSchema)
	return &t, nil
}

// UpdateTool 更新工具
func UpdateTool(id int64, req *model.UpdateToolRequest, updatedBy string) (*model.Tool, error) {
	_, err := db.DB.Exec(
		`UPDATE tools SET
			display_name = COALESCE(NULLIF(?, ''), display_name),
			description = COALESCE(?, description),
			tool_category = COALESCE(NULLIF(?, ''), tool_category),
			input_schema = COALESCE(?, input_schema),
			output_schema = COALESCE(?, output_schema),
			is_enabled = COALESCE(?, is_enabled),
			updated_by = ?
		 WHERE id = ?`,
		req.DisplayName, req.Description, req.ToolCategory,
		req.InputSchema, req.OutputSchema, req.IsEnabled, updatedBy, id)
	if err != nil {
		return nil, err
	}
	return GetTool(id)
}

// UpsertTool 插入或更新工具（扫描时使用）
func UpsertTool(toolName, displayName, implClass, category, createdBy string, description, inputSchema, outputSchema *string) error {
	_, err := db.DB.Exec(
		`INSERT INTO tools (tool_name, display_name, description, tool_category, implementation_class, input_schema, output_schema, created_by)
		 VALUES (?, ?, ?, ?, ?, ?, ?, ?)
		 ON DUPLICATE KEY UPDATE
			display_name = VALUES(display_name),
			description = COALESCE(VALUES(description), description),
			tool_category = VALUES(tool_category),
			implementation_class = VALUES(implementation_class),
			input_schema = COALESCE(VALUES(input_schema), input_schema),
			output_schema = COALESCE(VALUES(output_schema), output_schema)`,
		toolName, displayName, description, category, implClass, inputSchema, outputSchema, createdBy)
	return err
}

// EnsureToolsTable 确保 tools 表存在
func EnsureToolsTable() error {
	_, err := db.DB.Exec(`CREATE TABLE IF NOT EXISTS tools (
		id                   BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
		tool_name            VARCHAR(128)     NOT NULL                 COMMENT '工具名称（唯一标识）',
		display_name         VARCHAR(128)     NOT NULL                 COMMENT '显示名称',
		description          VARCHAR(512)     DEFAULT NULL             COMMENT '工具描述',
		tool_category        VARCHAR(64)      NOT NULL DEFAULT 'general' COMMENT '工具分类',
		implementation_class VARCHAR(256)     NOT NULL                 COMMENT '实现类（包路径）',
		input_schema         JSON             DEFAULT NULL             COMMENT '输入参数 Schema',
		output_schema        JSON             DEFAULT NULL             COMMENT '输出参数 Schema',
		is_enabled           TINYINT(1)       NOT NULL DEFAULT 1       COMMENT '是否启用',
		created_by           VARCHAR(64)      NOT NULL                 COMMENT '创建人',
		updated_by           VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
		created_at           DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
		updated_at           DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
		PRIMARY KEY (id),
		UNIQUE KEY uk_tool_name (tool_name),
		KEY idx_impl_class (implementation_class),
		KEY idx_category (tool_category)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='工具注册表'`)
	return err
}
