package repo

import (
	"database/sql"

	"groot-backend/internal/db"
	"groot-backend/internal/model"
)

// ============================================================
// 组件树（服务台账组件树）
// ============================================================

func ListComponentTree() ([]model.ComponentTreeNode, error) {
	rows, err := db.DB.Query(`SELECT id, parent_id, node_type, node_code, node_name, node_idx, node_remark,
		access_method, access_port, access_password,
		created_by, updated_by, created_at, updated_at
		FROM ruok_component_tree
		ORDER BY parent_id, node_idx, id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.ComponentTreeNode
	for rows.Next() {
		var d model.ComponentTreeNode
		var remark, accessMethod, accessPassword, updatedBy sql.NullString
		var accessPort sql.NullInt64
		if err := rows.Scan(&d.ID, &d.ParentID, &d.NodeType, &d.NodeCode, &d.NodeName, &d.NodeIdx,
			&remark, &accessMethod, &accessPort, &accessPassword,
			&d.CreatedBy, &updatedBy, &d.CreatedAt, &d.UpdatedAt); err != nil {
			return nil, err
		}
		d.NodeRemark = nullStrToPtr(remark)
		d.AccessMethod = nullStrToPtr(accessMethod)
		d.AccessPort = nullIntToPtr(accessPort)
		d.AccessPassword = componentTreePassword(accessPassword)
		d.UpdatedBy = nullStrToPtr(updatedBy)
		list = append(list, d)
	}
	if list == nil {
		list = []model.ComponentTreeNode{}
	}
	return list, rows.Err()
}

func GetComponentTreeNode(id int64) (*model.ComponentTreeNode, error) {
	var d model.ComponentTreeNode
	var remark, accessMethod, accessPassword, updatedBy sql.NullString
	var accessPort sql.NullInt64
	err := db.DB.QueryRow(`SELECT id, parent_id, node_type, node_code, node_name, node_idx, node_remark,
		access_method, access_port, access_password,
		created_by, updated_by, created_at, updated_at
		FROM ruok_component_tree WHERE id = ?`, id).
		Scan(&d.ID, &d.ParentID, &d.NodeType, &d.NodeCode, &d.NodeName, &d.NodeIdx,
			&remark, &accessMethod, &accessPort, &accessPassword,
			&d.CreatedBy, &updatedBy, &d.CreatedAt, &d.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	d.NodeRemark = nullStrToPtr(remark)
	d.AccessMethod = nullStrToPtr(accessMethod)
	d.AccessPort = nullIntToPtr(accessPort)
	d.AccessPassword = componentTreePassword(accessPassword)
	d.UpdatedBy = nullStrToPtr(updatedBy)
	return &d, nil
}

func CreateComponentTreeNode(req *model.CreateComponentTreeNodeRequest, createdBy string) (*model.ComponentTreeNode, error) {
	nodeIdx := 0
	if req.NodeIdx != nil {
		nodeIdx = *req.NodeIdx
	} else {
		var next int
		if err := db.DB.QueryRow(`SELECT COALESCE(MAX(node_idx), -1) + 1 FROM ruok_component_tree WHERE parent_id = ?`, req.ParentID).Scan(&next); err == nil {
			nodeIdx = next
		}
	}

	passwordCipher, err := componentTreePasswordCipher(req.AccessPassword)
	if err != nil {
		return nil, err
	}

	result, err := db.DB.Exec(`INSERT INTO ruok_component_tree
		(parent_id, node_type, node_code, node_name, node_idx, node_remark, access_method, access_port, access_password, created_by)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		req.ParentID, req.NodeType, req.NodeCode, req.NodeName, nodeIdx, req.NodeRemark,
		req.AccessMethod, req.AccessPort, passwordCipher, createdBy)
	if err != nil {
		return nil, err
	}
	id, _ := result.LastInsertId()
	return GetComponentTreeNode(id)
}

func UpdateComponentTreeNode(id int64, req *model.UpdateComponentTreeNodeRequest, updatedBy string) (*model.ComponentTreeNode, error) {
	existing, err := GetComponentTreeNode(id)
	if err != nil || existing == nil {
		return nil, err
	}

	parentID := existing.ParentID
	nodeType := existing.NodeType
	nodeCode := existing.NodeCode
	nodeName := existing.NodeName
	nodeIdx := existing.NodeIdx
	remark := existing.NodeRemark
	accessMethod := existing.AccessMethod
	accessPort := existing.AccessPort
	accessPassword := existing.AccessPassword
	if req.ParentID != nil {
		parentID = *req.ParentID
	}
	if req.NodeType != nil {
		nodeType = *req.NodeType
	}
	if req.NodeCode != nil {
		nodeCode = *req.NodeCode
	}
	if req.NodeName != nil {
		nodeName = *req.NodeName
	}
	if req.NodeIdx != nil {
		nodeIdx = *req.NodeIdx
	}
	if req.NodeRemark != nil {
		remark = req.NodeRemark
	}
	if req.AccessMethod != nil {
		accessMethod = req.AccessMethod
	}
	if req.AccessPort != nil {
		accessPort = req.AccessPort
	}
	if req.AccessPassword != nil {
		accessPassword = req.AccessPassword
	}

	passwordCipher, err := componentTreePasswordCipher(accessPassword)
	if err != nil {
		return nil, err
	}

	_, err = db.DB.Exec(`UPDATE ruok_component_tree SET parent_id=?, node_type=?, node_code=?, node_name=?, node_idx=?, node_remark=?, access_method=?, access_port=?, access_password=?, updated_by=? WHERE id=?`,
		parentID, nodeType, nodeCode, nodeName, nodeIdx, remark, accessMethod, accessPort, passwordCipher, updatedBy, id)
	if err != nil {
		return nil, err
	}
	return GetComponentTreeNode(id)
}

// DeleteComponentTreeNode 级联删除节点及全部子孙节点。
func DeleteComponentTreeNode(id int64) error {
	ids := []int64{id}
	queue := []int64{id}
	for len(queue) > 0 {
		cur := queue[0]
		queue = queue[1:]
		rows, err := db.DB.Query(`SELECT id FROM ruok_component_tree WHERE parent_id = ?`, cur)
		if err != nil {
			return err
		}
		for rows.Next() {
			var cid int64
			if err := rows.Scan(&cid); err != nil {
				rows.Close()
				return err
			}
			ids = append(ids, cid)
			queue = append(queue, cid)
		}
		rows.Close()
		if err := rows.Err(); err != nil {
			return err
		}
	}

	for _, did := range ids {
		if _, err := db.DB.Exec(`DELETE FROM ruok_component_tree WHERE id = ?`, did); err != nil {
			return err
		}
	}
	return nil
}

// MoveComponentTreeNode 将节点移动到 parentID 下的 nodeIdx 位置，并重排同级顺序。
func MoveComponentTreeNode(id, parentID int64, nodeIdx int) error {
	existing, err := GetComponentTreeNode(id)
	if err != nil || existing == nil {
		if err == nil {
			return sql.ErrNoRows
		}
		return err
	}

	rows, err := db.DB.Query(`SELECT id FROM ruok_component_tree WHERE parent_id = ? AND id != ? ORDER BY node_idx, id`, parentID, id)
	if err != nil {
		return err
	}
	var siblingIDs []int64
	for rows.Next() {
		var sid int64
		if err := rows.Scan(&sid); err != nil {
			rows.Close()
			return err
		}
		siblingIDs = append(siblingIDs, sid)
	}
	rows.Close()
	if err := rows.Err(); err != nil {
		return err
	}

	if nodeIdx < 0 {
		nodeIdx = 0
	}
	if nodeIdx > len(siblingIDs) {
		nodeIdx = len(siblingIDs)
	}
	finalIDs := make([]int64, 0, len(siblingIDs)+1)
	finalIDs = append(finalIDs, siblingIDs[:nodeIdx]...)
	finalIDs = append(finalIDs, id)
	finalIDs = append(finalIDs, siblingIDs[nodeIdx:]...)

	if _, err := db.DB.Exec(`UPDATE ruok_component_tree SET parent_id = ? WHERE id = ?`, parentID, id); err != nil {
		return err
	}
	for i, sid := range finalIDs {
		if _, err := db.DB.Exec(`UPDATE ruok_component_tree SET node_idx = ? WHERE id = ?`, i, sid); err != nil {
			return err
		}
	}
	return nil
}

// componentTreePassword 解密 access_password（NULL -> nil，解密失败回退原文）。
func componentTreePassword(n sql.NullString) *string {
	if !n.Valid {
		return nil
	}
	plain, err := decryptMobile(n.String)
	if err == nil {
		return &plain
	}
	return &n.String
}

// componentTreePasswordCipher 加密 access_password（nil/空串 -> nil）。
func componentTreePasswordCipher(p *string) (*string, error) {
	if p == nil || *p == "" {
		return nil, nil
	}
	cipher, err := encryptMobile(*p)
	if err != nil {
		return nil, err
	}
	return &cipher, nil
}
