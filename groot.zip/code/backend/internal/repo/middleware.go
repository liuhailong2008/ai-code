package repo

import (
	"database/sql"

	"groot-backend/internal/db"
	"groot-backend/internal/model"
)

func ListSopMiddlewares() ([]model.SopMiddleware, error) {
	rows, err := db.DB.Query(`SELECT id, app_name, app_desc, primary_post, backup_post, created_by, updated_by, created_at, updated_at FROM sop_middleware ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.SopMiddleware
	for rows.Next() {
		var m model.SopMiddleware
		var updatedBy sql.NullString
		if err := rows.Scan(&m.ID, &m.AppName, &m.AppDesc, &m.PrimaryPost, &m.BackupPost, &m.CreatedBy, &updatedBy, &m.CreatedAt, &m.UpdatedAt); err != nil {
			return nil, err
		}
		if updatedBy.Valid {
			m.UpdatedBy = &updatedBy.String
		}
		list = append(list, m)
	}
	return list, rows.Err()
}

func GetSopMiddleware(id int64) (*model.SopMiddleware, error) {
	var m model.SopMiddleware
	var updatedBy sql.NullString
	err := db.DB.QueryRow(`SELECT id, app_name, app_desc, primary_post, backup_post, created_by, updated_by, created_at, updated_at FROM sop_middleware WHERE id = ?`, id).
		Scan(&m.ID, &m.AppName, &m.AppDesc, &m.PrimaryPost, &m.BackupPost, &m.CreatedBy, &updatedBy, &m.CreatedAt, &m.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	if updatedBy.Valid {
		m.UpdatedBy = &updatedBy.String
	}
	return &m, nil
}

func CreateSopMiddleware(req *model.CreateSopMiddlewareRequest, createdBy string) (*model.SopMiddleware, error) {
	result, err := db.DB.Exec(`INSERT INTO sop_middleware (app_name, app_desc, primary_post, backup_post, created_by) VALUES (?, ?, ?, ?, ?)`,
		req.AppName, req.AppDesc, req.PrimaryPost, req.BackupPost, createdBy)
	if err != nil {
		return nil, err
	}

	id, _ := result.LastInsertId()
	return GetSopMiddleware(id)
}

func UpdateSopMiddleware(id int64, req *model.UpdateSopMiddlewareRequest, updatedBy string) (*model.SopMiddleware, error) {
	existing, err := GetSopMiddleware(id)
	if err != nil || existing == nil {
		return nil, err
	}

	appName := existing.AppName
	appDesc := existing.AppDesc
	primaryPost := existing.PrimaryPost
	backupPost := existing.BackupPost

	if req.AppName != nil {
		appName = *req.AppName
	}
	if req.AppDesc != nil {
		appDesc = *req.AppDesc
	}
	if req.PrimaryPost != nil {
		primaryPost = *req.PrimaryPost
	}
	if req.BackupPost != nil {
		backupPost = *req.BackupPost
	}

	_, err = db.DB.Exec(`UPDATE sop_middleware SET app_name=?, app_desc=?, primary_post=?, backup_post=?, updated_by=? WHERE id=?`,
		appName, appDesc, primaryPost, backupPost, updatedBy, id)
	if err != nil {
		return nil, err
	}

	return GetSopMiddleware(id)
}

func GetSopMiddlewareByAppName(appName string) (*model.SopMiddleware, error) {
	var m model.SopMiddleware
	var updatedBy sql.NullString
	err := db.DB.QueryRow(`SELECT id, app_name, app_desc, primary_post, backup_post, created_by, updated_by, created_at, updated_at FROM sop_middleware WHERE app_name = ? LIMIT 1`, appName).
		Scan(&m.ID, &m.AppName, &m.AppDesc, &m.PrimaryPost, &m.BackupPost, &m.CreatedBy, &updatedBy, &m.CreatedAt, &m.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	if updatedBy.Valid {
		m.UpdatedBy = &updatedBy.String
	}
	return &m, nil
}

func DeleteSopMiddleware(id int64) error {
	result, err := db.DB.Exec(`DELETE FROM sop_middleware WHERE id = ?`, id)
	if err != nil {
		return err
	}
	affected, _ := result.RowsAffected()
	if affected == 0 {
		return sql.ErrNoRows
	}
	return nil
}
