package repo

import (
	"groot-backend/internal/db"
	"groot-backend/internal/model"
)

func ListSopDefinitions() ([]model.SopDefinition, error) {
	rows, err := db.DB.Query(
		`SELECT id, sop_name, sop_code, sop_category, sop_desc, compose_type,
		        input_schema, output_schema, status, version, created_by, updated_by,
		        created_at, updated_at
		 FROM sop_definitions ORDER BY id DESC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.SopDefinition
	for rows.Next() {
		var s model.SopDefinition
		if err := rows.Scan(&s.ID, &s.SopName, &s.SopCode, &s.SopCategory,
			&s.SopDesc, &s.ComposeType, &s.InputSchema, &s.OutputSchema,
			&s.Status, &s.Version, &s.CreatedBy, &s.UpdatedBy,
			&s.CreatedAt, &s.UpdatedAt); err != nil {
			return nil, err
		}
		normalizeJSONNull(&s.InputSchema)
		normalizeJSONNull(&s.OutputSchema)
		list = append(list, s)
	}
	return list, nil
}

func GetSopDefinition(id int64) (*model.SopDefinition, error) {
	var s model.SopDefinition
	err := db.DB.QueryRow(
		`SELECT id, sop_name, sop_code, sop_category, sop_desc, compose_type,
		        input_schema, output_schema, status, version, created_by, updated_by,
		        created_at, updated_at
		 FROM sop_definitions WHERE id = ?`, id).Scan(
		&s.ID, &s.SopName, &s.SopCode, &s.SopCategory,
		&s.SopDesc, &s.ComposeType, &s.InputSchema, &s.OutputSchema,
		&s.Status, &s.Version, &s.CreatedBy, &s.UpdatedBy,
		&s.CreatedAt, &s.UpdatedAt)
	if err != nil {
		return nil, err
	}
	normalizeJSONNull(&s.InputSchema)
	normalizeJSONNull(&s.OutputSchema)
	return &s, nil
}

func CreateSopDefinition(req *model.CreateSopRequest, createdBy string) (*model.SopDefinition, error) {
	result, err := db.DB.Exec(
		`INSERT INTO sop_definitions (sop_name, sop_code, sop_category, sop_desc, compose_type,
			input_schema, output_schema, created_by)
		 VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
		req.SopName, req.SopCode, req.SopCategory, req.SopDesc, req.ComposeType,
		req.InputSchema, req.OutputSchema, createdBy)
	if err != nil {
		return nil, err
	}
	id, _ := result.LastInsertId()
	return GetSopDefinition(id)
}

func UpdateSopDefinition(id int64, req *model.UpdateSopRequest, updatedBy string) (*model.SopDefinition, error) {
	_, err := db.DB.Exec(
		`UPDATE sop_definitions SET
			sop_name = COALESCE(NULLIF(?, ''), sop_name),
			sop_code = COALESCE(NULLIF(?, ''), sop_code),
			sop_category = COALESCE(NULLIF(?, ''), sop_category),
			sop_desc = COALESCE(NULLIF(?, ''), sop_desc),
			compose_type = COALESCE(NULLIF(?, ''), compose_type),
			input_schema = COALESCE(NULLIF(?, ''), input_schema),
			output_schema = COALESCE(NULLIF(?, ''), output_schema),
			status = COALESCE(NULLIF(?, ''), status),
			updated_by = ?
		 WHERE id = ?`,
		req.SopName, req.SopCode, req.SopCategory, req.SopDesc, req.ComposeType,
		req.InputSchema, req.OutputSchema, req.Status, updatedBy, id)
	if err != nil {
		return nil, err
	}
	return GetSopDefinition(id)
}
