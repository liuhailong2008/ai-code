package repo

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"database/sql"
	"encoding/base64"
	"fmt"
	"io"
	"strings"

	"golang.org/x/crypto/bcrypt"

	"groot-backend/internal/config"
	"groot-backend/internal/db"
	"groot-backend/internal/model"
)

func encryptMobile(plaintext string) (string, error) {
	if plaintext == "" {
		return "", nil
	}
	cfg := config.Load()
	block, err := aes.NewCipher(cfg.AESKey())
	if err != nil {
		return "", err
	}
	aesGCM, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, aesGCM.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}
	ciphertext := aesGCM.Seal(nonce, nonce, []byte(plaintext), nil)
	return base64.StdEncoding.EncodeToString(ciphertext), nil
}

func decryptMobile(cipherB64 string) (string, error) {
	if cipherB64 == "" {
		return "", nil
	}
	cfg := config.Load()
	ciphertext, err := base64.StdEncoding.DecodeString(cipherB64)
	if err != nil {
		return "", err
	}
	block, err := aes.NewCipher(cfg.AESKey())
	if err != nil {
		return "", err
	}
	aesGCM, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	nonceSize := aesGCM.NonceSize()
	if len(ciphertext) < nonceSize {
		return "", nil
	}
	nonce, ciphertext := ciphertext[:nonceSize], ciphertext[nonceSize:]
	plaintext, err := aesGCM.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return "", err
	}
	return string(plaintext), nil
}

func FindUserByUsername(username string) (*model.User, error) {
	var u model.User
	var mobileCipher string
	err := db.DB.QueryRow(
		`SELECT id, username, mobile, password, display_name, role, created_at, updated_at FROM sys_users WHERE username = ?`,
		username,
	).Scan(&u.ID, &u.Username, &mobileCipher, &u.Password, &u.DisplayName, &u.Role, &u.CreatedAt, &u.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	u.Mobile, _ = decryptMobile(mobileCipher)
	return &u, nil
}

func FindUserByID(id int64) (*model.User, error) {
	var u model.User
	var mobileCipher string
	err := db.DB.QueryRow(
		`SELECT id, username, mobile, password, display_name, role, created_at, updated_at FROM sys_users WHERE id = ?`,
		id,
	).Scan(&u.ID, &u.Username, &mobileCipher, &u.Password, &u.DisplayName, &u.Role, &u.CreatedAt, &u.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	u.Mobile, _ = decryptMobile(mobileCipher)
	return &u, nil
}

func ListUsers() ([]model.User, error) {
	rows, err := db.DB.Query(
		`SELECT id, username, mobile, password, display_name, role, created_at, updated_at FROM sys_users ORDER BY id`,
	)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var users []model.User
	for rows.Next() {
		var u model.User
		var mobileCipher string
		if err := rows.Scan(&u.ID, &u.Username, &mobileCipher, &u.Password, &u.DisplayName, &u.Role, &u.CreatedAt, &u.UpdatedAt); err != nil {
			return nil, err
		}
		u.Mobile, _ = decryptMobile(mobileCipher)
		users = append(users, u)
	}
	if users == nil {
		users = []model.User{}
	}
	return users, rows.Err()
}

func CreateUser(req *model.CreateUserRequest) (*model.User, error) {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		return nil, fmt.Errorf("password hash failed: %w", err)
	}
	encryptedMobile, err := encryptMobile(req.Mobile)
	if err != nil {
		return nil, fmt.Errorf("mobile encrypt failed: %w", err)
	}

	result, err := db.DB.Exec(
		`INSERT INTO sys_users (username, mobile, password, display_name, role) VALUES (?, ?, ?, ?, ?)`,
		req.Username, encryptedMobile, string(hashedPassword), req.DisplayName, req.Role,
	)
	if err != nil {
		return nil, err
	}
	id, _ := result.LastInsertId()
	return FindUserByID(id)
}

func UpdateUser(id int64, req *model.UpdateUserRequest) (*model.User, error) {
	sets := []string{}
	args := []interface{}{}

	if req.Username != nil {
		sets = append(sets, "username = ?")
		args = append(args, *req.Username)
	}
	if req.Mobile != nil {
		enc, err := encryptMobile(*req.Mobile)
		if err != nil {
			return nil, err
		}
		sets = append(sets, "mobile = ?")
		args = append(args, enc)
	}
	if req.Password != nil && *req.Password != "" {
		hash, err := bcrypt.GenerateFromPassword([]byte(*req.Password), bcrypt.DefaultCost)
		if err != nil {
			return nil, err
		}
		sets = append(sets, "password = ?")
		args = append(args, string(hash))
	}
	if req.DisplayName != nil {
		sets = append(sets, "display_name = ?")
		args = append(args, *req.DisplayName)
	}
	if req.Role != nil {
		sets = append(sets, "role = ?")
		args = append(args, *req.Role)
	}

	if len(sets) == 0 {
		return FindUserByID(id)
	}

	args = append(args, id)
	query := fmt.Sprintf("UPDATE sys_users SET %s WHERE id = ?", strings.Join(sets, ", "))
	if _, err := db.DB.Exec(query, args...); err != nil {
		return nil, err
	}
	return FindUserByID(id)
}

func DeleteUser(id int64) error {
	_, err := db.DB.Exec(`DELETE FROM sys_users WHERE id = ?`, id)
	return err
}
