package repo

import (
	"database/sql"
	"fmt"

	"groot-backend/internal/db"
	"groot-backend/internal/model"
)

func ListDutySchedules(year, month int) ([]model.DutySchedule, error) {
	endYear, endMonth := year, month+1
	if endMonth > 12 {
		endYear++
		endMonth = 1
	}
	rows, err := db.DB.Query(`
		SELECT id, schedule_date, department, position_name,
			primary_user, backup_user,
			created_by, updated_by, created_at, updated_at
		FROM sop_duty_schedules
		WHERE schedule_date >= ? AND schedule_date < ?
		ORDER BY schedule_date`,
		fmt.Sprintf("%04d-%02d-01", year, month),
		fmt.Sprintf("%04d-%02d-01", endYear, endMonth))
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.DutySchedule
	for rows.Next() {
		var d model.DutySchedule
		var updatedBy sql.NullString
		if err := rows.Scan(&d.ID, &d.ScheduleDate, &d.Department, &d.PositionName,
			&d.PrimaryUser, &d.BackupUser,
			&d.CreatedBy, &updatedBy, &d.CreatedAt, &d.UpdatedAt); err != nil {
			return nil, err
		}
		if updatedBy.Valid {
			d.UpdatedBy = &updatedBy.String
		}
		list = append(list, d)
	}
	return list, rows.Err()
}

func GetDutyScheduleByDate(date string) (*model.DutySchedule, error) {
	var d model.DutySchedule
	var updatedBy sql.NullString
	err := db.DB.QueryRow(`
		SELECT id, schedule_date, department, position_name,
			primary_user, backup_user,
			created_by, updated_by, created_at, updated_at
		FROM sop_duty_schedules
		WHERE schedule_date = ?
		LIMIT 1`, date).
		Scan(&d.ID, &d.ScheduleDate, &d.Department, &d.PositionName,
			&d.PrimaryUser, &d.BackupUser,
			&d.CreatedBy, &updatedBy, &d.CreatedAt, &d.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	if updatedBy.Valid {
		d.UpdatedBy = &updatedBy.String
	}
	return &d, nil
}

func GetDutySchedule(id int64) (*model.DutySchedule, error) {
	var d model.DutySchedule
	var updatedBy sql.NullString
	err := db.DB.QueryRow(`
		SELECT id, schedule_date, department, position_name,
			primary_user, backup_user,
			created_by, updated_by, created_at, updated_at
		FROM sop_duty_schedules
		WHERE id = ?`, id).
		Scan(&d.ID, &d.ScheduleDate, &d.Department, &d.PositionName,
			&d.PrimaryUser, &d.BackupUser,
			&d.CreatedBy, &updatedBy, &d.CreatedAt, &d.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	if updatedBy.Valid {
		d.UpdatedBy = &updatedBy.String
	}
	return &d, nil
}

func CreateDutySchedule(req *model.CreateDutyScheduleRequest, createdBy string) (*model.DutySchedule, error) {
	result, err := db.DB.Exec(`INSERT INTO sop_duty_schedules (schedule_date, department, position_name, primary_user, backup_user, created_by) VALUES (?, ?, ?, ?, ?, ?)`,
		req.ScheduleDate, req.Department, req.PositionName, req.PrimaryUser, req.BackupUser, createdBy)
	if err != nil {
		return nil, err
	}

	id, _ := result.LastInsertId()
	return GetDutySchedule(id)
}

func UpdateDutySchedule(id int64, req *model.UpdateDutyScheduleRequest, updatedBy string) (*model.DutySchedule, error) {
	existing, err := GetDutySchedule(id)
	if err != nil || existing == nil {
		return nil, err
	}

	department := existing.Department
	positionName := existing.PositionName
	primaryUser := existing.PrimaryUser
	backupUser := existing.BackupUser

	if req.Department != nil {
		department = *req.Department
	}
	if req.PositionName != nil {
		positionName = *req.PositionName
	}
	if req.PrimaryUser != nil {
		primaryUser = *req.PrimaryUser
	}
	if req.BackupUser != nil {
		backupUser = *req.BackupUser
	}

	_, err = db.DB.Exec(`UPDATE sop_duty_schedules SET department=?, position_name=?, primary_user=?, backup_user=?, updated_by=? WHERE id=?`,
		department, positionName, primaryUser, backupUser, updatedBy, id)
	if err != nil {
		return nil, err
	}

	return GetDutySchedule(id)
}

func DeleteDutySchedule(id int64) error {
	result, err := db.DB.Exec(`DELETE FROM sop_duty_schedules WHERE id = ?`, id)
	if err != nil {
		return err
	}
	affected, _ := result.RowsAffected()
	if affected == 0 {
		return sql.ErrNoRows
	}
	return nil
}
