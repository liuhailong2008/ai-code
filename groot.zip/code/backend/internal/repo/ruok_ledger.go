package repo

import (
	"database/sql"

	"groot-backend/internal/db"
	"groot-backend/internal/model"
)

// nullStrToPtr 将 sql.NullString 转换为 *string（NULL -> nil）。
func nullStrToPtr(n sql.NullString) *string {
	if n.Valid {
		return &n.String
	}
	return nil
}

// nullIntToPtr 将 sql.NullInt64 转换为 *int（NULL -> nil）。
func nullIntToPtr(n sql.NullInt64) *int {
	if n.Valid {
		v := int(n.Int64)
		return &v
	}
	return nil
}

// ============================================================
// IDC台账
// ============================================================

func ListIdcs(envCode, idcCode, idcStatus string) ([]model.Idc, error) {
	query := `SELECT id, env_code, idc_code, idc_name, is_xinchuang, idc_status, idc_remark,
		created_by, updated_by, created_at, updated_at FROM ruok_idcs WHERE 1=1`
	var args []interface{}
	if envCode != "" {
		query += ` AND env_code = ?`
		args = append(args, envCode)
	}
	if idcCode != "" {
		query += ` AND idc_code = ?`
		args = append(args, idcCode)
	}
	if idcStatus != "" {
		query += ` AND idc_status = ?`
		args = append(args, idcStatus)
	}
	query += ` ORDER BY id`

	rows, err := db.DB.Query(query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.Idc
	for rows.Next() {
		var d model.Idc
		var remark, updatedBy sql.NullString
		if err := rows.Scan(&d.ID, &d.EnvCode, &d.IdcCode, &d.IdcName, &d.IsXinchuang, &d.IdcStatus,
			&remark, &d.CreatedBy, &updatedBy, &d.CreatedAt, &d.UpdatedAt); err != nil {
			return nil, err
		}
		d.IdcRemark = nullStrToPtr(remark)
		d.UpdatedBy = nullStrToPtr(updatedBy)
		list = append(list, d)
	}
	if list == nil {
		list = []model.Idc{}
	}
	return list, rows.Err()
}

func GetIdc(id int64) (*model.Idc, error) {
	var d model.Idc
	var remark, updatedBy sql.NullString
	err := db.DB.QueryRow(`SELECT id, env_code, idc_code, idc_name, is_xinchuang, idc_status, idc_remark,
		created_by, updated_by, created_at, updated_at FROM ruok_idcs WHERE id = ?`, id).
		Scan(&d.ID, &d.EnvCode, &d.IdcCode, &d.IdcName, &d.IsXinchuang, &d.IdcStatus,
			&remark, &d.CreatedBy, &updatedBy, &d.CreatedAt, &d.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	d.IdcRemark = nullStrToPtr(remark)
	d.UpdatedBy = nullStrToPtr(updatedBy)
	return &d, nil
}

func CreateIdc(req *model.CreateIdcRequest, createdBy string) (*model.Idc, error) {
	isXinchuang := req.IsXinchuang
	if isXinchuang == "" {
		isXinchuang = "否"
	}
	idcStatus := req.IdcStatus
	if idcStatus == "" {
		idcStatus = "新建"
	}
	result, err := db.DB.Exec(`INSERT INTO ruok_idcs (env_code, idc_code, idc_name, is_xinchuang, idc_status, idc_remark, created_by)
		VALUES (?, ?, ?, ?, ?, ?, ?)`,
		req.EnvCode, req.IdcCode, req.IdcName, isXinchuang, idcStatus, req.IdcRemark, createdBy)
	if err != nil {
		return nil, err
	}
	id, _ := result.LastInsertId()
	return GetIdc(id)
}

func UpdateIdc(id int64, req *model.UpdateIdcRequest, updatedBy string) (*model.Idc, error) {
	existing, err := GetIdc(id)
	if err != nil || existing == nil {
		return nil, err
	}
	envCode := existing.EnvCode
	idcName := existing.IdcName
	isXinchuang := existing.IsXinchuang
	idcStatus := existing.IdcStatus
	remark := existing.IdcRemark
	if req.EnvCode != nil {
		envCode = *req.EnvCode
	}
	if req.IdcName != nil {
		idcName = *req.IdcName
	}
	if req.IsXinchuang != nil {
		isXinchuang = *req.IsXinchuang
	}
	if req.IdcStatus != nil {
		idcStatus = *req.IdcStatus
	}
	if req.IdcRemark != nil {
		remark = req.IdcRemark
	}
	_, err = db.DB.Exec(`UPDATE ruok_idcs SET env_code=?, idc_name=?, is_xinchuang=?, idc_status=?, idc_remark=?, updated_by=? WHERE id=?`,
		envCode, idcName, isXinchuang, idcStatus, remark, updatedBy, id)
	if err != nil {
		return nil, err
	}
	return GetIdc(id)
}

func DeleteIdc(id int64) error {
	return deleteByID("ruok_idcs", id)
}

// ============================================================
// 主机台账
// ============================================================

func ListHosts(envCode, idcCode, clusterCode, hostIP string, componentTreeID int64) ([]model.Host, error) {
	query := `SELECT id, env_code, idc_code, cluster_code, component_tree_id, host_ip, leaf_code, rack_code,
		cpu_cores, memory_gb, disk_gb, cpu_model, os_name, ssh_port, ssh_user,
		created_by, updated_by, created_at, updated_at FROM ruok_hosts WHERE 1=1`
	var args []interface{}
	if envCode != "" {
		query += ` AND env_code = ?`
		args = append(args, envCode)
	}
	if idcCode != "" {
		query += ` AND idc_code = ?`
		args = append(args, idcCode)
	}
	if clusterCode != "" {
		query += ` AND cluster_code = ?`
		args = append(args, clusterCode)
	}
	if componentTreeID != 0 {
		query += ` AND component_tree_id = ?`
		args = append(args, componentTreeID)
	}
	if hostIP != "" {
		query += ` AND host_ip = ?`
		args = append(args, hostIP)
	}
	query += ` ORDER BY id`

	rows, err := db.DB.Query(query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.Host
	for rows.Next() {
		var d model.Host
		var cpuCores, memoryGB, diskGB, sshPort, componentTreeIDVal sql.NullInt64
		var cpuModel, osName, sshUser, updatedBy sql.NullString
		if err := rows.Scan(&d.ID, &d.EnvCode, &d.IdcCode, &d.ClusterCode, &componentTreeIDVal, &d.HostIP, &d.LeafCode, &d.RackCode,
			&cpuCores, &memoryGB, &diskGB, &cpuModel, &osName, &sshPort, &sshUser,
			&d.CreatedBy, &updatedBy, &d.CreatedAt, &d.UpdatedAt); err != nil {
			return nil, err
		}
		d.ComponentTreeID = nullInt64ToPtr(componentTreeIDVal)
		d.CPUCores = nullIntToPtr(cpuCores)
		d.MemoryGB = nullIntToPtr(memoryGB)
		d.DiskGB = nullIntToPtr(diskGB)
		d.SSHPort = nullIntToPtr(sshPort)
		d.CPUModel = nullStrToPtr(cpuModel)
		d.OSName = nullStrToPtr(osName)
		d.SSHUser = nullStrToPtr(sshUser)
		d.UpdatedBy = nullStrToPtr(updatedBy)
		list = append(list, d)
	}
	if list == nil {
		list = []model.Host{}
	}
	return list, rows.Err()
}

func GetHost(id int64) (*model.Host, error) {
	var d model.Host
	var cpuCores, memoryGB, diskGB, sshPort, componentTreeIDVal sql.NullInt64
	var cpuModel, osName, sshUser, updatedBy sql.NullString
	err := db.DB.QueryRow(`SELECT id, env_code, idc_code, cluster_code, component_tree_id, host_ip, leaf_code, rack_code,
		cpu_cores, memory_gb, disk_gb, cpu_model, os_name, ssh_port, ssh_user,
		created_by, updated_by, created_at, updated_at FROM ruok_hosts WHERE id = ?`, id).
		Scan(&d.ID, &d.EnvCode, &d.IdcCode, &d.ClusterCode, &componentTreeIDVal, &d.HostIP, &d.LeafCode, &d.RackCode,
			&cpuCores, &memoryGB, &diskGB, &cpuModel, &osName, &sshPort, &sshUser,
			&d.CreatedBy, &updatedBy, &d.CreatedAt, &d.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	d.ComponentTreeID = nullInt64ToPtr(componentTreeIDVal)
	d.CPUCores = nullIntToPtr(cpuCores)
	d.MemoryGB = nullIntToPtr(memoryGB)
	d.DiskGB = nullIntToPtr(diskGB)
	d.SSHPort = nullIntToPtr(sshPort)
	d.CPUModel = nullStrToPtr(cpuModel)
	d.OSName = nullStrToPtr(osName)
	d.SSHUser = nullStrToPtr(sshUser)
	d.UpdatedBy = nullStrToPtr(updatedBy)
	return &d, nil
}

func CreateHost(req *model.CreateHostRequest, createdBy string) (*model.Host, error) {
	result, err := db.DB.Exec(`INSERT INTO ruok_hosts (env_code, idc_code, cluster_code, component_tree_id, host_ip, leaf_code, rack_code,
		cpu_cores, memory_gb, disk_gb, cpu_model, os_name, ssh_port, ssh_user, created_by)
		VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		req.EnvCode, req.IdcCode, req.ClusterCode, req.ComponentTreeID, req.HostIP, req.LeafCode, req.RackCode,
		req.CPUCores, req.MemoryGB, req.DiskGB, req.CPUModel, req.OSName, req.SSHPort, req.SSHUser, createdBy)
	if err != nil {
		return nil, err
	}
	id, _ := result.LastInsertId()
	return GetHost(id)
}

func UpdateHost(id int64, req *model.UpdateHostRequest, updatedBy string) (*model.Host, error) {
	existing, err := GetHost(id)
	if err != nil || existing == nil {
		return nil, err
	}
	envCode := existing.EnvCode
	idcCode := existing.IdcCode
	clusterCode := existing.ClusterCode
	componentTreeID := existing.ComponentTreeID
	hostIP := existing.HostIP
	leafCode := existing.LeafCode
	rackCode := existing.RackCode
	cpuCores := existing.CPUCores
	memoryGB := existing.MemoryGB
	diskGB := existing.DiskGB
	cpuModel := existing.CPUModel
	osName := existing.OSName
	sshPort := existing.SSHPort
	sshUser := existing.SSHUser
	if req.EnvCode != nil {
		envCode = *req.EnvCode
	}
	if req.IdcCode != nil {
		idcCode = *req.IdcCode
	}
	if req.ClusterCode != nil {
		clusterCode = *req.ClusterCode
	}
	if req.ComponentTreeID != nil {
		componentTreeID = req.ComponentTreeID
	}
	if req.HostIP != nil {
		hostIP = *req.HostIP
	}
	if req.LeafCode != nil {
		leafCode = *req.LeafCode
	}
	if req.RackCode != nil {
		rackCode = *req.RackCode
	}
	if req.CPUCores != nil {
		cpuCores = req.CPUCores
	}
	if req.MemoryGB != nil {
		memoryGB = req.MemoryGB
	}
	if req.DiskGB != nil {
		diskGB = req.DiskGB
	}
	if req.CPUModel != nil {
		cpuModel = req.CPUModel
	}
	if req.OSName != nil {
		osName = req.OSName
	}
	if req.SSHPort != nil {
		sshPort = req.SSHPort
	}
	if req.SSHUser != nil {
		sshUser = req.SSHUser
	}
	_, err = db.DB.Exec(`UPDATE ruok_hosts SET env_code=?, idc_code=?, cluster_code=?, component_tree_id=?, host_ip=?, leaf_code=?, rack_code=?,
		cpu_cores=?, memory_gb=?, disk_gb=?, cpu_model=?, os_name=?, ssh_port=?, ssh_user=?, updated_by=? WHERE id=?`,
		envCode, idcCode, clusterCode, componentTreeID, hostIP, leafCode, rackCode,
		cpuCores, memoryGB, diskGB, cpuModel, osName, sshPort, sshUser, updatedBy, id)
	if err != nil {
		return nil, err
	}
	return GetHost(id)
}

func DeleteHost(id int64) error {
	return deleteByID("ruok_hosts", id)
}

// ============================================================
// 域名台账
// ============================================================

func ListDomains(envCode, idcCode, domainType string) ([]model.Domain, error) {
	query := `SELECT id, env_code, idc_code, domain_type, domain_name, target_host,
		created_by, updated_by, created_at, updated_at FROM ruok_domains WHERE 1=1`
	var args []interface{}
	if envCode != "" {
		query += ` AND env_code = ?`
		args = append(args, envCode)
	}
	if idcCode != "" {
		query += ` AND idc_code = ?`
		args = append(args, idcCode)
	}
	if domainType != "" {
		query += ` AND domain_type = ?`
		args = append(args, domainType)
	}
	query += ` ORDER BY id`

	rows, err := db.DB.Query(query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.Domain
	for rows.Next() {
		var d model.Domain
		var targetHost, updatedBy sql.NullString
		if err := rows.Scan(&d.ID, &d.EnvCode, &d.IdcCode, &d.DomainType, &d.DomainName, &targetHost,
			&d.CreatedBy, &updatedBy, &d.CreatedAt, &d.UpdatedAt); err != nil {
			return nil, err
		}
		d.TargetHost = nullStrToPtr(targetHost)
		d.UpdatedBy = nullStrToPtr(updatedBy)
		list = append(list, d)
	}
	if list == nil {
		list = []model.Domain{}
	}
	return list, rows.Err()
}

func GetDomain(id int64) (*model.Domain, error) {
	var d model.Domain
	var targetHost, updatedBy sql.NullString
	err := db.DB.QueryRow(`SELECT id, env_code, idc_code, domain_type, domain_name, target_host,
		created_by, updated_by, created_at, updated_at FROM ruok_domains WHERE id = ?`, id).
		Scan(&d.ID, &d.EnvCode, &d.IdcCode, &d.DomainType, &d.DomainName, &targetHost,
			&d.CreatedBy, &updatedBy, &d.CreatedAt, &d.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	d.TargetHost = nullStrToPtr(targetHost)
	d.UpdatedBy = nullStrToPtr(updatedBy)
	return &d, nil
}

func CreateDomain(req *model.CreateDomainRequest, createdBy string) (*model.Domain, error) {
	result, err := db.DB.Exec(`INSERT INTO ruok_domains (env_code, idc_code, domain_type, domain_name, target_host, created_by)
		VALUES (?, ?, ?, ?, ?, ?)`,
		req.EnvCode, req.IdcCode, req.DomainType, req.DomainName, req.TargetHost, createdBy)
	if err != nil {
		return nil, err
	}
	id, _ := result.LastInsertId()
	return GetDomain(id)
}

func UpdateDomain(id int64, req *model.UpdateDomainRequest, updatedBy string) (*model.Domain, error) {
	existing, err := GetDomain(id)
	if err != nil || existing == nil {
		return nil, err
	}
	envCode := existing.EnvCode
	idcCode := existing.IdcCode
	domainType := existing.DomainType
	domainName := existing.DomainName
	targetHost := existing.TargetHost
	if req.EnvCode != nil {
		envCode = *req.EnvCode
	}
	if req.IdcCode != nil {
		idcCode = *req.IdcCode
	}
	if req.DomainType != nil {
		domainType = *req.DomainType
	}
	if req.DomainName != nil {
		domainName = *req.DomainName
	}
	if req.TargetHost != nil {
		targetHost = req.TargetHost
	}
	_, err = db.DB.Exec(`UPDATE ruok_domains SET env_code=?, idc_code=?, domain_type=?, domain_name=?, target_host=?, updated_by=? WHERE id=?`,
		envCode, idcCode, domainType, domainName, targetHost, updatedBy, id)
	if err != nil {
		return nil, err
	}
	return GetDomain(id)
}

func DeleteDomain(id int64) error {
	return deleteByID("ruok_domains", id)
}

// ============================================================
// CMDB同步差异
// ============================================================

func ListCmdbSyncDiffs(batchCode, idcCode, diffStatus string) ([]model.CmdbSyncDiff, error) {
	query := `SELECT id, batch_code, env_code, idc_code, diff_type, host_ip, diff_status, sync_remark,
		created_by, updated_by, created_at, updated_at FROM ruok_cmdb_sync_diff WHERE 1=1`
	var args []interface{}
	if batchCode != "" {
		query += ` AND batch_code = ?`
		args = append(args, batchCode)
	}
	if idcCode != "" {
		query += ` AND idc_code = ?`
		args = append(args, idcCode)
	}
	if diffStatus != "" {
		query += ` AND diff_status = ?`
		args = append(args, diffStatus)
	}
	query += ` ORDER BY id`

	rows, err := db.DB.Query(query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.CmdbSyncDiff
	for rows.Next() {
		var d model.CmdbSyncDiff
		var remark, updatedBy sql.NullString
		if err := rows.Scan(&d.ID, &d.BatchCode, &d.EnvCode, &d.IdcCode, &d.DiffType, &d.HostIP, &d.DiffStatus,
			&remark, &d.CreatedBy, &updatedBy, &d.CreatedAt, &d.UpdatedAt); err != nil {
			return nil, err
		}
		d.SyncRemark = nullStrToPtr(remark)
		d.UpdatedBy = nullStrToPtr(updatedBy)
		list = append(list, d)
	}
	if list == nil {
		list = []model.CmdbSyncDiff{}
	}
	return list, rows.Err()
}

// deleteByID 删除指定表的一行，未命中返回 sql.ErrNoRows。
func deleteByID(table string, id int64) error {
	result, err := db.DB.Exec(`DELETE FROM `+table+` WHERE id = ?`, id)
	if err != nil {
		return err
	}
	affected, _ := result.RowsAffected()
	if affected == 0 {
		return sql.ErrNoRows
	}
	return nil
}
