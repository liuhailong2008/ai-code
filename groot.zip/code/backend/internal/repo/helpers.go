package repo

import (
	"fmt"
	"math/rand"
	"time"
)

func RandomID() string {
	return fmt.Sprintf("%d", 10000+rand.Intn(90000))
}

func NowISO() string {
	return time.Now().UTC().Format("2006-01-02T15:04:05Z")
}
