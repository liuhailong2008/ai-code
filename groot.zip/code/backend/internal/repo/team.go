package repo

import (
	"database/sql"

	"groot-backend/internal/db"
	"groot-backend/internal/model"
)

func ListTeams() ([]model.Team, error) {
	rows, err := db.DB.Query(`SELECT id, code, name, description, wechat_id, team_email, tech_leader, team_leader, created_by, updated_by, created_at, updated_at FROM sys_teams ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var teams []model.Team
	for rows.Next() {
		var t model.Team
		if err := rows.Scan(&t.ID, &t.Code, &t.Name, &t.Description, &t.WechatID, &t.TeamEmail, &t.TechLeader, &t.TeamLeader, &t.CreatedBy, &t.UpdatedBy, &t.CreatedAt, &t.UpdatedAt); err != nil {
			return nil, err
		}
		teams = append(teams, t)
	}
	return teams, rows.Err()
}

func GetTeam(id int64) (*model.Team, error) {
	var t model.Team
	err := db.DB.QueryRow(`SELECT id, code, name, description, wechat_id, team_email, tech_leader, team_leader, created_by, updated_by, created_at, updated_at FROM sys_teams WHERE id = ?`, id).
		Scan(&t.ID, &t.Code, &t.Name, &t.Description, &t.WechatID, &t.TeamEmail, &t.TechLeader, &t.TeamLeader, &t.CreatedBy, &t.UpdatedBy, &t.CreatedAt, &t.UpdatedAt)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return &t, nil
}

func CreateTeam(req *model.CreateTeamRequest, createdBy string) (*model.Team, error) {
	result, err := db.DB.Exec(`INSERT INTO sys_teams (code, name, description, wechat_id, team_email, tech_leader, team_leader, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
		req.Code, req.Name, req.Description, req.WechatID, req.TeamEmail, req.TechLeader, req.TeamLeader, createdBy)
	if err != nil {
		return nil, err
	}
	id, _ := result.LastInsertId()
	return GetTeam(id)
}

func UpdateTeam(id int64, req *model.UpdateTeamRequest, updatedBy string) (*model.Team, error) {
	existing, err := GetTeam(id)
	if err != nil || existing == nil {
		return nil, err
	}

	code := existing.Code
	name := existing.Name
	description := existing.Description
	wechatID := existing.WechatID
	teamEmail := existing.TeamEmail
	techLeader := existing.TechLeader
	teamLeader := existing.TeamLeader

	if req.Code != nil {
		code = *req.Code
	}
	if req.Name != nil {
		name = *req.Name
	}
	if req.Description != nil {
		description = req.Description
	}
	if req.WechatID != nil {
		wechatID = req.WechatID
	}
	if req.TeamEmail != nil {
		teamEmail = req.TeamEmail
	}
	if req.TechLeader != nil {
		techLeader = req.TechLeader
	}
	if req.TeamLeader != nil {
		teamLeader = req.TeamLeader
	}

	_, err = db.DB.Exec(`UPDATE sys_teams SET code=?, name=?, description=?, wechat_id=?, team_email=?, tech_leader=?, team_leader=?, updated_by=? WHERE id=?`,
		code, name, description, wechatID, teamEmail, techLeader, teamLeader, updatedBy, id)
	if err != nil {
		return nil, err
	}
	return GetTeam(id)
}

func DeleteTeam(id int64) error {
	result, err := db.DB.Exec(`DELETE FROM sys_teams WHERE id = ?`, id)
	if err != nil {
		return err
	}
	affected, _ := result.RowsAffected()
	if affected == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func ListTeamMembers(teamID int64) ([]model.TeamMember, error) {
	rows, err := db.DB.Query(
		`SELECT tm.id, tm.user_id, tm.team_id, tm.created_at, tm.updated_at,
		        u.username, u.display_name, u.role
		 FROM sys_team_members tm
		 JOIN sys_users u ON u.id = tm.user_id
		 WHERE tm.team_id = ?
		 ORDER BY tm.id`, teamID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var members []model.TeamMember
	for rows.Next() {
		var m model.TeamMember
		if err := rows.Scan(&m.ID, &m.UserID, &m.TeamID, &m.CreatedAt, &m.UpdatedAt,
			&m.Username, &m.DisplayName, &m.Role); err != nil {
			return nil, err
		}
		members = append(members, m)
	}
	if members == nil {
		members = []model.TeamMember{}
	}
	return members, rows.Err()
}

func AddTeamMember(teamID, userID int64) (*model.TeamMember, error) {
	result, err := db.DB.Exec(
		`INSERT INTO sys_team_members (user_id, team_id) VALUES (?, ?)`,
		userID, teamID)
	if err != nil {
		return nil, err
	}
	id, _ := result.LastInsertId()
	return GetTeamMember(id)
}

func GetTeamMember(id int64) (*model.TeamMember, error) {
	var m model.TeamMember
	err := db.DB.QueryRow(
		`SELECT tm.id, tm.user_id, tm.team_id, tm.created_at, tm.updated_at,
		        u.username, u.display_name, u.role
		 FROM sys_team_members tm
		 JOIN sys_users u ON u.id = tm.user_id
		 WHERE tm.id = ?`, id).
		Scan(&m.ID, &m.UserID, &m.TeamID, &m.CreatedAt, &m.UpdatedAt,
			&m.Username, &m.DisplayName, &m.Role)
	if err == sql.ErrNoRows {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	return &m, nil
}

func RemoveTeamMember(teamID, userID int64) error {
	result, err := db.DB.Exec(
		`DELETE FROM sys_team_members WHERE team_id = ? AND user_id = ?`,
		teamID, userID)
	if err != nil {
		return err
	}
	affected, _ := result.RowsAffected()
	if affected == 0 {
		return sql.ErrNoRows
	}
	return nil
}

func ListUserTeams(userID int64) ([]model.Team, error) {
	rows, err := db.DB.Query(
		`SELECT t.id, t.code, t.name, t.description, t.wechat_id, t.team_email, t.tech_leader, t.team_leader, t.created_by, t.updated_by, t.created_at, t.updated_at
		 FROM sys_teams t
		 JOIN sys_team_members ut ON ut.team_id = t.id
		 WHERE ut.user_id = ?
		 ORDER BY t.id`, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var teams []model.Team
	for rows.Next() {
		var t model.Team
		if err := rows.Scan(&t.ID, &t.Code, &t.Name, &t.Description, &t.WechatID, &t.TeamEmail, &t.TechLeader, &t.TeamLeader, &t.CreatedBy, &t.UpdatedBy, &t.CreatedAt, &t.UpdatedAt); err != nil {
			return nil, err
		}
		teams = append(teams, t)
	}
	if teams == nil {
		teams = []model.Team{}
	}
	return teams, rows.Err()
}

func SearchUsers(keyword string) ([]model.User, error) {
	var rows *sql.Rows
	var err error
	if keyword == "" {
		rows, err = db.DB.Query(
			`SELECT id, username, mobile, password, display_name, role, created_at, updated_at
			 FROM sys_users
			 ORDER BY display_name
			 LIMIT 5`)
	} else {
		rows, err = db.DB.Query(
			`SELECT id, username, mobile, password, display_name, role, created_at, updated_at
			 FROM sys_users
			 WHERE username LIKE ? OR display_name LIKE ?
			 ORDER BY display_name
			 LIMIT 20`,
			"%"+keyword+"%", "%"+keyword+"%")
	}
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var users []model.User
	for rows.Next() {
		var u model.User
		var mobileCipher string
		if err := rows.Scan(&u.ID, &u.Username, &mobileCipher, &u.Password, &u.DisplayName, &u.Role, &u.CreatedAt, &u.UpdatedAt); err != nil {
			return nil, err
		}
		u.Mobile, _ = decryptMobile(mobileCipher)
		users = append(users, u)
	}
	if users == nil {
		users = []model.User{}
	}
	return users, rows.Err()
}
