package repo

import (
	"groot-backend/internal/db"
	"groot-backend/internal/model"
)

// --- Skills ---

func ListSkills() ([]model.Skill, error) {
	rows, err := db.DB.Query(
		`SELECT id, skill_name, skill_code, description, version, file_path,
		        is_enabled, created_by, updated_by, created_at, updated_at
		 FROM skills ORDER BY id DESC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.Skill
	for rows.Next() {
		var s model.Skill
		if err := rows.Scan(&s.ID, &s.SkillName, &s.SkillCode, &s.Description, &s.Version,
			&s.FilePath, &s.IsEnabled, &s.CreatedBy, &s.UpdatedBy, &s.CreatedAt, &s.UpdatedAt); err != nil {
			return nil, err
		}
		list = append(list, s)
	}
	return list, nil
}

func GetSkill(id int64) (*model.Skill, error) {
	var s model.Skill
	err := db.DB.QueryRow(
		`SELECT id, skill_name, skill_code, description, version, file_path,
		        is_enabled, created_by, updated_by, created_at, updated_at
		 FROM skills WHERE id = ?`, id).Scan(
		&s.ID, &s.SkillName, &s.SkillCode, &s.Description, &s.Version,
		&s.FilePath, &s.IsEnabled, &s.CreatedBy, &s.UpdatedBy, &s.CreatedAt, &s.UpdatedAt)
	if err != nil {
		return nil, err
	}
	return &s, nil
}

func GetSkillByCode(code string) (*model.Skill, error) {
	var s model.Skill
	err := db.DB.QueryRow(
		`SELECT id, skill_name, skill_code, description, version, file_path,
		        is_enabled, created_by, updated_by, created_at, updated_at
		 FROM skills WHERE skill_code = ?`, code).Scan(
		&s.ID, &s.SkillName, &s.SkillCode, &s.Description, &s.Version,
		&s.FilePath, &s.IsEnabled, &s.CreatedBy, &s.UpdatedBy, &s.CreatedAt, &s.UpdatedAt)
	if err != nil {
		return nil, err
	}
	return &s, nil
}

func CreateSkill(skill *model.Skill) (int64, error) {
	result, err := db.DB.Exec(
		`INSERT INTO skills (skill_name, skill_code, description, version, file_path, created_by)
		 VALUES (?, ?, ?, ?, ?, ?)`,
		skill.SkillName, skill.SkillCode, skill.Description, skill.Version, skill.FilePath, skill.CreatedBy)
	if err != nil {
		return 0, err
	}
	return result.LastInsertId()
}

func UpdateSkill(id int64, req *model.UpdateSkillRequest, updatedBy string) error {
	_, err := db.DB.Exec(
		`UPDATE skills SET
			skill_name  = COALESCE(NULLIF(?, ''), skill_name),
			skill_code  = COALESCE(NULLIF(?, ''), skill_code),
			description = COALESCE(NULLIF(?, ''), description),
			version     = COALESCE(NULLIF(?, ''), version),
			is_enabled  = COALESCE(?, is_enabled),
			updated_by  = ?
		 WHERE id = ?`,
		req.SkillName, req.SkillCode, req.Description, req.Version, req.IsEnabled, updatedBy, id)
	return err
}

func DeleteSkill(id int64) error {
	_, err := db.DB.Exec(`DELETE FROM skills WHERE id = ?`, id)
	return err
}

// --- Skill Files ---

func ListSkillFiles(skillID int64) ([]model.SkillFile, error) {
	rows, err := db.DB.Query(
		`SELECT id, skill_id, file_name, file_path, file_type, parent_path, created_at
		 FROM skill_files WHERE skill_id = ? ORDER BY file_type, file_path`, skillID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.SkillFile
	for rows.Next() {
		var f model.SkillFile
		if err := rows.Scan(&f.ID, &f.SkillID, &f.FileName, &f.FilePath, &f.FileType, &f.ParentPath, &f.CreatedAt); err != nil {
			return nil, err
		}
		list = append(list, f)
	}
	return list, nil
}

func InsertSkillFile(f *model.SkillFile) error {
	_, err := db.DB.Exec(
		`INSERT INTO skill_files (skill_id, file_name, file_path, file_type, parent_path)
		 VALUES (?, ?, ?, ?, ?)`,
		f.SkillID, f.FileName, f.FilePath, f.FileType, f.ParentPath)
	return err
}

func DeleteSkillFiles(skillID int64) error {
	_, err := db.DB.Exec(`DELETE FROM skill_files WHERE skill_id = ?`, skillID)
	return err
}

func DeleteSkillFileByPath(skillID int64, filePath string) error {
	_, err := db.DB.Exec(`DELETE FROM skill_files WHERE skill_id = ? AND file_path = ?`, skillID, filePath)
	return err
}
