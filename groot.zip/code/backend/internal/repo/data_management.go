package repo

import (
	"fmt"
	"strings"
	"time"

	"groot-backend/internal/db"
)

type TableInfo struct {
	Name     string `json:"name"`
	RowCount int    `json:"rowCount"`
}

type TableData struct {
	Columns []string                 `json:"columns"`
	Rows    []map[string]interface{} `json:"rows"`
	Total   int                      `json:"total"`
	Page    int                      `json:"page"`
	PageSize int                     `json:"pageSize"`
}

func ListTables() ([]TableInfo, error) {
	rows, err := db.DB.Query(`SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_NAME`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var tables []TableInfo
	for rows.Next() {
		var t TableInfo
		if err := rows.Scan(&t.Name); err != nil {
			return nil, err
		}
		tables = append(tables, t)
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}

	// 用 COUNT(*) 获取实际行数（information_schema.TABLE_ROWS 是估算值）
	for i := range tables {
		tables[i].RowCount = getRealRowCount(tables[i].Name)
	}

	return tables, nil
}

func getRealRowCount(tableName string) int {
	var count int
	db.DB.QueryRow(fmt.Sprintf("SELECT COUNT(*) FROM `%s`", tableName)).Scan(&count)
	return count
}

func GetTableData(tableName string, page, pageSize int) (*TableData, error) {
	if !validTableName(tableName) {
		return nil, nil
	}

	total := getRealRowCount(tableName)

	offset := (page - 1) * pageSize
	rows, err := db.DB.Query(fmt.Sprintf("SELECT * FROM `%s` LIMIT %d OFFSET %d", tableName, pageSize, offset))
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	columns, err := rows.Columns()
	if err != nil {
		return nil, err
	}

	var result []map[string]interface{}
	for rows.Next() {
		values := make([]interface{}, len(columns))
		valuePtrs := make([]interface{}, len(columns))
		for i := range values {
			valuePtrs[i] = &values[i]
		}
		if err := rows.Scan(valuePtrs...); err != nil {
			return nil, err
		}
		row := make(map[string]interface{})
		for i, col := range columns {
			val := values[i]
			if b, ok := val.([]byte); ok {
				row[col] = string(b)
			} else {
				row[col] = val
			}
		}
		result = append(result, row)
	}
	if result == nil {
		result = []map[string]interface{}{}
	}

	return &TableData{Columns: columns, Rows: result, Total: total, Page: page, PageSize: pageSize}, rows.Err()
}

func InsertRow(tableName string, data map[string]interface{}) (map[string]interface{}, error) {
	if !validTableName(tableName) {
		return nil, fmt.Errorf("invalid table name")
	}

	now := time.Now().Format("2006-01-02 15:04:05")

	var cols []string
	var placeholders []string
	var values []interface{}
	for k, v := range data {
		// created_at / updated_at 未填时使用当前时间
		if (k == "created_at" || k == "updated_at") && v == nil {
			v = now
		}
		cols = append(cols, "`"+k+"`")
		placeholders = append(placeholders, "?")
		values = append(values, v)
	}

	query := fmt.Sprintf("INSERT INTO `%s` (%s) VALUES (%s)", tableName, strings.Join(cols, ","), strings.Join(placeholders, ","))
	result, err := db.DB.Exec(query, values...)
	if err != nil {
		return nil, err
	}
	id, _ := result.LastInsertId()

	// Return the inserted row
	return map[string]interface{}{"id": id}, nil
}

func UpdateRow(tableName string, rowID int64, data map[string]interface{}) error {
	if !validTableName(tableName) {
		return fmt.Errorf("invalid table name")
	}

	now := time.Now().Format("2006-01-02 15:04:05")

	var sets []string
	var values []interface{}
	for k, v := range data {
		if (k == "created_at" || k == "updated_at") && v == nil {
			v = now
		}
		sets = append(sets, fmt.Sprintf("`%s` = ?", k))
		values = append(values, v)
	}
	values = append(values, rowID)

	query := fmt.Sprintf("UPDATE `%s` SET %s WHERE id = ?", tableName, strings.Join(sets, ", "))
	_, err := db.DB.Exec(query, values...)
	return err
}

func DeleteRow(tableName string, rowID int64) error {
	if !validTableName(tableName) {
		return fmt.Errorf("invalid table name")
	}
	_, err := db.DB.Exec(fmt.Sprintf("DELETE FROM `%s` WHERE id = ?", tableName), rowID)
	return err
}

func validTableName(name string) bool {
	for _, c := range name {
		if !((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_') {
			return false
		}
	}
	return len(name) > 0
}
