package repo

// normalizeJSONNull 将 Dolt 内嵌驱动返回的 JSON NULL（字符串 "null"）归一化为 nil。
//
// 迁移前 MySQL 对 JSON 列的 NULL 扫描进 *string 时返回 nil，而 Dolt 内嵌驱动
// 会返回非 nil 的 *string 且其值等于 "null"。这里在 Scan 之后统一纠正，
// 以保持对外行为一致。
func normalizeJSONNull(s **string) {
	if *s != nil && **s == "null" {
		*s = nil
	}
}
