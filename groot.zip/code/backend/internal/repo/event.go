package repo

import (
	"database/sql"
	"encoding/json"
	"strings"
	"time"

	dbpkg "groot-backend/internal/db"
	"groot-backend/internal/model"
)

// ============================================================
// Events
// ============================================================

func ListEvents() []model.Event {
	rows, err := dbpkg.DB.Query(`
		SELECT e.id, e.team_id, e.event_title, COALESCE(st.text_content, ''),
		       e.event_status, e.event_severity, e.event_category,
		       COALESCE(e.idc_name, ''), COALESCE(e.app_name, ''), COALESCE(e.cluster_name, ''),
		       e.event_source, e.created_by, COALESCE(e.uni_no, ''), COALESCE(e.ext_ticket_id, ''),
		       COALESCE(e.event_metadata, ''),
		       e.opened_at, e.closed_at, e.created_at, e.updated_at
		FROM event_records e
		LEFT JOIN sys_texts st ON e.desc_text_id = st.id
		ORDER BY e.id DESC
	`)
	if err != nil {
		return []model.Event{}
	}
	defer rows.Close()

	var events []model.Event
	for rows.Next() {
		var ev model.Event
		var closedAt sql.NullTime
		if err := rows.Scan(&ev.ID, &ev.TeamID, &ev.Title, &ev.Description,
			&ev.Status, &ev.Severity, &ev.Category,
			&ev.IdcName, &ev.AppName, &ev.ClusterName,
			&ev.Source, &ev.CreatedBy, &ev.UniNo, &ev.ExtTicketID,
			&ev.Metadata,
			&ev.OpenedAt, &closedAt, &ev.CreatedAt, &ev.UpdatedAt); err != nil {
			continue
		}
		formatTime(&ev.OpenedAt)
		formatTime(&ev.CreatedAt)
		formatTime(&ev.UpdatedAt)
		if closedAt.Valid {
			ev.ClosedAt = closedAt.Time.Format("2006-01-02 15:04:05")
		}

		ev.Participants = listParticipants(ev.ID)
		events = append(events, ev)
	}
	return events
}

func GetEvent(id int64) *model.Event {
	var ev model.Event
	var descTextID sql.NullInt64
	var closedAt sql.NullTime
	err := dbpkg.DB.QueryRow(`
		SELECT e.id, e.team_id, e.event_title, COALESCE(st.text_content, ''),
		       e.event_status, e.event_severity, e.event_category,
		       COALESCE(e.idc_name, ''), COALESCE(e.app_name, ''), COALESCE(e.cluster_name, ''),
		       e.event_source, e.created_by, COALESCE(e.uni_no, ''), COALESCE(e.ext_ticket_id, ''),
		       COALESCE(e.event_metadata, ''),
		       e.opened_at, e.closed_at, e.created_at, e.updated_at,
		       e.desc_text_id
		FROM event_records e
		LEFT JOIN sys_texts st ON e.desc_text_id = st.id
		WHERE e.id = ?
	`, id).Scan(&ev.ID, &ev.TeamID, &ev.Title, &ev.Description,
		&ev.Status, &ev.Severity, &ev.Category,
		&ev.IdcName, &ev.AppName, &ev.ClusterName,
		&ev.Source, &ev.CreatedBy, &ev.UniNo, &ev.ExtTicketID,
		&ev.Metadata,
		&ev.OpenedAt, &closedAt, &ev.CreatedAt, &ev.UpdatedAt,
		&descTextID)
	if err != nil {
		return nil
	}
	formatTime(&ev.OpenedAt)
	formatTime(&ev.CreatedAt)
	formatTime(&ev.UpdatedAt)
	if closedAt.Valid {
		ev.ClosedAt = closedAt.Time.Format("2006-01-02 15:04:05")
	}

	ev.Participants = listParticipants(ev.ID)
	return &ev
}

func CreateEvent(req *model.CreateEventRequest) *model.Event {
	now := time.Now().Format("2006-01-02 15:04:05")

	// 插入描述到 sys_texts
	var descTextID int64
	if req.Description != "" {
		res, err := dbpkg.DB.Exec("INSERT INTO sys_texts (text_content, created_at) VALUES (?, ?)", req.Description, now)
		if err == nil {
			descTextID, _ = res.LastInsertId()
		}
	}

	source := req.Source
	if source == "" {
		source = "manual"
	}
	metadata := map[string]string{}
	if req.AppName != "" {
		metadata["app_name"] = req.AppName
	}
	if req.ClusterName != "" {
		metadata["cluster_name"] = req.ClusterName
	}
	metadataJSON, _ := json.Marshal(metadata)

	var descTextIDArg interface{}
	if descTextID > 0 {
		descTextIDArg = descTextID
	}

	res, err := dbpkg.DB.Exec(`
		INSERT INTO event_records (team_id, event_title, desc_text_id, event_status, event_severity,
			event_category, idc_name, app_name, cluster_name, event_source,
			created_by, uni_no, event_metadata, opened_at, created_at, updated_at)
		VALUES (?, ?, ?, 'open', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
	`, req.TeamID, req.Title, descTextIDArg,
		coalesce(req.Severity, "medium"),
		req.Category,
		req.IdcName, req.AppName, req.ClusterName, source,
		"system", req.UniNo, string(metadataJSON),
		now, now, now)
	if err != nil {
		return nil
	}

	id, _ := res.LastInsertId()
	return GetEvent(id)
}

func UpdateEventState(id int64, status string) *model.Event {
	_, err := dbpkg.DB.Exec("UPDATE event_records SET event_status = ?, updated_at = ? WHERE id = ?",
		status, time.Now().Format("2006-01-02 15:04:05"), id)
	if err != nil {
		return nil
	}
	return GetEvent(id)
}

// ============================================================
// Participants
// ============================================================

func listParticipants(eventID int64) []model.EventParticipant {
	rows, err := dbpkg.DB.Query(`
		SELECT ep.user_id, ep.user_name, COALESCE(u.display_name, ep.user_name), COALESCE(ep.user_avatar, ''), ep.participant_role, ep.joined_at
		FROM event_participants ep
		LEFT JOIN sys_users u ON ep.user_id = u.id
		WHERE ep.event_id = ?
		ORDER BY ep.id
	`, eventID)
	if err != nil {
		return nil
	}
	defer rows.Close()

	var parts []model.EventParticipant
	for rows.Next() {
		var p model.EventParticipant
		if err := rows.Scan(&p.UserID, &p.UserName, &p.DisplayName, &p.UserAvatar, &p.Role, &p.JoinedAt); err != nil {
			continue
		}
		formatTime(&p.JoinedAt)
		parts = append(parts, p)
	}
	if parts == nil {
		parts = []model.EventParticipant{}
	}
	return parts
}

// ============================================================
// Messages
// ============================================================

func GetMessages(eventID int64) []model.Message {
	rows, err := dbpkg.DB.Query(`
		SELECT m.id, m.event_id, m.actor_id, COALESCE(st.text_content, ''),
		       m.msg_role, m.created_at
		FROM event_messages m
		LEFT JOIN sys_texts st ON m.content_text_id = st.id
		WHERE m.event_id = ?
		ORDER BY m.id
	`, eventID)
	if err != nil {
		return []model.Message{}
	}
	defer rows.Close()

	var msgs []model.Message
	idIndex := map[int64]int{}
	for rows.Next() {
		var msg model.Message
		if err := rows.Scan(&msg.ID, &msg.EventID, &msg.ActorID, &msg.Content,
			&msg.Role, &msg.CreatedAt); err != nil {
			continue
		}
		formatTime(&msg.CreatedAt)
		msg.Mentions = []string{}
		idIndex[msg.ID] = len(msgs)
		msgs = append(msgs, msg)
	}

	// 一次性把 mentions 拼回去
	if len(msgs) > 0 {
		mRows, mErr := dbpkg.DB.Query(`
			SELECT message_id, mentioned_user
			FROM event_message_mentions
			WHERE event_id = ?
		`, eventID)
		if mErr == nil {
			defer mRows.Close()
			for mRows.Next() {
				var mid int64
				var user string
				if err := mRows.Scan(&mid, &user); err != nil {
					continue
				}
				if idx, ok := idIndex[mid]; ok {
					msgs[idx].Mentions = append(msgs[idx].Mentions, user)
				}
			}
		}
	}
	return msgs
}

func AddMessage(eventID int64, actorID string, req *model.CreateMessageRequest) *model.Message {
	return addMessageWithRole(eventID, actorID, "user", req.Content, req.Mentions)
}

func addMessageWithRole(eventID int64, actorID, role, content string, mentions []string) *model.Message {
	now := time.Now().Format("2006-01-02 15:04:05")

	// 插入消息内容到 sys_texts
	res, err := dbpkg.DB.Exec("INSERT INTO sys_texts (text_content, created_at) VALUES (?, ?)", content, now)
	if err != nil {
		return nil
	}
	contentTextID, _ := res.LastInsertId()

	res, err = dbpkg.DB.Exec(`
		INSERT INTO event_messages (event_id, actor_id, msg_role, content_text_id, created_at)
		VALUES (?, ?, ?, ?, ?)
	`, eventID, actorID, role, contentTextID, now)
	if err != nil {
		return nil
	}
	msgID, _ := res.LastInsertId()

	// 写入 mentions（去重并校验存在的 sys_users）
	cleanMentions := dedupMentions(mentions)
	if len(cleanMentions) > 0 {
		valid := filterExistingUsers(cleanMentions)
		for _, u := range valid {
			dbpkg.DB.Exec(`
				INSERT IGNORE INTO event_message_mentions (event_id, message_id, mentioned_user, created_at)
				VALUES (?, ?, ?, ?)
			`, eventID, msgID, u, now)
		}
		cleanMentions = valid
	}

	return &model.Message{
		ID:        msgID,
		EventID:   eventID,
		ActorID:   actorID,
		Content:   content,
		Role:      role,
		CreatedAt: now,
		Mentions:  cleanMentions,
	}
}

func dedupMentions(in []string) []string {
	seen := map[string]struct{}{}
	out := []string{}
	for _, s := range in {
		if s == "" {
			continue
		}
		if _, ok := seen[s]; ok {
			continue
		}
		seen[s] = struct{}{}
		out = append(out, s)
	}
	return out
}

func filterExistingUsers(usernames []string) []string {
	if len(usernames) == 0 {
		return nil
	}
	placeholders := ""
	args := make([]interface{}, 0, len(usernames))
	for i, u := range usernames {
		if i > 0 {
			placeholders += ","
		}
		placeholders += "?"
		args = append(args, u)
	}
	rows, err := dbpkg.DB.Query("SELECT username FROM sys_users WHERE username IN ("+placeholders+")", args...)
	if err != nil {
		// 数据库表尚未就绪时，作为降级：仅保留虚拟用户 groot
		out := []string{}
		for _, u := range usernames {
			if u == "groot" {
				out = append(out, u)
			}
		}
		return out
	}
	defer rows.Close()
	seen := map[string]struct{}{}
	out := []string{}
	for rows.Next() {
		var u string
		if err := rows.Scan(&u); err != nil {
			continue
		}
		if _, ok := seen[u]; ok {
			continue
		}
		seen[u] = struct{}{}
		out = append(out, u)
	}
	// 始终保留虚拟用户 groot，即使 DB 里还未写入
	if _, ok := seen["groot"]; !ok {
		for _, u := range usernames {
			if u == "groot" {
				out = append(out, "groot")
				break
			}
		}
	}
	return out
}

// MaybeReplyAsGroot 如果 mentions 包含 groot，则以虚拟用户 groot 身份追加一条提示消息
func MaybeReplyAsGroot(eventID int64, mentions []string, fromUser, originalContent, modelCode string) *model.Message {
	hasGroot := false
	for _, m := range mentions {
		if m == "groot" {
			hasGroot = true
			break
		}
	}
	if !hasGroot {
		return nil
	}
	modelName := ""
	if modelCode != "" {
		modelName = "（" + modelCode + "）"
	}
	reply := "你好 @" + fromUser + "，我是 Groot 智能助手" + modelName + "，已收到你的消息，正在分析中…"
	return addMessageWithRole(eventID, "groot", "agent", reply, []string{fromUser})
}

// AddGrootReply 保存大模型返回的完整回复
func AddGrootReply(eventID int64, content string) *model.Message {
	return addMessageWithRole(eventID, "groot", "agent", content, []string{})
}

// CountUnreadMentions 返回该事件下当前用户未读的 @ 提醒数量
func CountUnreadMentions(eventID int64, username string) int {
	var lastRead int64
	dbpkg.DB.QueryRow(`
		SELECT last_read_msg_id FROM event_message_reads
		WHERE event_id = ? AND user_name = ?
	`, eventID, username).Scan(&lastRead)

	var cnt int
	dbpkg.DB.QueryRow(`
		SELECT COUNT(*) FROM event_message_mentions mm
		WHERE mm.event_id = ? AND mm.mentioned_user = ? AND mm.message_id > ?
	`, eventID, username, lastRead).Scan(&cnt)
	return cnt
}

// CountUnreadAll 返回该事件下当前用户未读消息总数（不含自己发的）
func CountUnreadAll(eventID int64, username string) int {
	var lastRead int64
	dbpkg.DB.QueryRow(`
		SELECT last_read_msg_id FROM event_message_reads
		WHERE event_id = ? AND user_name = ?
	`, eventID, username).Scan(&lastRead)

	var cnt int
	dbpkg.DB.QueryRow(`
		SELECT COUNT(*) FROM event_messages
		WHERE event_id = ? AND id > ? AND actor_id <> ?
	`, eventID, lastRead, username).Scan(&cnt)
	return cnt
}

// ListUnreadByUser 列出该用户在所有事件下的未读统计（仅返回有未读@或未读消息的事件）
func ListUnreadByUser(username string) []model.EventUnread {
	rows, err := dbpkg.DB.Query(`
		SELECT e.id
		FROM event_records e
		WHERE e.event_status <> 'closed'
		ORDER BY e.id DESC
	`)
	if err != nil {
		return []model.EventUnread{}
	}
	defer rows.Close()

	out := []model.EventUnread{}
	for rows.Next() {
		var eid int64
		if err := rows.Scan(&eid); err != nil {
			continue
		}
		mention := CountUnreadMentions(eid, username)
		total := CountUnreadAll(eid, username)
		if total == 0 && mention == 0 {
			continue
		}
		out = append(out, model.EventUnread{
			EventID:       eid,
			UnreadTotal:   total,
			UnreadMention: mention,
		})
	}
	return out
}

// MarkRead 更新某用户在某事件下的已读位点
func MarkRead(eventID int64, username string, lastReadMsgID int64) {
	now := time.Now().Format("2006-01-02 15:04:05")
	dbpkg.DB.Exec(`
		INSERT INTO event_message_reads (event_id, user_name, last_read_msg_id, updated_at)
		VALUES (?, ?, ?, ?)
		ON DUPLICATE KEY UPDATE
			last_read_msg_id = GREATEST(last_read_msg_id, VALUES(last_read_msg_id)),
			updated_at = VALUES(updated_at)
	`, eventID, username, lastReadMsgID, now)
}

// ============================================================
// Presence
// ============================================================

func ReportPresence(eventID int64, req *model.ReportPresenceRequest) {
	now := time.Now().Format("2006-01-02 15:04:05")
	dbpkg.DB.Exec(`
		INSERT INTO event_user_presence (event_id, user_id, user_name, last_seen_at, created_at)
		VALUES (?, ?, ?, ?, ?)
		ON DUPLICATE KEY UPDATE last_seen_at = VALUES(last_seen_at)
	`, eventID, req.UserID, req.UserName, now, now)
}

func GetOnlineUsers(eventID int64) []model.PresenceUser {
	cutoff := time.Now().Add(-30 * time.Second).Format("2006-01-02 15:04:05")
	rows, err := dbpkg.DB.Query(`
		SELECT user_id, user_name, last_seen_at
		FROM event_user_presence
		WHERE event_id = ? AND last_seen_at >= ?
		ORDER BY last_seen_at DESC
	`, eventID, cutoff)
	if err != nil {
		return []model.PresenceUser{}
	}
	defer rows.Close()

	var users []model.PresenceUser
	for rows.Next() {
		var u model.PresenceUser
		if err := rows.Scan(&u.UserID, &u.UserName, &u.LastSeenAt); err != nil {
			continue
		}
		formatTime(&u.LastSeenAt)
		users = append(users, u)
	}
	if users == nil {
		users = []model.PresenceUser{}
	}
	return users
}

// ============================================================
// Helpers
// ============================================================

func formatTime(t *string) {
	if *t == "" {
		return
	}
	var parsed time.Time
	var err error
	// Dolt 内嵌驱动返回 RFC3339（如 "2026-09-17T11:53:06Z"），
	// 迁移前 MySQL 返回 "2006-01-02 15:04:05"，两者都要兼容。
	if strings.Contains(*t, "T") {
		parsed, err = time.Parse(time.RFC3339Nano, *t)
	} else {
		parsed, err = time.Parse("2006-01-02 15:04:05", *t)
	}
	if err != nil {
		return
	}
	// Dolt 把本地墙钟标注为 UTC，需重解释为 Asia/Shanghai 后再格式化。
	parsed = time.Date(parsed.Year(), parsed.Month(), parsed.Day(), parsed.Hour(), parsed.Minute(), parsed.Second(), 0, model.TimeZone)
	*t = parsed.Format("2006-01-02 15:04:05")
}

func coalesce(val, defaultVal string) string {
	if val == "" {
		return defaultVal
	}
	return val
}
