package model

// SysDict 数据字典项（parent_id 自关联，0 为字典类型/根节点）
type SysDict struct {
	ID        int64  `json:"id"`
	ParentID  int64  `json:"parentId"`
	DictKey   string `json:"dictKey"`
	DictValue string `json:"dictValue"`
	DictSn    int    `json:"dictSn"`
	CreatedAt Time   `json:"createdAt"`
	UpdatedAt Time   `json:"updatedAt"`
}

type CreateDictRequest struct {
	ParentID  int64  `json:"parentId"`
	DictKey   string `json:"dictKey" binding:"required"`
	DictValue string `json:"dictValue" binding:"required"`
	DictSn    int    `json:"dictSn"`
}

type UpdateDictRequest struct {
	ParentID  *int64  `json:"parentId"`
	DictKey   *string `json:"dictKey"`
	DictValue *string `json:"dictValue"`
	DictSn    *int    `json:"dictSn"`
}
