package model

// ============================================================
// 台账域（服务台账）
// ============================================================

// Idc IDC台账
type Idc struct {
	ID          int64   `json:"id"`
	EnvCode     string  `json:"envCode"`
	IdcCode     string  `json:"idcCode"`
	IdcName     string  `json:"idcName"`
	IsXinchuang string  `json:"isXinchuang"`
	IdcStatus   string  `json:"idcStatus"`
	IdcRemark   *string `json:"idcRemark"`
	CreatedBy   string  `json:"createdBy"`
	UpdatedBy   *string `json:"updatedBy"`
	CreatedAt   Time    `json:"createdAt"`
	UpdatedAt   Time    `json:"updatedAt"`
}

type CreateIdcRequest struct {
	EnvCode     string  `json:"envCode" binding:"required"`
	IdcCode     string  `json:"idcCode" binding:"required"`
	IdcName     string  `json:"idcName" binding:"required"`
	IsXinchuang string  `json:"isXinchuang"`
	IdcStatus   string  `json:"idcStatus"`
	IdcRemark   *string `json:"idcRemark"`
}

type UpdateIdcRequest struct {
	EnvCode     *string `json:"envCode"`
	IdcName     *string `json:"idcName"`
	IsXinchuang *string `json:"isXinchuang"`
	IdcStatus   *string `json:"idcStatus"`
	IdcRemark   *string `json:"idcRemark"`
}

// Host 主机台账（集群节点）
type Host struct {
	ID              int64   `json:"id"`
	EnvCode         string  `json:"envCode"`
	IdcCode         string  `json:"idcCode"`
	ClusterCode     string  `json:"clusterCode"`
	ComponentTreeID *int64  `json:"componentTreeId"`
	HostIP          string  `json:"hostIp"`
	LeafCode    string  `json:"leafCode"`
	RackCode    string  `json:"rackCode"`
	CPUCores    *int    `json:"cpuCores"`
	MemoryGB    *int    `json:"memoryGb"`
	DiskGB      *int    `json:"diskGb"`
	CPUModel    *string `json:"cpuModel"`
	OSName      *string `json:"osName"`
	SSHPort     *int    `json:"sshPort"`
	SSHUser     *string `json:"sshUser"`
	CreatedBy   string  `json:"createdBy"`
	UpdatedBy   *string `json:"updatedBy"`
	CreatedAt   Time    `json:"createdAt"`
	UpdatedAt   Time    `json:"updatedAt"`
}

type CreateHostRequest struct {
	EnvCode         string  `json:"envCode" binding:"required"`
	IdcCode         string  `json:"idcCode" binding:"required"`
	ClusterCode     string  `json:"clusterCode" binding:"required"`
	ComponentTreeID *int64  `json:"componentTreeId"`
	HostIP          string  `json:"hostIp" binding:"required"`
	LeafCode    string  `json:"leafCode"`
	RackCode    string  `json:"rackCode"`
	CPUCores    *int    `json:"cpuCores"`
	MemoryGB    *int    `json:"memoryGb"`
	DiskGB      *int    `json:"diskGb"`
	CPUModel    *string `json:"cpuModel"`
	OSName      *string `json:"osName"`
	SSHPort     *int    `json:"sshPort"`
	SSHUser     *string `json:"sshUser"`
}

type UpdateHostRequest struct {
	EnvCode         *string `json:"envCode"`
	IdcCode         *string `json:"idcCode"`
	ClusterCode     *string `json:"clusterCode"`
	ComponentTreeID *int64  `json:"componentTreeId"`
	HostIP          *string `json:"hostIp"`
	LeafCode    *string `json:"leafCode"`
	RackCode    *string `json:"rackCode"`
	CPUCores    *int    `json:"cpuCores"`
	MemoryGB    *int    `json:"memoryGb"`
	DiskGB      *int    `json:"diskGb"`
	CPUModel    *string `json:"cpuModel"`
	OSName      *string `json:"osName"`
	SSHPort     *int    `json:"sshPort"`
	SSHUser     *string `json:"sshUser"`
}

// Domain 域名台账
type Domain struct {
	ID         int64   `json:"id"`
	EnvCode    string  `json:"envCode"`
	IdcCode    string  `json:"idcCode"`
	DomainType string  `json:"domainType"`
	DomainName string  `json:"domainName"`
	TargetHost *string `json:"targetHost"`
	CreatedBy  string  `json:"createdBy"`
	UpdatedBy  *string `json:"updatedBy"`
	CreatedAt  Time    `json:"createdAt"`
	UpdatedAt  Time    `json:"updatedAt"`
}

type CreateDomainRequest struct {
	EnvCode    string  `json:"envCode" binding:"required"`
	IdcCode    string  `json:"idcCode" binding:"required"`
	DomainType string  `json:"domainType" binding:"required"`
	DomainName string  `json:"domainName" binding:"required"`
	TargetHost *string `json:"targetHost"`
}

type UpdateDomainRequest struct {
	EnvCode    *string `json:"envCode"`
	IdcCode    *string `json:"idcCode"`
	DomainType *string `json:"domainType"`
	DomainName *string `json:"domainName"`
	TargetHost *string `json:"targetHost"`
}

// CmdbSyncDiff CMDB同步差异
type CmdbSyncDiff struct {
	ID         int64   `json:"id"`
	BatchCode  string  `json:"batchCode"`
	EnvCode    string  `json:"envCode"`
	IdcCode    string  `json:"idcCode"`
	DiffType   string  `json:"diffType"`
	HostIP     string  `json:"hostIp"`
	DiffStatus string  `json:"diffStatus"`
	SyncRemark *string `json:"syncRemark"`
	CreatedBy  string  `json:"createdBy"`
	UpdatedBy  *string `json:"updatedBy"`
	CreatedAt  Time    `json:"createdAt"`
	UpdatedAt  Time    `json:"updatedAt"`
}

// ============================================================
// 验收标准域
// ============================================================

// AcceptanceStandard 验收标准树节点（分类 + 验收项）
type AcceptanceStandard struct {
	ID             int64   `json:"id"`
	ParentID       int64   `json:"parentId"`
	StandardCode   string  `json:"standardCode"`
	StandardName   string  `json:"standardName"`
	NodeType       string  `json:"nodeType"`
	CollectType    *string `json:"collectType"`
	CollectMethod  *string `json:"collectMethod"`
	CollectParams  *string `json:"collectParams"`
	JudgeCriteria  *string `json:"judgeCriteria"`
	OrderIdx       int     `json:"orderIdx"`
	StandardStatus string  `json:"standardStatus"`
	CreatedBy      string  `json:"createdBy"`
	UpdatedBy      *string `json:"updatedBy"`
	CreatedAt      Time    `json:"createdAt"`
	UpdatedAt      Time    `json:"updatedAt"`
}

type CreateStandardRequest struct {
	ParentID       int64   `json:"parentId"`
	StandardCode   string  `json:"standardCode" binding:"required"`
	StandardName   string  `json:"standardName" binding:"required"`
	NodeType       string  `json:"nodeType"`
	CollectType    *string `json:"collectType"`
	CollectMethod  *string `json:"collectMethod"`
	CollectParams  *string `json:"collectParams"`
	JudgeCriteria  *string `json:"judgeCriteria"`
	OrderIdx       *int    `json:"orderIdx"`
	StandardStatus string  `json:"standardStatus"`
}

type UpdateStandardRequest struct {
	ParentID       *int64  `json:"parentId"`
	StandardCode   *string `json:"standardCode"`
	StandardName   *string `json:"standardName"`
	NodeType       *string `json:"nodeType"`
	CollectType    *string `json:"collectType"`
	CollectMethod  *string `json:"collectMethod"`
	CollectParams  *string `json:"collectParams"`
	JudgeCriteria  *string `json:"judgeCriteria"`
	OrderIdx       *int    `json:"orderIdx"`
	StandardStatus *string `json:"standardStatus"`
}

// MoveStandardRequest 验收标准节点移动/排序
type MoveStandardRequest struct {
	ParentID int64 `json:"parentId"`
	OrderIdx int   `json:"orderIdx"`
}

// ============================================================
// 组件树域（服务台账组件树）
// ============================================================

// ComponentTreeNode 组件树节点（component/role/cluster/idc）
type ComponentTreeNode struct {
	ID             int64   `json:"id"`
	ParentID       int64   `json:"parentId"`
	NodeType       string  `json:"nodeType"`
	NodeCode       string  `json:"nodeCode"`
	NodeName       string  `json:"nodeName"`
	NodeIdx        int     `json:"nodeIdx"`
	NodeRemark     *string `json:"nodeRemark"`
	AccessMethod   *string `json:"accessMethod"`
	AccessPort     *int    `json:"accessPort"`
	AccessPassword *string `json:"accessPassword"`
	CreatedBy      string  `json:"createdBy"`
	UpdatedBy      *string `json:"updatedBy"`
	CreatedAt      Time    `json:"createdAt"`
	UpdatedAt      Time    `json:"updatedAt"`
}

// CreateComponentTreeNodeRequest 新增组件树节点
type CreateComponentTreeNodeRequest struct {
	ParentID       int64   `json:"parentId"`
	NodeType       string  `json:"nodeType" binding:"required"`
	NodeCode       string  `json:"nodeCode" binding:"required"`
	NodeName       string  `json:"nodeName" binding:"required"`
	NodeIdx        *int    `json:"nodeIdx"`
	NodeRemark     *string `json:"nodeRemark"`
	AccessMethod   *string `json:"accessMethod"`
	AccessPort     *int    `json:"accessPort"`
	AccessPassword *string `json:"accessPassword"`
}

// UpdateComponentTreeNodeRequest 更新组件树节点
type UpdateComponentTreeNodeRequest struct {
	ParentID       *int64  `json:"parentId"`
	NodeType       *string `json:"nodeType"`
	NodeCode       *string `json:"nodeCode"`
	NodeName       *string `json:"nodeName"`
	NodeIdx        *int    `json:"nodeIdx"`
	NodeRemark     *string `json:"nodeRemark"`
	AccessMethod   *string `json:"accessMethod"`
	AccessPort     *int    `json:"accessPort"`
	AccessPassword *string `json:"accessPassword"`
}

// MoveComponentTreeNodeRequest 组件树节点移动/排序
type MoveComponentTreeNodeRequest struct {
	ParentID int64 `json:"parentId"`
	NodeIdx  int   `json:"nodeIdx"`
}
