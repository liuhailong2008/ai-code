package model

type DutySchedule struct {
	ID             int64   `json:"id"`
	ScheduleDate   string  `json:"scheduleDate"`
	Department     string  `json:"department"`
	PositionName   string  `json:"positionName"`
	PrimaryUser    string  `json:"primaryUser"`
	BackupUser     string  `json:"backupUser"`
	CreatedBy      string  `json:"createdBy"`
	UpdatedBy      *string `json:"updatedBy"`
	CreatedAt      Time `json:"createdAt"`
	UpdatedAt      Time `json:"updatedAt"`
}

type CreateDutyScheduleRequest struct {
	ScheduleDate   string `json:"scheduleDate" binding:"required"`
	Department     string `json:"department" binding:"required"`
	PositionName   string `json:"positionName" binding:"required"`
	PrimaryUser    string `json:"primaryUser" binding:"required"`
	BackupUser     string `json:"backupUser" binding:"required"`
}

type UpdateDutyScheduleRequest struct {
	Department    *string `json:"department"`
	PositionName  *string `json:"positionName"`
	PrimaryUser   *string `json:"primaryUser"`
	BackupUser    *string `json:"backupUser"`
}
