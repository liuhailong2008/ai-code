package model

import (
	"database/sql/driver"
	"fmt"
	"time"
)

// TimeZone 项目统一时区，与迁移前 MySQL DSN 的 loc=Asia/Shanghai 保持一致。
// 中国无夏令时，Asia/Shanghai 即固定 UTC+8，使用 FixedZone 避免依赖 tzdata/CGO。
var TimeZone = time.FixedZone("Asia/Shanghai", 8*3600)

// Time 是 time.Time 的封装类型。
//
// Dolt 内嵌驱动在返回 DATETIME 列时，会把「本地墙钟」错误地标注为 UTC
// （例如数据库里的 11:54:25 被读成 11:54:25 +0000 UTC），导致 JSON 序列化
// 输出 Z 后缀、前端解析后偏移 8 小时。本类型在 Scan 时把该墙钟重解释为
// Asia/Shanghai，从而与迁移前 MySQL 行为保持一致。
type Time time.Time

// Scan 实现 database/sql 的 Scanner 接口。
func (t *Time) Scan(v interface{}) error {
	switch tv := v.(type) {
	case time.Time:
		*t = Time(reinterpretShanghai(tv))
		return nil
	case nil:
		*t = Time(time.Time{})
		return nil
	default:
		return fmt.Errorf("model.Time.Scan: unsupported type %T", v)
	}
}

// Value 实现 driver.Valuer 接口。
func (t Time) Value() (driver.Value, error) {
	return time.Time(t), nil
}

// MarshalJSON 按 time.Time 的 RFC3339 规则输出（携带 +08:00 偏移）。
func (t Time) MarshalJSON() ([]byte, error) {
	return time.Time(t).MarshalJSON()
}

// UnmarshalJSON 解析 RFC3339 时间。
func (t *Time) UnmarshalJSON(data []byte) error {
	var tt time.Time
	if err := tt.UnmarshalJSON(data); err != nil {
		return err
	}
	*t = Time(tt)
	return nil
}

// reinterpretShanghai 保留墙钟的年月日时分秒，仅将时区重解释为 Asia/Shanghai。
func reinterpretShanghai(t time.Time) time.Time {
	return time.Date(t.Year(), t.Month(), t.Day(), t.Hour(), t.Minute(), t.Second(), t.Nanosecond(), TimeZone)
}
