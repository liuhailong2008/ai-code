package model

type ModelConfig struct {
	ID               int64      `json:"id"`
	Code             string     `json:"code"`
	Name             string     `json:"name"`
	Provider         string     `json:"provider"`
	BaseURL          string     `json:"baseUrl"`
	APIKey           string     `json:"apiKey"`
	HasApiKey        bool       `json:"hasApiKey"`
	Purpose          string     `json:"purpose"`
	IsActive         bool       `json:"isActive"`
	IsEnabled        bool       `json:"isEnabled"`
	Priority         int        `json:"priority"`
	ContextWindow    int        `json:"contextWindow"`
	MaxTokens        int        `json:"maxTokens"`
	SupportsThinking bool       `json:"supportsThinking"`
	SupportsVision   bool       `json:"supportsVision"`
	SupportsTools    bool       `json:"supportsTools"`
	SupportsJSON     bool       `json:"supportsJson"`
	Temperature      *float64   `json:"temperature"`
	TopP             *float64   `json:"topP"`
	CreatedBy        string     `json:"createdBy"`
	UpdatedBy        *string    `json:"updatedBy"`
	CreatedAt        Time `json:"createdAt"`
	UpdatedAt        Time `json:"updatedAt"`
}

type CreateModelConfigRequest struct {
	Code             string   `json:"code" binding:"required"`
	Name             string   `json:"name" binding:"required"`
	Provider         string   `json:"provider" binding:"required"`
	BaseURL          string   `json:"baseUrl" binding:"required"`
	APIKey           string   `json:"apiKey" binding:"required"`
	Purpose          string   `json:"purpose" binding:"required"`
	IsActive         *bool    `json:"isActive"`
	IsEnabled        *bool    `json:"isEnabled"`
	Priority         *int     `json:"priority"`
	ContextWindow    *int     `json:"contextWindow"`
	MaxTokens        *int     `json:"maxTokens"`
	SupportsThinking *bool    `json:"supportsThinking"`
	SupportsVision   *bool    `json:"supportsVision"`
	SupportsTools    *bool    `json:"supportsTools"`
	SupportsJSON     *bool    `json:"supportsJson"`
	Temperature      *float64 `json:"temperature"`
	TopP             *float64 `json:"topP"`
}

type UpdateModelConfigRequest struct {
	Code             *string  `json:"code"`
	Name             *string  `json:"name"`
	Provider         *string  `json:"provider"`
	BaseURL          *string  `json:"baseUrl"`
	APIKey           *string  `json:"apiKey"`
	Purpose          *string  `json:"purpose"`
	IsActive         *bool    `json:"isActive"`
	IsEnabled        *bool    `json:"isEnabled"`
	Priority         *int     `json:"priority"`
	ContextWindow    *int     `json:"contextWindow"`
	MaxTokens        *int     `json:"maxTokens"`
	SupportsThinking *bool    `json:"supportsThinking"`
	SupportsVision   *bool    `json:"supportsVision"`
	SupportsTools    *bool    `json:"supportsTools"`
	SupportsJSON     *bool    `json:"supportsJson"`
	Temperature      *float64 `json:"temperature"`
	TopP             *float64 `json:"topP"`
}
