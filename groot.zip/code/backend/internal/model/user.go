package model

type User struct {
	ID          int64     `json:"id"`
	Username    string    `json:"username"`
	Mobile      string    `json:"mobile"`
	Password    string    `json:"-"`
	DisplayName string    `json:"displayName"`
	Role        string    `json:"role"`
	CreatedAt   Time `json:"createdAt"`
	UpdatedAt   Time `json:"updatedAt"`
}

type LoginRequest struct {
	Username string `json:"username" binding:"required"`
	Password string `json:"password" binding:"required"`
}

type LoginResponse struct {
	Token string `json:"token"`
	User  User   `json:"user"`
}

type CreateUserRequest struct {
	Username    string `json:"username" binding:"required"`
	Mobile      string `json:"mobile"`
	Password    string `json:"password" binding:"required"`
	DisplayName string `json:"displayName" binding:"required"`
	Role        string `json:"role" binding:"required"`
}

type UpdateUserRequest struct {
	Username    *string `json:"username"`
	Mobile      *string `json:"mobile"`
	Password    *string `json:"password"`
	DisplayName *string `json:"displayName"`
	Role        *string `json:"role"`
}
