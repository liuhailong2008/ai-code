package model

// --- Skill ---

type Skill struct {
	ID          int64     `json:"id"`
	SkillName   string    `json:"skillName"`
	SkillCode   string    `json:"skillCode"`
	Description *string   `json:"description"`
	Version     *string   `json:"version"`
	FilePath    string    `json:"filePath"`
	IsEnabled   bool      `json:"isEnabled"`
	CreatedBy   string    `json:"createdBy"`
	UpdatedBy   *string   `json:"updatedBy"`
	CreatedAt   Time `json:"createdAt"`
	UpdatedAt   Time `json:"updatedAt"`
}

// --- SkillFile ---

type SkillFile struct {
	ID         int64     `json:"id"`
	SkillID    int64     `json:"skillId"`
	FileName   string    `json:"fileName"`
	FilePath   string    `json:"filePath"`
	FileType   string    `json:"fileType"`
	ParentPath string    `json:"parentPath"`
	CreatedAt  Time `json:"createdAt"`
}

// --- Tree Node (for directory structure) ---

type SkillTreeNode struct {
	Name     string            `json:"name"`
	Path     string            `json:"path"`
	Type     string            `json:"type"` // "file" or "dir"
	Children []*SkillTreeNode  `json:"children,omitempty"`
}

type SkillTreeResponse struct {
	SkillID   int64             `json:"skillId"`
	SkillName string            `json:"skillName"`
	Tree      []*SkillTreeNode  `json:"tree"`
}

// --- Requests ---

type CreateSkillRequest struct {
	SkillName   string  `json:"skillName"`
	SkillCode   string  `json:"skillCode"`
	Description *string `json:"description"`
	Version     *string `json:"version"`
}

type UpdateSkillRequest struct {
	SkillName   *string `json:"skillName"`
	SkillCode   *string `json:"skillCode"`
	Description *string `json:"description"`
	Version     *string `json:"version"`
	IsEnabled   *bool   `json:"isEnabled"`
}

type SaveFileRequest struct {
	Content string `json:"content"`
}

// --- SKILL.md frontmatter (parsed from uploaded skills) ---

type SkillFrontmatter struct {
	Name        string `yaml:"name"`
	Description string `yaml:"description"`
}
