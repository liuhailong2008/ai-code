package model

type SopMiddleware struct {
	ID        int64     `json:"id"`
	AppName   string    `json:"appName"`
	AppDesc   string    `json:"appDesc"`
	PrimaryPost string   `json:"primaryPost"`
	BackupPost  string   `json:"backupPost"`
	CreatedBy string    `json:"createdBy"`
	UpdatedBy *string   `json:"updatedBy"`
	CreatedAt Time `json:"createdAt"`
	UpdatedAt Time `json:"updatedAt"`
}

type CreateSopMiddlewareRequest struct {
	AppName   string `json:"appName" binding:"required"`
	AppDesc   string `json:"appDesc" binding:"required"`
	PrimaryPost string `json:"primaryPost" binding:"required"`
	BackupPost  string `json:"backupPost" binding:"required"`
}

type UpdateSopMiddlewareRequest struct {
	AppName   *string `json:"appName"`
	AppDesc   *string `json:"appDesc"`
	PrimaryPost *string `json:"primaryPost"`
	BackupPost  *string `json:"backupPost"`
}
