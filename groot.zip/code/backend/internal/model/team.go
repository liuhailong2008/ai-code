package model

type Team struct {
	ID          int64      `json:"id"`
	Code        string     `json:"code"`
	Name        string     `json:"name"`
	Description *string    `json:"description"`
	WechatID    *string    `json:"wechatId"`
	TeamEmail   *string    `json:"teamEmail"`
	TechLeader  *string    `json:"techLeader"`
	TeamLeader  *string    `json:"teamLeader"`
	CreatedBy   string     `json:"createdBy"`
	UpdatedBy   *string    `json:"updatedBy"`
	CreatedAt   Time `json:"createdAt"`
	UpdatedAt   Time `json:"updatedAt"`
}

type CreateTeamRequest struct {
	Code        string  `json:"code" binding:"required"`
	Name        string  `json:"name" binding:"required"`
	Description *string `json:"description"`
	WechatID    *string `json:"wechatId"`
	TeamEmail   *string `json:"teamEmail"`
	TechLeader  *string `json:"techLeader"`
	TeamLeader  *string `json:"teamLeader"`
}

type UpdateTeamRequest struct {
	Code        *string `json:"code"`
	Name        *string `json:"name"`
	Description *string `json:"description"`
	WechatID    *string `json:"wechatId"`
	TeamEmail   *string `json:"teamEmail"`
	TechLeader  *string `json:"techLeader"`
	TeamLeader  *string `json:"teamLeader"`
}

type TeamMember struct {
	ID          int64     `json:"id"`
	UserID      int64     `json:"userId"`
	TeamID      int64     `json:"teamId"`
	Username    string    `json:"username"`
	DisplayName string    `json:"displayName"`
	Role        string    `json:"role"`
	CreatedAt   Time `json:"createdAt"`
	UpdatedAt   Time `json:"updatedAt"`
}

type AddTeamMemberRequest struct {
	UserID int64 `json:"userId" binding:"required"`
}
