package model

type McpConfig struct {
	ID          int64    `json:"id"`
	McpName     string   `json:"mcpName"`
	McpCode     string   `json:"mcpCode"`
	McpType     string   `json:"mcpType"`
	BaseURL     string   `json:"baseUrl"`
	ApiKey      *string  `json:"apiKey"`
	Headers     *string  `json:"headers"`
	TimeoutMs   int      `json:"timeoutMs"`
	Description *string  `json:"description"`
	IsEnabled   bool     `json:"isEnabled"`
	CreatedBy   string   `json:"createdBy"`
	UpdatedBy   *string  `json:"updatedBy"`
	CreatedAt   Time `json:"createdAt"`
	UpdatedAt   Time `json:"updatedAt"`
}

type McpTool struct {
	ID          int64    `json:"id"`
	McpID       int64    `json:"mcpId"`
	ToolName    string   `json:"toolName"`
	ToolDesc    *string  `json:"toolDesc"`
	InputSchema *string  `json:"inputSchema"`
	OutputDesc  *string  `json:"outputDesc"`
	IsEnabled   bool     `json:"isEnabled"`
	CreatedAt   Time `json:"createdAt"`
	UpdatedAt   Time `json:"updatedAt"`
}

type CreateMcpRequest struct {
	McpName     string  `json:"mcpName"`
	McpCode     string  `json:"mcpCode"`
	McpType     string  `json:"mcpType"`
	BaseURL     string  `json:"baseUrl"`
	ApiKey      *string `json:"apiKey"`
	Headers     *string `json:"headers"`
	TimeoutMs   *int    `json:"timeoutMs"`
	Description *string `json:"description"`
}

type UpdateMcpRequest struct {
	McpName     *string `json:"mcpName"`
	McpCode     *string `json:"mcpCode"`
	McpType     *string `json:"mcpType"`
	BaseURL     *string `json:"baseUrl"`
	ApiKey      *string `json:"apiKey"`
	Headers     *string `json:"headers"`
	TimeoutMs   *int    `json:"timeoutMs"`
	Description *string `json:"description"`
	IsEnabled   *bool   `json:"isEnabled"`
}

type UpdateMcpToolRequest struct {
	ToolDesc   *string `json:"toolDesc"`
	OutputDesc *string `json:"outputDesc"`
}
