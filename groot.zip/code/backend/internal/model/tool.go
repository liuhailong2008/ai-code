package model

// Tool 工具数据模型（对应数据库 tools 表）
type Tool struct {
	ID                  int64     `json:"id"`
	ToolName            string    `json:"toolName"`
	DisplayName         string    `json:"displayName"`
	Description         *string   `json:"description"`
	ToolCategory        string    `json:"toolCategory"`
	ImplementationClass string    `json:"implementationClass"`
	InputSchema         *string   `json:"inputSchema"`
	OutputSchema        *string   `json:"outputSchema"`
	IsEnabled           bool      `json:"isEnabled"`
	CreatedBy           string    `json:"createdBy"`
	UpdatedBy           *string   `json:"updatedBy"`
	CreatedAt           Time `json:"createdAt"`
	UpdatedAt           Time `json:"updatedAt"`
}

// UpdateToolRequest 更新工具请求
type UpdateToolRequest struct {
	DisplayName  *string `json:"displayName"`
	Description  *string `json:"description"`
	ToolCategory *string `json:"toolCategory"`
	InputSchema  *string `json:"inputSchema"`
	OutputSchema *string `json:"outputSchema"`
	IsEnabled    *bool   `json:"isEnabled"`
}
