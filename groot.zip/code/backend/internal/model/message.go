package model

type Message struct {
	ID        int64    `json:"id"`
	EventID   int64    `json:"eventId"`
	ActorID   string   `json:"actorId"`
	Content   string   `json:"content"`
	Role      string   `json:"role"`
	CreatedAt string   `json:"createdAt"`
	Mentions  []string `json:"mentions"`
}

type CreateMessageRequest struct {
	Content   string   `json:"content" binding:"required"`
	Mentions  []string `json:"mentions"`
	ModelCode string   `json:"modelCode"`
}

// MarkReadRequest 标记某事件下当前用户的已读位点
type MarkReadRequest struct {
	LastReadMessageID int64 `json:"lastReadMessageId" binding:"required"`
}

// EventUnread 单事件未读统计
type EventUnread struct {
	EventID       int64 `json:"eventId"`
	UnreadTotal   int   `json:"unreadTotal"`
	UnreadMention int   `json:"unreadMention"`
}
