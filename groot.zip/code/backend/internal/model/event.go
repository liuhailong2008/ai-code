package model

type EventParticipant struct {
	UserID      int64  `json:"userId"`
	UserName    string `json:"userName"`
	DisplayName string `json:"displayName"`
	UserAvatar  string `json:"userAvatar"`
	Role        string `json:"role"`
	JoinedAt    string `json:"joinedAt"`
}

type Event struct {
	ID           int64              `json:"id"`
	TeamID       int64              `json:"teamId"`
	Title        string             `json:"title"`
	Description  string             `json:"description"`
	Status       string             `json:"status"`
	Severity     string             `json:"severity"`
	Category     string             `json:"category"`
	IdcName      string             `json:"idcName"`
	AppName      string             `json:"appName"`
	ClusterName  string             `json:"clusterName"`
	Source       string             `json:"source"`
	CreatedBy    string             `json:"createdBy"`
	UniNo        string             `json:"uniNo"`
	ExtTicketID  string             `json:"extTicketId"`
	Metadata     string             `json:"metadata"`
	OpenedAt     string             `json:"openedAt"`
	ClosedAt     string             `json:"closedAt"`
	CreatedAt    string             `json:"createdAt"`
	UpdatedAt    string             `json:"updatedAt"`
	Participants []EventParticipant `json:"participants"`
}

type CreateEventRequest struct {
	TeamID      int64  `json:"teamId" binding:"required"`
	Title       string `json:"title" binding:"required"`
	Description string `json:"description"`
	Category    string `json:"category" binding:"required"`
	Severity    string `json:"severity"`
	AppName     string `json:"appName"`
	ClusterName string `json:"clusterName"`
	IdcName     string `json:"idcName"`
	Source      string `json:"source"`
	UniNo       string `json:"uniNo"`
}

type UpdateEventStateRequest struct {
	Status string `json:"status" binding:"required"`
}

type PresenceUser struct {
	UserID     int64  `json:"userId"`
	UserName   string `json:"userName"`
	LastSeenAt string `json:"lastSeenAt"`
}

type ReportPresenceRequest struct {
	UserID   int64  `json:"userId" binding:"required"`
	UserName string `json:"userName" binding:"required"`
}
