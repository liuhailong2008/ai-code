package model

import (
	"encoding/json"
)

// json.RawMessage wrapper for JSON fields
type JSONField json.RawMessage

func (j JSONField) MarshalJSON() ([]byte, error) {
	if j == nil {
		return []byte("null"), nil
	}
	return []byte(j), nil
}

func (j *JSONField) UnmarshalJSON(data []byte) error {
	*j = JSONField(data)
	return nil
}

type SopDefinition struct {
	ID           int64      `json:"id"`
	SopName      string     `json:"sopName"`
	SopCode      string     `json:"sopCode"`
	SopCategory  string     `json:"sopCategory"`
	SopDesc      *string    `json:"sopDesc"`
	ComposeType  string     `json:"composeType"`
	InputSchema  *string    `json:"inputSchema"`
	OutputSchema *string    `json:"outputSchema"`
	Status       string     `json:"status"`
	Version      int        `json:"version"`
	CreatedBy    string     `json:"createdBy"`
	UpdatedBy    *string    `json:"updatedBy"`
	CreatedAt    Time `json:"createdAt"`
	UpdatedAt    Time `json:"updatedAt"`
}

type CreateSopRequest struct {
	SopName      string  `json:"sopName" binding:"required"`
	SopCode      string  `json:"sopCode" binding:"required"`
	SopCategory  string  `json:"sopCategory" binding:"required"`
	SopDesc      *string `json:"sopDesc"`
	ComposeType  string  `json:"composeType" binding:"required"`
	InputSchema  *string `json:"inputSchema"`
	OutputSchema *string `json:"outputSchema"`
}

type UpdateSopRequest struct {
	SopName      *string `json:"sopName"`
	SopCode      *string `json:"sopCode"`
	SopCategory  *string `json:"sopCategory"`
	SopDesc      *string `json:"sopDesc"`
	ComposeType  *string `json:"composeType"`
	InputSchema  *string `json:"inputSchema"`
	OutputSchema *string `json:"outputSchema"`
	Status       *string `json:"status"`
}
