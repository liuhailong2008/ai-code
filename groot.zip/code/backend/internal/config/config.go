package config

import (
	"crypto/sha256"
	"os"
	"path/filepath"
)

type Config struct {
	ServerPort    string
	DBDir         string
	DBName        string
	SQLDir        string
	JWTSecret     string
	EncryptionKey string
	SkillsDir     string
}

func Load() *Config {
	return &Config{
		ServerPort:    getEnv("SERVER_PORT", "8080"),
		DBDir:         getEnv("DB_DIR", resolveDir("data")),
		DBName:        getEnv("DB_NAME", "groot"),
		SQLDir:        getEnv("SQL_DIR", resolveDir("sql")),
		JWTSecret:     getEnv("JWT_SECRET", "groot-jwt-secret-key"),
		EncryptionKey: getEnv("ENCRYPTION_KEY", "groot-aes-256-key!!"),
		SkillsDir:     resolveSkillsDir(),
	}
}

func resolveSkillsDir() string {
	return resolveDir("skills")
}

// resolveDir 默认：当前工作目录的 ../<name>/（与 backend 同级）
func resolveDir(name string) string {
	cwd, err := os.Getwd()
	if err != nil {
		return filepath.Join("..", name)
	}
	return filepath.Join(cwd, "..", name)
}

func (c *Config) DSN() string {
	return "file://" + c.DBDir + "?commitname=groot&commitemail=groot@local&database=" + c.DBName
}

func (c *Config) AESKey() []byte {
	hash := sha256.Sum256([]byte(c.EncryptionKey))
	return hash[:]
}

func getEnv(key, defaultVal string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return defaultVal
}
