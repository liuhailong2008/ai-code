package service

import (
	"archive/zip"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"gopkg.in/yaml.v3"
	"groot-backend/internal/model"
	"groot-backend/internal/repo"
)

// ExtractSkillFromZip 解压 zip 并返回技能元数据和文件列表
func ExtractSkillFromZip(zipPath, destDir string) (*model.SkillFrontmatter, []model.SkillFile, error) {
	reader, err := zip.OpenReader(zipPath)
	if err != nil {
		return nil, nil, fmt.Errorf("无法打开 zip 文件: %w", err)
	}
	defer reader.Close()

	// 创建目标目录
	if err := os.MkdirAll(destDir, 0755); err != nil {
		return nil, nil, fmt.Errorf("无法创建目标目录: %w", err)
	}

	var frontmatter *model.SkillFrontmatter
	var files []model.SkillFile

	for _, f := range reader.File {
		// 安全检查：防止路径穿越
		cleanPath := filepath.Clean(f.Name)
		if strings.HasPrefix(cleanPath, "..") || filepath.IsAbs(cleanPath) {
			continue
		}

		// 去掉 zip 顶层目录，使 SKILL.md 位于技能根目录
		relPath := cleanPath
		if idx := strings.IndexByte(relPath, '/'); idx != -1 {
			relPath = relPath[idx+1:]
		}
		if relPath == "" {
			continue // 跳过顶层目录本身
		}

		destPath := filepath.Join(destDir, relPath)

		if f.FileInfo().IsDir() {
			if err := os.MkdirAll(destPath, 0755); err != nil {
				return nil, nil, fmt.Errorf("创建目录失败 %s: %w", relPath, err)
			}
			files = append(files, model.SkillFile{
				FileName:   filepath.Base(relPath),
				FilePath:   relPath,
				FileType:   "dir",
				ParentPath: filepath.Dir(relPath),
			})
			continue
		}

		// 确保父目录存在
		if err := os.MkdirAll(filepath.Dir(destPath), 0755); err != nil {
			return nil, nil, fmt.Errorf("创建父目录失败: %w", err)
		}

		// 解压文件
		srcFile, err := f.Open()
		if err != nil {
			return nil, nil, fmt.Errorf("打开压缩文件失败 %s: %w", relPath, err)
		}

		dstFile, err := os.Create(destPath)
		if err != nil {
			srcFile.Close()
			return nil, nil, fmt.Errorf("创建文件失败 %s: %w", relPath, err)
		}

		_, err = io.Copy(dstFile, srcFile)
		srcFile.Close()
		dstFile.Close()
		if err != nil {
			return nil, nil, fmt.Errorf("写入文件失败 %s: %w", relPath, err)
		}

		files = append(files, model.SkillFile{
			FileName:   filepath.Base(relPath),
			FilePath:   relPath,
			FileType:   "file",
			ParentPath: filepath.Dir(relPath),
		})

		// 解析 SKILL.md（查找技能根目录下的 SKILL.md）
		if filepath.Base(relPath) == "SKILL.md" && !strings.ContainsRune(filepath.Dir(relPath), filepath.Separator) {
			fm, err := parseSkillMD(destPath)
			if err == nil {
				frontmatter = fm
			}
		}
	}

	if frontmatter == nil {
		return nil, nil, fmt.Errorf("技能包中未找到有效的 SKILL.md")
	}

	return frontmatter, files, nil
}

// parseSkillMD 解析 SKILL.md 的 YAML frontmatter
func parseSkillMD(filePath string) (*model.SkillFrontmatter, error) {
	data, err := os.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	content := string(data)
	// 查找 YAML frontmatter: 以 --- 开头和结束
	if !strings.HasPrefix(content, "---\n") {
		return nil, fmt.Errorf("SKILL.md 缺少 YAML frontmatter")
	}

	// 找到第二个 ---
	endIdx := strings.Index(content[4:], "\n---")
	if endIdx == -1 {
		return nil, fmt.Errorf("SKILL.md YAML frontmatter 格式不正确")
	}

	yamlContent := content[4 : 4+endIdx]

	var fm model.SkillFrontmatter
	if err := yaml.Unmarshal([]byte(yamlContent), &fm); err != nil {
		return nil, fmt.Errorf("解析 YAML frontmatter 失败: %w", err)
	}

	return &fm, nil
}

// BuildSkillTree 从文件列表构建树形结构
func BuildSkillTree(files []model.SkillFile) []*model.SkillTreeNode {
	nodeMap := make(map[string]*model.SkillTreeNode)
	var roots []*model.SkillTreeNode

	// 先创建所有节点
	for _, f := range files {
		node := &model.SkillTreeNode{
			Name: f.FileName,
			Path: f.FilePath,
			Type: f.FileType,
		}
		nodeMap[f.FilePath] = node
	}

	// 建立父子关系
	for _, f := range files {
		node := nodeMap[f.FilePath]
		if f.ParentPath == "" || f.ParentPath == "." {
			roots = append(roots, node)
		} else {
			parent, ok := nodeMap[f.ParentPath]
			if ok && parent.Type == "dir" {
				parent.Children = append(parent.Children, node)
			} else {
				roots = append(roots, node)
			}
		}
	}

	return roots
}

// ValidatePath 校验文件路径在技能目录内，防止路径穿越
func ValidatePath(skillDir, reqPath string) (string, error) {
	cleanPath := filepath.Clean(reqPath)
	if strings.HasPrefix(cleanPath, "..") || filepath.IsAbs(cleanPath) {
		return "", fmt.Errorf("非法路径: %s", reqPath)
	}

	fullPath := filepath.Join(skillDir, cleanPath)
	absFull, err := filepath.Abs(fullPath)
	if err != nil {
		return "", fmt.Errorf("路径解析失败: %w", err)
	}

	absBase, err := filepath.Abs(skillDir)
	if err != nil {
		return "", fmt.Errorf("基准路径解析失败: %w", err)
	}

	if !strings.HasPrefix(absFull, absBase+string(filepath.Separator)) && absFull != absBase {
		return "", fmt.Errorf("路径超出允许范围")
	}

	return absFull, nil
}

// SaveSkillFromZip 完整的上传处理流程：解压 → 入库 → 返回 skill
func SaveSkillFromZip(zipPath, skillsDir, skillCode, username string) (*model.Skill, error) {
	destDir := filepath.Join(skillsDir, skillCode)

	// 如果已存在同名技能，先清理
	if _, err := os.Stat(destDir); err == nil {
		existing, err := repo.GetSkillByCode(skillCode)
		if err == nil {
			// 删除旧文件和旧数据库记录
			os.RemoveAll(destDir)
			repo.DeleteSkillFiles(existing.ID)
			repo.DeleteSkill(existing.ID)
		}
	}

	frontmatter, files, err := ExtractSkillFromZip(zipPath, destDir)
	if err != nil {
		return nil, err
	}

	skillName := frontmatter.Name
	if skillName == "" {
		skillName = skillCode
	}

	description := frontmatter.Description
	filePath := skillCode

	skill := &model.Skill{
		SkillName:   skillName,
		SkillCode:   skillCode,
		Description: &description,
		FilePath:    filePath,
		CreatedBy:   username,
	}

	id, err := repo.CreateSkill(skill)
	if err != nil {
		os.RemoveAll(destDir)
		return nil, fmt.Errorf("创建技能记录失败: %w", err)
	}

	for i := range files {
		files[i].SkillID = id
		if err := repo.InsertSkillFile(&files[i]); err != nil {
			// 回滚
			repo.DeleteSkillFiles(id)
			repo.DeleteSkill(id)
			os.RemoveAll(destDir)
			return nil, fmt.Errorf("保存文件索引失败: %w", err)
		}
	}

	return repo.GetSkill(id)
}
