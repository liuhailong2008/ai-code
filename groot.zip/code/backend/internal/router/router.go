package router

import (
	"groot-backend/internal/handler"
	"groot-backend/internal/middleware"

	"github.com/gin-gonic/gin"
)

func Setup(r *gin.Engine) {
	api := r.Group("/api")

	// 认证（无需鉴权）
	auth := api.Group("/auth")
	{
		auth.POST("/login", handler.Login)
		auth.GET("/me", middleware.AuthRequired(), handler.GetMe)
		auth.PATCH("/profile", middleware.AuthRequired(), handler.UpdateProfile)
	}

	// 事件管理（需要鉴权）
	events := api.Group("/events", middleware.AuthRequired())
	{
		events.GET("", handler.ListEvents)
		events.GET("/:id", handler.GetEvent)
		events.POST("", handler.CreateEvent)
		events.PATCH("/:id/state", handler.UpdateEventState)
		events.GET("/:id/messages", handler.GetMessages)
		events.POST("/:id/messages", handler.PostMessage)
		events.POST("/:id/messages/read", handler.MarkMessagesRead)
		events.GET("/:id/unread", handler.GetEventUnread)
		events.POST("/:id/presence", handler.ReportPresence)
		events.GET("/:id/presence", handler.GetOnlineUsers)
		events.GET("/:id/staffing", handler.GetEventStaffing)
		events.GET("/:id/uiblocks", handler.GetUIBlocks)
		events.GET("/:id/stream", handler.StreamGrootReply)
	}

	// 当前用户的全部未读统计
	api.GET("/me/unread", middleware.AuthRequired(), handler.ListMyUnread)

	// 模型（带鉴权）
	api.GET("/models/active", middleware.AuthRequired(), handler.ListActiveModels)

	// 系统设置（需要鉴权）
	systemSetting := api.Group("/system-setting", middleware.AuthRequired())
	{
		systemSetting.GET("/teams", handler.ListTeams)
		systemSetting.GET("/teams/:id", handler.GetTeam)
		systemSetting.POST("/teams", handler.CreateTeam)
		systemSetting.PATCH("/teams/:id", handler.UpdateTeam)
		systemSetting.DELETE("/teams/:id", handler.DeleteTeam)
		systemSetting.GET("/teams/:id/members", handler.ListTeamMembers)
		systemSetting.POST("/teams/:id/members", handler.AddTeamMember)
		systemSetting.DELETE("/teams/:id/members/:userId", handler.RemoveTeamMember)

		systemSetting.GET("/users/:id/teams", handler.GetUserTeams)
		systemSetting.GET("/users/search", handler.SearchUsers)

		systemSetting.GET("/members", handler.ListUsers)
		systemSetting.GET("/members/:id", handler.GetUser)
		systemSetting.POST("/members", handler.CreateUser)
		systemSetting.PATCH("/members/:id", handler.UpdateUser)
		systemSetting.DELETE("/members/:id", handler.DeleteUser)

		systemSetting.GET("/dicts", handler.ListDicts)
		systemSetting.GET("/dicts/:id", handler.GetDict)
		systemSetting.POST("/dicts", handler.CreateDict)
		systemSetting.PATCH("/dicts/:id", handler.UpdateDict)
		systemSetting.DELETE("/dicts/:id", handler.DeleteDict)

		systemSetting.GET("/data-management/tables", handler.ListTables)
		systemSetting.GET("/data-management/tables/:tableName", handler.GetTableData)
		systemSetting.POST("/data-management/tables/:tableName/rows", handler.InsertTableRow)
		systemSetting.PATCH("/data-management/tables/:tableName/rows/:rowId", handler.UpdateTableRow)
		systemSetting.DELETE("/data-management/tables/:tableName/rows/:rowId", handler.DeleteTableRow)

		systemSetting.GET("/model-configs", handler.ListModelConfigs)
		systemSetting.GET("/model-configs/:id", handler.GetModelConfig)
		systemSetting.POST("/model-configs", handler.CreateModelConfig)
		systemSetting.PATCH("/model-configs/:id", handler.UpdateModelConfig)
		systemSetting.DELETE("/model-configs/:id", handler.DeleteModelConfig)
		systemSetting.POST("/model-configs/:id/verify", handler.VerifyModelConfig)

		systemSetting.GET("/middlewares", handler.ListSopMiddlewares)
		systemSetting.GET("/middlewares/:id", handler.GetSopMiddleware)
		systemSetting.POST("/middlewares", handler.CreateSopMiddleware)
		systemSetting.PATCH("/middlewares/:id", handler.UpdateSopMiddleware)
		systemSetting.DELETE("/middlewares/:id", handler.DeleteSopMiddleware)

		systemSetting.GET("/duty-schedules", handler.ListDutySchedules)
		systemSetting.GET("/duty-schedules/:id", handler.GetDutySchedule)
		systemSetting.POST("/duty-schedules", handler.CreateDutySchedule)
		systemSetting.PATCH("/duty-schedules/:id", handler.UpdateDutySchedule)
		systemSetting.DELETE("/duty-schedules/:id", handler.DeleteDutySchedule)

		systemSetting.GET("/sops", handler.ListSopDefinitions)
		systemSetting.GET("/sops/:id", handler.GetSopDefinition)
		systemSetting.POST("/sops", handler.CreateSopDefinition)
		systemSetting.PATCH("/sops/:id", handler.UpdateSopDefinition)

		systemSetting.GET("/mcps", handler.ListMcpConfigs)
		systemSetting.GET("/mcps/:id", handler.GetMcpConfig)
		systemSetting.POST("/mcps", handler.CreateMcpConfig)
		systemSetting.PATCH("/mcps/:id", handler.UpdateMcpConfig)
		systemSetting.GET("/mcps/:id/tools", handler.ListMcpTools)
		systemSetting.PATCH("/mcps/:id/tools/:toolId", handler.UpdateMcpTool)
		systemSetting.POST("/mcps/debug", handler.DebugMcpConnection)

		systemSetting.GET("/tools", handler.ListTools)
		systemSetting.GET("/tools/:id", handler.GetTool)
		systemSetting.PATCH("/tools/:id", handler.UpdateTool)
		systemSetting.POST("/tools/scan", handler.ScanTools)
		systemSetting.POST("/tools/:id/debug", handler.DebugTool)
	}

	// 中间件台账与机房验收（需要鉴权）
	ruok := api.Group("/ruok", middleware.AuthRequired())
	{
		ruok.GET("/idcs", handler.ListIdcs)
		ruok.GET("/idcs/:id", handler.GetIdc)
		ruok.POST("/idcs", handler.CreateIdc)
		ruok.PATCH("/idcs/:id", handler.UpdateIdc)
		ruok.DELETE("/idcs/:id", handler.DeleteIdc)

		ruok.GET("/hosts", handler.ListHosts)
		ruok.GET("/hosts/:id", handler.GetHost)
		ruok.POST("/hosts", handler.CreateHost)
		ruok.PATCH("/hosts/:id", handler.UpdateHost)
		ruok.DELETE("/hosts/:id", handler.DeleteHost)

		ruok.GET("/domains", handler.ListDomains)
		ruok.GET("/domains/:id", handler.GetDomain)
		ruok.POST("/domains", handler.CreateDomain)
		ruok.PATCH("/domains/:id", handler.UpdateDomain)
		ruok.DELETE("/domains/:id", handler.DeleteDomain)

		ruok.GET("/cmdb-sync-diffs", handler.ListCmdbSyncDiffs)

		ruok.GET("/standards", handler.ListStandards)
		ruok.GET("/standards/:id", handler.GetStandard)
		ruok.POST("/standards", handler.CreateStandard)
		ruok.PATCH("/standards/:id", handler.UpdateStandard)
		ruok.DELETE("/standards/:id", handler.DeleteStandard)
		ruok.PATCH("/standards/:id/move", handler.MoveStandard)

		ruok.GET("/component-tree", handler.ListComponentTree)
		ruok.GET("/component-tree/:id", handler.GetComponentTreeNode)
		ruok.POST("/component-tree", handler.CreateComponentTreeNode)
		ruok.PATCH("/component-tree/:id", handler.UpdateComponentTreeNode)
		ruok.DELETE("/component-tree/:id", handler.DeleteComponentTreeNode)
		ruok.PATCH("/component-tree/:id/move", handler.MoveComponentTreeNode)
	}

	// 技能管理（需要鉴权）
	skills := api.Group("/skills", middleware.AuthRequired())
	{
		skills.GET("", handler.ListSkills)
		skills.GET("/:id", handler.GetSkill)
		skills.POST("", handler.CreateSkill)
		skills.POST("/upload", handler.UploadSkill)
		skills.PATCH("/:id", handler.UpdateSkill)
		skills.DELETE("/:id", handler.DeleteSkill)
		skills.GET("/:id/tree", handler.GetSkillTree)
		skills.GET("/:id/file", handler.GetSkillFile)
		skills.PUT("/:id/file", handler.SaveSkillFile)
		skills.POST("/:id/file", handler.CreateSkillFile)
		skills.DELETE("/:id/file", handler.DeleteSkillFile)
	}
}
