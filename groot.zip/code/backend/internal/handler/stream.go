package handler

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"groot-backend/internal/repo"
)

// StreamGrootReply SSE 流式端点：调用大模型并逐 token 返回
func StreamGrootReply(c *gin.Context) {
	eventID, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid event id"})
		return
	}

	modelCode := c.Query("modelCode")

	// 获取激活的聊天模型（优先使用前端指定的模型）
	modelCfg, err := repo.GetActiveChatModelByCode(modelCode)
	if err != nil {
		c.JSON(http.StatusServiceUnavailable, gin.H{"error": err.Error()})
		return
	}
	if modelCfg == nil {
		c.JSON(http.StatusServiceUnavailable, gin.H{"error": "没有可用的聊天模型，请先在系统设置中配置并激活"})
		return
	}

	// 前置检查：API Key 不能为空
	if modelCfg.APIKey == "" {
		c.JSON(http.StatusServiceUnavailable, gin.H{"error": "聊天模型的 API Key 未配置，请先在系统设置中配置 API Key"})
		return
	}

	// 获取事件历史消息作为上下文
	history := repo.GetMessages(eventID)

	// 构造消息列表
	messages := make([]map[string]string, 0, len(history)+1)
	messages = append(messages, map[string]string{
		"role":    "system",
		"content": "你是 Groot，一个运维智能助手。你精通中间件运维、故障排查、性能优化。请用简洁专业的中文回答。",
	})
	for _, msg := range history {
		role := msg.Role
		if role == "agent" {
			role = "assistant"
		}
		messages = append(messages, map[string]string{
			"role":    role,
			"content": msg.Content,
		})
	}

	// 构造请求体
	reqBody := map[string]interface{}{
		"model":    modelCfg.Code,
		"messages": messages,
		"stream":   true,
	}
	if modelCfg.MaxTokens > 0 {
		reqBody["max_tokens"] = modelCfg.MaxTokens
	}
	if modelCfg.Temperature != nil {
		reqBody["temperature"] = *modelCfg.Temperature
	}

	jsonBody, err := json.Marshal(reqBody)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to marshal request"})
		return
	}

	apiURL := modelCfg.BaseURL + "/chat/completions"
	httpReq, err := http.NewRequest("POST", apiURL, bytes.NewReader(jsonBody))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to create request"})
		return
	}
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("Authorization", "Bearer "+modelCfg.APIKey)
	httpReq.Header.Set("Accept", "text/event-stream")

	client := &http.Client{Timeout: 120 * time.Second}
	resp, err := client.Do(httpReq)
	if err != nil {
		c.JSON(http.StatusBadGateway, gin.H{"error": fmt.Sprintf("模型连接失败: %s", err.Error())})
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		body, _ := io.ReadAll(resp.Body)
		c.JSON(http.StatusBadGateway, gin.H{
			"error":    fmt.Sprintf("模型返回错误 (HTTP %d)", resp.StatusCode),
			"response": string(body),
		})
		return
	}

	// 设置 SSE 响应头
	c.Writer.Header().Set("Content-Type", "text/event-stream")
	c.Writer.Header().Set("Cache-Control", "no-cache")
	c.Writer.Header().Set("Connection", "keep-alive")
	c.Writer.Header().Set("X-Accel-Buffering", "no")
	c.Writer.Flush()

	// 读取大模型流式响应，逐 token 转发给前端
	var fullContent strings.Builder
	reader := bufio.NewReader(resp.Body)

	for {
		line, err := reader.ReadString('\n')
		if err != nil {
			if err == io.EOF {
				break
			}
			sendSSE(c, "error", gin.H{"error": err.Error()})
			return
		}

		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		if !strings.HasPrefix(line, "data: ") {
			continue
		}

		data := strings.TrimPrefix(line, "data: ")

		// [DONE] 表示流结束
		if data == "[DONE]" {
			break
		}

		// 解析 OpenAI 流式响应
		var chunk struct {
			Choices []struct {
				Delta struct {
					Content string `json:"content"`
				} `json:"delta"`
			} `json:"choices"`
		}
		if err := json.Unmarshal([]byte(data), &chunk); err != nil {
			continue
		}

		for _, choice := range chunk.Choices {
			token := choice.Delta.Content
			if token == "" {
				continue
			}
			fullContent.WriteString(token)
			sendSSE(c, "token", gin.H{"content": token})
		}
	}

	// 保存完整回复到数据库
	fullReply := fullContent.String()
	if fullReply != "" {
		repo.AddGrootReply(eventID, fullReply)
	}

	// 发送完成事件
	sendSSE(c, "done", nil)
}

func sendSSE(c *gin.Context, eventType string, data gin.H) {
	if data == nil {
		data = gin.H{}
	}
	data["type"] = eventType
	jsonData, err := json.Marshal(data)
	if err != nil {
		return
	}
	fmt.Fprintf(c.Writer, "data: %s\n\n", string(jsonData))
	c.Writer.Flush()
}
