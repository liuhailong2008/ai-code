package handler

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"groot-backend/internal/model"
	"groot-backend/internal/repo"
)

func ListModelConfigs(c *gin.Context) {
	configs, err := repo.ListModelConfigs()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	if configs == nil {
		configs = []model.ModelConfig{}
	}
	c.JSON(http.StatusOK, configs)
}

// ListActiveModels 返回指定用途下已激活+启用的模型列表（不含敏感字段）
// Query 参数: purpose = chat | reasoning | embedding | vision | rerank | all
func ListActiveModels(c *gin.Context) {
	purpose := c.Query("purpose")
	if purpose == "" {
		purpose = "chat"
	}
	configs, err := repo.ListActiveModels(purpose)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	if configs == nil {
		configs = []model.ModelConfig{}
	}
	c.JSON(http.StatusOK, configs)
}

func GetModelConfig(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	config, err := repo.GetModelConfigWithKey(id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	if config == nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "model config not found"})
		return
	}
	c.JSON(http.StatusOK, config)
}

func CreateModelConfig(c *gin.Context) {
	var req model.CreateModelConfigRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	config, err := repo.CreateModelConfig(&req, "admin")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusCreated, config)
}

func UpdateModelConfig(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	var req model.UpdateModelConfigRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	config, err := repo.UpdateModelConfig(id, &req, "admin")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	if config == nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "model config not found"})
		return
	}
	c.JSON(http.StatusOK, config)
}

func DeleteModelConfig(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	if err := repo.DeleteModelConfig(id); err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "model config not found"})
		return
	}
	c.Status(http.StatusNoContent)
}

// VerifyModelConfig 验证模型连通性，发送测试提示词并返回模型回复
// 支持可选请求体传入 apiKey/baseUrl/code 等覆写字段，用于"先验证再保存"场景
func VerifyModelConfig(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	// 尝试解析请求体中的覆写字段
	var overrides model.UpdateModelConfigRequest
	hasOverrides := false
	if c.Request.ContentLength > 0 {
		if err := c.ShouldBindJSON(&overrides); err == nil {
			hasOverrides = true
		}
	}

	var apiKey, baseURL, code string
	var temperature *float64

	// 先从数据库读取原始配置作为兜底（非新建场景）
	if id > 0 {
		config, err := repo.GetModelConfigWithKey(id)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
			return
		}
		if config != nil {
			apiKey = config.APIKey
			baseURL = config.BaseURL
			code = config.Code
			temperature = config.Temperature
		}
	}

	// 再用前端传来的覆写值覆盖
	if hasOverrides {
		if overrides.APIKey != nil && *overrides.APIKey != "" {
			apiKey = *overrides.APIKey
		}
		if overrides.BaseURL != nil && *overrides.BaseURL != "" {
			baseURL = *overrides.BaseURL
		}
		if overrides.Code != nil && *overrides.Code != "" {
			code = *overrides.Code
		}
		if overrides.Temperature != nil {
			temperature = overrides.Temperature
		}
	}

	// 前置检查：API Key 不能为空
	if apiKey == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "未配置 API Key，请先填写 API Key"})
		return
	}

	// 构造 OpenAI 兼容的请求体
	reqBody := map[string]interface{}{
		"model": code,
		"messages": []map[string]string{
			{"role": "user", "content": "你准备好了吗？"},
		},
		"max_tokens": 100,
	}
	if temperature != nil {
		reqBody["temperature"] = *temperature
	}

	jsonBody, err := json.Marshal(reqBody)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to marshal request"})
		return
	}

	apiURL := baseURL + "/chat/completions"

	httpReq, err := http.NewRequest("POST", apiURL, bytes.NewReader(jsonBody))
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to create request"})
		return
	}
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("Authorization", "Bearer "+apiKey)

	client := &http.Client{Timeout: 30 * time.Second}
	resp, err := client.Do(httpReq)
	if err != nil {
		c.JSON(http.StatusBadGateway, gin.H{"error": fmt.Sprintf("模型连接失败: %s", err.Error())})
		return
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to read response"})
		return
	}

	if resp.StatusCode != http.StatusOK {
		c.JSON(http.StatusBadGateway, gin.H{
			"error":    fmt.Sprintf("模型返回错误 (HTTP %d)", resp.StatusCode),
			"response": string(body),
		})
		return
	}

	var result struct {
		Choices []struct {
			Message struct {
				Content string `json:"content"`
			} `json:"message"`
		} `json:"choices"`
	}
	if err := json.Unmarshal(body, &result); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{
			"error":    "无法解析模型响应",
			"response": string(body),
		})
		return
	}

	content := ""
	if len(result.Choices) > 0 {
		content = result.Choices[0].Message.Content
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"content": content,
	})
}
