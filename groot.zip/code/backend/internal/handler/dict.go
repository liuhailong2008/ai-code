package handler

import (
	"net/http"

	"github.com/gin-gonic/gin"

	"groot-backend/internal/model"
	"groot-backend/internal/repo"
)

// ============================================================
// 数据字典
// ============================================================

func ListDicts(c *gin.Context) {
	list, err := repo.ListDicts()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, list)
}

func GetDict(c *gin.Context) {
	id, err := parseID(c)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	item, err := repo.GetDict(id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	if item == nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "dict not found"})
		return
	}
	c.JSON(http.StatusOK, item)
}

func CreateDict(c *gin.Context) {
	var req model.CreateDictRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	item, err := repo.CreateDict(&req)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusCreated, item)
}

func UpdateDict(c *gin.Context) {
	id, err := parseID(c)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	var req model.UpdateDictRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	item, err := repo.UpdateDict(id, &req)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	if item == nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "dict not found"})
		return
	}
	c.JSON(http.StatusOK, item)
}

func DeleteDict(c *gin.Context) {
	id, err := parseID(c)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	if err := repo.DeleteDict(id); err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "dict not found"})
		return
	}
	c.Status(http.StatusNoContent)
}
