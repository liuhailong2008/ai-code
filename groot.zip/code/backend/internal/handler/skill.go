package handler

import (
	"database/sql"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"groot-backend/internal/config"
	"groot-backend/internal/model"
	"groot-backend/internal/repo"
	"groot-backend/internal/service"
)

var skillsDir string

func InitSkillsDir(cfg *config.Config) {
	skillsDir = cfg.SkillsDir
}

// --- Skill CRUD Handlers ---

func ListSkills(c *gin.Context) {
	list, err := repo.ListSkills()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	if list == nil {
		list = []model.Skill{}
	}
	c.JSON(http.StatusOK, list)
}

func GetSkill(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	skill, err := repo.GetSkill(id)
	if err != nil {
		if err == sql.ErrNoRows {
			c.JSON(http.StatusNotFound, gin.H{"error": "skill not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, skill)
}

func CreateSkill(c *gin.Context) {
	var req model.CreateSkillRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	username := c.GetString("username")
	filePath := req.SkillCode

	skill := &model.Skill{
		SkillName:   req.SkillName,
		SkillCode:   req.SkillCode,
		Description: req.Description,
		Version:     req.Version,
		FilePath:    filePath,
		CreatedBy:   username,
	}

	id, err := repo.CreateSkill(skill)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// 确保技能目录存在
	destDir := filepath.Join(skillsDir, req.SkillCode)
	os.MkdirAll(destDir, 0755)

	created, _ := repo.GetSkill(id)
	c.JSON(http.StatusCreated, created)
}

func UpdateSkill(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	var req model.UpdateSkillRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	username := c.GetString("username")
	if err := repo.UpdateSkill(id, &req, username); err != nil {
		if err == sql.ErrNoRows {
			c.JSON(http.StatusNotFound, gin.H{"error": "skill not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	skill, _ := repo.GetSkill(id)
	c.JSON(http.StatusOK, skill)
}

func DeleteSkill(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	skill, err := repo.GetSkill(id)
	if err != nil {
		if err == sql.ErrNoRows {
			c.JSON(http.StatusNotFound, gin.H{"error": "skill not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// 删除文件系统中的技能目录
	destDir := filepath.Join(skillsDir, skill.FilePath)
	os.RemoveAll(destDir)

	// 删除数据库中的文件索引
	repo.DeleteSkillFiles(id)

	// 删除技能记录
	repo.DeleteSkill(id)

	c.JSON(http.StatusNoContent, nil)
}

// --- Upload Handler ---

func UploadSkill(c *gin.Context) {
	file, err := c.FormFile("file")
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "请上传 zip 文件"})
		return
	}

	// 技能编码：优先用表单字段，否则用文件名（去掉 .zip 后缀）
	skillCode := c.PostForm("skillCode")
	if skillCode == "" {
		ext := filepath.Ext(file.Filename)
		skillCode = file.Filename[:len(file.Filename)-len(ext)]
	}

	// 保存临时 zip 文件
	tmpPath := filepath.Join(os.TempDir(), file.Filename)
	if err := c.SaveUploadedFile(file, tmpPath); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "保存上传文件失败: " + err.Error()})
		return
	}
	defer os.Remove(tmpPath)

	username := c.GetString("username")
	skill, err := service.SaveSkillFromZip(tmpPath, skillsDir, skillCode, username)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusCreated, skill)
}

// --- File Browsing & Editing Handlers ---

func GetSkillTree(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	skill, err := repo.GetSkill(id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "skill not found"})
		return
	}

	files, err := repo.ListSkillFiles(id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	tree := service.BuildSkillTree(files)
	c.JSON(http.StatusOK, model.SkillTreeResponse{
		SkillID:   skill.ID,
		SkillName: skill.SkillName,
		Tree:      tree,
	})
}

func GetSkillFile(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	filePath := c.Query("path")
	if filePath == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "path is required"})
		return
	}

	skill, err := repo.GetSkill(id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "skill not found"})
		return
	}

	skillDir := filepath.Join(skillsDir, skill.FilePath)
	fullPath, err := service.ValidatePath(skillDir, filePath)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	data, err := os.ReadFile(fullPath)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "文件不存在"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"path":    filePath,
		"content": string(data),
	})
}

func SaveSkillFile(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	filePath := c.Query("path")
	if filePath == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "path is required"})
		return
	}

	var req model.SaveFileRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	skill, err := repo.GetSkill(id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "skill not found"})
		return
	}

	skillDir := filepath.Join(skillsDir, skill.FilePath)
	fullPath, err := service.ValidatePath(skillDir, filePath)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	if err := os.WriteFile(fullPath, []byte(req.Content), 0644); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "保存文件失败: " + err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"success": true})
}

func CreateSkillFile(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	filePath := c.Query("path")
	if filePath == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "path is required"})
		return
	}

	var req model.SaveFileRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	skill, err := repo.GetSkill(id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "skill not found"})
		return
	}

	skillDir := filepath.Join(skillsDir, skill.FilePath)
	fullPath, err := service.ValidatePath(skillDir, filePath)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// 确保父目录存在
	if err := os.MkdirAll(filepath.Dir(fullPath), 0755); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "创建目录失败: " + err.Error()})
		return
	}

	// 检查文件是否已存在
	if _, err := os.Stat(fullPath); err == nil {
		c.JSON(http.StatusConflict, gin.H{"error": "文件已存在"})
		return
	}

	if err := os.WriteFile(fullPath, []byte(req.Content), 0644); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "创建文件失败: " + err.Error()})
		return
	}

	// 同时更新数据库索引（如果是目录下的文件）
	if strings.HasSuffix(filePath, ".md") {
		repo.InsertSkillFile(&model.SkillFile{
			SkillID:    id,
			FileName:   filepath.Base(filePath),
			FilePath:   filePath,
			FileType:   "file",
			ParentPath: filepath.Dir(filePath),
		})
	}

	c.JSON(http.StatusCreated, gin.H{"success": true, "path": filePath})
}

func DeleteSkillFile(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	filePath := c.Query("path")
	if filePath == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "path is required"})
		return
	}

	skill, err := repo.GetSkill(id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "skill not found"})
		return
	}

	skillDir := filepath.Join(skillsDir, skill.FilePath)
	fullPath, err := service.ValidatePath(skillDir, filePath)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	if err := os.Remove(fullPath); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "删除文件失败: " + err.Error()})
		return
	}

	// 从数据库索引中删除
	repo.DeleteSkillFileByPath(id, filePath)

	c.JSON(http.StatusNoContent, nil)
}
