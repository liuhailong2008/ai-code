package handler

import (
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"groot-backend/internal/repo"
)

// StaffMember 人员信息（用户名 + 显示名）
type StaffMember struct {
	Username    string `json:"username"`
	DisplayName string `json:"displayName"`
}

func resolveStaff(username string) StaffMember {
	m := StaffMember{Username: username, DisplayName: username}
	if username == "" {
		return m
	}
	u, err := repo.FindUserByUsername(username)
	if err == nil && u != nil && u.DisplayName != "" {
		m.DisplayName = u.DisplayName
	}
	return m
}

// EventStaffingResponse 事件值班/组件人员信息
type EventStaffingResponse struct {
	AppName       string      `json:"appName"`
	AppDesc       string      `json:"appDesc"`
	PrimaryPost   StaffMember `json:"primaryPost"`
	BackupPost    StaffMember `json:"backupPost"`
	HasMiddleware bool        `json:"hasMiddleware"`

	DutyDate        string      `json:"dutyDate"`
	Department      string      `json:"department"`
	PositionName    string      `json:"positionName"`
	DutyPrimaryUser StaffMember `json:"dutyPrimaryUser"`
	DutyBackupUser  StaffMember `json:"dutyBackupUser"`
	HasDuty         bool        `json:"hasDuty"`
}

// GetEventStaffing 返回事件相关的值班和组件主备岗信息
func GetEventStaffing(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid event id"})
		return
	}

	event := repo.GetEvent(id)
	if event == nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "event not found"})
		return
	}

	resp := EventStaffingResponse{
		AppName: event.AppName,
	}

	if event.AppName != "" {
		mw, err := repo.GetSopMiddlewareByAppName(event.AppName)
		if err == nil && mw != nil {
			resp.AppDesc = mw.AppDesc
			resp.PrimaryPost = resolveStaff(mw.PrimaryPost)
			resp.BackupPost = resolveStaff(mw.BackupPost)
			resp.HasMiddleware = true
		}
	}

	today := time.Now().Format("2006-01-02")
	resp.DutyDate = today
	duty, err := repo.GetDutyScheduleByDate(today)
	if err == nil && duty != nil {
		resp.Department = duty.Department
		resp.PositionName = duty.PositionName
		resp.DutyPrimaryUser = resolveStaff(duty.PrimaryUser)
		resp.DutyBackupUser = resolveStaff(duty.BackupUser)
		resp.HasDuty = true
	}

	c.JSON(http.StatusOK, resp)
}

// GetUIBlocks 返回事件关联的 UI 交互块列表（目前为预留功能，返回空数组）
func GetUIBlocks(c *gin.Context) {
	c.JSON(http.StatusOK, []struct{}{})
}

