package handler

import (
	"context"
	"database/sql"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"groot-backend/internal/model"
	"groot-backend/internal/repo"
	"groot-backend/internal/tools"
)

// ListTools 列出所有工具
func ListTools(c *gin.Context) {
	list, err := repo.ListTools()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	if list == nil {
		list = []model.Tool{}
	}
	c.JSON(http.StatusOK, list)
}

// GetTool 获取单个工具
func GetTool(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	t, err := repo.GetTool(id)
	if err != nil {
		if err == sql.ErrNoRows {
			c.JSON(http.StatusNotFound, gin.H{"error": "tool not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, t)
}

// UpdateTool 更新工具
func UpdateTool(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	var req model.UpdateToolRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	actorID := c.GetString("actor_id")
	t, err := repo.UpdateTool(id, &req, actorID)
	if err != nil {
		if err == sql.ErrNoRows {
			c.JSON(http.StatusNotFound, gin.H{"error": "tool not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, t)
}

// ScanTools 扫描工具实现目录，自动发现并注册新工具
func ScanTools(c *gin.Context) {
	actorID := c.GetString("actor_id")
	discovered, inserted, err := doScanTools(actorID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"discovered": discovered,
		"inserted":   inserted,
	})
}

// DebugTool 调试工具
func DebugTool(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	var req struct {
		Input string `json:"input"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	dbTool, err := repo.GetTool(id)
	if err != nil {
		if err == sql.ErrNoRows {
			c.JSON(http.StatusNotFound, gin.H{"error": "tool not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	t, ok := tools.Get(dbTool.ToolName)
	if !ok {
		c.JSON(http.StatusNotFound, gin.H{"error": "tool implementation not found in registry"})
		return
	}

	output, err := t.Run(context.Background(), req.Input)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{
			"success": false,
			"error":   err.Error(),
		})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"success": true,
		"output":  output,
	})
}

// doScanTools 执行工具扫描，遍历注册表中所有已注册的工具
func doScanTools(createdBy string) (discovered []string, inserted []string, err error) {
	discovered = []string{}
	inserted = []string{}

	allTools := tools.GetAll()
	if len(allTools) == 0 {
		return discovered, inserted, nil
	}

	for _, t := range allTools {
		info := t.Info()
		discovered = append(discovered, info.Name)

		var desc *string
		if info.Description != "" {
			desc = &info.Description
		}
		var inputSchema *string
		if info.InputSchema != "" {
			inputSchema = &info.InputSchema
		}
		var outputSchema *string
		if info.OutputSchema != "" {
			outputSchema = &info.OutputSchema
		}

		category := info.Category
		if category == "" {
			category = "general"
		}

		implClass := "tools/" + info.Name

		existing, _ := repo.GetToolByName(info.Name)
		if existing == nil {
			if err := repo.UpsertTool(info.Name, info.DisplayName, implClass, category, createdBy, desc, inputSchema, outputSchema); err != nil {
				return discovered, inserted, err
			}
			inserted = append(inserted, info.Name)
		} else {
			repo.UpsertTool(info.Name, info.DisplayName, implClass, category, createdBy, desc, inputSchema, outputSchema)
		}
	}

	return discovered, inserted, nil
}

// EnsureToolsTable 初始化 tools 表并执行首次扫描
func EnsureToolsTable(createdBy string) error {
	if err := repo.EnsureToolsTable(); err != nil {
		return err
	}
	_, _, err := doScanTools(createdBy)
	return err
}
