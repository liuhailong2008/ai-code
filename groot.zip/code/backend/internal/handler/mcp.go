package handler

import (
	"bytes"
	"database/sql"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"groot-backend/internal/model"
	"groot-backend/internal/repo"
)

// --- MCP Config Handlers ---

func ListMcpConfigs(c *gin.Context) {
	list, err := repo.ListMcpConfigs()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	if list == nil {
		list = []model.McpConfig{}
	}
	c.JSON(http.StatusOK, list)
}

func GetMcpConfig(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	mcp, err := repo.GetMcpConfig(id)
	if err != nil {
		if err == sql.ErrNoRows {
			c.JSON(http.StatusNotFound, gin.H{"error": "MCP not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, mcp)
}

func CreateMcpConfig(c *gin.Context) {
	var req model.CreateMcpRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	actorID := c.GetString("actor_id")
	mcp, err := repo.CreateMcpConfig(&req, actorID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusCreated, mcp)
}

func UpdateMcpConfig(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	var req model.UpdateMcpRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	actorID := c.GetString("actor_id")
	mcp, err := repo.UpdateMcpConfig(id, &req, actorID)
	if err != nil {
		if err == sql.ErrNoRows {
			c.JSON(http.StatusNotFound, gin.H{"error": "MCP not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, mcp)
}

// --- MCP Tool Handlers ---

func ListMcpTools(c *gin.Context) {
	mcpID, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	tools, err := repo.ListMcpTools(mcpID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	if tools == nil {
		tools = []model.McpTool{}
	}
	c.JSON(http.StatusOK, tools)
}

func UpdateMcpTool(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("toolId"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid tool id"})
		return
	}
	var req model.UpdateMcpToolRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	tool, err := repo.UpdateMcpTool(id, &req)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, tool)
}

// --- MCP Debug / Discover ---

type McpDebugRequest struct {
	McpName  string `json:"mcpName"`
	McpType  string `json:"mcpType"`
	BaseURL  string `json:"baseUrl"`
	ApiKey   string `json:"apiKey"`
	McpID    int64  `json:"mcpId"` // 0 for new, >0 for existing
}

type McpDiscoveredTool struct {
	Name        string `json:"name"`
	Description string `json:"description"`
	InputSchema json.RawMessage `json:"inputSchema"`
}

type McpDebugResponse struct {
	Success bool                `json:"success"`
	Message string              `json:"message"`
	Tools   []McpDiscoveredTool `json:"tools"`
}

func DebugMcpConnection(c *gin.Context) {
	var req McpDebugRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Send tools/list JSON-RPC request to MCP server
	tools, err := discoverMcpTools(req.BaseURL, req.ApiKey)
	if err != nil {
		c.JSON(http.StatusOK, McpDebugResponse{
			Success: false,
			Message: fmt.Sprintf("连接失败: %v", err),
			Tools:   []McpDiscoveredTool{},
		})
		return
	}

	// If mcpId > 0, save discovered tools to DB
	if req.McpID > 0 {
		for _, t := range tools {
			inputSchema := string(t.InputSchema)
			desc := t.Description
			repo.UpsertMcpTool(&model.McpTool{
				McpID:       req.McpID,
				ToolName:    t.Name,
				ToolDesc:    &desc,
				InputSchema: &inputSchema,
			})
		}
	}

	c.JSON(http.StatusOK, McpDebugResponse{
		Success: true,
		Message: fmt.Sprintf("连接成功，发现 %d 个工具", len(tools)),
		Tools:   tools,
	})
}

func discoverMcpTools(baseURL string, apiKey string) ([]McpDiscoveredTool, error) {
	rpcReq := map[string]interface{}{
		"jsonrpc": "2.0",
		"method":  "tools/list",
		"id":      1,
	}
	body, _ := json.Marshal(rpcReq)

	client := &http.Client{Timeout: 10 * time.Second}
	req, err := http.NewRequest("POST", baseURL, bytes.NewReader(body))
	if err != nil {
		return nil, fmt.Errorf("create request: %w", err)
	}
	req.Header.Set("Content-Type", "application/json")
	if apiKey != "" {
		req.Header.Set("Authorization", "Bearer "+apiKey)
	}

	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("request: %w", err)
	}
	defer resp.Body.Close()

	respBody, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("read response: %w", err)
	}

	// Parse JSON-RPC response
	var rpcResp struct {
		Result struct {
			Tools []McpDiscoveredTool `json:"tools"`
		} `json:"result"`
		Error *struct {
			Message string `json:"message"`
		} `json:"error"`
	}
	if err := json.Unmarshal(respBody, &rpcResp); err != nil {
		return nil, fmt.Errorf("parse response: %w (body: %s)", err, string(respBody[:min(len(respBody), 200)]))
	}
	if rpcResp.Error != nil {
		return nil, fmt.Errorf("rpc error: %s", rpcResp.Error.Message)
	}

	return rpcResp.Result.Tools, nil
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
