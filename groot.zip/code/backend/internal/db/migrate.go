package db

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

// runMigrations 按文件名顺序执行 SQL 目录下的所有建表/初始化脚本。
// 所有脚本必须幂等（CREATE TABLE IF NOT EXISTS / INSERT IGNORE），可安全重复执行。
func runMigrations(sqlDir string) error {
	files, err := listSQLFiles(sqlDir)
	if err != nil {
		return err
	}
	for _, f := range files {
		raw, err := os.ReadFile(f)
		if err != nil {
			return err
		}
		stmts := splitSQL(string(raw))
		for _, s := range stmts {
			if _, err := DB.Exec(s); err != nil {
				return fmt.Errorf("%s: %w", filepath.Base(f), err)
			}
		}
		fmt.Printf("migrated %s (%d 条语句)\n", filepath.Base(f), len(stmts))
	}
	return nil
}

func listSQLFiles(dir string) ([]string, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, err
	}
	var out []string
	for _, e := range entries {
		if !e.IsDir() && strings.HasSuffix(e.Name(), ".sql") {
			out = append(out, filepath.Join(dir, e.Name()))
		}
	}
	sort.Strings(out)
	return out, nil
}

// splitSQL 按分号拆分语句并跳过 -- 行注释。
// 仅适用于本项目不含存储过程、字符串内不含分号的简单脚本。
func splitSQL(raw string) []string {
	var lines []string
	for _, ln := range strings.Split(raw, "\n") {
		trimmed := strings.TrimSpace(ln)
		if strings.HasPrefix(trimmed, "--") {
			continue
		}
		lines = append(lines, trimmed)
	}
	joined := strings.Join(lines, "\n")
	var out []string
	for _, part := range strings.Split(joined, ";") {
		part = strings.TrimSpace(part)
		if part != "" {
			out = append(out, part)
		}
	}
	return out
}
