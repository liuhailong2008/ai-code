package db

import (
	"database/sql"
	"fmt"
	"log"
	"os"

	"groot-backend/internal/config"

	_ "github.com/dolthub/driver"
)

var DB *sql.DB

func Init(cfg *config.Config) {
	var err error

	// 内嵌驱动要求数据目录预先存在
	if err = os.MkdirAll(cfg.DBDir, 0o755); err != nil {
		log.Fatalf("failed to create data dir: %v", err)
	}

	DB, err = sql.Open("dolt", cfg.DSN())
	if err != nil {
		log.Fatalf("failed to open database: %v", err)
	}

	DB.SetMaxOpenConns(25)
	DB.SetMaxIdleConns(5)

	if err = DB.Ping(); err != nil {
		log.Fatalf("failed to ping database: %v", err)
	}

	// 首次启动时创建数据库（内嵌驱动不会自动建库）
	if _, err = DB.Exec("CREATE DATABASE IF NOT EXISTS " + cfg.DBName); err != nil {
		log.Fatalf("failed to create database: %v", err)
	}
	if _, err = DB.Exec("USE " + cfg.DBName); err != nil {
		log.Fatalf("failed to use database: %v", err)
	}

	// 执行建表/初始化脚本
	if err = runMigrations(cfg.SQLDir); err != nil {
		log.Fatalf("failed to run migrations: %v", err)
	}

	fmt.Println("database connected successfully")
}

func Close() {
	if DB != nil {
		DB.Close()
	}
}
