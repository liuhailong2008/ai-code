package editfile

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"

	"groot-backend/internal/tools"
)

func init() {
	tools.Register(&EditFileTool{})
}

type EditFileTool struct{}

func (t *EditFileTool) Info() tools.ToolInfo {
	return tools.ToolInfo{
		Name:        "edit_file",
		DisplayName: "编辑文件",
		Description: "在文件中替换指定文本",
		Category:    "filesystem",
		InputSchema: `{"type":"object","properties":{"file_path":{"type":"string","description":"文件路径"},"old_str":{"type":"string","description":"要替换的原文本"},"new_str":{"type":"string","description":"替换后的新文本"}},"required":["file_path","old_str","new_str"]}`,
		OutputSchema: `{"type":"object","properties":{"success":{"type":"boolean"}}}`,
	}
}

func (t *EditFileTool) Run(ctx context.Context, argumentsInJSON string) (string, error) {
	var args struct {
		FilePath string `json:"file_path"`
		OldStr   string `json:"old_str"`
		NewStr   string `json:"new_str"`
	}
	if err := json.Unmarshal([]byte(argumentsInJSON), &args); err != nil {
		return "", fmt.Errorf("invalid arguments: %w", err)
	}
	data, err := os.ReadFile(args.FilePath)
	if err != nil {
		return "", fmt.Errorf("read file error: %w", err)
	}
	content := string(data)
	if !strings.Contains(content, args.OldStr) {
		return "", fmt.Errorf("old_str not found in file")
	}
	newContent := strings.Replace(content, args.OldStr, args.NewStr, 1)
	if err := os.WriteFile(args.FilePath, []byte(newContent), 0644); err != nil {
		return "", fmt.Errorf("write file error: %w", err)
	}
	result, _ := json.Marshal(map[string]bool{"success": true})
	return string(result), nil
}
