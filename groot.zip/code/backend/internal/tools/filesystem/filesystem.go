package filesystem

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"groot-backend/internal/tools"
)

func init() {
	tools.Register(&FileSystemTool{})
}

// FileSystemTool 文件系统工具
type FileSystemTool struct{}

func (t *FileSystemTool) Info() tools.ToolInfo {
	return tools.ToolInfo{
		Name:         "filesystem",
		DisplayName:  "文件系统",
		Description:  "访问本地文件系统，支持列出目录、读取文件内容",
		Category:     "filesystem",
		InputSchema:  `{"type":"object","properties":{"action":{"type":"string","enum":["list","read"]},"path":{"type":"string","description":"文件或目录路径"}},"required":["action","path"]}`,
		OutputSchema: `{"type":"object","properties":{"result":{"type":"string","description":"执行结果"}}}`,
	}
}

func (t *FileSystemTool) Run(ctx context.Context, argumentsInJSON string) (string, error) {
	var args struct {
		Action string `json:"action"`
		Path   string `json:"path"`
	}
	if err := json.Unmarshal([]byte(argumentsInJSON), &args); err != nil {
		return "", fmt.Errorf("invalid arguments: %w", err)
	}

	absPath, err := filepath.Abs(args.Path)
	if err != nil {
		return "", fmt.Errorf("invalid path: %w", err)
	}
	cwd, _ := os.Getwd()
	if !strings.HasPrefix(absPath, cwd) {
		return "", fmt.Errorf("access denied: path outside working directory")
	}

	switch args.Action {
	case "list":
		return t.listDir(absPath)
	case "read":
		return t.readFile(absPath)
	default:
		return "", fmt.Errorf("unknown action: %s", args.Action)
	}
}

func (t *FileSystemTool) listDir(path string) (string, error) {
	entries, err := os.ReadDir(path)
	if err != nil {
		return "", fmt.Errorf("read dir error: %w", err)
	}
	var files []string
	for _, e := range entries {
		suffix := ""
		if e.IsDir() {
			suffix = "/"
		}
		files = append(files, e.Name()+suffix)
	}
	data, _ := json.Marshal(map[string]interface{}{
		"path":  path,
		"files": files,
	})
	return string(data), nil
}

func (t *FileSystemTool) readFile(path string) (string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return "", fmt.Errorf("read file error: %w", err)
	}
	return string(data), nil
}
