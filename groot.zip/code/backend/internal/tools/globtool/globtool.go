package globtool

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"

	"groot-backend/internal/tools"
)

func init() {
	tools.Register(&GlobTool{})
}

type GlobTool struct{}

func (t *GlobTool) Info() tools.ToolInfo {
	return tools.ToolInfo{
		Name:        "glob",
		DisplayName: "文件匹配",
		Description: "根据 glob 模式匹配文件",
		Category:    "filesystem",
		InputSchema: `{"type":"object","properties":{"pattern":{"type":"string","description":"glob 匹配模式，如 *.go"}},"required":["pattern"]}`,
		OutputSchema: `{"type":"object","properties":{"files":{"type":"array","items":{"type":"string"}}}}`,
	}
}

func (t *GlobTool) Run(ctx context.Context, argumentsInJSON string) (string, error) {
	var args struct {
		Pattern string `json:"pattern"`
	}
	if err := json.Unmarshal([]byte(argumentsInJSON), &args); err != nil {
		return "", fmt.Errorf("invalid arguments: %w", err)
	}
	matches, err := filepath.Glob(args.Pattern)
	if err != nil {
		return "", fmt.Errorf("glob error: %w", err)
	}
	if matches == nil {
		matches = []string{}
	}
	// 过滤出文件（排除目录）
	var files []string
	for _, m := range matches {
		info, err := os.Stat(m)
		if err != nil {
			continue
		}
		suffix := ""
		if info.IsDir() {
			suffix = "/"
		}
		files = append(files, m+suffix)
	}
	result, _ := json.Marshal(map[string]interface{}{"files": files})
	return string(result), nil
}
