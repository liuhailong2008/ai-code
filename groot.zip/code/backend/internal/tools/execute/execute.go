package execute

import (
	"context"
	"encoding/json"
	"fmt"
	"os/exec"
	"strings"

	"groot-backend/internal/tools"
)

func init() {
	tools.Register(&ExecuteTool{})
}

type ExecuteTool struct{}

func (t *ExecuteTool) Info() tools.ToolInfo {
	return tools.ToolInfo{
		Name:        "execute",
		DisplayName: "执行命令",
		Description: "执行 Shell 命令并返回输出",
		Category:    "system",
		InputSchema: `{"type":"object","properties":{"command":{"type":"string","description":"要执行的 Shell 命令"},"cwd":{"type":"string","description":"工作目录（可选）"}},"required":["command"]}`,
		OutputSchema: `{"type":"object","properties":{"stdout":{"type":"string"},"stderr":{"type":"string"},"exit_code":{"type":"integer"}}}`,
	}
}

func (t *ExecuteTool) Run(ctx context.Context, argumentsInJSON string) (string, error) {
	var args struct {
		Command string `json:"command"`
		Cwd     string `json:"cwd"`
	}
	if err := json.Unmarshal([]byte(argumentsInJSON), &args); err != nil {
		return "", fmt.Errorf("invalid arguments: %w", err)
	}

	// 安全检查：禁止危险命令
	dangerous := []string{"rm ", "mkfs", "dd if=", "> /dev/", "shutdown", "reboot", "init 0", "init 6"}
	for _, d := range dangerous {
		if strings.Contains(strings.ToLower(args.Command), d) {
			return "", fmt.Errorf("dangerous command blocked: contains %q", d)
		}
	}

	cmd := exec.CommandContext(ctx, "sh", "-c", args.Command)
	if args.Cwd != "" {
		cmd.Dir = args.Cwd
	}

	output, err := cmd.CombinedOutput()
	exitCode := 0
	if err != nil {
		if exitErr, ok := err.(*exec.ExitError); ok {
			exitCode = exitErr.ExitCode()
		} else {
			return "", fmt.Errorf("execute error: %w", err)
		}
	}

	result, _ := json.Marshal(map[string]interface{}{
		"stdout":    string(output),
		"exit_code": exitCode,
	})
	return string(result), nil
}
