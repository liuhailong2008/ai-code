package greptool

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"groot-backend/internal/tools"
)

func init() {
	tools.Register(&GrepTool{})
}

type GrepTool struct{}

func (t *GrepTool) Info() tools.ToolInfo {
	return tools.ToolInfo{
		Name:        "grep",
		DisplayName: "文本搜索",
		Description: "在文件中搜索匹配的文本内容",
		Category:    "filesystem",
		InputSchema: `{"type":"object","properties":{"pattern":{"type":"string","description":"搜索模式（支持正则）"},"path":{"type":"string","description":"搜索路径（文件或目录）"}},"required":["pattern"]}`,
		OutputSchema: `{"type":"object","properties":{"matches":{"type":"array","items":{"type":"object","properties":{"file":{"type":"string"},"line":{"type":"integer"},"content":{"type":"string"}}}}}}`,
	}
}

func (t *GrepTool) Run(ctx context.Context, argumentsInJSON string) (string, error) {
	var args struct {
		Pattern string `json:"pattern"`
		Path    string `json:"path"`
	}
	if err := json.Unmarshal([]byte(argumentsInJSON), &args); err != nil {
		return "", fmt.Errorf("invalid arguments: %w", err)
	}

	searchPath := args.Path
	if searchPath == "" {
		searchPath = "."
	}

	type match struct {
		File    string `json:"file"`
		Line    int    `json:"line"`
		Content string `json:"content"`
	}
	var matches []match

	err := filepath.Walk(searchPath, func(path string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return nil
		}
		f, err := os.Open(path)
		if err != nil {
			return nil
		}
		defer f.Close()

		scanner := bufio.NewScanner(f)
		lineNum := 0
		for scanner.Scan() {
			lineNum++
			line := scanner.Text()
			if strings.Contains(line, args.Pattern) {
				matches = append(matches, match{File: path, Line: lineNum, Content: line})
			}
		}
		return nil
	})
	if err != nil {
		return "", fmt.Errorf("grep error: %w", err)
	}

	if matches == nil {
		matches = []match{}
	}
	result, _ := json.Marshal(map[string]interface{}{"matches": matches})
	return string(result), nil
}
