package readfile

import (
	"context"
	"encoding/json"
	"fmt"
	"os"

	"groot-backend/internal/tools"
)

func init() {
	tools.Register(&ReadFileTool{})
}

type ReadFileTool struct{}

func (t *ReadFileTool) Info() tools.ToolInfo {
	return tools.ToolInfo{
		Name:        "read_file",
		DisplayName: "读取文件",
		Description: "读取指定文件的内容",
		Category:    "filesystem",
		InputSchema: `{"type":"object","properties":{"file_path":{"type":"string","description":"文件路径"}},"required":["file_path"]}`,
		OutputSchema: `{"type":"object","properties":{"content":{"type":"string","description":"文件内容"}}}`,
	}
}

func (t *ReadFileTool) Run(ctx context.Context, argumentsInJSON string) (string, error) {
	var args struct {
		FilePath string `json:"file_path"`
	}
	if err := json.Unmarshal([]byte(argumentsInJSON), &args); err != nil {
		return "", fmt.Errorf("invalid arguments: %w", err)
	}
	data, err := os.ReadFile(args.FilePath)
	if err != nil {
		return "", fmt.Errorf("read file error: %w", err)
	}
	result, _ := json.Marshal(map[string]string{"content": string(data)})
	return string(result), nil
}
