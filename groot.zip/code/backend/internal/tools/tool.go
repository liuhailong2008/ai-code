package tools

import "context"

// ToolInfo 工具元信息
type ToolInfo struct {
	Name         string `json:"name"`
	DisplayName  string `json:"display_name"`
	Description  string `json:"description"`
	Category     string `json:"category"`
	InputSchema  string `json:"input_schema"`
	OutputSchema string `json:"output_schema"`
}

// Tool 工具接口，所有工具实现需实现此接口
type Tool interface {
	// Info 返回工具元信息
	Info() ToolInfo
	// Run 执行工具，参数为 JSON 编码字符串，返回字符串结果
	Run(ctx context.Context, argumentsInJSON string) (string, error)
}

// registry 工具注册表
var registry = map[string]Tool{}

// Register 注册工具
func Register(t Tool) {
	info := t.Info()
	registry[info.Name] = t
}

// GetAll 获取所有已注册的工具
func GetAll() map[string]Tool {
	return registry
}

// Get 按名称获取工具
func Get(name string) (Tool, bool) {
	t, ok := registry[name]
	return t, ok
}
