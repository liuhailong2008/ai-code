package writefile

import (
	"context"
	"encoding/json"
	"fmt"
	"os"

	"groot-backend/internal/tools"
)

func init() {
	tools.Register(&WriteFileTool{})
}

type WriteFileTool struct{}

func (t *WriteFileTool) Info() tools.ToolInfo {
	return tools.ToolInfo{
		Name:        "write_file",
		DisplayName: "写入文件",
		Description: "将内容写入指定文件",
		Category:    "filesystem",
		InputSchema: `{"type":"object","properties":{"file_path":{"type":"string","description":"文件路径"},"content":{"type":"string","description":"写入内容"}},"required":["file_path","content"]}`,
		OutputSchema: `{"type":"object","properties":{"success":{"type":"boolean"}}}`,
	}
}

func (t *WriteFileTool) Run(ctx context.Context, argumentsInJSON string) (string, error) {
	var args struct {
		FilePath string `json:"file_path"`
		Content  string `json:"content"`
	}
	if err := json.Unmarshal([]byte(argumentsInJSON), &args); err != nil {
		return "", fmt.Errorf("invalid arguments: %w", err)
	}
	if err := os.WriteFile(args.FilePath, []byte(args.Content), 0644); err != nil {
		return "", fmt.Errorf("write file error: %w", err)
	}
	result, _ := json.Marshal(map[string]bool{"success": true})
	return string(result), nil
}
