import json
import subprocess

s = json.dumps({
    "nodes": [
        {"nodeKey": "check_disk",      "nodeName": "检查磁盘使用率",   "nodeType": "tool",      "toolCode": "check_disk_usage"},
        {"nodeKey": "find_large",      "nodeName": "定位大文件",       "nodeType": "tool",      "toolCode": "find_large_files"},
        {"nodeKey": "analyze_safe",    "nodeName": "分析可删文件",     "nodeType": "llm",       "modelCode": "deepseek-v4-flash"},
        {"nodeKey": "delete_files",    "nodeName": "删除无用文件",     "nodeType": "tool",      "toolCode": "safe_delete"},
        {"nodeKey": "verify_space",    "nodeName": "验证磁盘空间",     "nodeType": "tool",      "toolCode": "check_disk_usage"},
        {"nodeKey": "notify",          "nodeName": "发送清理报告",     "nodeType": "tool",      "toolCode": "send_notification"},
    ],
    "edges": [
        {"fromNode": "START",          "toNode": "check_disk",      "edgeType": "control"},
        {"fromNode": "check_disk",     "toNode": "find_large",      "edgeType": "both", "condition": {"matchExpr": "usage > 80"}},
        {"fromNode": "find_large",     "toNode": "analyze_safe",    "edgeType": "both"},
        {"fromNode": "analyze_safe",   "toNode": "delete_files",    "edgeType": "both"},
        {"fromNode": "delete_files",   "toNode": "verify_space",    "edgeType": "control"},
        {"fromNode": "verify_space",   "toNode": "notify",          "edgeType": "both"},
        {"fromNode": "notify",         "toNode": "END",             "edgeType": "control"},
    ],
}, ensure_ascii=False)

escaped = s.replace("\\", "\\\\").replace("'", "\\'")
sql = f"UPDATE sop_definitions SET input_schema = '{escaped}' WHERE id = 2;"
subprocess.run(['docker', 'exec', '-i', 'groot-mysql', 'mysql', '-uroot', '-pgroot123', 'groot'], input=sql.encode(), check=True)

# Verify
subprocess.run(['docker', 'exec', '-i', 'groot-mysql', 'mysql', '-uroot', '-pgroot123', 'groot', '-e', 'SELECT id, sop_name, CHAR_LENGTH(input_schema) FROM sop_definitions'], check=True)
print("Both SOPs have graph/workflow data now")
