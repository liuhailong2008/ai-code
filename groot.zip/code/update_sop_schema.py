import json
import subprocess

s = json.dumps({
    "nodes": [
        {"nodeKey": "check_status",   "nodeName": "检查节点状态",   "nodeType": "tool",      "toolCode": "check_node_health"},
        {"nodeKey": "analyze",        "nodeName": "分析故障原因",   "nodeType": "llm",       "modelCode": "deepseek-v4-flash"},
        {"nodeKey": "restart",        "nodeName": "重启故障组件",   "nodeType": "tool",      "toolCode": "restart_component"},
        {"nodeKey": "wait_recovery",  "nodeName": "等待服务恢复",   "nodeType": "lambda",    "config": {"sleep": 30}},
        {"nodeKey": "health_check",   "nodeName": "健康检查",       "nodeType": "tool",      "toolCode": "health_check"},
        {"nodeKey": "notify",         "nodeName": "发送告警通知",   "nodeType": "tool",      "toolCode": "send_notification"},
    ],
    "edges": [
        {"fromNode": "START",         "toNode": "check_status",  "edgeType": "control"},
        {"fromNode": "check_status",  "toNode": "analyze",       "edgeType": "both"},
        {"fromNode": "analyze",       "toNode": "restart",       "edgeType": "both",      "condition": {"matchExpr": "needs_restart"}},
        {"fromNode": "analyze",       "toNode": "notify",        "edgeType": "control",   "condition": {"matchExpr": "healthy"}},
        {"fromNode": "restart",       "toNode": "wait_recovery", "edgeType": "control"},
        {"fromNode": "wait_recovery", "toNode": "health_check",  "edgeType": "control"},
        {"fromNode": "health_check",  "toNode": "restart",       "edgeType": "control",   "condition": {"matchExpr": "unhealthy", "maxLoop": 3}},
        {"fromNode": "health_check",  "toNode": "notify",        "edgeType": "control",   "condition": {"matchExpr": "healthy"}},
        {"fromNode": "notify",        "toNode": "END",           "edgeType": "control"},
    ],
}, ensure_ascii=False)

escaped = s.replace("\\", "\\\\").replace("'", "\\'")
sql = f"UPDATE sop_definitions SET input_schema = '{escaped}' WHERE id = 1;"

# Write SQL to file and exec via docker
with open('/Users/liuhailong/Documents/workspace/groot/code/update_schema.sql', 'w') as f:
    f.write(sql)

subprocess.run([
    'docker', 'exec', '-i', 'groot-mysql',
    'mysql', '-uroot', '-pgroot123', 'groot'
], input=sql.encode(), check=True)

print("Done. Verifying...")
subprocess.run([
    'docker', 'exec', '-i', 'groot-mysql',
    'mysql', '-uroot', '-pgroot123', 'groot',
    '-e', 'SELECT id, CHAR_LENGTH(input_schema) FROM sop_definitions WHERE id=1'
], check=True)
