import { useState, useEffect, useRef, useCallback } from 'react'
import type { StreamEvent } from '../api/stream'
import { connectWithRetry } from '../api/stream'
import { getStreamUrl } from '../api/events'

interface UseStreamMessageOptions {
  enabled?: boolean
  onDone?: () => void
  modelCode?: string | null
}

export function useStreamMessage(
  eventId: number,
  { enabled = true, onDone, modelCode }: UseStreamMessageOptions = {},
) {
  const [tokens, setTokens] = useState<string[]>([])
  const [isStreaming, setIsStreaming] = useState(false)
  const [isDone, setIsDone] = useState(false)
  const cleanupRef = useRef<(() => void) | null>(null)
  const onDoneRef = useRef(onDone)
  onDoneRef.current = onDone

  const resetState = useCallback(() => {
    setTokens([])
    setIsStreaming(false)
    setIsDone(false)
    cleanupRef.current?.()
    cleanupRef.current = null
  }, [])

  useEffect(() => {
    if (!enabled) return

    let cancelled = false

    const onEvent = (event: StreamEvent) => {
      if (cancelled) return

      switch (event.type) {
        case 'token':
          setTokens((prev) => [...prev, event.content])
          setIsStreaming(true)
          break
        case 'done':
          setIsDone(true)
          setIsStreaming(false)
          onDoneRef.current?.()
          break
        case 'error':
          console.error('Stream error:', event.error)
          setIsStreaming(false)
          break
      }
    }

    const url = getStreamUrl(eventId, modelCode)
    connectWithRetry(url, onEvent).then((cleanup: () => void) => {
      if (!cancelled) {
        cleanupRef.current = cleanup
      } else {
        cleanup()
      }
    })

    return () => {
      cancelled = true
      cleanupRef.current?.()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [eventId, enabled, modelCode])

  return { tokens, isStreaming, isDone, resetState }
}