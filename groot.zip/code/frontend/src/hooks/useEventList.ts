import { useQuery } from '@tanstack/react-query'
import { listEvents } from '../api/events'

export function useEventList() {
  return useQuery({
    queryKey: ['events'],
    queryFn: () => listEvents(),
  })
}