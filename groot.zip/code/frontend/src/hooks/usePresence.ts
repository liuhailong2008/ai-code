import { useEffect, useRef } from 'react'
import { useQuery } from '@tanstack/react-query'
import { reportPresence, getOnlineUsers } from '../api/events'
import { useAuthStore } from '../stores/auth'

const HEARTBEAT_INTERVAL = 15_000 // 15秒一次心跳

export function usePresence(eventId: number) {
  const user = useAuthStore((s) => s.user)
  const userIdRef = useRef(user?.id)
  const userNameRef = useRef(user?.displayName || user?.username || '')

  // 保持 ref 最新
  useEffect(() => {
    userIdRef.current = user?.id
    userNameRef.current = user?.displayName || user?.username || ''
  }, [user])

  // 查询在线用户列表
  const { data: onlineUsers = [], refetch: refetchOnline } = useQuery({
    queryKey: ['onlineUsers', eventId],
    queryFn: () => getOnlineUsers(eventId),
    refetchInterval: 10_000, // 每10秒自动刷新
  })

  // 心跳上报
  useEffect(() => {
    if (!userIdRef.current) return

    // 立即上报一次
    reportPresence(eventId, userIdRef.current, userNameRef.current).catch(() => {})

    const timer = setInterval(() => {
      if (!userIdRef.current) return
      reportPresence(eventId, userIdRef.current, userNameRef.current).catch(() => {})
    }, HEARTBEAT_INTERVAL)

    return () => clearInterval(timer)
  }, [eventId])

  return {
    onlineUsers,
    onlineUserIds: new Set(onlineUsers.map((u) => u.userId)),
    refetchOnline,
  }
}
