import { create } from 'zustand'
import { persist } from 'zustand/middleware'

type Theme = 'shadcn-light' | 'shadcn-dark' | 'cyberpunk-terminal' | 'cyberpunk-neon'

interface ThemeState {
  theme: Theme
  setTheme: (theme: Theme) => void
}

export const useThemeStore = create<ThemeState>()(
  persist(
    (set) => ({
      theme: 'shadcn-light',
      setTheme: (theme) => set({ theme }),
    }),
    {
      name: 'theme-storage',
    },
  ),
)