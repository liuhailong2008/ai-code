import { create } from 'zustand'

interface UiState {
  sidebarCollapsed: boolean
  uiBlockPaneCollapsed: boolean
  selectedEventId: string | null
  toggleSidebar: () => void
  toggleUIBlockPane: () => void
  setSelectedEventId: (eventId: string | null) => void
}

export const useUiStore = create<UiState>((set) => ({
  sidebarCollapsed: false,
  uiBlockPaneCollapsed: false,
  selectedEventId: null,
  toggleSidebar: () => set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
  toggleUIBlockPane: () => set((state) => ({ uiBlockPaneCollapsed: !state.uiBlockPaneCollapsed })),
  setSelectedEventId: (selectedEventId) => set({ selectedEventId }),
}))