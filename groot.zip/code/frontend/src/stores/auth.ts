import { create } from 'zustand'
import type { User } from '../schemas'

const AUTH_KEY = 'groot-auth'

function loadAuth(): { user: User | null; token: string | null } {
  try {
    const raw = localStorage.getItem(AUTH_KEY)
    if (raw) return JSON.parse(raw)
  } catch { /* ignore */ }
  return { user: null, token: null }
}

function saveAuth(user: User | null, token: string | null) {
  if (user && token) {
    localStorage.setItem(AUTH_KEY, JSON.stringify({ user, token }))
  } else {
    localStorage.removeItem(AUTH_KEY)
  }
}

interface AuthState {
  user: User | null
  token: string | null
  isLoading: boolean
  login: (username: string, password: string) => Promise<void>
  logout: () => Promise<void>
  setUser: (user: User | null) => void
}

const initial = loadAuth()

export const useAuthStore = create<AuthState>((set) => ({
  user: initial.user,
  token: initial.token,
  isLoading: false,
  login: async (username: string, password: string) => {
    set({ isLoading: true })
    try {
      const { login: apiLogin } = await import('../api/auth')
      const res = await apiLogin(username, password)
      saveAuth(res.user, res.token)
      set({ user: res.user, token: res.token, isLoading: false })
    } catch (error) {
      set({ isLoading: false })
      throw error
    }
  },
  logout: async () => {
    // 先清除本地状态，确保即使 API 失败也能退出
    saveAuth(null, null)
    set({ user: null, token: null, isLoading: false })
    // 后台尝试通知服务端（忽略结果）
    try {
      const { logout: apiLogout } = await import('../api/auth')
      await apiLogout()
    } catch { /* 即使服务端调用失败，本地已清除 */ }
  },
  setUser: (user) => {
    const token = useAuthStore.getState().token
    if (user) {
      saveAuth(user, token)
    }
    set({ user })
  },
}))
