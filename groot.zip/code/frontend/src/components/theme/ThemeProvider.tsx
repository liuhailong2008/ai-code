import { createContext, useContext, useEffect, type ReactNode } from 'react'
import { useThemeStore } from '../../stores/theme'

type Theme = 'shadcn-light' | 'shadcn-dark' | 'cyberpunk-terminal' | 'cyberpunk-neon'

interface ThemeContextValue {
  theme: Theme
  setTheme: (theme: Theme) => void
}

const ThemeContext = createContext<ThemeContextValue | null>(null)

export function ThemeProvider({ children }: { children: ReactNode }) {
  const { theme, setTheme } = useThemeStore()

  useEffect(() => {
    document.documentElement.classList.remove(
      'shadcn-light',
      'shadcn-dark',
      'cyberpunk-terminal',
      'cyberpunk-neon',
    )

    if (theme === 'shadcn-dark' || theme === 'cyberpunk-terminal') {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }

    document.documentElement.setAttribute('data-theme', theme)
  }, [theme])

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider')
  }
  return context
}