export interface ThemeDefinition {
  id: string
  name: string
  label: string
  icon: string
}

export const themeDefinitions: ThemeDefinition[] = [
  {
    id: 'shadcn-light',
    name: '浅色',
    label: 'Shadcn Light',
    icon: 'sun',
  },
  {
    id: 'shadcn-dark',
    name: '深色',
    label: 'Shadcn Dark',
    icon: 'moon',
  },
  {
    id: 'cyberpunk-terminal',
    name: '赛博终端',
    label: 'Cyberpunk Terminal',
    icon: 'terminal',
  },
  {
    id: 'cyberpunk-neon',
    name: '赛博霓虹',
    label: 'Cyberpunk Neon',
    icon: 'zap',
  },
]