import { useTheme } from './ThemeProvider'
import { themeDefinitions } from './themes'

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()

  return (
    <select
      value={theme}
      onChange={(e) => setTheme(e.target.value as typeof theme)}
      className="text-sm bg-background border-border rounded px-2 py-1 border"
    >
      {themeDefinitions.map((t) => (
        <option key={t.id} value={t.id}>
          {t.name}
        </option>
      ))}
    </select>
  )
}