import { useState, type FormEvent, type KeyboardEvent, useRef, useEffect, useMemo } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { postMessage } from '../../api/events'
import { searchUsers } from '../../api/members'
import { listActiveModels } from '../../api/model-configs'
import type { User } from '../../schemas/user'
import type { ModelConfig } from '../../schemas/model-config'

interface ChatInputProps {
  eventId: number
}

// 在文本中提取所有 @username（用户名只允许字母数字下划线和点）
const MENTION_PATTERN = /@([A-Za-z0-9_.\-]+)/g

function extractMentions(text: string): string[] {
  const set = new Set<string>()
  let m: RegExpExecArray | null
  while ((m = MENTION_PATTERN.exec(text)) !== null) {
    set.add(m[1])
  }
  return Array.from(set)
}

interface MentionState {
  active: boolean
  start: number // @ 在 textarea 中的位置
  query: string
}

const MODEL_STORAGE_KEY = (eventId: number) => `groot.event.${eventId}.model`

export function ChatInput({ eventId }: ChatInputProps) {
  const [content, setContent] = useState('')
  const [mention, setMention] = useState<MentionState>({ active: false, start: -1, query: '' })
  const [highlightIdx, setHighlightIdx] = useState(0)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const queryClient = useQueryClient()

  // 选中的模型：优先从 url 或 localStorage 恢复；默认为列表第一项
  const { data: models = [] } = useQuery({
    queryKey: ['active-chat-models'],
    queryFn: () => listActiveModels('chat'),
    staleTime: 60 * 1000,
    retry: 3,
    retryDelay: 1000,
  })

  const [selectedModel, setSelectedModel] = useState<ModelConfig | null>(null)
  const modelReady = useRef<boolean>(false)

  // 初始化选中的模型
  useEffect(() => {
    if (models.length === 0 || modelReady.current) return
    const saved = typeof window !== 'undefined' ? localStorage.getItem(MODEL_STORAGE_KEY(eventId)) : null
    if (saved) {
      const found = models.find((m) => m.code === saved)
      if (found) {
        setSelectedModel(found)
        modelReady.current = true
        return
      }
    }
    setSelectedModel(models[0])
    modelReady.current = true
  }, [models, eventId])

  const mutation = useMutation({
    mutationFn: () =>
      postMessage(eventId, content, extractMentions(content), selectedModel?.code ?? null),
    onSuccess: (data) => {
      setContent('')
      queryClient.invalidateQueries({ queryKey: ['messages', eventId] })
      queryClient.invalidateQueries({ queryKey: ['unread', eventId] })
      queryClient.invalidateQueries({ queryKey: ['my-unread'] })
      // 如果 @ 了 groot，触发流式回复
      if (data.mentions?.includes('groot')) {
        window.dispatchEvent(
          new CustomEvent('groot-stream-start', {
            detail: { eventId, modelCode: selectedModel?.code },
          })
        )
      }
    },
  })

  // 候选用户：根据 query 调后端搜索，并始终把虚拟用户 groot 作为可选
  const { data: candidates = [] } = useQuery({
    queryKey: ['mention-candidates', mention.query],
    queryFn: () => searchUsers(mention.query),
    enabled: mention.active,
    staleTime: 30 * 1000,
  })

  const visibleCandidates = useMemo<User[]>(() => {
    const grootUser: User = {
      id: -1,
      username: 'groot',
      displayName: 'Groot 智能助手',
      role: 'agent',
      mobile: '',
      createdAt: '',
      updatedAt: '',
    }
    const kw = mention.query.trim().toLowerCase()
    const others = candidates.filter((u) => u.username !== 'groot').slice(0, 7)
    const matchGroot = !kw || 'groot'.includes(kw) || 'groot 智能助手'.includes(kw) || 'ai'.includes(kw)
    if (matchGroot) {
      return [grootUser, ...others]
    }
    return others
  }, [candidates, mention.query])

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px'
    }
  }, [content])

  // 监听外部插入文本事件（如人员面板点击）
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent<{ text: string }>).detail
      if (!detail?.text) return
      setContent((prev) => {
        const sep = prev && !prev.endsWith(' ') ? ' ' : ''
        return prev + sep + detail.text + ' '
      })
      requestAnimationFrame(() => textareaRef.current?.focus())
    }
    window.addEventListener('chat-insert-text', handler)
    return () => window.removeEventListener('chat-insert-text', handler)
  }, [])

  // 在 content/光标变化时检测是否处于 @ 触发状态
  const detectMention = (value: string, caret: number) => {
    let i = caret - 1
    while (i >= 0) {
      const ch = value[i]
      if (ch === '@') {
        if (i === 0 || /\s/.test(value[i - 1])) {
          const query = value.slice(i + 1, caret)
          if (!/\s/.test(query)) {
            setMention({ active: true, start: i, query })
            setHighlightIdx(0)
            return
          }
        }
        break
      }
      if (/\s/.test(ch)) break
      i--
    }
    setMention((s) => (s.active ? { active: false, start: -1, query: '' } : s))
  }

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value
    setContent(value)
    const caret = e.target.selectionStart ?? value.length
    detectMention(value, caret)
  }

  const handleKeyUp = () => {
    const ta = textareaRef.current
    if (!ta) return
    detectMention(ta.value, ta.selectionStart ?? 0)
  }

  // 在光标处插入文本（用于 @ 按钮调用）
  const insertAtCursor = (text: string, triggerMention: boolean) => {
    const ta = textareaRef.current
    if (!ta) {
      setContent((prev) => prev + text)
      return
    }
    const start = ta.selectionStart ?? content.length
    const end = ta.selectionEnd ?? content.length
    const before = content.slice(0, start)
    const after = content.slice(end)
    const sep = before.length === 0 || /\s$/.test(before) ? '' : ' '
    const next = before + sep + text + after
    setContent(next)
    requestAnimationFrame(() => {
      ta.focus()
      const pos = (before + sep + text).length
      ta.setSelectionRange(pos, pos)
      if (triggerMention) {
        detectMention(next, pos)
      }
    })
  }

  const insertMention = (username: string) => {
    if (!mention.active || mention.start < 0) return
    const before = content.slice(0, mention.start)
    const after = content.slice(textareaRef.current?.selectionStart ?? content.length)
    const inserted = `@${username} `
    const next = before + inserted + after
    setContent(next)
    setMention({ active: false, start: -1, query: '' })
    requestAnimationFrame(() => {
      const ta = textareaRef.current
      if (!ta) return
      const pos = (before + inserted).length
      ta.focus()
      ta.setSelectionRange(pos, pos)
    })
  }

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    if (content.trim() && !mutation.isPending) {
      mutation.mutate()
    }
  }

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (mention.active && visibleCandidates.length > 0) {
      if (e.key === 'ArrowDown') {
        e.preventDefault()
        setHighlightIdx((i) => (i + 1) % visibleCandidates.length)
        return
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault()
        setHighlightIdx((i) => (i - 1 + visibleCandidates.length) % visibleCandidates.length)
        return
      }
      if (e.key === 'Enter' || e.key === 'Tab') {
        e.preventDefault()
        insertMention(visibleCandidates[highlightIdx].username)
        return
      }
      if (e.key === 'Escape') {
        e.preventDefault()
        setMention({ active: false, start: -1, query: '' })
        return
      }
    }

    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      if (content.trim() && !mutation.isPending) {
        mutation.mutate()
      }
    }
  }

  const handleSelectModel = (code: string) => {
    const found = models.find((m) => m.code === code)
    if (!found) return
    setSelectedModel(found)
    localStorage.setItem(MODEL_STORAGE_KEY(eventId), code)
  }

  const providerLabel = (p: string) => {
    const low = (p || '').toLowerCase()
    if (low === 'deepseek') return 'DeepSeek'
    if (low === 'volcengine') return '豆包'
    if (low === 'zhipu') return '智谱'
    return p
  }

  return (
    <form onSubmit={handleSubmit} className="relative flex flex-col gap-2">
      {mention.active && visibleCandidates.length > 0 && (
        <div className="absolute bottom-full left-0 mb-2 w-72 max-h-64 overflow-auto rounded-lg border border-border bg-popover shadow-lg z-50">
          <div className="px-3 py-1.5 text-[10px] uppercase tracking-wider text-muted-foreground border-b border-border">
            选择要 @ 的用户
          </div>
          {visibleCandidates.map((u, idx) => (
            <button
              key={u.id}
              type="button"
              onMouseEnter={() => setHighlightIdx(idx)}
              onMouseDown={(e) => {
                e.preventDefault()
                insertMention(u.username)
              }}
              className={`w-full flex items-center gap-2 px-3 py-2 text-left text-sm transition-colors ${
                  idx === highlightIdx ? 'bg-primary/10 text-foreground' : 'text-foreground hover:bg-muted'
                }`}
            >
              <span className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold text-white shrink-0 ${
                u.username === 'groot' ? 'bg-emerald-500' : 'bg-blue-500'
              }`}>
                {(u.displayName || u.username).charAt(0).toUpperCase()}
              </span>
              <span className="flex-1 min-w-0">
                <span className="block truncate font-medium">{u.displayName || u.username}</span>
                <span className="block truncate text-xs text-muted-foreground">@{u.username}</span>
              </span>
              {u.username === 'groot' && (
                <span className="shrink-0 text-[10px] text-emerald-500 border border-emerald-500/30 rounded px-1.5 py-0.5">
                  AI 助手
                </span>
              )}
            </button>
          ))}
        </div>
      )}

      <div className="relative flex items-end gap-2">
        {/* @ 按钮：在光标处插入 "@" 并触发下拉 */}
        <button
          type="button"
          onClick={() => insertAtCursor('@', true)}
          className="shrink-0 w-9 h-9 rounded-xl border border-border bg-background hover:bg-muted/80 flex items-center justify-center text-base font-semibold text-muted-foreground hover:text-foreground hover:border-primary/50 transition-colors"
          title="提及用户 (@)"
          aria-label="提及用户"
        >
          @
        </button>

        <textarea
          ref={textareaRef}
          value={content}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          onKeyUp={handleKeyUp}
          onClick={handleKeyUp}
          placeholder="输入运维指令，输入 @ 可提及用户，/..."
          rows={1}
          className="flex-1 resize-none rounded-xl border border-border bg-background px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/30 min-h-[42px]"
        />

        <button
          type="submit"
          disabled={!content.trim() || mutation.isPending}
          className={`shrink-0 w-9 h-9 rounded-full flex items-center justify-center transition-all ${
            content.trim() && !mutation.isPending
              ? 'bg-primary text-primary-foreground hover:bg-primary/90'
              : 'bg-muted text-muted-foreground'
          }`}
          aria-label="发送消息"
        >
          {mutation.isPending ? (
            <span className="animate-spin">⟳</span>
          ) : (
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          )}
        </button>
      </div>

      {/* 底部工具条：模型选择 */}
      <div className="flex items-center justify-between gap-3 text-xs text-muted-foreground">
        <div className="flex items-center gap-2">
          <label className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <span className="text-[13px]">✨</span>
            <span>模型</span>
          </label>
          {models.length === 0 ? (
            <span className="text-[11px] text-muted-foreground/70 italic">未配置</span>
          ) : (
            <div className="flex flex-wrap gap-1">
              {models.map((m) => {
                const active = selectedModel?.code === m.code
                return (
                  <button
                    key={m.code}
                    type="button"
                    onClick={() => handleSelectModel(m.code)}
                    title={`${m.name} (${providerLabel(m.provider)})`}
                    className={`rounded-full px-2.5 py-1 text-[11px] transition-all ${
                      active
                        ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/40 shadow-sm'
                        : 'hover:bg-muted hover:text-foreground border border-transparent'
                    }`}
                  >
                    {m.name}
                  </button>
                )
              })}
            </div>
          )}
        </div>

        {selectedModel && (
          <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground/80">
            <span className="inline-flex items-center gap-1">
              {providerLabel(selectedModel.provider)} · {selectedModel.code}
            </span>
            {selectedModel.supportsThinking && (
              <span className="text-[10px] bg-amber-500/15 text-amber-700 dark:text-amber-300 px-1.5 py-0.5 rounded-full border border-amber-500/30">思考</span>
            )}
          </div>
        )}
      </div>
    </form>
  )
}
