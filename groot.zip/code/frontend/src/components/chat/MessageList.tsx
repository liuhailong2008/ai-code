import type { Message } from '../../schemas'

interface MessageListProps {
  messages: Message[]
  eventId: number
}

export function MessageList({ messages }: MessageListProps) {
  if (messages.length === 0) {
    return (
      <div className="p-4 text-center text-muted-foreground">
        暂无消息，开始对话吧
      </div>
    )
  }

  return (
    <div className="space-y-3 p-4">
      {messages.map((message) => (
        <MessageBubble key={message.id} message={message} />
      ))}
    </div>
  )
}

function MessageBubble({ message }: { message: Message }) {
  const isUser = message.role === 'user'
  const isSystem = message.role === 'system'

  return (
    <div
      className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''}`}
    >
      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary text-xs font-bold shrink-0 mt-1">
        {message.actorId?.charAt(0) || '?'}
      </div>
      <div
        className={`max-w-[80%] ${
          isSystem
            ? 'bg-muted text-muted-foreground'
            : isUser
              ? 'bg-primary text-primary-foreground'
              : 'bg-secondary text-secondary-foreground'
        } rounded-lg px-4 py-3 text-sm`}
      >
        {!isUser && (
          <p className="text-xs font-medium mb-1 opacity-70">
            {message.actorId || '未知'}
          </p>
        )}
        <p className="whitespace-pre-wrap">{message.content}</p>
        <p className="text-xs mt-1 opacity-50">
          {new Date(message.createdAt).toLocaleTimeString('zh-CN')}
        </p>
      </div>
    </div>
  )
}
