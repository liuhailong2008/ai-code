import { useEffect, useRef } from 'react'
import { useStreamMessage } from '../../hooks/useStreamMessage'

interface StreamingMessageProps {
  eventId: number
  enabled?: boolean
  onDone?: () => void
  modelCode?: string | null
}

export function StreamingMessage({ eventId, enabled = true, onDone, modelCode }: StreamingMessageProps) {
  const { tokens, isStreaming, isDone } = useStreamMessage(eventId, { enabled, onDone, modelCode })
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollIntoView({ behavior: 'smooth' })
    }
  }, [tokens])

  if (!isStreaming && !isDone) return null

  const content = tokens.join('')

  return (
    <div ref={containerRef} className="flex gap-3">
      <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-blue-500 text-white text-xs font-bold shrink-0 mt-1">
        AI
      </span>
      <div className="max-w-[80%] bg-secondary text-secondary-foreground rounded-lg px-4 py-3 text-sm">
        <p className="text-xs font-medium mb-1 opacity-70">运维智能体</p>
        <p className="whitespace-pre-wrap">
          {content}
          {isStreaming && <span className="animate-pulse">|</span>}
        </p>
        {isDone && (
          <p className="text-xs mt-1 opacity-50">
            {new Date().toLocaleTimeString('zh-CN')}
          </p>
        )}
      </div>
    </div>
  )
}