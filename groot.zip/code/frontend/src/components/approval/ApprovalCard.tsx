import { useMutation, useQueryClient } from '@tanstack/react-query'
import { approveApproval, rejectApproval } from '../../api/approvals'
import type { Approval } from '../../schemas'

interface ApprovalCardProps {
  approval: Approval
}

export function ApprovalCard({ approval }: ApprovalCardProps) {
  const queryClient = useQueryClient()
  const approveMutation = useMutation({
    mutationFn: () => approveApproval(approval.id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['approvals'] })
    },
  })

  const rejectMutation = useMutation({
    mutationFn: () => rejectApproval(approval.id, '拒绝'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['approvals'] })
    },
  })

  const statusLabel =
    approval.status === 'approved' ? '已批准' :
    approval.status === 'rejected' ? '已拒绝' : '待审批'

  return (
    <div className="border border-border rounded-lg p-4 bg-card">
      <div className="flex items-center justify-between mb-2">
        <h4 className="font-medium text-sm">{approval.title}</h4>
        <span className={`text-xs px-2 py-0.5 rounded ${
          approval.status === 'approved' ? 'bg-green-500/20 text-green-500' :
          approval.status === 'rejected' ? 'bg-destructive/20 text-destructive' :
          'bg-yellow-500/20 text-yellow-500'
        }`}>
          {statusLabel}
        </span>
      </div>
      <p className="text-xs text-muted-foreground mb-3">{approval.description}</p>
      <div className="text-xs text-muted-foreground mb-3">
        <p>申请人: {approval.requestedBy.name} · {new Date(approval.requestedAt).toLocaleString('zh-CN')}</p>
        {approval.reviewedBy && (
          <p>审批人: {approval.reviewedBy.name} · {approval.reviewedAt ? new Date(approval.reviewedAt).toLocaleString('zh-CN') : ''}</p>
        )}
        {approval.reviewComment && (
          <p>备注: {approval.reviewComment}</p>
        )}
      </div>
      {approval.status === 'pending' && (
        <div className="flex gap-2">
          <button
            onClick={() => approveMutation.mutate()}
            disabled={approveMutation.isPending}
            className="flex-1 px-3 py-1.5 text-xs rounded bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
          >
            批准
          </button>
          <button
            onClick={() => rejectMutation.mutate()}
            disabled={rejectMutation.isPending}
            className="flex-1 px-3 py-1.5 text-xs rounded border border-border hover:bg-destructive/10 disabled:opacity-50"
          >
            拒绝
          </button>
        </div>
      )}
    </div>
  )
}