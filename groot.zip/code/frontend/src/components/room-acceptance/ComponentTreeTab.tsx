import { useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  listComponentTree, createComponentTreeNode, updateComponentTreeNode, deleteComponentTreeNode,
  listHosts,
  type ComponentTreeNode,
  type Host,
} from '../../api/ruok'

// 节点类型元信息：component(组件) -> role(二级分类,可选) -> cluster(集群) -> idc(机房)
type NodeTypeKey = 'component' | 'role' | 'cluster' | 'idc'
interface NodeTypeMeta { label: string; badge: string; childTypes: NodeTypeKey[] }
const NODE_TYPES: Record<NodeTypeKey, NodeTypeMeta> = {
  component: { label: '组件', badge: 'bg-primary/10 text-primary', childTypes: ['role', 'cluster'] },
  role: { label: '二级分类', badge: 'bg-muted text-muted-foreground', childTypes: ['cluster'] },
  cluster: { label: '集群', badge: 'bg-accent text-muted-foreground', childTypes: ['idc'] },
  idc: { label: '机房', badge: 'bg-muted text-foreground', childTypes: [] },
}
function nodeTypeMeta(nodeType: string): NodeTypeMeta {
  return NODE_TYPES[nodeType as NodeTypeKey] ?? NODE_TYPES.component
}

const ADD_LABELS: Record<string, string> = {
  role: '+二级分类',
  cluster: '+集群',
  idc: '+机房',
}

interface TreeNode {
  node: ComponentTreeNode
  children: TreeNode[]
}

function buildTree(list: ComponentTreeNode[]): TreeNode[] {
  const byParent = new Map<number, ComponentTreeNode[]>()
  for (const n of list) {
    const arr = byParent.get(n.parentId) ?? []
    arr.push(n)
    byParent.set(n.parentId, arr)
  }
  const build = (parentId: number): TreeNode[] => {
    const nodes = (byParent.get(parentId) ?? []).sort((a, b) => a.nodeIdx - b.nodeIdx || a.id - b.id)
    return nodes.map((n) => ({ node: n, children: build(n.id) }))
  }
  return build(0)
}

interface CreateState {
  parentId: number
  nodeType: string
}

export function ComponentTreeTab() {
  const queryClient = useQueryClient()
  const { data, isLoading } = useQuery({
    queryKey: ['ruok', 'component-tree'],
    queryFn: listComponentTree,
  })
  const list = data ?? []

  const [expanded, setExpanded] = useState<Set<number>>(new Set())
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [createForm, setCreateForm] = useState<CreateState | null>(null)

  const createMutation = useMutation({
    mutationFn: createComponentTreeNode,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['ruok', 'component-tree'] }),
  })
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Record<string, unknown> }) => updateComponentTreeNode(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['ruok', 'component-tree'] }),
  })
  const deleteMutation = useMutation({
    mutationFn: deleteComponentTreeNode,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['ruok', 'component-tree'] })
      setSelectedId(null)
    },
  })

  const tree = useMemo(() => buildTree(list), [list])
  const selected = selectedId != null ? list.find((n) => n.id === selectedId) ?? null : null

  const { data: hosts, isLoading: hostsLoading } = useQuery({
    queryKey: ['ruok', 'component-tree', 'hosts', selected?.id],
    queryFn: () => listHosts({ componentTreeId: selected!.id }),
    enabled: selected?.nodeType === 'idc',
  })

  const toggleExpand = (id: number) => {
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  return (
    <div className="flex h-full">
      {/* 左侧树 */}
      <div className="w-1/2 border-r border-border flex flex-col overflow-hidden">
        <div className="px-4 py-3 border-b border-border flex items-center gap-2 shrink-0">
          <h3 className="text-sm font-semibold text-foreground">组件树</h3>
          <div className="flex-1" />
          <button
            onClick={() => setCreateForm({ parentId: 0, nodeType: 'component' })}
            className="px-3 py-1.5 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90 cursor-pointer"
          >
            + 新增组件类型
          </button>
        </div>

        <div className="flex-1 overflow-auto p-3">
          {isLoading ? (
            <p className="text-sm text-muted-foreground">加载中...</p>
          ) : list.length === 0 ? (
            <p className="text-sm text-muted-foreground">暂无组件树，请先新增组件类型。</p>
          ) : (
            <div className="space-y-0.5">
              {tree.map((tn) => (
                <TreeNodeRow
                  key={tn.node.id}
                  tn={tn}
                  depth={0}
                  expanded={expanded}
                  selectedId={selectedId}
                  onToggle={toggleExpand}
                  onSelect={setSelectedId}
                  onAdd={(parentId, nodeType) => setCreateForm({ parentId, nodeType })}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* 右侧详情 */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {selected ? (
          selected.nodeType === 'idc' ? (
            <IdcPanel
              key={selected.id}
              node={selected}
              hosts={hosts ?? []}
              hostsLoading={hostsLoading}
              saving={updateMutation.isPending}
              onSave={(data) => updateMutation.mutate({ id: selected.id, data })}
              onDelete={() => {
                if (confirm('确认删除该机房节点？')) deleteMutation.mutate(selected.id)
              }}
            />
          ) : (
            <NodeEditPanel
              key={selected.id}
              node={selected}
              saving={updateMutation.isPending}
              onSave={(data) => updateMutation.mutate({ id: selected.id, data })}
              onDelete={() => {
                if (confirm('确认删除？其子节点将一并被删除。')) deleteMutation.mutate(selected.id)
              }}
            />
          )
        ) : (
          <div className="flex-1 flex items-center justify-center text-sm text-muted-foreground">
            点击左侧节点查看/编辑属性；点击机房节点可查看关联主机。
          </div>
        )}
      </div>

      {createForm && (
        <CreateNodeModal
          form={createForm}
          saving={createMutation.isPending}
          onSave={(data) => createMutation.mutate(data)}
          onCancel={() => setCreateForm(null)}
        />
      )}
    </div>
  )
}

// ------------------------------------------------------------
// 树节点
// ------------------------------------------------------------

interface TreeNodeRowProps {
  tn: TreeNode
  depth: number
  expanded: Set<number>
  selectedId: number | null
  onToggle: (id: number) => void
  onSelect: (id: number) => void
  onAdd: (parentId: number, nodeType: string) => void
}

function TreeNodeRow({ tn, depth, expanded, selectedId, onToggle, onSelect, onAdd }: TreeNodeRowProps) {
  const { node, children } = tn
  const meta = nodeTypeMeta(node.nodeType)
  const isOpen = expanded.has(node.id)
  const isSelected = selectedId === node.id
  const hasChildren = children.length > 0

  return (
    <div>
      <div
        onClick={() => onSelect(node.id)}
        className={`flex items-center gap-2 px-2 py-1.5 rounded cursor-pointer transition-colors ${
          isSelected ? 'bg-accent' : 'hover:bg-accent/40'
        }`}
        style={{ paddingLeft: `${depth * 20 + 8}px` }}
      >
        {hasChildren ? (
          <button
            onClick={(e) => { e.stopPropagation(); onToggle(node.id) }}
            className="w-4 text-muted-foreground cursor-pointer text-xs"
          >
            {isOpen ? '▼' : '▶'}
          </button>
        ) : (
          <span className="w-4" />
        )}
        <span className={`text-xs px-1.5 py-0.5 rounded ${meta.badge}`}>{meta.label}</span>
        <span className="text-sm text-foreground">{node.nodeName}</span>
        <div className="flex-1" />
        {meta.childTypes.map((ct) => (
          <button
            key={ct}
            onClick={(e) => { e.stopPropagation(); onAdd(node.id, ct) }}
            className="text-xs text-primary hover:underline cursor-pointer"
          >
            {ADD_LABELS[ct] ?? '+子节点'}
          </button>
        ))}
      </div>

      {hasChildren && isOpen && (
        <div>
          {children.map((child) => (
            <TreeNodeRow
              key={child.node.id}
              tn={child}
              depth={depth + 1}
              expanded={expanded}
              selectedId={selectedId}
              onToggle={onToggle}
              onSelect={onSelect}
              onAdd={onAdd}
            />
          ))}
        </div>
      )}
    </div>
  )
}

// ------------------------------------------------------------
// 节点属性编辑面板（component / role / cluster）
// ------------------------------------------------------------

interface NodeEditPanelProps {
  node: ComponentTreeNode
  saving: boolean
  onSave: (data: Record<string, unknown>) => void
  onDelete: () => void
}

function NodeEditPanel({ node, saving, onSave, onDelete }: NodeEditPanelProps) {
  return (
    <div className="flex flex-col h-full">
      <div className="px-4 py-3 border-b border-border shrink-0 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-foreground">
          节点属性
          <span className="text-xs font-normal text-muted-foreground ml-2">
            {nodeTypeMeta(node.nodeType).label}
          </span>
        </h3>
        <button onClick={onDelete} className="text-xs text-destructive hover:underline cursor-pointer">删除节点</button>
      </div>
      <div className="flex-1 overflow-auto">
        <NodeEditForm node={node} saving={saving} onSave={onSave} />
      </div>
    </div>
  )
}

function NodeEditForm({ node, saving, onSave }: { node: ComponentTreeNode; saving: boolean; onSave: (data: Record<string, unknown>) => void }) {
  const [values, setValues] = useState<Record<string, string>>({
    nodeCode: node.nodeCode,
    nodeName: node.nodeName,
    nodeIdx: String(node.nodeIdx),
    nodeRemark: node.nodeRemark ?? '',
  })

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    onSave({
      nodeCode: (values.nodeCode ?? '').trim(),
      nodeName: (values.nodeName ?? '').trim(),
      nodeIdx: Number(values.nodeIdx) || 0,
      nodeRemark: (values.nodeRemark ?? '').trim() || null,
    })
  }

  return (
    <form onSubmit={handleSubmit} className="p-4">
      <div className="grid grid-cols-2 gap-3 max-w-2xl">
        <Field label="节点编码" required>
          <input value={values.nodeCode} onChange={(e) => setValues({ ...values, nodeCode: e.target.value })} required className={inputCls} />
        </Field>
        <Field label="节点名称" required>
          <input value={values.nodeName} onChange={(e) => setValues({ ...values, nodeName: e.target.value })} required className={inputCls} />
        </Field>
        <Field label="排序序号">
          <input type="number" value={values.nodeIdx} onChange={(e) => setValues({ ...values, nodeIdx: e.target.value })} className={inputCls} />
        </Field>
        <div className="col-span-2 flex flex-col gap-1">
          <label className="text-xs font-medium text-muted-foreground">备注</label>
          <textarea value={values.nodeRemark} onChange={(e) => setValues({ ...values, nodeRemark: e.target.value })} rows={3} className={inputCls} />
        </div>
      </div>
      <div className="flex justify-end gap-2 mt-6 max-w-2xl">
        <button type="submit" disabled={saving} className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90 disabled:opacity-50 cursor-pointer">
          {saving ? '保存中...' : '保存'}
        </button>
      </div>
    </form>
  )
}

// ------------------------------------------------------------
// 机房节点面板（属性 + 关联主机列表）
// ------------------------------------------------------------

interface IdcPanelProps {
  node: ComponentTreeNode
  hosts: Host[]
  hostsLoading: boolean
  saving: boolean
  onSave: (data: Record<string, unknown>) => void
  onDelete: () => void
}

function IdcPanel({ node, hosts, hostsLoading, saving, onSave, onDelete }: IdcPanelProps) {
  const columns = [
    { key: 'hostIp', label: '主机IP' },
    { key: 'leafCode', label: 'Leaf' },
    { key: 'rackCode', label: '机柜' },
    { key: 'cpuCores', label: 'CPU核数' },
    { key: 'memoryGb', label: '内存(GB)' },
    { key: 'diskGb', label: '磁盘(GB)' },
    { key: 'cpuModel', label: 'CPU型号' },
    { key: 'osName', label: '操作系统' },
  ]
  const [hostsOpen, setHostsOpen] = useState(true)

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 py-3 border-b border-border shrink-0 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-foreground">
          机房节点
          <span className="text-xs font-normal text-muted-foreground ml-2">{node.nodeName}</span>
        </h3>
        <button onClick={onDelete} className="text-xs text-destructive hover:underline cursor-pointer">删除节点</button>
      </div>

      <CollapsibleSection title="机房信息" defaultOpen={false}>
        <NodeEditForm node={node} saving={saving} onSave={onSave} />
      </CollapsibleSection>

      <CollapsibleSection title="访问方式" defaultOpen={false}>
        <AccessForm node={node} saving={saving} onSave={onSave} />
      </CollapsibleSection>

      <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
        <button
          onClick={() => setHostsOpen(!hostsOpen)}
          className="w-full flex items-center gap-2 px-4 py-3 text-sm font-semibold text-foreground hover:bg-accent/40 cursor-pointer shrink-0"
        >
          <span className="text-xs text-muted-foreground">{hostsOpen ? '▼' : '▶'}</span>
          关联主机
          {!hostsLoading && <span className="text-xs font-normal text-muted-foreground ml-1">共 {hosts.length} 台</span>}
        </button>
        {hostsOpen && (
          <div className="flex-1 overflow-auto">
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-muted/50">
                <tr>
                  <th className="text-left px-3 py-2 font-medium text-foreground border-b border-border">#</th>
                  {columns.map((c) => (
                    <th key={c.key} className="text-left px-3 py-2 font-medium text-foreground border-b border-border whitespace-nowrap">{c.label}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {hostsLoading ? (
                  <tr><td colSpan={columns.length + 1} className="px-3 py-8 text-center text-muted-foreground">加载中...</td></tr>
                ) : hosts.length === 0 ? (
                  <tr><td colSpan={columns.length + 1} className="px-3 py-8 text-center text-muted-foreground">该机房暂无关联主机</td></tr>
                ) : (
                  hosts.map((row, idx) => (
                    <tr key={String(row.id)} className="border-b border-border/50 hover:bg-accent/30">
                      <td className="px-3 py-2 text-muted-foreground">{idx + 1}</td>
                      {columns.map((c) => {
                        const v = (row as unknown as Record<string, unknown>)[c.key]
                        return (
                          <td key={c.key} className="px-3 py-2 text-foreground max-w-[200px] truncate" title={String(v ?? '-')}>
                            {(v ?? '-') as ReactNode}
                          </td>
                        )
                      })}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}

function AccessForm({ node, saving, onSave }: { node: ComponentTreeNode; saving: boolean; onSave: (data: Record<string, unknown>) => void }) {
  const [values, setValues] = useState<Record<string, string>>({
    accessMethod: node.accessMethod ?? '',
    accessPort: node.accessPort != null ? String(node.accessPort) : '',
    accessPassword: node.accessPassword ?? '',
  })

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    onSave({
      accessMethod: (values.accessMethod ?? '').trim() || null,
      accessPort: values.accessPort && values.accessPort.trim() !== '' ? Number(values.accessPort) : null,
      accessPassword: values.accessPassword || null,
    })
  }

  return (
    <form onSubmit={handleSubmit} className="p-4">
      <div className="grid grid-cols-1 gap-3 max-w-2xl">
        <Field label="访问方式">
          <textarea value={values.accessMethod} onChange={(e) => setValues({ ...values, accessMethod: e.target.value })} rows={3} className={inputCls} />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="访问端口">
            <input type="number" value={values.accessPort} onChange={(e) => setValues({ ...values, accessPort: e.target.value })} className={inputCls} />
          </Field>
          <Field label="访问密码">
            <input type="password" value={values.accessPassword} onChange={(e) => setValues({ ...values, accessPassword: e.target.value })} className={inputCls} />
          </Field>
        </div>
      </div>
      <div className="flex justify-end gap-2 mt-4 max-w-2xl">
        <button type="submit" disabled={saving} className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90 disabled:opacity-50 cursor-pointer">
          {saving ? '保存中...' : '保存'}
        </button>
      </div>
    </form>
  )
}

// ------------------------------------------------------------
// 新增节点弹窗
// ------------------------------------------------------------

interface CreateNodeModalProps {
  form: CreateState
  saving: boolean
  onSave: (data: Record<string, unknown>) => void
  onCancel: () => void
}

function CreateNodeModal({ form, saving, onSave, onCancel }: CreateNodeModalProps) {
  const meta = nodeTypeMeta(form.nodeType)
  const [values, setValues] = useState<Record<string, string>>({
    nodeCode: '',
    nodeName: '',
    nodeRemark: '',
  })

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    onSave({
      parentId: form.parentId,
      nodeType: form.nodeType,
      nodeCode: (values.nodeCode ?? '').trim(),
      nodeName: (values.nodeName ?? '').trim(),
      nodeRemark: (values.nodeRemark ?? '').trim() || null,
    })
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-card border border-border rounded-lg shadow-lg w-[480px] max-h-[85vh] flex flex-col">
        <div className="p-4 border-b border-border flex items-center justify-between">
          <h3 className="text-base font-semibold text-foreground">新增{meta.label}节点</h3>
          <button onClick={onCancel} className="text-muted-foreground hover:text-foreground text-lg leading-none cursor-pointer">&times;</button>
        </div>
        <form onSubmit={handleSubmit} className="p-4 overflow-auto flex-1">
          <div className="grid grid-cols-1 gap-3">
            <Field label="节点编码" required>
              <input value={values.nodeCode} onChange={(e) => setValues({ ...values, nodeCode: e.target.value })} required className={inputCls} autoFocus />
            </Field>
            <Field label="节点名称" required>
              <input value={values.nodeName} onChange={(e) => setValues({ ...values, nodeName: e.target.value })} required className={inputCls} />
            </Field>
            <Field label="备注">
              <textarea value={values.nodeRemark} onChange={(e) => setValues({ ...values, nodeRemark: e.target.value })} rows={2} className={inputCls} />
            </Field>
          </div>
          <div className="flex justify-end gap-2 mt-6">
            <button type="button" onClick={onCancel} className="px-4 py-2 text-sm border border-border rounded text-foreground hover:bg-accent cursor-pointer">取消</button>
            <button type="submit" disabled={saving} className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90 disabled:opacity-50 cursor-pointer">
              {saving ? '保存中...' : '保存'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

// ------------------------------------------------------------
// 通用
// ------------------------------------------------------------

const inputCls = 'w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary'

function Field({ label, required, children }: { label: string; required?: boolean; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-xs font-medium text-muted-foreground">
        {label}
        {required && <span className="text-destructive ml-0.5">*</span>}
      </label>
      {children}
    </div>
  )
}

function CollapsibleSection({ title, defaultOpen = false, children }: { title: string; defaultOpen?: boolean; children: ReactNode }) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="shrink-0 border-b border-border">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-2 px-4 py-3 text-sm font-semibold text-foreground hover:bg-accent/40 cursor-pointer"
      >
        <span className="text-xs text-muted-foreground">{open ? '▼' : '▶'}</span>
        {title}
      </button>
      {open && <div>{children}</div>}
    </div>
  )
}
