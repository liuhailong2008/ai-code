import { useMemo, useState, type FormEvent, type ReactNode } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import {
  listStandards, createStandard, updateStandard, deleteStandard, moveStandard,
  type AcceptanceStandard,
} from '../../api/ruok'

const COLLECT_TYPES = ['cmdb', 'ssh', 'prometheus', 'port', 'process', 'middleware']

interface TreeNode {
  node: AcceptanceStandard
  children: TreeNode[]
}

function buildTree(list: AcceptanceStandard[]): TreeNode[] {
  const byParent = new Map<number, AcceptanceStandard[]>()
  for (const n of list) {
    const arr = byParent.get(n.parentId) ?? []
    arr.push(n)
    byParent.set(n.parentId, arr)
  }
  const build = (parentId: number): TreeNode[] => {
    const nodes = (byParent.get(parentId) ?? []).sort((a, b) => a.orderIdx - b.orderIdx || a.id - b.id)
    return nodes.map((n) => ({ node: n, children: build(n.id) }))
  }
  return build(0)
}

interface FormState {
  mode: 'create' | 'edit'
  defaultParentId: number
  defaultNodeType: string
  node?: AcceptanceStandard
}

export function StandardsTab() {
  const queryClient = useQueryClient()
  const { data, isLoading } = useQuery({
    queryKey: ['ruok', 'standards'],
    queryFn: listStandards,
  })
  const list = data ?? []

  const [expanded, setExpanded] = useState<Set<number>>(new Set())
  const [filter, setFilter] = useState('')
  const [form, setForm] = useState<FormState | null>(null)
  const [dragId, setDragId] = useState<number | null>(null)

  const createMutation = useMutation({
    mutationFn: createStandard,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['ruok', 'standards'] }),
  })
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Record<string, unknown> }) => updateStandard(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['ruok', 'standards'] }),
  })
  const deleteMutation = useMutation({
    mutationFn: deleteStandard,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['ruok', 'standards'] }),
  })
  const moveMutation = useMutation({
    mutationFn: ({ id, parentId, orderIdx }: { id: number; parentId: number; orderIdx: number }) => moveStandard(id, parentId, orderIdx),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['ruok', 'standards'] }),
  })

  const tree = useMemo(() => buildTree(list), [list])

  const categories = useMemo(() => list.filter((n) => n.nodeType === 'category'), [list])

  const filtered = filter.trim()
    ? list.filter((n) => {
        const kw = filter.trim().toLowerCase()
        return n.standardCode.toLowerCase().includes(kw)
          || n.standardName.toLowerCase().includes(kw)
          || n.nodeType.toLowerCase().includes(kw)
      })
    : null

  const toggleExpand = (id: number) => {
    setExpanded((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const handleDrop = (targetId: number) => {
    if (dragId == null || dragId === targetId) return
    const target = list.find((n) => n.id === targetId)
    if (!target) return
    // 拖到目标节点上 = 插入到该节点之前（同级排序）
    const siblings = list
      .filter((n) => n.parentId === target.parentId && n.id !== dragId)
      .sort((a, b) => a.orderIdx - b.orderIdx || a.id - b.id)
    const idx = siblings.findIndex((n) => n.id === targetId)
    const orderIdx = idx < 0 ? siblings.length : idx
    moveMutation.mutate({ id: dragId, parentId: target.parentId, orderIdx })
    setDragId(null)
  }

  const handleMove = (id: number, dir: -1 | 1) => {
    const node = list.find((n) => n.id === id)
    if (!node) return
    const siblings = list
      .filter((n) => n.parentId === node.parentId)
      .sort((a, b) => a.orderIdx - b.orderIdx || a.id - b.id)
    const idx = siblings.findIndex((n) => n.id === id)
    const targetIdx = idx + dir
    if (targetIdx < 0 || targetIdx >= siblings.length) return
    moveMutation.mutate({ id, parentId: node.parentId, orderIdx: targetIdx })
  }

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 py-3 border-b border-border flex items-center gap-3 shrink-0">
        <h3 className="text-sm font-semibold text-foreground">验收标准</h3>
        <input
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder="按编码/名称/类型筛选"
          className="px-3 py-1.5 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary w-64"
        />
        <div className="flex-1" />
        <button
          onClick={() => setForm({ mode: 'create', defaultParentId: 0, defaultNodeType: 'category' })}
          className="px-3 py-1.5 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90 cursor-pointer"
        >
          + 新增根分类
        </button>
      </div>

      <div className="flex-1 overflow-auto p-4">
        {isLoading ? (
          <p className="text-sm text-muted-foreground">加载中...</p>
        ) : list.length === 0 ? (
          <p className="text-sm text-muted-foreground">暂无验收标准，请先新增根分类。</p>
        ) : filtered ? (
          filtered.length === 0 ? (
            <p className="text-sm text-muted-foreground">无匹配结果</p>
          ) : (
            <div className="space-y-1">
              {filtered.map((n) => (
                <div key={n.id} className="flex items-center gap-2 px-2 py-1.5 rounded border border-border/50 hover:bg-accent/30">
                  <span className="text-xs px-1.5 py-0.5 rounded bg-muted text-muted-foreground">{n.nodeType === 'category' ? '分类' : '验收项'}</span>
                  <span className="text-sm text-foreground">{n.standardName}</span>
                  <span className="text-xs text-muted-foreground">{n.standardCode}</span>
                  <div className="flex-1" />
                  <button onClick={() => setForm({ mode: 'edit', defaultParentId: n.parentId, defaultNodeType: n.nodeType, node: n })} className="text-xs text-primary hover:underline cursor-pointer">编辑</button>
                  <button onClick={() => { if (confirm('确认删除？其子节点将一并被删除。')) deleteMutation.mutate(n.id) }} className="text-xs text-destructive hover:underline cursor-pointer">删除</button>
                </div>
              ))}
            </div>
          )
        ) : (
          <TreeList
            nodes={tree}
            expanded={expanded}
            onToggle={toggleExpand}
            onAddCategory={(parentId) => setForm({ mode: 'create', defaultParentId: parentId, defaultNodeType: 'category' })}
            onAddItem={(parentId) => setForm({ mode: 'create', defaultParentId: parentId, defaultNodeType: 'item' })}
            onEdit={(node) => setForm({ mode: 'edit', defaultParentId: node.parentId, defaultNodeType: node.nodeType, node })}
            onDelete={(id) => { if (confirm('确认删除？其子节点将一并被删除。')) deleteMutation.mutate(id) }}
            onMove={handleMove}
            dragId={dragId}
            onDragStart={setDragId}
            onDrop={handleDrop}
          />
        )}
      </div>

      {form && (
        <StandardFormModal
          form={form}
          categories={categories}
          saving={createMutation.isPending || updateMutation.isPending}
          onSave={(data) => {
            if (form.mode === 'edit' && form.node) updateMutation.mutate({ id: form.node.id, data })
            else createMutation.mutate(data)
          }}
          onCancel={() => setForm(null)}
        />
      )}
    </div>
  )
}

interface TreeListProps {
  nodes: TreeNode[]
  expanded: Set<number>
  onToggle: (id: number) => void
  onAddCategory: (parentId: number) => void
  onAddItem: (parentId: number) => void
  onEdit: (node: AcceptanceStandard) => void
  onDelete: (id: number) => void
  onMove: (id: number, dir: -1 | 1) => void
  dragId: number | null
  onDragStart: (id: number) => void
  onDrop: (targetId: number) => void
}

function TreeList({ nodes, expanded, onToggle, onAddCategory, onAddItem, onEdit, onDelete, onMove, dragId, onDragStart, onDrop }: TreeListProps) {
  return (
    <div className="space-y-0.5">
      {nodes.map((tn) => (
        <TreeNodeRow
          key={tn.node.id}
          tn={tn}
          depth={0}
          expanded={expanded}
          onToggle={onToggle}
          onAddCategory={onAddCategory}
          onAddItem={onAddItem}
          onEdit={onEdit}
          onDelete={onDelete}
          onMove={onMove}
          dragId={dragId}
          onDragStart={onDragStart}
          onDrop={onDrop}
        />
      ))}
    </div>
  )
}

interface TreeNodeRowProps extends Omit<TreeListProps, 'nodes'> {
  tn: TreeNode
  depth: number
}

function TreeNodeRow(props: TreeNodeRowProps) {
  const { tn, depth, expanded, onToggle, onAddCategory, onAddItem, onEdit, onDelete, onMove, dragId, onDragStart, onDrop } = props
  const { node, children } = tn
  const isCategory = node.nodeType === 'category'
  const isOpen = expanded.has(node.id)
  const isDragging = dragId === node.id

  return (
    <div>
      <div
        draggable
        onDragStart={(e) => { e.dataTransfer.setData('text/plain', String(node.id)); onDragStart(node.id) }}
        onDragOver={(e) => { if (dragId != null) e.preventDefault() }}
        onDrop={(e) => { e.preventDefault(); onDrop(node.id) }}
        className={`flex items-center gap-2 px-2 py-1.5 rounded border border-transparent hover:bg-accent/30 transition-colors cursor-grab ${
          isDragging ? 'opacity-40' : ''
        }`}
        style={{ paddingLeft: `${depth * 20 + 8}px` }}
      >
        {isCategory ? (
          <button onClick={() => onToggle(node.id)} className="w-4 text-muted-foreground cursor-pointer text-xs">
            {isOpen ? '▼' : '▶'}
          </button>
        ) : (
          <span className="w-4" />
        )}
        <span className={`text-xs px-1.5 py-0.5 rounded ${isCategory ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>
          {isCategory ? '分类' : '验收项'}
        </span>
        <span className="text-sm text-foreground">{node.standardName}</span>
        <span className="text-xs text-muted-foreground">{node.standardCode}</span>
        {node.collectType && <span className="text-xs text-muted-foreground">· {node.collectType}</span>}
        <div className="flex-1" />
        {isCategory && (
          <>
            <button onClick={() => onAddCategory(node.id)} className="text-xs text-primary hover:underline cursor-pointer">+分类</button>
            <button onClick={() => onAddItem(node.id)} className="text-xs text-primary hover:underline cursor-pointer">+验收项</button>
          </>
        )}
        <button onClick={() => onMove(node.id, -1)} className="text-xs text-muted-foreground hover:text-foreground cursor-pointer px-1" title="上移">↑</button>
        <button onClick={() => onMove(node.id, 1)} className="text-xs text-muted-foreground hover:text-foreground cursor-pointer px-1" title="下移">↓</button>
        <button onClick={() => onEdit(node)} className="text-xs text-primary hover:underline cursor-pointer">编辑</button>
        <button onClick={() => onDelete(node.id)} className="text-xs text-destructive hover:underline cursor-pointer">删除</button>
      </div>

      {isCategory && isOpen && children.length > 0 && (
        <div>
          {children.map((child) => (
            <TreeNodeRow
              key={child.node.id}
              tn={child}
              depth={depth + 1}
              expanded={expanded}
              onToggle={onToggle}
              onAddCategory={onAddCategory}
              onAddItem={onAddItem}
              onEdit={onEdit}
              onDelete={onDelete}
              onMove={onMove}
              dragId={dragId}
              onDragStart={onDragStart}
              onDrop={onDrop}
            />
          ))}
        </div>
      )}
    </div>
  )
}

interface StandardFormModalProps {
  form: FormState
  categories: AcceptanceStandard[]
  saving: boolean
  onSave: (data: Record<string, unknown>) => void
  onCancel: () => void
}

function StandardFormModal({ form, categories, saving, onSave, onCancel }: StandardFormModalProps) {
  const node = form.node
  const [values, setValues] = useState<Record<string, string>>({
    standardCode: node?.standardCode ?? '',
    standardName: node?.standardName ?? '',
    nodeType: node?.nodeType ?? form.defaultNodeType,
    parentId: String(node?.parentId ?? form.defaultParentId),
    collectType: node?.collectType ?? '',
    collectMethod: node?.collectMethod ?? '',
    collectParams: node?.collectParams ?? '',
    judgeCriteria: node?.judgeCriteria ?? '',
    standardStatus: node?.standardStatus ?? 'enabled',
  })

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    const data: Record<string, unknown> = {
      parentId: Number(values.parentId) || 0,
      standardCode: (values.standardCode ?? '').trim(),
      standardName: (values.standardName ?? '').trim(),
      nodeType: values.nodeType,
      collectType: (values.collectType ?? '').trim() || null,
      collectMethod: (values.collectMethod ?? '').trim() || null,
      collectParams: values.collectParams,
      judgeCriteria: values.judgeCriteria,
      standardStatus: values.standardStatus,
    }
    onSave(data)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-card border border-border rounded-lg shadow-lg w-[620px] max-h-[85vh] flex flex-col">
        <div className="p-4 border-b border-border flex items-center justify-between">
          <h3 className="text-base font-semibold text-foreground">{form.mode === 'edit' ? '编辑验收标准' : '新增验收标准'}</h3>
          <button onClick={onCancel} className="text-muted-foreground hover:text-foreground text-lg leading-none cursor-pointer">&times;</button>
        </div>
        <form onSubmit={handleSubmit} className="p-4 overflow-auto flex-1">
          <div className="grid grid-cols-2 gap-3">
            <Field label="编码" required>
              <input value={values.standardCode} onChange={(e) => setValues({ ...values, standardCode: e.target.value })} required className={inputCls} />
            </Field>
            <Field label="名称" required>
              <input value={values.standardName} onChange={(e) => setValues({ ...values, standardName: e.target.value })} required className={inputCls} />
            </Field>
            <Field label="类型">
              <select value={values.nodeType} onChange={(e) => setValues({ ...values, nodeType: e.target.value })} className={inputCls}>
                <option value="category">分类</option>
                <option value="item">验收项</option>
              </select>
            </Field>
            <Field label="父级分类">
              <select value={values.parentId} onChange={(e) => setValues({ ...values, parentId: e.target.value })} className={inputCls}>
                <option value="0">根级</option>
                {categories
                  .filter((c) => c.id !== node?.id)
                  .map((c) => (
                    <option key={c.id} value={String(c.id)}>{c.standardName}</option>
                  ))}
              </select>
            </Field>
            <Field label="采集类型">
              <select value={values.collectType} onChange={(e) => setValues({ ...values, collectType: e.target.value })} className={inputCls}>
                <option value="">未设置</option>
                {COLLECT_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
            </Field>
            <Field label="采集方式">
              <input value={values.collectMethod} onChange={(e) => setValues({ ...values, collectMethod: e.target.value })} className={inputCls} />
            </Field>
            <Field label="状态">
              <select value={values.standardStatus} onChange={(e) => setValues({ ...values, standardStatus: e.target.value })} className={inputCls}>
                <option value="enabled">启用</option>
                <option value="disabled">停用</option>
              </select>
            </Field>
            <div className="col-span-2 flex flex-col gap-1">
              <label className="text-xs font-medium text-muted-foreground">采集参数</label>
              <textarea value={values.collectParams} onChange={(e) => setValues({ ...values, collectParams: e.target.value })} rows={3} className={inputCls} placeholder="JSON 或文本，留空为无" />
            </div>
            <div className="col-span-2 flex flex-col gap-1">
              <label className="text-xs font-medium text-muted-foreground">判定标准</label>
              <textarea value={values.judgeCriteria} onChange={(e) => setValues({ ...values, judgeCriteria: e.target.value })} rows={3} className={inputCls} placeholder="判定逻辑描述" />
            </div>
          </div>
          <div className="flex justify-end gap-2 mt-6">
            <button type="button" onClick={onCancel} className="px-4 py-2 text-sm border border-border rounded text-foreground hover:bg-accent cursor-pointer">取消</button>
            <button type="submit" disabled={saving} className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90 disabled:opacity-50 cursor-pointer">
              {saving ? '保存中...' : '保存'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

const inputCls = 'w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary'

function Field({ label, required, children }: { label: string; required?: boolean; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-xs font-medium text-muted-foreground">
        {label}
        {required && <span className="text-destructive ml-0.5">*</span>}
      </label>
      {children}
    </div>
  )
}
