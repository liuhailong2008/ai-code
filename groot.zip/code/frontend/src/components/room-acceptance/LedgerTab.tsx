import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { EntityCrudTable, type FieldDef } from './EntityCrudTable'
import {
  listIdcs, createIdc, updateIdc, deleteIdc,
  listDomains, createDomain, updateDomain, deleteDomain,
  listCmdbSyncDiffs,
} from '../../api/ruok'
import { listDicts, type SysDict } from '../../api/dict'
import { ComponentTreeTab } from './ComponentTreeTab'

interface EntityConfig {
  key: string
  label: string
  fields: FieldDef[]
  list: () => Promise<any[]>
  create: (data: Record<string, unknown>) => Promise<any>
  update: (id: number, data: Record<string, unknown>) => Promise<any>
  remove: (id: number) => Promise<void>
}

// 从数据字典中取某字典类型下的取值（按 dict_sn 排序）
function dictOptions(dicts: SysDict[], parentKey: string): string[] {
  const parent = dicts.find((d) => d.parentId === 0 && d.dictKey === parentKey)
  if (!parent) return []
  return dicts
    .filter((d) => d.parentId === parent.id)
    .sort((a, b) => a.dictSn - b.dictSn)
    .map((d) => d.dictValue)
}

const ENTITIES: EntityConfig[] = [
  {
    key: 'idc',
    label: 'IDC',
    fields: [
      { key: 'envCode', label: '环境', type: 'select', required: true },
      { key: 'idcCode', label: 'IDC编号', required: true },
      { key: 'idcName', label: 'IDC名称', required: true },
      { key: 'isXinchuang', label: '是否信创', type: 'select', options: ['是', '否'] },
      { key: 'idcStatus', label: '状态', type: 'select' },
      { key: 'idcRemark', label: '备注' },
    ],
    list: () => listIdcs(),
    create: createIdc,
    update: updateIdc,
    remove: deleteIdc,
  },
  {
    key: 'domain',
    label: '域名',
    fields: [
      { key: 'envCode', label: '环境', type: 'select', options: ['开发VDI', '生产', '测试'], required: true },
      { key: 'idcCode', label: 'IDC编号', required: true },
      { key: 'domainType', label: '类型', type: 'select', options: ['全局', '本地'], required: true },
      { key: 'domainName', label: '域名', required: true },
      { key: 'targetHost', label: '目标主机' },
    ],
    list: () => listDomains(),
    create: createDomain,
    update: updateDomain,
    remove: deleteDomain,
  },
]

export function LedgerTab() {
  const [active, setActive] = useState('tree')

  const { data: dicts } = useQuery({
    queryKey: ['dicts'],
    queryFn: listDicts,
  })
  const envOptions = dictOptions(dicts ?? [], 'idc_env')
  const statusOptions = dictOptions(dicts ?? [], 'idc_status')

  const entities = ENTITIES.map((e) => {
    if (e.key !== 'idc') return e
    return {
      ...e,
      fields: e.fields.map((f) => {
        if (f.key === 'envCode') return { ...f, options: envOptions }
        if (f.key === 'idcStatus') return { ...f, options: statusOptions }
        return f
      }),
    }
  })

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-1 px-4 pt-3 border-b border-border shrink-0">
        <button
          onClick={() => setActive('tree')}
          className={`px-3 py-1.5 text-sm rounded-t transition-colors cursor-pointer ${
            active === 'tree' ? 'bg-card text-foreground border border-b-0 border-border font-medium' : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          组件树
        </button>
        {entities.map((e) => (
          <button
            key={e.key}
            onClick={() => setActive(e.key)}
            className={`px-3 py-1.5 text-sm rounded-t transition-colors cursor-pointer ${
              active === e.key ? 'bg-card text-foreground border border-b-0 border-border font-medium' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            {e.label}
          </button>
        ))}
        <button
          onClick={() => setActive('diff')}
          className={`px-3 py-1.5 text-sm rounded-t transition-colors cursor-pointer ${
            active === 'diff' ? 'bg-card text-foreground border border-b-0 border-border font-medium' : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          CMDB对账
        </button>
      </div>

      <div className="flex-1 overflow-hidden">
        {active === 'tree' && <ComponentTreeTab />}
        {entities.map((e) =>
          active === e.key ? <LedgerEntityTab key={e.key} config={e} /> : null,
        )}
        {active === 'diff' && <CmdbDiffTab />}
      </div>
    </div>
  )
}

function LedgerEntityTab({ config }: { config: EntityConfig }) {
  const queryClient = useQueryClient()
  const { data, isLoading } = useQuery({
    queryKey: ['ruok', config.key],
    queryFn: config.list,
  })

  const createMutation = useMutation({
    mutationFn: config.create,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['ruok', config.key] }),
  })
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Record<string, unknown> }) => config.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['ruok', config.key] }),
  })
  const deleteMutation = useMutation({
    mutationFn: config.remove,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['ruok', config.key] }),
  })

  return (
    <EntityCrudTable
      title={config.label}
      fields={config.fields}
      rows={(data ?? []) as Record<string, unknown>[]}
      loading={isLoading}
      saving={createMutation.isPending || updateMutation.isPending}
      onCreate={(d) => createMutation.mutate(d)}
      onUpdate={(id, d) => updateMutation.mutate({ id, data: d })}
      onDelete={(id) => deleteMutation.mutate(id)}
    />
  )
}

function CmdbDiffTab() {
  const { data, isLoading } = useQuery({
    queryKey: ['ruok', 'cmdb-diff'],
    queryFn: () => listCmdbSyncDiffs(),
  })
  const rows = data ?? []
  const columns = [
    { key: 'batchCode', label: '批次号' },
    { key: 'envCode', label: '环境' },
    { key: 'idcCode', label: 'IDC编号' },
    { key: 'diffType', label: '差异类型' },
    { key: 'hostIp', label: '主机IP' },
    { key: 'diffStatus', label: '状态' },
    { key: 'syncRemark', label: '备注' },
  ]

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 py-3 border-b border-border shrink-0">
        <h3 className="text-sm font-semibold text-foreground">
          CMDB对账差异
          {!isLoading && <span className="text-xs font-normal text-muted-foreground ml-2">共 {rows.length} 条</span>}
        </h3>
      </div>
      <div className="flex-1 overflow-auto">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-muted/50">
            <tr>
              <th className="text-left px-3 py-2 font-medium text-foreground border-b border-border">#</th>
              {columns.map((c) => (
                <th key={c.key} className="text-left px-3 py-2 font-medium text-foreground border-b border-border whitespace-nowrap">{c.label}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={columns.length + 1} className="px-3 py-8 text-center text-muted-foreground">加载中...</td></tr>
            ) : rows.length === 0 ? (
              <tr><td colSpan={columns.length + 1} className="px-3 py-8 text-center text-muted-foreground">暂无差异</td></tr>
            ) : (
              rows.map((row, idx) => (
                <tr key={row.id} className="border-b border-border/50 hover:bg-accent/30">
                  <td className="px-3 py-2 text-muted-foreground">{idx + 1}</td>
                  {columns.map((c) => (
                    <td key={c.key} className="px-3 py-2 text-foreground max-w-[240px] truncate" title={String((row as any)[c.key] ?? '-')}>
                      {(row as any)[c.key] ?? '-'}
                    </td>
                  ))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
