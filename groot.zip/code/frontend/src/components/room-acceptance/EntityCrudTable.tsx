import { useState, type FormEvent } from 'react'

export interface FieldDef {
  key: string
  label: string
  type?: 'text' | 'number' | 'select' | 'password'
  options?: string[]
  required?: boolean
  hideInTable?: boolean
}

interface EntityCrudTableProps {
  title: string
  fields: FieldDef[]
  rows: Record<string, unknown>[]
  loading: boolean
  saving: boolean
  onCreate: (data: Record<string, unknown>) => void
  onUpdate: (id: number, data: Record<string, unknown>) => void
  onDelete: (id: number) => void
}

export function EntityCrudTable({ title, fields, rows, loading, saving, onCreate, onUpdate, onDelete }: EntityCrudTableProps) {
  const [editing, setEditing] = useState<Record<string, unknown> | null>(null)
  const [creating, setCreating] = useState(false)

  const visibleFields = fields.filter((f) => !f.hideInTable)

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 py-3 border-b border-border flex items-center justify-between shrink-0">
        <h3 className="text-sm font-semibold text-foreground">
          {title}
          {!loading && <span className="text-xs font-normal text-muted-foreground ml-2">共 {rows.length} 条</span>}
        </h3>
        <button
          onClick={() => setCreating(true)}
          className="px-3 py-1.5 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90 cursor-pointer"
        >
          + 新增
        </button>
      </div>

      <div className="flex-1 overflow-auto">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-muted/50">
            <tr>
              <th className="text-left px-3 py-2 font-medium text-foreground border-b border-border whitespace-nowrap">#</th>
              {visibleFields.map((f) => (
                <th key={f.key} className="text-left px-3 py-2 font-medium text-foreground border-b border-border whitespace-nowrap">
                  {f.label}
                </th>
              ))}
              <th className="text-left px-3 py-2 font-medium text-foreground border-b border-border whitespace-nowrap">操作</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={visibleFields.length + 2} className="px-3 py-8 text-center text-muted-foreground">加载中...</td>
              </tr>
            ) : rows.length === 0 ? (
              <tr>
                <td colSpan={visibleFields.length + 2} className="px-3 py-8 text-center text-muted-foreground">暂无数据</td>
              </tr>
            ) : (
              rows.map((row, idx) => (
                <tr key={row.id as number} className="border-b border-border/50 hover:bg-accent/30 transition-colors">
                  <td className="px-3 py-2 text-muted-foreground">{idx + 1}</td>
                  {visibleFields.map((f) => (
                    <td key={f.key} className="px-3 py-2 text-foreground max-w-[240px] truncate" title={renderValue(row[f.key])}>
                      {renderValue(row[f.key])}
                    </td>
                  ))}
                  <td className="px-3 py-2 whitespace-nowrap">
                    <button onClick={() => setEditing(row)} className="text-xs text-primary hover:underline mr-3 cursor-pointer">编辑</button>
                    <button
                      onClick={() => { if (confirm('确认删除？')) onDelete(row.id as number) }}
                      className="text-xs text-destructive hover:underline cursor-pointer"
                    >
                      删除
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {(creating || editing) && (
        <EntityFormModal
          title={editing ? `编辑${title}` : `新增${title}`}
          fields={fields}
          initial={editing ?? {}}
          saving={saving}
          onSave={(data) => {
            if (editing) onUpdate(editing.id as number, data)
            else onCreate(data)
          }}
          onCancel={() => { setCreating(false); setEditing(null) }}
        />
      )}
    </div>
  )
}

interface EntityFormModalProps {
  title: string
  fields: FieldDef[]
  initial: Record<string, unknown>
  saving: boolean
  onSave: (data: Record<string, unknown>) => void
  onCancel: () => void
}

function EntityFormModal({ title, fields, initial, saving, onSave, onCancel }: EntityFormModalProps) {
  const [values, setValues] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {}
    for (const f of fields) {
      const v = initial[f.key]
      init[f.key] = v === null || v === undefined ? '' : String(v)
    }
    return init
  })

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    const data: Record<string, unknown> = {}
    for (const f of fields) {
      const raw = (values[f.key] ?? '').trim()
      if (f.type === 'number') {
        data[f.key] = raw === '' ? null : Number(raw)
      } else {
        data[f.key] = raw === '' ? null : raw
      }
    }
    onSave(data)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-card border border-border rounded-lg shadow-lg w-[620px] max-h-[85vh] flex flex-col">
        <div className="p-4 border-b border-border flex items-center justify-between">
          <h3 className="text-base font-semibold text-foreground">{title}</h3>
          <button onClick={onCancel} className="text-muted-foreground hover:text-foreground text-lg leading-none cursor-pointer">&times;</button>
        </div>
        <form onSubmit={handleSubmit} className="p-4 overflow-auto flex-1">
          <div className="grid grid-cols-2 gap-3">
            {fields.map((f) => (
              <div key={f.key} className="flex flex-col gap-1">
                <label className="text-xs font-medium text-muted-foreground">
                  {f.label}
                  {f.required && <span className="text-destructive ml-0.5">*</span>}
                </label>
                {f.type === 'select' ? (
                  <select
                    value={values[f.key]}
                    onChange={(e) => setValues({ ...values, [f.key]: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="">请选择</option>
                    {(f.options ?? []).map((opt) => (
                      <option key={opt} value={opt}>{opt}</option>
                    ))}
                  </select>
                ) : (
                  <input
                    type={f.type === 'number' ? 'number' : f.type === 'password' ? 'password' : 'text'}
                    value={values[f.key]}
                    onChange={(e) => setValues({ ...values, [f.key]: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="留空为 NULL"
                  />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-end gap-2 mt-6">
            <button type="button" onClick={onCancel} className="px-4 py-2 text-sm border border-border rounded text-foreground hover:bg-accent cursor-pointer">取消</button>
            <button type="submit" disabled={saving} className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90 disabled:opacity-50 cursor-pointer">
              {saving ? '保存中...' : '保存'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

function renderValue(value: unknown): string {
  if (value === null || value === undefined) return '-'
  return String(value)
}
