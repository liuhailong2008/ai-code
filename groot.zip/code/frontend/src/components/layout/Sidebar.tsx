import { Link, useLocation, useNavigate } from '@tanstack/react-router'
import { useQuery } from '@tanstack/react-query'
import { useState, useEffect } from 'react'
import { useAuthStore } from '../../stores/auth'
import { listEvents } from '../../api/events'
import { getUserTeams } from '../../api/teams'

const menuItems = [
  { path: '/approvals', label: '我的审批' },
  { path: '/history', label: '历史事件' },
]

const docsSubItems = [
  { path: '/settings/middleware', label: '组件设置' },
  { path: '/settings/members', label: '人员设置' },
  { path: '/settings/team', label: '团队设置' },
  { path: '/settings/duty', label: '值班信息' },
]

const sopSubItems = [
  { path: '/sop', label: 'SOP' },
  { path: '/sop/agents', label: 'Agent' },
  { path: '/sop/tools', label: 'Tool' },
  { path: '/sop/mcp', label: 'MCP' },
  { path: '/sop/skills', label: 'Skill' },
  { path: '/sop/loop', label: 'Loop' },
]

const opsSubItems = [
  { path: '/ops/fault-drill', label: '故障演练' },
  { path: '/ops/room-acceptance', label: '机房验收' },
  { path: '/ops/cert-inspection', label: '证书巡检' },
]

const ROLE_LABELS: Record<string, string> = {
  admin: '管理员',
  operator: '运维人员',
  viewer: '审计用户',
}

const settingsSubItems = [
  { path: '/settings/model', label: '模型管理' },
  { path: '/settings/dict', label: '数据字典' },
  { path: '/settings/data-management', label: '数据管理' },
]

interface SidebarProps {
  collapsed?: boolean
}

export function Sidebar({ collapsed }: SidebarProps) {
  const location = useLocation()
  const navigate = useNavigate()
  const { user } = useAuthStore()
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [sopOpen, setSopOpen] = useState(false)
  const [docsOpen, setDocsOpen] = useState(false)
  const [opsOpen, setOpsOpen] = useState(false)

  const { data: events } = useQuery({
    queryKey: ['events'],
    queryFn: () => listEvents(),
  })

  const { data: teams } = useQuery({
    queryKey: ['userTeams', user?.id],
    queryFn: () => getUserTeams(user!.id),
    enabled: !!user,
  })

  const teamNames = teams?.map((t) => t.name).join('、') || ''

  const isEventsActive = location.pathname.startsWith('/events')
  const isSettingsActive = location.pathname.startsWith('/settings')
  const isSopActive = location.pathname.startsWith('/sop')
  const isOpsActive = location.pathname.startsWith('/ops')
  useEffect(() => { if (isSopActive) setSopOpen(true) }, [isSopActive])
  useEffect(() => { if (isOpsActive) setOpsOpen(true) }, [isOpsActive])

  if (collapsed) return null

  return (
    <aside className="w-52 border-r border-border bg-card shrink-0 flex flex-col">
      <nav className="flex-1 overflow-auto">
        {/* 新建按钮 */}
        <div className="p-2">
          <button
            onClick={() => navigate({ to: '/events' })}
            className="w-full p-2 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors cursor-pointer"
          >
            + 新事件
          </button>
        </div>

        {/* 事件菜单项 */}
        <div className="px-2">
          <Link
            to="/events"
            className={`flex items-center justify-between p-2 rounded text-sm transition-colors cursor-pointer ${
              isEventsActive
                ? 'bg-accent text-accent-foreground'
                : 'text-muted-foreground hover:bg-accent/50'
            }`}
          >
            <span>事件</span>
          </Link>

          {/* 处理中事件子列表 */}
          {events && events.length > 0 && (
            <div className="ml-3 mt-1 space-y-0.5">
              {events.map((event) => {
                const isEventActive = location.pathname.includes(String(event.id))
                return (
                  <Link
                    key={event.id}
                    to="/events/$id"
                    params={{ id: String(event.id) }}
                    className={`flex items-center gap-2 px-2 py-1.5 rounded text-xs transition-colors cursor-pointer ${
                      isEventActive
                        ? 'bg-accent text-accent-foreground'
                        : 'text-muted-foreground hover:bg-accent/50 hover:text-foreground'
                    }`}
                  >
                    <span
                      className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                        event.severity === 'critical' || event.severity === 'high'
                          ? 'bg-red-500'
                          : event.severity === 'medium'
                            ? 'bg-orange-500'
                            : 'bg-muted-foreground'
                      }`}
                    />
                    <span className="truncate">{event.title}</span>
                  </Link>
                )
              })}
            </div>
          )}
        </div>

        {/* 分隔线 */}
        <div className="mx-3 my-3 border-t border-border" />

        {/* 下方菜单项 */}
        {menuItems.map((item) => {
          const isActive = location.pathname.startsWith(item.path)
          return (
            <div key={item.path} className="px-2">
              <Link
                to={item.path as any}
                className={`flex items-center justify-between p-2 rounded text-sm transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-accent text-accent-foreground'
                    : 'text-muted-foreground hover:bg-accent/50'
                }`}
              >
                <span>{item.label}</span>
              </Link>
            </div>
          )
        })}

        {/* 运维场景 - 可展开 */}
        <div className="px-2">
          <button
            onClick={() => setOpsOpen(!opsOpen)}
            className={`w-full flex items-center justify-between p-2 rounded text-sm transition-colors cursor-pointer ${
              isOpsActive || opsOpen
                ? 'bg-accent text-accent-foreground'
                : 'text-muted-foreground hover:bg-accent/50'
            }`}
          >
            <span>运维场景</span>
            <svg
              className={`w-3 h-3 transition-transform ${opsOpen ? 'rotate-90' : ''}`}
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>

          {opsOpen && (
            <div className="ml-3 mt-1 space-y-0.5">
              {opsSubItems.map((item) => {
                const isActive = location.pathname === item.path
                return (
                  <Link
                    key={item.path}
                    to={item.path as any}
                    className={`block px-2 py-1.5 rounded text-xs transition-colors cursor-pointer ${
                      isActive
                        ? 'bg-accent text-accent-foreground'
                        : 'text-muted-foreground hover:bg-accent/50 hover:text-foreground'
                    }`}
                  >
                    {item.label}
                  </Link>
                )
              })}
            </div>
          )}
        </div>

        {/* 资料库 - 可展开 */}
        {user?.role === 'admin' && (
        <div className="px-2">
          <button
            onClick={() => setDocsOpen(!docsOpen)}
            className={`w-full flex items-center justify-between p-2 rounded text-sm transition-colors cursor-pointer ${
              isSettingsActive || docsOpen
                ? 'bg-accent text-accent-foreground'
                : 'text-muted-foreground hover:bg-accent/50'
            }`}
          >
            <span>资料库</span>
            <svg
              className={`w-3 h-3 transition-transform ${docsOpen ? 'rotate-90' : ''}`}
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>

          {docsOpen && (
            <div className="ml-3 mt-1 space-y-0.5">
              {docsSubItems.map((item) => {
                const isActive = location.pathname === item.path
                return (
                  <Link
                    key={item.path}
                    to={item.path as any}
                    className={`block px-2 py-1.5 rounded text-xs transition-colors cursor-pointer ${
                      isActive
                        ? 'bg-accent text-accent-foreground'
                        : 'text-muted-foreground hover:bg-accent/50 hover:text-foreground'
                    }`}
                  >
                    {item.label}
                  </Link>
                )
              })}
            </div>
          )}
        </div>
        )}

        {/* 预案管理 - 可展开 */}
        <div className="px-2">
          <button
            onClick={() => setSopOpen(!sopOpen)}
            className={`w-full flex items-center justify-between p-2 rounded text-sm transition-colors cursor-pointer ${
              isSopActive || sopOpen
                ? 'bg-accent text-accent-foreground'
                : 'text-muted-foreground hover:bg-accent/50'
            }`}
          >
            <span>预案管理</span>
            <svg
              className={`w-3 h-3 transition-transform ${sopOpen ? 'rotate-90' : ''}`}
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>

          {sopOpen && (
            <div className="ml-3 mt-1 space-y-0.5">
              {sopSubItems.map((item) => {
                const isActive = (() => {
                  if (item.path === '/sop') return location.pathname === '/sop' || /^\/sop\/\d+$/.test(location.pathname)
                  if (item.path === '/sop/mcp') return location.pathname === '/sop/mcp' || /^\/sop\/mcp\/.+/.test(location.pathname)
                  return location.pathname === item.path
                })()
                return (
                  <Link
                    key={item.path}
                    to={item.path as any}
                    className={`block px-2 py-1.5 rounded text-xs transition-colors cursor-pointer ${
                      isActive
                        ? 'bg-accent text-accent-foreground'
                        : 'text-muted-foreground hover:bg-accent/50 hover:text-foreground'
                    }`}
                  >
                    {item.label}
                  </Link>
                )
              })}
            </div>
          )}
        </div>

        {/* 报表 */}
        <div className="px-2">
          <Link
            to="/reports"
            className={`flex items-center justify-between p-2 rounded text-sm transition-colors cursor-pointer ${
              location.pathname.startsWith('/reports')
                ? 'bg-accent text-accent-foreground'
                : 'text-muted-foreground hover:bg-accent/50'
            }`}
          >
            <span>报表</span>
          </Link>
        </div>

        {/* 系统设置 - 仅管理员可见 */}
        {user?.role === 'admin' && (
        <div className="px-2">
          <button
            onClick={() => setSettingsOpen(!settingsOpen)}
            className={`w-full flex items-center justify-between p-2 rounded text-sm transition-colors cursor-pointer ${
              isSettingsActive || settingsOpen
                ? 'bg-accent text-accent-foreground'
                : 'text-muted-foreground hover:bg-accent/50'
            }`}
          >
            <span>系统设置</span>
            <svg
              className={`w-3 h-3 transition-transform ${settingsOpen ? 'rotate-90' : ''}`}
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>

          {settingsOpen && (
            <div className="ml-3 mt-1 space-y-0.5">
              {settingsSubItems.map((item) => {
                const isActive = location.pathname === item.path
                return (
                  <Link
                    key={item.path}
                    to={item.path as any}
                    className={`block px-2 py-1.5 rounded text-xs transition-colors cursor-pointer ${
                      isActive
                        ? 'bg-accent text-accent-foreground'
                        : 'text-muted-foreground hover:bg-accent/50 hover:text-foreground'
                    }`}
                  >
                    {item.label}
                  </Link>
                )
              })}
            </div>
          )}
        </div>
        )}
      </nav>

      {/* 用户信息 */}
      {user && (
        <button
          onClick={() => navigate({ to: '/profile' })}
          className="p-3 border-t border-border shrink-0 text-left hover:bg-accent/50 transition-colors cursor-pointer w-full"
        >
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary text-sm font-bold flex-shrink-0">
              {user.displayName.charAt(0)}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-medium text-foreground truncate">{user.displayName}</p>
              <p className="text-xs text-muted-foreground">{ROLE_LABELS[user.role] || user.role}{teamNames ? ` · ${teamNames}` : ''}</p>
            </div>
          </div>
        </button>
      )}
    </aside>
  )
}