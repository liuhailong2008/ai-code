import type { UIBlock } from '../../schemas'

interface UIBlockPaneProps {
  blocks: UIBlock[]
}

export function UIBlockPane({ blocks }: UIBlockPaneProps) {
  const sorted = [...blocks].sort((a, b) => a.orderIdx - b.orderIdx)

  return (
    <aside className="w-80 border-l border-border bg-card shrink-0 overflow-auto">
      <div className="p-3 border-b border-border">
        <h3 className="text-sm font-semibold text-foreground">交互面板</h3>
      </div>
      <div className="p-3 space-y-4">
        {sorted.map((block) => (
          <UIBlockRenderer key={block.id} block={block} />
        ))}
      </div>
    </aside>
  )
}

function UIBlockRenderer({ block }: { block: UIBlock }) {
  return (
    <div className="border border-border rounded-lg p-3 bg-card">
      <h4 className="text-xs font-medium text-muted-foreground mb-2 uppercase">
        {block.type}
      </h4>
      <div className="text-sm text-foreground">
        {'type' in block && block.type === 'dashboard' && <DashboardBlock data={block.data} />}
        {'type' in block && block.type === 'plan' && <PlanBlock data={block.data} />}
        {'type' in block && block.type === 'diff' && <p>代码差异查看</p>}
        {'type' in block && block.type === 'topology' && <p>拓扑图</p>}
        {'type' in block && block.type === 'form' && <p>表单</p>}
        {'type' in block && block.type === 'log' && <LogBlock data={block.data} />}
        {'type' in block && block.type === 'approval' && <p>审批卡片</p>}
        {'type' in block && block.type === 'report' && <p>报表下载</p>}
      </div>
    </div>
  )
}

interface DashboardData {
  title: string
  metrics?: { label: string; value: number; unit?: string }[]
  chart?: { type: string; data: number[][] }
}

function DashboardBlock({ data }: { data: DashboardData }) {
  return (
    <div>
      <h4 className="font-medium mb-2">{data.title}</h4>
      <div className="grid grid-cols-2 gap-2 mb-3">
        {data.metrics?.map((m, i) => (
          <div key={i} className="text-center p-2 bg-muted rounded">
            <p className="text-lg font-bold text-primary">{m.value}{m.unit || ''}</p>
            <p className="text-xs text-muted-foreground">{m.label}</p>
          </div>
        ))}
      </div>
      <div className="h-20 bg-muted rounded flex items-center justify-center text-xs text-muted-foreground">
        折线图 ({data.chart?.type})
      </div>
    </div>
  )
}

interface StepData {
  id: string
  title: string
  description: string
  status: string
}

interface PlanData {
  title: string
  steps?: StepData[]
}

function PlanBlock({ data }: { data: PlanData }) {
  return (
    <div>
      <h4 className="font-medium mb-2">{data.title}</h4>
      <div className="space-y-2">
        {data.steps?.map((step) => (
          <div key={step.id} className="flex items-start gap-2 text-xs">
            <span className={`mt-0.5 ${
              step.status === 'completed' ? 'text-green-500' :
              step.status === 'in_progress' ? 'text-blue-500' :
              step.status === 'failed' ? 'text-red-500' : 'text-muted-foreground'
            }`}>
              {step.status === 'completed' ? '✓' :
               step.status === 'in_progress' ? '▶' :
               step.status === 'failed' ? '✗' : '○'}
            </span>
            <div>
              <p className="font-medium">{step.title}</p>
              <p className="text-muted-foreground">{step.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

interface LogEntryData {
  timestamp: string
  level: string
  message: string
}

interface LogData {
  title: string
  logs?: LogEntryData[]
}

function LogBlock({ data }: { data: LogData }) {
  return (
    <div>
      <h4 className="font-medium mb-2">{data.title}</h4>
      <div className="bg-black text-green-400 rounded p-2 font-mono text-xs max-h-48 overflow-auto space-y-1">
        {data.logs?.map((log, i) => (
          <p key={i} className={
            log.level === 'error' ? 'text-red-400' :
            log.level === 'warn' ? 'text-yellow-400' : 'text-green-400'
          }>
            [{log.level.toUpperCase()}] {log.message}
          </p>
        ))}
      </div>
    </div>
  )
}