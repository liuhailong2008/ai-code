import { z } from 'zod'

export const EventParticipantSchema = z.object({
  userId: z.number(),
  userName: z.string(),
  displayName: z.string(),
  userAvatar: z.string(),
  role: z.enum(['owner', 'reviewer', 'approver', 'watcher']),
  joinedAt: z.string(),
})

export const EventSchema = z.object({
  id: z.number(),
  teamId: z.number(),
  title: z.string(),
  description: z.string(),
  status: z.enum(['open', 'in_progress', 'resolved', 'closed']),
  severity: z.enum(['low', 'medium', 'high', 'critical']),
  category: z.string(),
  idcName: z.string(),
  appName: z.string(),
  clusterName: z.string(),
  source: z.string(),
  createdBy: z.string(),
  uniNo: z.string(),
  extTicketId: z.string(),
  metadata: z.string(),
  openedAt: z.string(),
  closedAt: z.string(),
  createdAt: z.string(),
  updatedAt: z.string(),
  participants: z.array(EventParticipantSchema),
})

export type Event = z.infer<typeof EventSchema>
export type EventParticipant = z.infer<typeof EventParticipantSchema>
