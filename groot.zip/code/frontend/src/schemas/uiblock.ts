import { z } from 'zod'

const DashboardBlockDataSchema = z.object({
  title: z.string(),
  metrics: z.array(
    z.object({
      label: z.string(),
      value: z.number(),
      unit: z.string().optional(),
    }),
  ),
  chart: z.object({
    type: z.enum(['line', 'bar', 'area']),
    data: z.array(z.tuple([z.number(), z.number()])),
  }),
})

const PlanBlockDataSchema = z.object({
  title: z.string(),
  steps: z.array(
    z.object({
      id: z.string(),
      title: z.string(),
      description: z.string(),
      status: z.enum(['pending', 'in_progress', 'completed', 'failed']),
      estimatedTime: z.number().optional(),
    }),
  ),
})

const DiffBlockDataSchema = z.object({
  title: z.string(),
  before: z.string(),
  after: z.string(),
  language: z.string(),
})

const TopologyBlockDataSchema = z.object({
  title: z.string(),
  nodes: z.array(
    z.object({
      id: z.string(),
      label: z.string(),
      type: z.string(),
      status: z.enum(['healthy', 'warning', 'error']),
    }),
  ),
  edges: z.array(
    z.object({
      id: z.string(),
      source: z.string(),
      target: z.string(),
      label: z.string().optional(),
    }),
  ),
})

const FormBlockDataSchema = z.object({
  title: z.string(),
  fields: z.array(
    z.object({
      name: z.string(),
      label: z.string(),
      type: z.enum(['text', 'number', 'select', 'textarea']),
      required: z.boolean(),
      options: z.array(z.string()).optional(),
      value: z.any().optional(),
    }),
  ),
})

const LogBlockDataSchema = z.object({
  title: z.string(),
  logs: z.array(
    z.object({
      timestamp: z.string(),
      level: z.enum(['info', 'warn', 'error', 'debug']),
      message: z.string(),
    }),
  ),
})

const ApprovalBlockDataSchema = z.object({
  approvalId: z.string(),
  title: z.string(),
  description: z.string(),
})

const ReportBlockDataSchema = z.object({
  reportId: z.string(),
  title: z.string(),
  type: z.enum(['periodic', 'adhoc']),
  format: z.enum(['pdf', 'csv', 'xlsx']),
})

export const UIBlockSchema = z.discriminatedUnion('type', [
  z.object({
    id: z.string(),
    type: z.literal('dashboard'),
    orderIdx: z.number(),
    data: DashboardBlockDataSchema,
  }),
  z.object({
    id: z.string(),
    type: z.literal('plan'),
    orderIdx: z.number(),
    data: PlanBlockDataSchema,
  }),
  z.object({
    id: z.string(),
    type: z.literal('diff'),
    orderIdx: z.number(),
    data: DiffBlockDataSchema,
  }),
  z.object({
    id: z.string(),
    type: z.literal('topology'),
    orderIdx: z.number(),
    data: TopologyBlockDataSchema,
  }),
  z.object({
    id: z.string(),
    type: z.literal('form'),
    orderIdx: z.number(),
    data: FormBlockDataSchema,
  }),
  z.object({
    id: z.string(),
    type: z.literal('log'),
    orderIdx: z.number(),
    data: LogBlockDataSchema,
  }),
  z.object({
    id: z.string(),
    type: z.literal('approval'),
    orderIdx: z.number(),
    data: ApprovalBlockDataSchema,
  }),
  z.object({
    id: z.string(),
    type: z.literal('report'),
    orderIdx: z.number(),
    data: ReportBlockDataSchema,
  }),
])

export type UIBlock = z.infer<typeof UIBlockSchema>
export type UIBlockType = UIBlock['type']