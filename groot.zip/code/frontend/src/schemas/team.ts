import { z } from 'zod'

export const TeamSchema = z.object({
  id: z.number(),
  code: z.string(),
  name: z.string(),
  description: z.string().nullable(),
  wechatId: z.string().nullable(),
  teamEmail: z.string().nullable(),
  techLeader: z.string().nullable(),
  teamLeader: z.string().nullable(),
  createdBy: z.string(),
  updatedBy: z.string().nullable(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
})

export type Team = z.infer<typeof TeamSchema>

export const TeamCreateSchema = z.object({
  code: z.string().min(1, '团队编码不能为空'),
  name: z.string().min(1, '团队名称不能为空'),
  description: z.string().nullable().optional(),
  wechatId: z.string().nullable().optional(),
  teamEmail: z.string().nullable().optional(),
  techLeader: z.string().nullable().optional(),
  teamLeader: z.string().nullable().optional(),
})

export type TeamCreate = z.infer<typeof TeamCreateSchema>

export const TeamUpdateSchema = TeamCreateSchema.partial()

export type TeamUpdate = z.infer<typeof TeamUpdateSchema>
