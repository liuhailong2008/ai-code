import { z } from 'zod'

export const SopMiddlewareSchema = z.object({
  id: z.number(),
  appName: z.string(),
  appDesc: z.string(),
  primaryPost: z.string(),
  backupPost: z.string(),
  createdBy: z.string(),
  updatedBy: z.string().nullable(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
})

export type SopMiddleware = z.infer<typeof SopMiddlewareSchema>

export const SopMiddlewareCreateSchema = z.object({
  appName: z.string().min(1, '应用名称不能为空'),
  appDesc: z.string().min(1, '应用描述不能为空'),
  primaryPost: z.string().min(1, '主岗不能为空'),
  backupPost: z.string().min(1, '备岗不能为空'),
})

export type SopMiddlewareCreate = z.infer<typeof SopMiddlewareCreateSchema>

export const SopMiddlewareUpdateSchema = SopMiddlewareCreateSchema.partial()

export type SopMiddlewareUpdate = z.infer<typeof SopMiddlewareUpdateSchema>
