import { z } from 'zod'

export const UserPreferencesSchema = z.object({
  theme: z.enum(['shadcn-light', 'shadcn-dark', 'cyberpunk-terminal', 'cyberpunk-neon']),
  notifications: z.boolean(),
  language: z.enum(['zh-CN', 'en-US']),
})

export const UserSchema = z.object({
  id: z.number(),
  username: z.string(),
  mobile: z.string().optional(),
  displayName: z.string(),
  role: z.enum(['admin', 'operator', 'viewer']),
  preferences: UserPreferencesSchema.optional(),
  createdAt: z.string(),
  updatedAt: z.string(),
})

export type User = z.infer<typeof UserSchema>
export type UserPreferences = z.infer<typeof UserPreferencesSchema>
