import { z } from 'zod'

export const ApprovalSchema = z.object({
  id: z.string(),
  eventId: z.string(),
  title: z.string(),
  description: z.string(),
  status: z.enum(['pending', 'approved', 'rejected']),
  requestedBy: z.object({
    id: z.string(),
    name: z.string(),
  }),
  requestedAt: z.string().datetime(),
  reviewedBy: z
    .object({
      id: z.string(),
      name: z.string(),
    })
    .optional(),
  reviewedAt: z.string().datetime().optional(),
  reviewComment: z.string().optional(),
})

export type Approval = z.infer<typeof ApprovalSchema>