import { z } from 'zod'

export const ModelConfigSchema = z.object({
  id: z.number(),
  code: z.string(),
  name: z.string(),
  provider: z.string(),
  baseUrl: z.string(),
  apiKey: z.string(),
  hasApiKey: z.boolean(),
  purpose: z.string(),
  isActive: z.boolean(),
  isEnabled: z.boolean(),
  priority: z.number(),
  contextWindow: z.number(),
  maxTokens: z.number(),
  supportsThinking: z.boolean(),
  supportsVision: z.boolean(),
  supportsTools: z.boolean(),
  supportsJson: z.boolean(),
  temperature: z.number().nullable(),
  topP: z.number().nullable(),
  createdBy: z.string(),
  updatedBy: z.string().nullable(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
})

export type ModelConfig = z.infer<typeof ModelConfigSchema>

export const ModelConfigCreateSchema = z.object({
  code: z.string().min(1, '模型编码不能为空'),
  name: z.string().min(1, '模型名称不能为空'),
  provider: z.string().min(1, '供应商不能为空'),
  baseUrl: z.string().min(1, 'API地址不能为空'),
  apiKey: z.string().min(1, 'API Key不能为空'),
  purpose: z.string().min(1, '用途不能为空'),
  isActive: z.boolean().optional(),
  isEnabled: z.boolean().optional(),
  priority: z.number().optional(),
  contextWindow: z.number().optional(),
  maxTokens: z.number().optional(),
  supportsThinking: z.boolean().optional(),
  supportsVision: z.boolean().optional(),
  supportsTools: z.boolean().optional(),
  supportsJson: z.boolean().optional(),
  temperature: z.number().nullable().optional(),
  topP: z.number().nullable().optional(),
})

export type ModelConfigCreate = z.infer<typeof ModelConfigCreateSchema>

export const ModelConfigUpdateSchema = ModelConfigCreateSchema.partial()

export type ModelConfigUpdate = z.infer<typeof ModelConfigUpdateSchema>
