import { z } from 'zod'

export const ReportSchema = z.object({
  id: z.string(),
  title: z.string(),
  type: z.enum(['periodic', 'adhoc']),
  format: z.enum(['pdf', 'csv', 'xlsx']),
  createdAt: z.string().datetime(),
  createdBy: z.object({
    id: z.string(),
    name: z.string(),
  }),
  downloadUrl: z.string().url(),
  size: z.number(),
})

export type Report = z.infer<typeof ReportSchema>