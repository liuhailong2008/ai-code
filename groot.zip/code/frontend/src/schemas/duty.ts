import { z } from 'zod'

export const DutyScheduleSchema = z.object({
  id: z.number(),
  scheduleDate: z.string(),
  department: z.string(),
  positionName: z.string(),
  primaryUser: z.string(),
  backupUser: z.string(),
  createdBy: z.string(),
  updatedBy: z.string().nullable(),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
})

export type DutySchedule = z.infer<typeof DutyScheduleSchema>

export const DutyScheduleCreateSchema = z.object({
  scheduleDate: z.string().min(1, '日期不能为空'),
  department: z.string().min(1, '部门不能为空'),
  positionName: z.string().min(1, '岗位不能为空'),
  primaryUser: z.string({ required_error: '主岗不能为空' }),
  backupUser: z.string({ required_error: '备岗不能为空' }),
})

export type DutyScheduleCreate = z.infer<typeof DutyScheduleCreateSchema>

export const DutyScheduleUpdateSchema = z.object({
  department: z.string().optional(),
  positionName: z.string().optional(),
  primaryUser: z.string().optional(),
  backupUser: z.string().optional(),
})

export type DutyScheduleUpdate = z.infer<typeof DutyScheduleUpdateSchema>
