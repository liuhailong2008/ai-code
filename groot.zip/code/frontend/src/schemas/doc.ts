import { z } from 'zod'

export const DocSchema = z.object({
  id: z.string(),
  title: z.string(),
  category: z.string(),
  content: z.string(),
  tags: z.array(z.string()),
  createdAt: z.string().datetime(),
  updatedAt: z.string().datetime(),
  createdBy: z.object({
    id: z.string(),
    name: z.string(),
  }),
})

export type Doc = z.infer<typeof DocSchema>