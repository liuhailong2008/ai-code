import { z } from 'zod'

export const MessageSchema = z.object({
  id: z.number(),
  eventId: z.number(),
  actorId: z.string(),
  role: z.enum(['user', 'agent', 'system']),
  content: z.string(),
  createdAt: z.string(),
  mentions: z.array(z.string()).nullish().transform((v) => v ?? []),
})

export type Message = z.infer<typeof MessageSchema>
