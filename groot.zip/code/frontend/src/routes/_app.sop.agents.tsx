import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/_app/sop/agents')({
  component: AgentsPage,
})

function AgentsPage() {
  return (
    <div className="flex-1 overflow-auto p-6">
      <h2 className="text-xl font-bold text-foreground">智能体</h2>
      <p className="text-sm text-muted-foreground mt-2">智能体管理功能开发中...</p>
    </div>
  )
}
