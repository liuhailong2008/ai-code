import { createFileRoute, Navigate } from '@tanstack/react-router'

export const Route = createFileRoute('/_app/sop/skills')({
  component: SkillsRedirect,
})

function SkillsRedirect() {
  return <Navigate to="/skills" />
}
