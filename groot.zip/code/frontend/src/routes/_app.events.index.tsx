import { createFileRoute, Link } from '@tanstack/react-router'
import { useQuery } from '@tanstack/react-query'
import { useMemo } from 'react'
import { listEvents, listMyUnread } from '../api/events'

function formatTime(t: string): string {
  if (!t) return ''
  const d = new Date(t)
  if (isNaN(d.getTime())) return t
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  const h = String(d.getHours()).padStart(2, '0')
  const min = String(d.getMinutes()).padStart(2, '0')
  const s = String(d.getSeconds()).padStart(2, '0')
  return `${y}年${m}月${day}日 ${h}:${min}:${s}`
}

function formatDuration(since: string, until?: string): string {
  if (!since) return ''
  const start = new Date(since)
  if (isNaN(start.getTime())) return ''
  const end = until ? new Date(until) : new Date()
  if (isNaN(end.getTime())) return ''
  const diffMs = end.getTime() - start.getTime()
  if (diffMs < 0) return ''
  const days = Math.floor(diffMs / 86400000)
  const hours = Math.floor((diffMs % 86400000) / 3600000)
  const minutes = Math.floor((diffMs % 3600000) / 60000)
  let result = ''
  if (days > 0) result += `${days}天`
  if (hours > 0) result += `${hours}时`
  result += `${minutes}分`
  return result
}

export const Route = createFileRoute('/_app/events/')({
  component: EventsIndexPage,
})

function EventsIndexPage() {
  const { data: events, isLoading, error } = useQuery({
    queryKey: ['events'],
    queryFn: () => listEvents(),
  })

  const { data: unreadList } = useQuery({
    queryKey: ['my-unread'],
    queryFn: () => listMyUnread(),
    refetchInterval: 15 * 1000,
  })

  const unreadMap = useMemo(() => {
    const m: Record<number, { total: number; mention: number }> = {}
    unreadList?.forEach((u) => { m[u.eventId] = { total: u.unreadTotal, mention: u.unreadMention } })
    return m
  }, [unreadList])

  return (
    <main className="flex-1 overflow-auto p-6">
      <h2 className="text-xl font-bold mb-4 text-foreground">处理中事件</h2>

      {isLoading && <p className="text-muted-foreground">加载中...</p>}

      {error && (
        <div className="p-4 border border-destructive rounded bg-destructive/10 text-destructive">
          加载失败: {(error as Error).message}
        </div>
      )}

      {events && events.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 gap-3">
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
            <svg className="w-8 h-8 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <p className="text-muted-foreground text-sm">暂无处理中的事件</p>
        </div>
      )}

      <div className="space-y-3">
        {events?.map((event) => (
          <Link
            key={event.id}
            to="/events/$id"
            params={{ id: String(event.id) }}
            className="p-4 border border-border rounded bg-card hover:bg-accent/50 cursor-pointer transition-colors block"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-foreground flex items-center gap-2">
                {event.title}
                {unreadMap[event.id]?.mention > 0 && (
                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-white bg-amber-500 px-1.5 py-0.5 rounded-full" title={`${unreadMap[event.id].mention} 条未读 @`}>
                    @ {unreadMap[event.id].mention}
                  </span>
                )}
                {unreadMap[event.id] && unreadMap[event.id].total > 0 && unreadMap[event.id].mention === 0 && (
                  <span className="inline-flex items-center text-[10px] font-bold text-white bg-blue-500 px-1.5 py-0.5 rounded-full" title={`${unreadMap[event.id].total} 条未读消息`}>
                    {unreadMap[event.id].total}
                  </span>
                )}
              </h3>
              <span
                className={`text-xs px-2 py-1 rounded ${
                  event.severity === 'critical' || event.severity === 'high'
                    ? 'bg-destructive/20 text-destructive'
                    : event.severity === 'medium'
                      ? 'bg-yellow-500/20 text-yellow-500'
                      : 'bg-muted text-muted-foreground'
                }`}
              >
                {event.severity}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {event.category} · {event.participants.length} 人参与
              {event.openedAt && (
                event.closedAt ? (
                  <>
                    {' '}· 触发时间：{formatTime(event.openedAt)}，完成时间：{formatTime(event.closedAt)}
                    <span className="text-orange-500"> 用时：{formatDuration(event.openedAt, event.closedAt)}</span>
                  </>
                ) : (
                  <>
                    {' '}· 触发时间：{formatTime(event.openedAt)}，已持续：
                    <span className="text-orange-500">{formatDuration(event.openedAt)}</span>
                  </>
                )
              )}
            </p>
          </Link>
        ))}
      </div>
    </main>
  )
}
