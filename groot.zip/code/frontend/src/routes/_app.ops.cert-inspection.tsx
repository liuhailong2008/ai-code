import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/_app/ops/cert-inspection')({
  component: CertInspectionPage,
})

function CertInspectionPage() {
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold text-foreground">证书巡检</h2>
      <p className="text-muted-foreground mt-4">证书巡检列表加载中...</p>
    </div>
  )
}
