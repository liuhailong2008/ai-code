import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState, useMemo, useEffect, useRef } from 'react'
import { getEvent, getMessages, getUIBlocks, getEventStaffing, markMessagesRead } from '../api/events'
import { listUsers } from '../api/members'
import { useAuthStore } from '../stores/auth'
import { ChatInput } from '../components/chat/ChatInput'
import { StreamingMessage } from '../components/chat/StreamingMessage'
import { UIBlockPane } from '../components/layout/UIBlockPane'
import type { Message, UIBlock } from '../schemas'

const AVATAR_COLORS = [
  'bg-blue-500', 'bg-green-500', 'bg-purple-500', 'bg-orange-500',
  'bg-pink-500', 'bg-teal-500', 'bg-indigo-500', 'bg-rose-500',
]

function formatTime(t: string): string {
  if (!t) return ''
  const d = new Date(t)
  if (isNaN(d.getTime())) return t
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  const h = String(d.getHours()).padStart(2, '0')
  const min = String(d.getMinutes()).padStart(2, '0')
  const s = String(d.getSeconds()).padStart(2, '0')
  return `${y}年${m}月${day}日 ${h}:${min}:${s}`
}

function formatDuration(since: string, until?: string): string {
  if (!since) return ''
  const start = new Date(since)
  if (isNaN(start.getTime())) return ''
  const end = until ? new Date(until) : new Date()
  if (isNaN(end.getTime())) return ''
  const diffMs = end.getTime() - start.getTime()
  if (diffMs < 0) return ''
  const days = Math.floor(diffMs / 86400000)
  const hours = Math.floor((diffMs % 86400000) / 3600000)
  const minutes = Math.floor((diffMs % 3600000) / 60000)
  let result = ''
  if (days > 0) result += `${days}天`
  if (hours > 0) result += `${hours}时`
  result += `${minutes}分`
  return result
}

export const Route = createFileRoute('/_app/events/$id')({
  component: EventDetailPage,
})

function EventDetailPage() {
  const { id } = Route.useParams()
  const eventId = Number(id)
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const currentUser = useAuthStore((s) => s.user)
  const [showPanel, setShowPanel] = useState(false)
  const [showStaffing, setShowStaffing] = useState(false)
  const [showTimeline, setShowTimeline] = useState(false)
  const [streamActive, setStreamActive] = useState(false)
  const [streamKey, setStreamKey] = useState(0)
  const [streamModelCode, setStreamModelCode] = useState<string | null>(null)
  const chatContainerRef = useRef<HTMLDivElement>(null)

  const { data: event, isLoading: eventLoading } = useQuery({
    queryKey: ['event', eventId],
    queryFn: () => getEvent(eventId),
  })

  const { data: messages, isLoading: messagesLoading } = useQuery({
    queryKey: ['messages', eventId],
    queryFn: () => getMessages(eventId),
  })

  const { data: uiblocks } = useQuery({
    queryKey: ['uiblocks', eventId],
    queryFn: () => getUIBlocks(eventId),
  })

  const { data: staffing } = useQuery({
    queryKey: ['staffing', eventId],
    queryFn: () => getEventStaffing(eventId),
    enabled: showStaffing,
  })

  const { data: users } = useQuery({
    queryKey: ['users-for-display'],
    queryFn: () => listUsers(),
    staleTime: 5 * 60 * 1000,
  })

  const userMap = useMemo(() => {
    const m: Record<string, string> = {}
    users?.forEach((u) => { m[u.username] = u.displayName || u.username })
    return m
  }, [users])

  // 自动上报已读位点：消息加载/变化时把当前用户在该事件下的"最后已读"推到最新一条
  const markReadMutation = useMutation({
    mutationFn: (lastReadMessageId: number) => markMessagesRead(eventId, lastReadMessageId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['unread', eventId] })
      queryClient.invalidateQueries({ queryKey: ['my-unread'] })
    },
  })
  const lastMarkedRef = useRef<number>(0)
  useEffect(() => {
    if (!currentUser?.username || !messages || messages.length === 0) return
    const lastId = messages[messages.length - 1].id
    if (lastId > lastMarkedRef.current) {
      lastMarkedRef.current = lastId
      markReadMutation.mutate(lastId)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messages, currentUser?.username])

  // 新消息到来时自动滚动到底部
  useEffect(() => {
    if (!chatContainerRef.current || !messages || messages.length === 0) return
    const el = chatContainerRef.current
    el.scrollTo({ top: el.scrollHeight, behavior: 'instant' })
  }, [messages])

  // 监听 @groot 事件，启动流式回复
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent<{ eventId: number; modelCode?: string }>).detail
      if (detail?.eventId === eventId) {
        setStreamModelCode(detail.modelCode ?? null)
        setStreamActive(true)
        setStreamKey((k) => k + 1)
      }
    }
    window.addEventListener('groot-stream-start', handler)
    return () => window.removeEventListener('groot-stream-start', handler)
  }, [eventId])

  const handleStreamDone = () => {
    setStreamActive(false)
    queryClient.invalidateQueries({ queryKey: ['messages', eventId] })
  }

  if (eventLoading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-background">
        <p className="text-muted-foreground animate-pulse">加载中...</p>
      </div>
    )
  }

  if (!event) {
    return (
      <div className="flex-1 flex items-center justify-center bg-background">
        <p className="text-muted-foreground">事件未找到</p>
      </div>
    )
  }

  return (
    <div className="flex-1 flex flex-col bg-background overflow-hidden">
      {/* 顶部标题栏 */}
      <header className="h-12 shrink-0 border-b border-border flex items-center px-4 gap-3 bg-card">
        <button
          onClick={() => navigate({ to: '/events' })}
          className="text-muted-foreground hover:text-foreground transition-colors shrink-0"
        >
          ← 返回
        </button>
        <div className="flex-1 min-w-0">
          <h1 className="text-sm font-semibold text-foreground truncate">{event.title}</h1>
          <div className="text-xs text-muted-foreground flex items-center gap-1.5">
            <span>
              {[event.idcName, event.appName, event.clusterName, event.uniNo]
                .filter(Boolean)
                .join(' · ') || event.category}
            </span>
            {event.participants.length > 0 && (
              <>
                <span>·</span>
                <span className="inline-flex items-center -space-x-1.5">
                  {event.participants.map((p, i) => (
                    <span key={p.userId} className="relative group">
                      <span
                        className={`inline-flex items-center justify-center w-5 h-5 rounded-full text-[10px] font-bold text-white border border-white ${AVATAR_COLORS[i % AVATAR_COLORS.length]}`}
                      >
                        {(p.displayName || p.userName).charAt(0)}
                      </span>
                      <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1.5 px-2.5 py-1 bg-popover text-popover-foreground border border-border rounded shadow-lg text-xs opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity duration-150 z-50 whitespace-nowrap">
                        {p.displayName || p.userName}
                      </div>
                    </span>
                  ))}
                </span>
                <span>{event.participants.length}人</span>
              </>
            )}
          </div>
        </div>
        <div className="shrink-0 flex flex-col items-end gap-0.5 self-end mb-[2.5px]">
          {event.openedAt && (
            <div className="text-right text-[11px] leading-tight whitespace-nowrap text-muted-foreground">
              {event.closedAt ? (
                <>
                  <span>触发时间：{formatTime(event.openedAt)}，完成时间：{formatTime(event.closedAt)}</span>
                  <span className="text-orange-500"> 用时：{formatDuration(event.openedAt, event.closedAt)}</span>
                </>
              ) : (
                <>
                  <span>触发时间：{formatTime(event.openedAt)}，已持续：</span>
                  <span className="text-orange-500">{formatDuration(event.openedAt)}</span>
                </>
              )}
            </div>
          )}
        </div>
        {uiblocks && uiblocks.length > 0 && (
          <button
            onClick={() => setShowPanel(!showPanel)}
            className={`text-xs px-2 py-0.5 rounded border shrink-0 transition-colors ${
              showPanel
                ? 'bg-primary text-primary-foreground border-primary'
                : 'bg-card text-muted-foreground border-border hover:text-foreground'
            }`}
          >
            {showPanel ? '收起面板' : '工具面板'}
          </button>
        )}
        <button
          onClick={() => setShowStaffing(!showStaffing)}
          className={`text-xs px-2 py-0.5 rounded border shrink-0 transition-colors ${
            showStaffing
              ? 'bg-primary text-primary-foreground border-primary'
              : 'bg-card text-muted-foreground border-border hover:text-foreground'
          }`}
        >
          人员
        </button>
        <button
          onClick={() => setShowTimeline(!showTimeline)}
          className={`text-xs px-2 py-0.5 rounded border shrink-0 transition-colors ${
            showTimeline
              ? 'bg-primary text-primary-foreground border-primary'
              : 'bg-card text-muted-foreground border-border hover:text-foreground'
          }`}
        >
          时间线
        </button>
      </header>

      {/* 聊天区域 */}
      <div className="flex-1 flex overflow-hidden min-h-0">
        <main className="flex-1 flex flex-col overflow-hidden min-h-0 min-w-0">
          {/* 消息列表 */}
          <div ref={chatContainerRef} className="flex-1 overflow-y-auto min-h-0">
            {messagesLoading ? (
              <div className="flex items-center justify-center h-full">
                <p className="text-muted-foreground animate-pulse">加载消息中...</p>
              </div>
            ) : messages && messages.length > 0 ? (
              <>
                <ChatMessages messages={messages} userMap={userMap} currentUser={currentUser?.username || ''} />
                {streamActive && (
                  <div className="max-w-[900px] mx-auto px-4">
                    <StreamingMessage
                      key={streamKey}
                      eventId={eventId}
                      enabled={streamActive}
                      onDone={handleStreamDone}
                      modelCode={streamModelCode}
                    />
                  </div>
                )}
              </>
            ) : streamActive ? (
              <div className="max-w-[900px] mx-auto px-4 py-6">
                <StreamingMessage
                  key={streamKey}
                  eventId={eventId}
                  enabled={streamActive}
                  onDone={handleStreamDone}
                  modelCode={streamModelCode}
                />
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full gap-4">
                <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
                  <svg
                    className="w-8 h-8 text-muted-foreground"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"
                    />
                  </svg>
                </div>
                <div className="text-center">
                  <p className="text-sm font-medium text-foreground mb-1">
                    运维智能体就绪
                  </p>
                  <p className="text-sm text-muted-foreground">
                    描述你的运维需求，开始对话
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* 底部输入框 */}
          <div className="shrink-0 border-t border-border bg-card">
            <div className="max-w-[900px] mx-auto px-4 py-3">
              <ChatInput eventId={eventId} />
            </div>
          </div>
        </main>

        {/* 右侧工具面板 */}
        {showPanel && uiblocks && (
          <div className="w-80 border-l border-border shrink-0 overflow-hidden">
            <UIBlockPane blocks={uiblocks as UIBlock[]} />
          </div>
        )}

        {/* 右侧人员面板 */}
        {showStaffing && (
          <StaffingPane staffing={staffing} appName={event.appName} />
        )}

        {/* 右侧时间线面板 */}
        {showTimeline && (
          <TimelinePane event={event} messages={messages} userMap={userMap} />
        )}
      </div>
    </div>
  )
}

function StaffingPane({ staffing, appName }: { staffing?: import('../api/events').EventStaffing; appName: string }) {
  const insertMention = (username: string) => {
    if (!username) return
    window.dispatchEvent(new CustomEvent('chat-insert-text', { detail: { text: `@${username}` } }))
  }

  const NameButton = ({ user }: { user: { username: string; displayName: string } }) => (
    <button
      onClick={() => insertMention(user.username)}
      className="font-medium text-foreground hover:text-primary transition-colors cursor-pointer"
      title={`点击 @${user.username}`}
    >
      {user.displayName || user.username}
    </button>
  )

  return (
    <div className="w-80 border-l border-border shrink-0 overflow-auto bg-card">
      <div className="p-4 border-b border-border">
        <h2 className="text-sm font-bold text-foreground">人员信息</h2>
      </div>

      {!staffing ? (
        <div className="p-4 text-sm text-muted-foreground">加载中...</div>
      ) : (
        <div className="p-4 space-y-5 text-sm">
          {/* 组件主备岗 */}
          <section>
            <h3 className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wider">
              组件负责人
            </h3>
            {staffing.hasMiddleware ? (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">{staffing.appName}主岗</span>
                  <NameButton user={staffing.primaryPost} />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">{staffing.appName}备岗</span>
                  <NameButton user={staffing.backupPost} />
                </div>
              </div>
            ) : (
              <div className="text-xs text-muted-foreground">
                {appName ? `未在「组件设置」中找到 ${appName}` : '该事件无关联组件'}
              </div>
            )}
          </section>

          {/* 今日值班 */}
          <section>
            <h3 className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wider">
              今日值班 {staffing.dutyDate && `(${staffing.dutyDate})`}
            </h3>
            {staffing.hasDuty ? (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">主岗</span>
                  <NameButton user={staffing.dutyPrimaryUser} />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">备岗</span>
                  <NameButton user={staffing.dutyBackupUser} />
                </div>
              </div>
            ) : (
              <div className="text-xs text-muted-foreground">今日无值班安排</div>
            )}
          </section>
        </div>
      )}
    </div>
  )
}

// ====== 时间线面板 ======

interface TimelineEntry {
  type: 'event_created' | 'message' | 'status_change' | 'event_closed'
  time: string
  actor?: string
  content: string
  role?: string
}

function TimelinePane({
  event,
  messages,
  userMap,
}: {
  event: any
  messages?: any[]
  userMap: Record<string, string>
}) {
  const entries = useMemo<TimelineEntry[]>(() => {
    const list: TimelineEntry[] = []

    // 事件创建
    list.push({
      type: 'event_created',
      time: event.createdAt || event.openedAt,
      actor: event.createdBy,
      content: `事件创建: ${event.title}`,
    })

    // 事件关闭
    if (event.closedAt) {
      list.push({
        type: 'event_closed',
        time: event.closedAt,
        content: '事件已关闭',
      })
    }

    list.sort((a, b) => new Date(a.time).getTime() - new Date(b.time).getTime())
    return list
  }, [event, messages, userMap])

  const iconMap: Record<string, { bg: string }> = {
    event_created: { bg: 'bg-blue-500' },
    message: { bg: 'bg-muted-foreground/30' },
    status_change: { bg: 'bg-amber-500' },
    event_closed: { bg: 'bg-green-500' },
  }
  const getIconBg = (type: string) => iconMap[type]?.bg ?? 'bg-muted-foreground/30'

  return (
    <div className="w-80 border-l border-border shrink-0 overflow-auto bg-card flex flex-col">
      <div className="p-4 border-b border-border shrink-0">
        <h2 className="text-sm font-bold text-foreground">时间线</h2>
      </div>
      <div className="flex-1 overflow-auto p-4">
        {entries.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">暂无活动</p>
        ) : (
          <div className="relative">
            {/* 竖线 */}
            <div className="absolute left-[7px] top-1.5 bottom-1.5 w-px bg-border" />
            <div className="space-y-5">
              {entries.map((entry, i) => {
                const bg = getIconBg(entry.type)
                const isUserMsg = entry.type === 'message' && entry.role === 'user'
                const isAssistantMsg = entry.type === 'message' && entry.role === 'assistant'
                const isEventCreated = entry.type === 'event_created'
                const isEventClosed = entry.type === 'event_closed'

                return (
                  <div key={i} className="relative pl-6">
                    {/* 圆点 */}
                    <div
                      className={`absolute left-[4.5px] top-1.5 w-1.5 h-1.5 rounded-full ${bg}`}
                    />

                    {/* 时间 */}
                    <div className="text-[10px] text-muted-foreground/60 mb-0.5">
                      {formatTime(entry.time)}
                    </div>

                    {/* 内容 */}
                    <div
                      className={`text-xs leading-relaxed ${
                        isEventCreated
                          ? 'text-blue-600 font-medium'
                          : isEventClosed
                            ? 'text-green-600 font-medium'
                            : 'text-foreground/85'
                      }`}
                    >
                      {isUserMsg || isAssistantMsg ? (
                        <>
                          <span className="font-medium text-foreground">{entry.actor}</span>
                          {isUserMsg && (
                            <span className="ml-1 text-[10px] px-1.5 py-px rounded bg-blue-100 text-blue-700">
                              用户
                            </span>
                          )}
                          {isAssistantMsg && (
                            <span className="ml-1 text-[10px] px-1.5 py-px rounded bg-purple-100 text-purple-700">
                              AI
                            </span>
                          )}
                          <span className="ml-1 text-muted-foreground/70">:</span>
                          <div className="mt-0.5 text-muted-foreground/70 line-clamp-3">
                            {entry.content}
                          </div>
                        </>
                      ) : (
                        <span>{entry.content}</span>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function ChatMessages({ messages, userMap, currentUser }: { messages: Message[]; userMap: Record<string, string>; currentUser: string }) {
  return (
    <div className="max-w-[900px] mx-auto px-4 py-6 space-y-6">
      {messages.map((message) => (
        <ChatBubble key={message.id} message={message} userMap={userMap} currentUser={currentUser} />
      ))}
    </div>
  )
}

// 把消息内容中的 @username 解析为高亮片段
function renderContentWithMentions(
  content: string,
  userMap: Record<string, string>,
  currentUser: string,
) {
  const parts: Array<string | { user: string }> = []
  const pattern = /@([A-Za-z0-9_.\-]+)/g
  let lastIndex = 0
  let m: RegExpExecArray | null
  while ((m = pattern.exec(content)) !== null) {
    if (m.index > lastIndex) parts.push(content.slice(lastIndex, m.index))
    parts.push({ user: m[1] })
    lastIndex = m.index + m[0].length
  }
  if (lastIndex < content.length) parts.push(content.slice(lastIndex))

  return parts.map((p, i) => {
    if (typeof p === 'string') return <span key={i}>{p}</span>
    const isMe = p.user === currentUser
    const isGroot = p.user === 'groot'
    const display = userMap[p.user] || p.user
    return (
      <span
        key={i}
        className={`font-medium ${
          isMe
            ? 'text-amber-600 dark:text-amber-300'
            : isGroot
              ? 'text-emerald-600 dark:text-emerald-300'
              : 'text-blue-600 dark:text-blue-300'
        }`}
        title={`@${p.user}`}
      >
        @{display}
      </span>
    )
  })
}

function ChatBubble({ message, userMap, currentUser }: { message: Message; userMap: Record<string, string>; currentUser: string }) {
  const isUser = message.role === 'user' && message.actorId === currentUser
  const isSystem = message.role === 'system'
  const displayName = userMap[message.actorId] || message.actorId || '未知'
  const isGroot = message.actorId === 'groot'
  const mentionedMe = !!currentUser && (message.mentions || []).includes(currentUser)

  if (isSystem) {
    return (
      <div className="flex justify-center">
        <span className="text-xs text-muted-foreground bg-muted/50 px-3 py-1 rounded-full">
          {message.content}
        </span>
      </div>
    )
  }

  return (
    <div className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''}`}>
      {/* 头像 */}
      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
        isGroot ? 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400' : 'bg-primary/20 text-primary'
      }`}>
        {displayName?.charAt(0) || '?'}
      </div>

      {/* 气泡 */}
      <div className={`flex flex-col gap-1 max-w-[75%] ${isUser ? 'items-end' : ''}`}>
        {/* 发送者名称 */}
        <span className="text-xs text-muted-foreground px-1 flex items-center gap-1.5">
          {displayName}
          {isGroot && (
            <span className="text-[10px] text-emerald-500 border border-emerald-500/30 rounded px-1 py-px">
              AI 助手
            </span>
          )}
          {mentionedMe && (
            <span className="text-[10px] font-semibold text-amber-600 dark:text-amber-300 bg-amber-400/20 border border-amber-400/40 rounded px-1.5 py-px">
              @ 提到了你
            </span>
          )}
        </span>

        {/* 消息内容 */}
        <div
          className={`relative rounded-2xl px-4 py-2.5 text-sm leading-relaxed whitespace-pre-wrap ${
            isUser
              ? 'bg-emerald-50 text-emerald-950 rounded-tr-sm dark:bg-emerald-800/30 dark:text-emerald-50'
              : 'bg-secondary text-secondary-foreground rounded-tl-sm'
          } ${
            mentionedMe
              ? 'ring-2 ring-amber-400/70 shadow-[0_0_0_4px_rgba(251,191,36,0.15)]'
              : ''
          }`}
        >
          {mentionedMe && (
            <span className="absolute -top-2 -left-2 inline-flex items-center justify-center w-5 h-5 rounded-full bg-amber-400 text-[10px] font-bold text-white shadow">
              @
            </span>
          )}
          {renderContentWithMentions(message.content, userMap, currentUser)}
        </div>

        {/* 时间 */}
        <span className="text-[10px] text-muted-foreground/60 px-1">
          {new Date(message.createdAt).toLocaleTimeString('zh-CN', {
            hour: '2-digit',
            minute: '2-digit',
          })}
        </span>
      </div>
    </div>
  )
}
