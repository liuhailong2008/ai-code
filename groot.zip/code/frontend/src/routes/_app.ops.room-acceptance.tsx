import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { LedgerTab } from '../components/room-acceptance/LedgerTab'
import { StandardsTab } from '../components/room-acceptance/StandardsTab'

export const Route = createFileRoute('/_app/ops/room-acceptance')({
  component: RoomAcceptancePage,
})

const TABS = [
  { key: 'ledger', label: '服务台账' },
  { key: 'standards', label: '验收标准' },
  { key: 'execution', label: '验收执行' },
  { key: 'history', label: '验收历史' },
]

// 各 TAB 对应的数据查询 key：切换或刷新时据此触发重新加载
const TAB_QUERY_KEYS: Record<string, readonly unknown[]> = {
  ledger: ['ruok'],
  standards: ['ruok', 'standards'],
  execution: [],
  history: [],
}

function RoomAcceptancePage() {
  const [active, setActive] = useState('ledger')
  const queryClient = useQueryClient()

  const refresh = (key: string) => {
    const queryKey = TAB_QUERY_KEYS[key]
    if (queryKey && queryKey.length > 0) {
      queryClient.invalidateQueries({ queryKey })
    }
  }

  const handleSelect = (key: string) => {
    setActive(key)
    refresh(key)
  }

  return (
    <div className="flex flex-col h-full">
      <div className="px-6 pt-4 pb-0 border-b border-border shrink-0">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-bold text-foreground">机房验收</h2>
          <button
            onClick={() => refresh(active)}
            className="px-3 py-1.5 text-sm border border-border rounded text-foreground hover:bg-accent cursor-pointer"
          >
            刷新
          </button>
        </div>
        <div className="flex items-center gap-1 mt-3">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => handleSelect(t.key)}
              className={`px-4 py-2 text-sm rounded-t border-b-2 transition-colors cursor-pointer ${
                active === t.key
                  ? 'border-primary text-foreground font-medium'
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-hidden">
        {active === 'ledger' && <LedgerTab />}
        {active === 'standards' && <StandardsTab />}
        {(active === 'execution' || active === 'history') && (
          <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
            {active === 'execution' ? '验收执行' : '验收历史'}功能开发中...
          </div>
        )}
      </div>
    </div>
  )
}
