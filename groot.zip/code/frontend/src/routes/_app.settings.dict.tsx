import { createFileRoute } from '@tanstack/react-router'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState, type FormEvent } from 'react'
import { listDicts, createDict, updateDict, deleteDict, type SysDict } from '../api/dict'

export const Route = createFileRoute('/_app/settings/dict')({
  component: DictSettingsPage,
})

function DictSettingsPage() {
  const queryClient = useQueryClient()
  const [editing, setEditing] = useState<SysDict | null>(null)
  const [creating, setCreating] = useState(false)

  const { data: dicts, isLoading } = useQuery({
    queryKey: ['dicts'],
    queryFn: listDicts,
  })

  const createMutation = useMutation({
    mutationFn: createDict,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dicts'] })
      setCreating(false)
    },
  })
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Record<string, unknown> }) => updateDict(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dicts'] })
      setEditing(null)
    },
  })
  const deleteMutation = useMutation({
    mutationFn: deleteDict,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['dicts'] }),
  })

  const list = dicts ?? []
  const roots = list.filter((d) => d.parentId === 0)
  const valueById = new Map(list.map((d) => [d.id, d.dictValue]))

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="px-4 py-3 border-b border-border flex items-center justify-between shrink-0">
        <h3 className="text-sm font-semibold text-foreground">
          数据字典
          {!isLoading && <span className="text-xs font-normal text-muted-foreground ml-2">共 {list.length} 条</span>}
        </h3>
        <button
          onClick={() => setCreating(true)}
          className="px-3 py-1.5 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90 cursor-pointer"
        >
          + 新增
        </button>
      </div>

      <div className="flex-1 overflow-auto">
        <table className="w-full text-sm">
          <thead className="sticky top-0 bg-muted/50">
            <tr>
              <th className="text-left px-3 py-2 font-medium text-foreground border-b border-border whitespace-nowrap">#</th>
              <th className="text-left px-3 py-2 font-medium text-foreground border-b border-border whitespace-nowrap">父级</th>
              <th className="text-left px-3 py-2 font-medium text-foreground border-b border-border whitespace-nowrap">键</th>
              <th className="text-left px-3 py-2 font-medium text-foreground border-b border-border whitespace-nowrap">值</th>
              <th className="text-left px-3 py-2 font-medium text-foreground border-b border-border whitespace-nowrap">排序</th>
              <th className="text-left px-3 py-2 font-medium text-foreground border-b border-border whitespace-nowrap">操作</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={6} className="px-3 py-8 text-center text-muted-foreground">加载中...</td></tr>
            ) : list.length === 0 ? (
              <tr><td colSpan={6} className="px-3 py-8 text-center text-muted-foreground">暂无数据</td></tr>
            ) : (
              list.map((d, idx) => (
                <tr key={d.id} className="border-b border-border/50 hover:bg-accent/30 transition-colors">
                  <td className="px-3 py-2 text-muted-foreground">{idx + 1}</td>
                  <td className="px-3 py-2 text-foreground">{d.parentId === 0 ? '根' : (valueById.get(d.parentId) ?? d.parentId)}</td>
                  <td className="px-3 py-2 text-foreground max-w-[200px] truncate" title={d.dictKey}>{d.dictKey}</td>
                  <td className="px-3 py-2 text-foreground max-w-[240px] truncate" title={d.dictValue}>{d.dictValue}</td>
                  <td className="px-3 py-2 text-foreground">{d.dictSn}</td>
                  <td className="px-3 py-2 whitespace-nowrap">
                    <button onClick={() => setEditing(d)} className="text-xs text-primary hover:underline mr-3 cursor-pointer">编辑</button>
                    <button
                      onClick={() => { if (confirm('确认删除该字典项？')) deleteMutation.mutate(d.id) }}
                      className="text-xs text-destructive hover:underline cursor-pointer"
                    >
                      删除
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {(creating || editing) && (
        <DictFormModal
          title={editing ? '编辑字典项' : '新增字典项'}
          roots={roots}
          initial={editing ?? null}
          saving={createMutation.isPending || updateMutation.isPending}
          onSave={(data) => {
            if (editing) updateMutation.mutate({ id: editing.id, data })
            else createMutation.mutate(data)
          }}
          onCancel={() => { setCreating(false); setEditing(null) }}
        />
      )}
    </div>
  )
}

interface DictFormModalProps {
  title: string
  roots: SysDict[]
  initial: SysDict | null
  saving: boolean
  onSave: (data: Record<string, unknown>) => void
  onCancel: () => void
}

function DictFormModal({ title, roots, initial, saving, onSave, onCancel }: DictFormModalProps) {
  const [values, setValues] = useState<Record<string, string>>({
    parentId: initial ? String(initial.parentId) : '',
    dictKey: initial?.dictKey ?? '',
    dictValue: initial?.dictValue ?? '',
    dictSn: initial ? String(initial.dictSn) : '0',
  })

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    const parentId = values.parentId === '' ? 0 : Number(values.parentId)
    const dictSn = values.dictSn.trim() === '' ? 0 : Number(values.dictSn)
    onSave({ parentId, dictKey: values.dictKey.trim(), dictValue: values.dictValue.trim(), dictSn })
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-card border border-border rounded-lg shadow-lg w-[480px] flex flex-col">
        <div className="p-4 border-b border-border flex items-center justify-between">
          <h3 className="text-base font-semibold text-foreground">{title}</h3>
          <button onClick={onCancel} className="text-muted-foreground hover:text-foreground text-lg leading-none cursor-pointer">&times;</button>
        </div>
        <form onSubmit={handleSubmit} className="p-4 space-y-3">
          <Field label="父级">
            <select
              value={values.parentId}
              onChange={(e) => setValues({ ...values, parentId: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="">根节点</option>
              {roots.map((r) => (
                <option key={r.id} value={r.id}>{r.dictValue}</option>
              ))}
            </select>
          </Field>
          <Field label="键" required>
            <input
              type="text"
              value={values.dictKey}
              onChange={(e) => setValues({ ...values, dictKey: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              required
            />
          </Field>
          <Field label="值" required>
            <input
              type="text"
              value={values.dictValue}
              onChange={(e) => setValues({ ...values, dictValue: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              required
            />
          </Field>
          <Field label="排序">
            <input
              type="number"
              value={values.dictSn}
              onChange={(e) => setValues({ ...values, dictSn: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </Field>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onCancel} className="px-4 py-2 text-sm border border-border rounded text-foreground hover:bg-accent cursor-pointer">取消</button>
            <button type="submit" disabled={saving} className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90 disabled:opacity-50 cursor-pointer">
              {saving ? '保存中...' : '保存'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-xs font-medium text-muted-foreground">
        {label}
        {required && <span className="text-destructive ml-0.5">*</span>}
      </label>
      {children}
    </div>
  )
}
