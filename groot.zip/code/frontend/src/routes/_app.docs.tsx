import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/_app/docs')({
  component: DocsPage,
})

function DocsPage() {
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold text-foreground">资料库</h2>
      <p className="text-muted-foreground mt-4">资料列表加载中...</p>
    </div>
  )
}