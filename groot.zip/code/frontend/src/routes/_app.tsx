import { createFileRoute, Outlet, useNavigate } from '@tanstack/react-router'
import { useAuthStore } from '../stores/auth'
import { ThemeToggle } from '../components/theme/ThemeToggle'
import { Sidebar } from '../components/layout/Sidebar'
import { useEffect, useState, useCallback } from 'react'

export const Route = createFileRoute('/_app')({
  component: AppLayout,
})

function AppLayout() {
  const { user, isLoading, logout } = useAuthStore()
  const navigate = useNavigate()
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  const handleLogout = useCallback(async () => {
    await logout()
    navigate({ to: '/login' })
  }, [logout, navigate])

  useEffect(() => {
    if (!isLoading && !user) {
      navigate({ to: '/login' })
    }
  }, [user, isLoading, navigate])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <p className="text-muted-foreground">加载中...</p>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      <header className="h-12 border-b border-border flex items-center px-4 justify-between shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="p-1 rounded text-muted-foreground hover:text-foreground hover:bg-accent/50 transition-colors cursor-pointer"
            title={sidebarCollapsed ? '展开菜单' : '收起菜单'}
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <h1 className="text-sm font-semibold text-foreground">中间件运维智能体平台</h1>
        </div>
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <span className="text-xs text-muted-foreground">
            {user.displayName}
          </span>
          <button
            onClick={handleLogout}
            className="text-xs px-3 py-1 rounded border border-border text-muted-foreground hover:text-foreground hover:bg-accent/50 transition-colors cursor-pointer"
          >
            退出
          </button>
        </div>
      </header>
      <div className="flex-1 flex overflow-hidden">
        <Sidebar collapsed={sidebarCollapsed} />
        <Outlet />
      </div>
    </div>
  )
}