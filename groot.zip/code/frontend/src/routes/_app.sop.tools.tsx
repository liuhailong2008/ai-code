import { createFileRoute } from '@tanstack/react-router'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState, useMemo } from 'react'
import { listTools, scanTools, updateTool, debugTool, type Tool, type ScanResult, type DebugResult } from '../api/tools'

export const Route = createFileRoute('/_app/sop/tools')({
  component: ToolsPage,
})

const CATEGORY_LABELS: Record<string, string> = {
  filesystem: '文件系统',
  system: '系统',
  network: '网络',
  redis: 'Redis',
  kafka: 'Kafka',
}

// 格式化 JSON，提高可读性
function prettyJson(raw: string | null): string {
  if (!raw) return ''
  try {
    return JSON.stringify(JSON.parse(raw), null, 2)
  } catch {
    return raw
  }
}

// 根据 inputSchema 生成默认输入参数
function generateDefaultInput(inputSchema: string | null): string {
  if (!inputSchema) return '{}'
  try {
    const schema = JSON.parse(inputSchema)
    const props = schema.properties || {}
    const defaults: Record<string, unknown> = {}
    for (const [key, prop] of Object.entries(props) as [string, any][]) {
      if (prop.enum && prop.enum.length > 0) {
        defaults[key] = prop.enum[0]
      } else if (prop.default !== undefined) {
        defaults[key] = prop.default
      } else if (prop.type === 'string') {
        if (key.includes('path') || key.includes('file')) {
          defaults[key] = '/path/to/file'
        } else if (key === 'command') {
          defaults[key] = 'echo hello'
        } else if (key === 'pattern') {
          defaults[key] = '*'
        } else if (key === 'content') {
          defaults[key] = 'hello world'
        } else if (key === 'action') {
          defaults[key] = 'list'
        } else {
          defaults[key] = ''
        }
      } else if (prop.type === 'number' || prop.type === 'integer') {
        defaults[key] = 0
      } else if (prop.type === 'boolean') {
        defaults[key] = false
      } else if (prop.type === 'array') {
        defaults[key] = []
      } else if (prop.type === 'object') {
        defaults[key] = {}
      }
    }
    return JSON.stringify(defaults, null, 2)
  } catch {
    return '{}'
  }
}

function ToolsPage() {
  const queryClient = useQueryClient()
  const [scanResult, setScanResult] = useState<ScanResult | null>(null)
  const [viewTool, setViewTool] = useState<Tool | null>(null)
  const [editTool, setEditTool] = useState<Tool | null>(null)

  const { data: tools, isLoading } = useQuery({
    queryKey: ['tools'],
    queryFn: () => listTools(),
  })

  const scanMutation = useMutation({
    mutationFn: scanTools,
    onSuccess: (data: ScanResult) => {
      setScanResult(data)
      queryClient.invalidateQueries({ queryKey: ['tools'] })
    },
  })

  return (
    <div className="flex-1 overflow-auto p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-foreground">Tool 管理</h2>
        <button
          onClick={() => scanMutation.mutate()}
          disabled={scanMutation.isPending}
          className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors cursor-pointer disabled:opacity-50"
        >
          {scanMutation.isPending ? '扫描中...' : '重新扫描'}
        </button>
      </div>

      {scanResult && (
        <div className="mb-4 p-3 rounded bg-green-50 dark:bg-green-900/20 text-sm border border-green-200 dark:border-green-900">
          扫描完成：发现 {scanResult.discovered.length} 个工具，新增 {scanResult.inserted.length} 个
          {scanResult.discovered.length > 0 && (
            <span className="text-muted-foreground ml-2">
              ({scanResult.discovered.join(', ')})
            </span>
          )}
          <button
            onClick={() => setScanResult(null)}
            className="ml-3 text-muted-foreground hover:text-foreground cursor-pointer"
          >
            ×
          </button>
        </div>
      )}

      {isLoading ? (
        <p className="text-sm text-muted-foreground">加载中...</p>
      ) : (
        <div className="border border-border rounded overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted">
              <tr>
                <th className="text-left px-4 py-2 font-medium">工具名称</th>
                <th className="text-left px-4 py-2 font-medium">显示名</th>
                <th className="text-left px-4 py-2 font-medium">分类</th>
                <th className="text-left px-4 py-2 font-medium">实现类</th>
                <th className="text-left px-4 py-2 font-medium">状态</th>
                <th className="text-left px-4 py-2 font-medium">操作</th>
              </tr>
            </thead>
            <tbody>
              {(tools && tools.length > 0) ? tools.map((tool: Tool) => (
                <tr key={tool.id} className="border-t border-border hover:bg-accent/30">
                  <td className="px-4 py-2 font-medium font-mono text-xs">{tool.toolName}</td>
                  <td className="px-4 py-2">{tool.displayName}</td>
                  <td className="px-4 py-2">
                    <span className="text-xs px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                      {CATEGORY_LABELS[tool.toolCategory] || tool.toolCategory}
                    </span>
                  </td>
                  <td className="px-4 py-2 text-xs font-mono text-muted-foreground">{tool.implementationClass}</td>
                  <td className="px-4 py-2">
                    <span className={`text-xs px-1.5 py-0.5 rounded ${
                      tool.isEnabled
                        ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300'
                        : 'bg-muted text-muted-foreground'
                    }`}>
                      {tool.isEnabled ? '已启用' : '已禁用'}
                    </span>
                  </td>
                  <td className="px-4 py-2">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setViewTool(tool)}
                        className="text-xs text-primary hover:underline cursor-pointer"
                      >
                        查看
                      </button>
                      <button
                        onClick={() => setEditTool(tool)}
                        className="text-xs text-primary hover:underline cursor-pointer"
                      >
                        编辑
                      </button>
                    </div>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">
                    暂无工具，点击"重新扫描"发现工具
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* 查看弹窗 */}
      {viewTool && (
        <ToolModal
          tool={viewTool}
          mode="view"
          onClose={() => setViewTool(null)}
        />
      )}

      {/* 编辑弹窗 */}
      {editTool && (
        <ToolModal
          tool={editTool}
          mode="edit"
          onClose={() => setEditTool(null)}
          onSaved={() => {
            setEditTool(null)
            queryClient.invalidateQueries({ queryKey: ['tools'] })
          }}
        />
      )}
    </div>
  )
}

// 通用弹窗：支持查看和编辑两种模式
function ToolModal({
  tool,
  mode,
  onClose,
  onSaved,
}: {
  tool: Tool
  mode: 'view' | 'edit'
  onClose: () => void
  onSaved?: () => void
}) {
  const defaultInput = useMemo(() => generateDefaultInput(tool.inputSchema), [tool.inputSchema])
  const [displayName, setDisplayName] = useState(tool.displayName)
  const [description, setDescription] = useState(tool.description || '')
  const [toolCategory, setToolCategory] = useState(tool.toolCategory)
  const [isEnabled, setIsEnabled] = useState(tool.isEnabled)
  const [debugInput, setDebugInput] = useState(defaultInput)
  const [debugResult, setDebugResult] = useState<DebugResult | null>(null)

  const isView = mode === 'view'

  const updateMutation = useMutation({
    mutationFn: () => updateTool(tool.id, { displayName, description: description || undefined, toolCategory, isEnabled }),
    onSuccess: () => onSaved?.(),
  })

  const debugMutation = useMutation({
    mutationFn: () => debugTool(tool.id, debugInput),
    onSuccess: (data: DebugResult) => setDebugResult(data),
  })

  const inputClass = isView
    ? 'w-full px-3 py-1.5 rounded border border-border bg-muted text-sm text-muted-foreground'
    : 'w-full px-3 py-1.5 rounded border border-border bg-background text-sm'

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-card border border-border rounded-lg p-6 w-[1040px] max-h-[85vh] overflow-auto">
        <h3 className="text-lg font-bold text-foreground mb-4">
          {tool.displayName} - {isView ? '查看' : '编辑'}
        </h3>

        <div className="flex gap-6">
          {/* 左侧：基本信息区 */}
          <div className="w-1/2 space-y-3">
            <div>
              <label className="block text-xs text-muted-foreground mb-1">工具名称</label>
              <input type="text" value={tool.toolName} disabled className="w-full px-3 py-1.5 rounded border border-border bg-muted text-sm text-muted-foreground" />
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1">实现类</label>
              <input type="text" value={tool.implementationClass} disabled className="w-full px-3 py-1.5 rounded border border-border bg-muted text-sm font-mono text-muted-foreground" />
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1">显示名称</label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                disabled={isView}
                className={inputClass}
              />
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1">分类</label>
              {isView ? (
                <input type="text" value={CATEGORY_LABELS[toolCategory] || toolCategory} disabled className="w-full px-3 py-1.5 rounded border border-border bg-muted text-sm text-muted-foreground" />
              ) : (
                <select
                  value={toolCategory}
                  onChange={(e) => setToolCategory(e.target.value)}
                  className="w-full px-3 py-1.5 rounded border border-border bg-background text-sm"
                >
                  {Object.entries(CATEGORY_LABELS).map(([value, label]) => (
                    <option key={value} value={value}>{label}</option>
                  ))}
                  <option value="general">通用</option>
                </select>
              )}
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1">描述</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                disabled={isView}
                rows={2}
                className={`${inputClass} resize-none`}
              />
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs text-muted-foreground">是否启用</label>
              <input
                type="checkbox"
                checked={isEnabled}
                onChange={(e) => setIsEnabled(e.target.checked)}
                disabled={isView}
                className="rounded"
              />
            </div>
            {tool.inputSchema && (
              <div>
                <label className="block text-xs text-muted-foreground mb-1">输入 Schema</label>
                <pre className="text-xs p-2 rounded bg-muted max-h-[180px] overflow-auto font-mono">{prettyJson(tool.inputSchema)}</pre>
              </div>
            )}
            {tool.outputSchema && (
              <div>
                <label className="block text-xs text-muted-foreground mb-1">输出 Schema</label>
                <pre className="text-xs p-2 rounded bg-muted max-h-[180px] overflow-auto font-mono">{prettyJson(tool.outputSchema)}</pre>
              </div>
            )}
          </div>

          {/* 右侧：调试区 */}
          <div className="w-1/2 border-l border-border pl-6">
            <h4 className="text-sm font-medium text-foreground mb-3">调试运行</h4>

            <div>
              <label className="block text-xs text-muted-foreground mb-1">输入参数 (JSON)</label>
              <textarea
                value={debugInput}
                onChange={(e) => setDebugInput(e.target.value)}
                rows={6}
                className="w-full px-3 py-1.5 rounded border border-border bg-background text-sm font-mono resize-none"
              />
            </div>

            <div className="flex items-center gap-2 mt-3">
              <button
                onClick={() => debugMutation.mutate()}
                disabled={debugMutation.isPending}
                className="px-4 py-1.5 rounded bg-primary text-primary-foreground text-sm hover:bg-primary/90 cursor-pointer disabled:opacity-50"
              >
                {debugMutation.isPending ? '执行中...' : '运行调试'}
              </button>
              <button
                onClick={() => setDebugInput(defaultInput)}
                className="px-3 py-1.5 rounded border border-border text-sm text-muted-foreground hover:bg-accent cursor-pointer"
              >
                重置参数
              </button>
            </div>

            {debugResult && (
              <div className="mt-3">
                <label className="block text-xs text-muted-foreground mb-1">
                  结果 ({debugResult.success ? '成功' : '失败'})
                </label>
                <pre className={`text-xs p-3 rounded max-h-[250px] overflow-auto font-mono ${
                  debugResult.success ? 'bg-green-50 dark:bg-green-900/20' : 'bg-red-50 dark:bg-red-900/20'
                }`}>
                  {prettyJson(debugResult.success ? (debugResult.output ?? '') : (debugResult.error ?? ''))}
                </pre>
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-2 mt-6 pt-4 border-t border-border">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded border border-border text-sm hover:bg-accent cursor-pointer"
          >
            关闭
          </button>
          {!isView && (
            <button
              onClick={() => updateMutation.mutate()}
              disabled={updateMutation.isPending}
              className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-sm hover:bg-primary/90 cursor-pointer disabled:opacity-50"
            >
              {updateMutation.isPending ? '保存中...' : '保存'}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
