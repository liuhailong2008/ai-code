import { createFileRoute } from '@tanstack/react-router'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState, useRef } from 'react'
import {
  listSkills, getSkill, uploadSkill, updateSkill, deleteSkill,
  getSkillTree, getSkillFile, saveSkillFile, createSkillFile,
  type Skill, type SkillTreeNode,
} from '../api/skills'

export const Route = createFileRoute('/_app/skills')({
  component: SkillsPage,
})

function SkillsPage() {
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [activeTab, setActiveTab] = useState<'info' | 'files'>('info')

  return (
    <main className="flex-1 flex overflow-hidden">
      {/* 左侧技能列表 */}
      <SkillListPanel
        selectedId={selectedId}
        onSelect={(id) => { setSelectedId(id); setActiveTab('info') }}
      />
      {/* 右侧详情 */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {selectedId ? (
          <SkillDetailPanel
            skillId={selectedId}
            activeTab={activeTab}
            onTabChange={setActiveTab}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center text-muted-foreground">
            请选择一个技能查看详情
          </div>
        )}
      </div>
    </main>
  )
}

// ==================== 左侧技能列表 ====================

function SkillListPanel({ selectedId, onSelect }: {
  selectedId: number | null
  onSelect: (id: number) => void
}) {
  const queryClient = useQueryClient()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [search, setSearch] = useState('')
  const [uploading, setUploading] = useState(false)
  const [uploadError, setUploadError] = useState('')

  const { data: skills, isLoading } = useQuery({
    queryKey: ['skills'],
    queryFn: () => listSkills(),
  })

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploading(true)
    setUploadError('')
    try {
      await uploadSkill(file)
      queryClient.invalidateQueries({ queryKey: ['skills'] })
    } catch (err: any) {
      setUploadError(err.message || '上传失败')
    } finally {
      setUploading(false)
      if (fileInputRef.current) fileInputRef.current.value = ''
    }
  }

  const filtered = skills?.filter(s =>
    s.skillName.toLowerCase().includes(search.toLowerCase()) ||
    s.skillCode.toLowerCase().includes(search.toLowerCase())
  ) ?? []

  return (
    <div className="w-80 border-r border-border bg-card flex flex-col shrink-0">
      <div className="p-3 space-y-2">
        <div className="flex items-center gap-2">
          <input
            type="text"
            placeholder="搜索技能..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 px-2 py-1.5 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
          <label className={`px-2 py-1.5 rounded text-xs font-medium cursor-pointer transition-colors ${
            uploading ? 'bg-muted text-muted-foreground' : 'bg-primary text-primary-foreground hover:bg-primary/90'
          }`}>
            {uploading ? '上传中...' : '+ 上传'}
            <input
              ref={fileInputRef}
              type="file"
              accept=".zip"
              onChange={handleUpload}
              className="hidden"
              disabled={uploading}
            />
          </label>
        </div>
        {uploadError && (
          <p className="text-xs text-destructive">{uploadError}</p>
        )}
      </div>

      <div className="flex-1 overflow-auto">
        {isLoading ? (
          <p className="p-3 text-sm text-muted-foreground">加载中...</p>
        ) : filtered.length === 0 ? (
          <p className="p-3 text-sm text-muted-foreground">暂无技能</p>
        ) : (
          filtered.map((skill) => (
            <SkillCard
              key={skill.id}
              skill={skill}
              isSelected={skill.id === selectedId}
              onClick={() => onSelect(skill.id)}
              onDeleted={() => {
                if (skill.id === selectedId) onSelect(0)
                queryClient.invalidateQueries({ queryKey: ['skills'] })
              }}
            />
          ))
        )}
      </div>
    </div>
  )
}

function SkillCard({ skill, isSelected, onClick, onDeleted }: {
  skill: Skill
  isSelected: boolean
  onClick: () => void
  onDeleted: () => void
}) {
  const queryClient = useQueryClient()
  const deleteMutation = useMutation({
    mutationFn: () => deleteSkill(skill.id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skills'] })
      onDeleted()
    },
  })

  const toggleMutation = useMutation({
    mutationFn: () => updateSkill(skill.id, { isEnabled: !skill.isEnabled }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['skills'] }),
  })

  return (
    <div
      onClick={onClick}
      className={`p-3 border-b border-border cursor-pointer transition-colors ${
        isSelected ? 'bg-accent' : 'hover:bg-accent/50'
      }`}
    >
      <div className="flex items-center justify-between">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full shrink-0 ${skill.isEnabled ? 'bg-green-500' : 'bg-gray-400'}`} />
            <span className="font-medium text-sm text-foreground truncate">{skill.skillName}</span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5 truncate">{skill.skillCode}</p>
          {skill.description && (
            <p className="text-xs text-muted-foreground mt-0.5 truncate">{skill.description}</p>
          )}
        </div>
        <div className="flex items-center gap-1 shrink-0 ml-2">
          <button
            onClick={(e) => { e.stopPropagation(); toggleMutation.mutate() }}
            className="text-xs px-1.5 py-0.5 rounded hover:bg-muted transition-colors"
            title={skill.isEnabled ? '禁用' : '启用'}
          >
            {skill.isEnabled ? '禁用' : '启用'}
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); if (confirm('确定删除此技能？')) deleteMutation.mutate() }}
            className="text-xs px-1.5 py-0.5 rounded hover:bg-red-100 text-red-600 transition-colors"
            title="删除"
          >
            删除
          </button>
        </div>
      </div>
    </div>
  )
}

// ==================== 右侧详情面板 ====================

function SkillDetailPanel({ skillId, activeTab, onTabChange }: {
  skillId: number
  activeTab: 'info' | 'files'
  onTabChange: (tab: 'info' | 'files') => void
}) {
  return (
    <>
      {/* Tab 切换 */}
      <div className="flex border-b border-border px-4">
        <button
          onClick={() => onTabChange('info')}
          className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
            activeTab === 'info'
              ? 'border-primary text-primary'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          基本信息
        </button>
        <button
          onClick={() => onTabChange('files')}
          className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
            activeTab === 'files'
              ? 'border-primary text-primary'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          文件浏览
        </button>
      </div>

      {/* Tab 内容 */}
      <div className="flex-1 overflow-auto">
        {activeTab === 'info' ? (
          <SkillInfoTab skillId={skillId} />
        ) : (
          <SkillFilesTab skillId={skillId} />
        )}
      </div>
    </>
  )
}

// ==================== 基本信息 Tab ====================

function SkillInfoTab({ skillId }: { skillId: number }) {
  const queryClient = useQueryClient()
  const { data: skill, isLoading } = useQuery({
    queryKey: ['skill', skillId],
    queryFn: () => getSkill(skillId),
  })

  const [editMode, setEditMode] = useState(false)
  const [form, setForm] = useState({ skillName: '', description: '', version: '' })

  const updateMutation = useMutation({
    mutationFn: (data: { skillName?: string; description?: string; version?: string }) =>
      updateSkill(skillId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skill', skillId] })
      queryClient.invalidateQueries({ queryKey: ['skills'] })
      setEditMode(false)
    },
  })

  if (isLoading) return <p className="p-4 text-sm text-muted-foreground">加载中...</p>
  if (!skill) return <p className="p-4 text-sm text-destructive">技能不存在</p>

  const startEdit = () => {
    setForm({
      skillName: skill.skillName,
      description: skill.description || '',
      version: skill.version || '',
    })
    setEditMode(true)
  }

  const handleSave = () => {
    updateMutation.mutate({
      skillName: form.skillName || undefined,
      description: form.description || undefined,
      version: form.version || undefined,
    })
  }

  return (
    <div className="p-6 max-w-lg">
      <div className="space-y-4">
        <FormField label="技能名称">
          {editMode ? (
            <input
              value={form.skillName}
              onChange={(e) => setForm({ ...form, skillName: e.target.value })}
              className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          ) : (
            <p className="text-foreground">{skill.skillName}</p>
          )}
        </FormField>

        <FormField label="技能编码">
          <p className="text-foreground">{skill.skillCode}</p>
        </FormField>

        <FormField label="描述">
          {editMode ? (
            <textarea
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              rows={3}
              className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
            />
          ) : (
            <p className="text-foreground">{skill.description || '-'}</p>
          )}
        </FormField>

        <FormField label="版本">
          {editMode ? (
            <input
              value={form.version}
              onChange={(e) => setForm({ ...form, version: e.target.value })}
              className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          ) : (
            <p className="text-foreground">{skill.version || '-'}</p>
          )}
        </FormField>

        <FormField label="状态">
          <span className={`text-sm ${skill.isEnabled ? 'text-green-600' : 'text-gray-500'}`}>
            {skill.isEnabled ? '已启用' : '已禁用'}
          </span>
        </FormField>

        <FormField label="创建人">
          <span className="text-sm text-muted-foreground">{skill.createdBy}</span>
        </FormField>

        <FormField label="创建时间">
          <span className="text-sm text-muted-foreground">
            {new Date(skill.createdAt).toLocaleString('zh-CN')}
          </span>
        </FormField>

        <div className="flex gap-2 pt-2">
          {editMode ? (
            <>
              <button
                onClick={handleSave}
                disabled={updateMutation.isPending}
                className="px-4 py-1.5 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 disabled:opacity-50"
              >
                {updateMutation.isPending ? '保存中...' : '保存'}
              </button>
              <button
                onClick={() => setEditMode(false)}
                className="px-4 py-1.5 rounded border border-border text-sm hover:bg-muted"
              >
                取消
              </button>
            </>
          ) : (
            <button
              onClick={startEdit}
              className="px-4 py-1.5 rounded border border-border text-sm hover:bg-muted"
            >
              编辑
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

function FormField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs text-muted-foreground mb-1">{label}</label>
      {children}
    </div>
  )
}

// ==================== 文件浏览 Tab ====================

function SkillFilesTab({ skillId }: { skillId: number }) {
  const { data: treeData, isLoading } = useQuery({
    queryKey: ['skillTree', skillId],
    queryFn: () => getSkillTree(skillId),
  })

  const [selectedPath, setSelectedPath] = useState<string | null>(null)
  const [editMode, setEditMode] = useState(false)
  const [editContent, setEditContent] = useState('')
  const [isNewFile, setIsNewFile] = useState(false)
  const [newFileName, setNewFileName] = useState('')

  const queryClient = useQueryClient()

  const { data: fileData, isLoading: fileLoading } = useQuery({
    queryKey: ['skillFile', skillId, selectedPath],
    queryFn: () => getSkillFile(skillId, selectedPath!),
    enabled: !!selectedPath && !isNewFile,
  })

  const saveMutation = useMutation({
    mutationFn: ({ path, content }: { path: string; content: string }) =>
      saveSkillFile(skillId, path, content),
    onSuccess: () => {
      setEditMode(false)
      queryClient.invalidateQueries({ queryKey: ['skillFile', skillId, selectedPath] })
    },
  })

  const createMutation = useMutation({
    mutationFn: ({ path, content }: { path: string; content: string }) =>
      createSkillFile(skillId, path, content),
    onSuccess: () => {
      setIsNewFile(false)
      setNewFileName('')
      queryClient.invalidateQueries({ queryKey: ['skillTree', skillId] })
    },
  })

  const handleFileClick = (path: string) => {
    setSelectedPath(path)
    setEditMode(false)
    setIsNewFile(false)
  }

  const handleStartEdit = () => {
    if (fileData?.content != null) {
      setEditContent(fileData.content)
    }
    setEditMode(true)
  }

  const handleCancelEdit = () => {
    setEditMode(false)
    if (isNewFile) {
      setIsNewFile(false)
      setNewFileName('')
    }
  }

  const handleStartNewFile = () => {
    setIsNewFile(true)
    setEditContent('')
    setNewFileName('')
    setEditMode(true)
  }

  const handleSave = () => {
    if (isNewFile) {
      if (!newFileName) return
      const dir = selectedPath && treeData?.tree.find(n =>
        n.type === 'dir' && selectedPath.startsWith(n.path)
      ) ? selectedPath : ''
      const fullPath = dir ? `${dir}/${newFileName}` : newFileName
      createMutation.mutate({ path: fullPath, content: editContent })
    } else if (selectedPath) {
      saveMutation.mutate({ path: selectedPath, content: editContent })
    }
  }

  if (isLoading) return <p className="p-4 text-sm text-muted-foreground">加载中...</p>

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* 目录树 */}
      <div className="w-56 border-r border-border overflow-auto p-2 shrink-0">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-medium text-muted-foreground">目录结构</span>
          <button
            onClick={handleStartNewFile}
            className="text-xs px-1.5 py-0.5 rounded bg-primary text-primary-foreground hover:bg-primary/90"
          >
            + 新建
          </button>
        </div>
        {treeData?.tree.map((node, i) => (
          <TreeNode
            key={i}
            node={node}
            selectedPath={selectedPath}
            onSelect={handleFileClick}
            depth={0}
          />
        ))}
      </div>

      {/* 文件内容区 */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {!selectedPath && !isNewFile ? (
          <div className="flex-1 flex items-center justify-center text-sm text-muted-foreground">
            请选择文件查看
          </div>
        ) : editMode ? (
          /* 编辑模式 */
          <div className="flex-1 flex flex-col">
            {isNewFile && (
              <div className="px-3 py-2 border-b border-border flex items-center gap-2">
                <input
                  value={newFileName}
                  onChange={(e) => setNewFileName(e.target.value)}
                  placeholder="文件名 (如 example.md)"
                  className="flex-1 px-2 py-1 rounded border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
              </div>
            )}
            <textarea
              value={editContent}
              onChange={(e) => setEditContent(e.target.value)}
              className="flex-1 min-h-[60vh] p-4 bg-background text-sm text-foreground font-mono resize-y focus:outline-none"
              placeholder="输入 Markdown 内容..."
            />
            <div className="flex gap-2 p-3 border-t border-border">
              <button
                onClick={handleSave}
                disabled={saveMutation.isPending || createMutation.isPending}
                className="px-4 py-1.5 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 disabled:opacity-50"
              >
                {saveMutation.isPending || createMutation.isPending ? '保存中...' : '保存'}
              </button>
              <button
                onClick={handleCancelEdit}
                className="px-4 py-1.5 rounded border border-border text-sm hover:bg-muted"
              >
                取消
              </button>
            </div>
          </div>
        ) : (
          /* 阅读模式 */
          <>
            <div className="flex items-center justify-between px-4 py-2 border-b border-border">
              <span className="text-sm text-muted-foreground">{selectedPath}</span>
              <button
                onClick={handleStartEdit}
                className="text-xs px-3 py-1 rounded border border-border hover:bg-muted transition-colors"
              >
                编辑
              </button>
            </div>
            <div className="flex-1 overflow-auto p-4">
              {fileLoading ? (
                <p className="text-sm text-muted-foreground">加载中...</p>
              ) : fileData ? (
                <pre className="text-sm text-foreground whitespace-pre-wrap font-mono leading-relaxed">
                  {fileData.content}
                </pre>
              ) : (
                <p className="text-sm text-muted-foreground">无法加载文件内容</p>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  )
}

function TreeNode({ node, selectedPath, onSelect, depth }: {
  node: SkillTreeNode
  selectedPath: string | null
  onSelect: (path: string) => void
  depth: number
}) {
  const [expanded, setExpanded] = useState(depth < 1)
  const isDir = node.type === 'dir'
  const isSelected = node.path === selectedPath

  return (
    <div>
      <div
        onClick={() => {
          if (isDir) {
            setExpanded(!expanded)
          } else {
            onSelect(node.path)
          }
        }}
        className={`flex items-center gap-1 px-1 py-1 rounded text-sm cursor-pointer transition-colors ${
          isSelected ? 'bg-accent text-accent-foreground' : 'text-foreground hover:bg-accent/50'
        }`}
        style={{ paddingLeft: `${depth * 16 + 4}px` }}
      >
        {isDir ? (
          <svg className={`w-3 h-3 transition-transform ${expanded ? 'rotate-90' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        ) : (
          <svg className="w-3 h-3 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-3-3v6" />
          </svg>
        )}
        <span className="truncate text-xs">{node.name}</span>
      </div>
      {isDir && expanded && node.children?.map((child, i) => (
        <TreeNode
          key={i}
          node={child}
          selectedPath={selectedPath}
          onSelect={onSelect}
          depth={depth + 1}
        />
      ))}
    </div>
  )
}
