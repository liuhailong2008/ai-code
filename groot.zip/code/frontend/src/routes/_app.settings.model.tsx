import { createFileRoute } from '@tanstack/react-router'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState, useEffect } from 'react'
import { listModelConfigs, createModelConfig, updateModelConfig, deleteModelConfig, verifyModelConfig } from '../api/model-configs'
import type { ModelConfig, ModelConfigCreate, ModelConfigUpdate } from '../schemas'

export const Route = createFileRoute('/_app/settings/model')({
  component: ModelSettingsPage,
})

const PURPOSE_LABELS: Record<string, string> = {
  chat: '通用对话',
  reasoning: '推理',
  embedding: '向量化',
  vision: '视觉',
  rerank: '重排序',
}

function ModelSettingsPage() {
  const queryClient = useQueryClient()
  const [selectedConfig, setSelectedConfig] = useState<ModelConfig | null>(null)
  const [isNew, setIsNew] = useState(false)
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null)
  const [verifyingAll, setVerifyingAll] = useState(false)

  const { data: configs, isLoading, error } = useQuery({
    queryKey: ['modelConfigs'],
    queryFn: listModelConfigs,
  })

  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => setMessage(null), 5000)
      return () => clearTimeout(timer)
    }
  }, [message])

  const handleVerifyAll = async () => {
    if (!configs || configs.length === 0) {
      setMessage({ type: 'error', text: '没有可验证的模型' })
      return
    }
    setVerifyingAll(true)
    let successCount = 0
    let failCount = 0
    for (const model of configs) {
      try {
        await verifyModelConfig(model.id)
        await updateModelConfig(model.id, { isActive: true })
        successCount++
      } catch {
        failCount++
      }
    }
    setVerifyingAll(false)
    queryClient.invalidateQueries({ queryKey: ['modelConfigs'] })
    if (failCount === 0) {
      setMessage({ type: 'success', text: `全部验证通过 (${successCount} 个)，已激活` })
    } else {
      setMessage({ type: 'error', text: `${successCount} 个成功，${failCount} 个失败` })
    }
  }

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* 左侧：模型列表 */}
      <ModelList
        configs={configs}
        isLoading={isLoading}
        error={error}
        selectedId={selectedConfig?.id ?? null}
        onSelect={(config) => {
          setSelectedConfig(config)
          setIsNew(false)
        }}
        onNew={() => {
          setSelectedConfig(null)
          setIsNew(true)
        }}
        onVerifyAll={handleVerifyAll}
        verifyingAll={verifyingAll}
      />

      {/* 右侧：明细 */}
      <div className="flex-1 overflow-auto">
        {message && (
          <div className="fixed top-4 right-4 z-50 px-4 py-3 rounded shadow-lg text-sm border animate-in fade-in slide-in-from-top-2"
            style={{
              background: message.type === 'success' ? 'rgb(220 252 231)' : 'rgb(254 226 226)',
              color: message.type === 'success' ? 'rgb(22 101 52)' : 'rgb(153 27 27)',
              borderColor: message.type === 'success' ? 'rgb(187 247 208)' : 'rgb(254 202 202)',
            }}
          >
            {message.text}
          </div>
        )}

        {isNew ? (
          <ModelForm
            mode="create"
            onSaved={(newConfig) => {
              setSelectedConfig(newConfig)
              setIsNew(false)
              setMessage({ type: 'success', text: '保存成功' })
              queryClient.invalidateQueries({ queryKey: ['modelConfigs'] })
            }}
            onCancel={() => setIsNew(false)}
            onError={(err) => setMessage({ type: 'error', text: err })}
          />
        ) : selectedConfig ? (
          <ModelForm
            key={selectedConfig.id}
            mode="edit"
            config={selectedConfig}
            onSaved={(updated) => {
              setSelectedConfig(updated)
              setMessage({ type: 'success', text: '保存成功' })
              queryClient.invalidateQueries({ queryKey: ['modelConfigs'] })
            }}
            onDeleted={() => {
              setSelectedConfig(null)
              setMessage({ type: 'success', text: '模型已删除' })
              queryClient.invalidateQueries({ queryKey: ['modelConfigs'] })
            }}
            onCancel={() => setSelectedConfig(null)}
            onError={(err) => setMessage({ type: 'error', text: err })}
          />
        ) : (
          <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
            请选择左侧模型或创建新模型
          </div>
        )}
      </div>
    </div>
  )
}

// ====== 左侧模型列表 ======

interface ModelListProps {
  configs?: ModelConfig[]
  isLoading: boolean
  error: Error | null
  selectedId: number | null
  onSelect: (config: ModelConfig) => void
  onNew: () => void
  onVerifyAll: () => void
  verifyingAll: boolean
}

function ModelList({ configs, isLoading, error, selectedId, onSelect, onNew, onVerifyAll, verifyingAll }: ModelListProps) {
  const grouped: Record<string, ModelConfig[]> = (configs || []).reduce<Record<string, ModelConfig[]>>((acc, c) => {
    if (!acc[c.purpose]) acc[c.purpose] = []
    acc[c.purpose]!.push(c)
    return acc
  }, {})

  return (
    <div className="w-64 border-r border-border shrink-0 flex flex-col">
      <div className="p-3 border-b border-border flex items-center justify-between">
        <h3 className="text-sm font-semibold text-foreground">模型列表</h3>
        <div className="flex items-center gap-1.5">
          <button
            onClick={onVerifyAll}
            disabled={verifyingAll}
            className="text-xs px-2 py-1 rounded border border-blue-500 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950 disabled:opacity-50 transition-colors cursor-pointer"
          >
            {verifyingAll ? '验证中...' : '全部验证并激活'}
          </button>
          <button
            onClick={onNew}
            className="text-xs px-2 py-1 rounded bg-primary text-primary-foreground hover:bg-primary/90 transition-colors cursor-pointer"
          >
            + 新建
          </button>
        </div>
      </div>
      <div className="flex-1 overflow-auto">
        {isLoading && (
          <p className="p-3 text-xs text-muted-foreground">加载中...</p>
        )}
        {error && (
          <p className="p-3 text-xs text-destructive">加载失败: {error.message}</p>
        )}
        {configs?.length === 0 && (
          <p className="p-3 text-xs text-muted-foreground">暂无模型</p>
        )}
        {Object.entries(grouped).map(([purpose, items]) => (
          <div key={purpose}>
            <div className="px-3 py-1.5 text-xs font-medium text-muted-foreground bg-muted/30">
              {PURPOSE_LABELS[purpose] || purpose}
            </div>
            {items.map((config) => {
              const isActive = config.id === selectedId
              return (
                <button
                  key={config.id}
                  onClick={() => onSelect(config)}
                  className={`w-full text-left px-3 py-2.5 text-sm transition-colors cursor-pointer border-b border-border/50 ${
                    isActive
                      ? 'bg-accent text-accent-foreground'
                      : 'text-foreground hover:bg-accent/50'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    <span className="font-medium truncate">{config.name}</span>
                    {config.isActive && (
                      <span className="w-1.5 h-1.5 rounded-full bg-green-500 shrink-0" title="已激活" />
                    )}
                    {!config.isEnabled && (
                      <span className="text-xs text-muted-foreground shrink-0">(已禁用)</span>
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground truncate">{config.code}</div>
                </button>
              )
            })}
          </div>
        ))}
      </div>
    </div>
  )
}

// ====== 模型表单 ======

interface ModelFormProps {
  mode: 'create' | 'edit'
  config?: ModelConfig
  onSaved: (config: ModelConfig) => void
  onCancel: () => void
  onDeleted?: () => void
  onError: (err: string) => void
}

function ModelForm({ mode, config, onSaved, onCancel, onDeleted, onError }: ModelFormProps) {
  const [form, setForm] = useState<ModelConfigCreate>({
    code: config?.code ?? '',
    name: config?.name ?? '',
    provider: config?.provider ?? '',
    baseUrl: config?.baseUrl ?? '',
    apiKey: config?.apiKey ?? '',
    purpose: config?.purpose ?? '',
    isActive: config?.isActive ?? false,
    isEnabled: config?.isEnabled ?? true,
    priority: config?.priority ?? 0,
    contextWindow: config?.contextWindow ?? 4096,
    maxTokens: config?.maxTokens ?? 4096,
    supportsThinking: config?.supportsThinking ?? false,
    supportsVision: config?.supportsVision ?? false,
    supportsTools: config?.supportsTools ?? false,
    supportsJson: config?.supportsJson ?? false,
    temperature: config?.temperature ?? 0.7,
    topP: config?.topP ?? 1.0,
  })
  const [saving, setSaving] = useState(false)
  const [verifying, setVerifying] = useState(false)
  const [verifyResponse, setVerifyResponse] = useState<string | null>(null)
  const [verifyError, setVerifyError] = useState<string | null>(null)

  const createMutation = useMutation({
    mutationFn: (data: ModelConfigCreate) => createModelConfig(data),
  })

  const updateMutation = useMutation({
    mutationFn: (data: ModelConfigUpdate) => updateModelConfig(config!.id, data),
  })

  const deleteMutation = useMutation({
    mutationFn: () => deleteModelConfig(config!.id),
  })

  const handleSubmit = async () => {
    if (!form.baseUrl.trim()) {
      onError('API 地址不能为空')
      return
    }
    if (mode === 'create' && !form.apiKey.trim()) {
      onError('API Key 不能为空')
      return
    }
    setSaving(true)
    try {
      if (mode === 'create') {
        const result = await createMutation.mutateAsync(form)
        onSaved(result)
      } else {
        const changed = buildChanges()
        if (Object.keys(changed).length === 0) {
          onCancel()
          return
        }
        const result = await updateMutation.mutateAsync(changed as ModelConfigUpdate)
        onSaved(result)
      }
    } catch (err) {
      onError(err instanceof Error ? err.message : '保存失败')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async () => {
    if (!confirm('确定要删除该模型吗？')) return
    try {
      await deleteMutation.mutateAsync()
      onDeleted?.()
    } catch (err) {
      onError(err instanceof Error ? err.message : '删除失败')
    }
  }

  const handleVerify = async (activateAfter: boolean) => {
    setVerifyError(null)
    setVerifyResponse(null)

    // 验证前检查
    const effectiveApiKey = form.apiKey?.trim() || ''
    const effectiveBaseUrl = form.baseUrl?.trim() || ''
    const effectiveCode = form.code?.trim() || ''

    // create 模式必须有 apiKey，edit 模式如果 form 里有就用 form 的（用户刚输入），否则检查 DB 中是否有
    if (!effectiveApiKey && mode === 'create') {
      setVerifyError('API Key 不能为空，请先填写 API Key')
      return
    }
    if (!effectiveBaseUrl) {
      setVerifyError('API 地址不能为空，请先填写 API 地址')
      return
    }

    setVerifying(true)
    try {
      // 构造验证请求，传入当前表单数据（不经过保存）
      const verifyOverrides: Record<string, unknown> = {}
      if (effectiveApiKey) verifyOverrides.apiKey = effectiveApiKey
      if (effectiveBaseUrl) verifyOverrides.baseUrl = effectiveBaseUrl
      if (effectiveCode) verifyOverrides.code = effectiveCode
      if (form.temperature != null) verifyOverrides.temperature = form.temperature

      // 用表单数据直接验证（后端优先使用请求体中的覆写值）
      const result = await verifyModelConfig(
        mode === 'create' ? 0 : config!.id,
        verifyOverrides as { apiKey?: string; baseUrl?: string; code?: string; temperature?: number | null },
      )
      setVerifyResponse(result.content)

      // 验证通过后，如果需要激活，则保存并激活
      if (activateAfter) {
        if (mode === 'create') {
          const created = await createMutation.mutateAsync({ ...form, isActive: true })
          setForm((prev) => ({ ...prev, isActive: true }))
          onSaved(created)
        } else {
          // 先保存变更，再激活
          const changed: Record<string, unknown> = buildChanges()
          if (Object.keys(changed).length > 0) {
            await updateModelConfig(config!.id, { ...changed, isActive: true } as ModelConfigUpdate)
          } else {
            await updateModelConfig(config!.id, { isActive: true })
          }
          const updated = await updateModelConfig(config!.id, { isActive: true })
          setForm((prev) => ({ ...prev, isActive: true }))
          onSaved(updated)
        }
      }
    } catch (err) {
      setVerifyError(err instanceof Error ? err.message : '验证失败')
    } finally {
      setVerifying(false)
    }
  }

  // 构建变更字段
  const buildChanges = (): Record<string, unknown> => {
    const changed: Record<string, unknown> = {}
    const booleanFields: (keyof ModelConfigCreate)[] = [
      'isActive', 'isEnabled', 'supportsThinking', 'supportsVision', 'supportsTools', 'supportsJson',
    ]
    const numFields: (keyof ModelConfigCreate)[] = ['priority', 'contextWindow', 'maxTokens', 'temperature', 'topP']
    const strFields: (keyof ModelConfigCreate)[] = ['code', 'name', 'provider', 'baseUrl', 'apiKey', 'purpose']

    for (const f of strFields) {
      if (form[f] !== (config as ModelConfig)[f]) {
        changed[f] = form[f] || null
      }
    }
    for (const f of booleanFields) {
      if (form[f] !== (config as ModelConfig)[f]) {
        changed[f] = form[f]
      }
    }
    for (const f of numFields) {
      if (form[f] !== (config as ModelConfig)[f]) {
        changed[f] = form[f]
      }
    }
    return changed
  }

  const setStrField = (field: keyof ModelConfigCreate) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }))
  }

  const setNumField = (field: keyof ModelConfigCreate) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value === '' ? (null as unknown as never) : Number(e.target.value) }))
  }

  const setCheckField = (field: keyof ModelConfigCreate) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm((prev) => ({ ...prev, [field]: e.target.checked }))
  }

  return (
    <div className="p-6 max-w-2xl">
      <h3 className="text-lg font-bold text-foreground mb-6">
        {mode === 'create' ? '新建模型' : '编辑模型'}
      </h3>

      <div className="space-y-4">
        {/* 基本信息 */}
        <fieldset className="border border-border rounded-lg p-4">
          <legend className="text-sm font-semibold text-foreground px-2">基本信息</legend>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <FormField label="模型编码" required>
                <input value={form.code} onChange={setStrField('code')} placeholder="如 deepseek-chat" className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50" />
              </FormField>
              <FormField label="模型名称" required>
                <input value={form.name} onChange={setStrField('name')} placeholder="如 DeepSeek-V4-Flash" className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50" />
              </FormField>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <FormField label="供应商" required>
                <select value={form.provider} onChange={setStrField('provider')} className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50">
                  <option value="">请选择</option>
                  <option value="deepseek">DeepSeek</option>
                  <option value="volcengine">火山引擎</option>
                  <option value="zhipu">智谱</option>
                </select>
              </FormField>
              <FormField label="用途" required>
                <select value={form.purpose} onChange={setStrField('purpose')} className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50">
                  <option value="">请选择</option>
                  <option value="chat">通用对话</option>
                  <option value="reasoning">推理</option>
                  <option value="embedding">向量化</option>
                  <option value="vision">视觉</option>
                  <option value="rerank">重排序</option>
                </select>
              </FormField>
              <FormField label="优先级">
                <input type="number" value={form.priority} onChange={setNumField('priority')} min={0} className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50" />
              </FormField>
            </div>
          </div>
        </fieldset>

        {/* API配置 */}
        <fieldset className="border border-border rounded-lg p-4">
          <legend className="text-sm font-semibold text-foreground px-2">API配置</legend>
          <div className="space-y-3">
            <FormField label="API地址" required>
              <input value={form.baseUrl} onChange={setStrField('baseUrl')} placeholder="https://api.deepseek.com/v1" className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50" />
            </FormField>
            <FormField label="API Key" required={mode === 'create'}>
              <div className="flex items-center gap-2">
                <input value={form.apiKey} onChange={setStrField('apiKey')} placeholder={mode === 'create' ? '请输入 API Key' : '留空则不修改'} className="flex-1 px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50" />
                {mode === 'edit' && (
                  <span className={`shrink-0 text-xs px-2 py-1 rounded-full border ${
                    config?.hasApiKey
                      ? 'bg-green-50 text-green-700 border-green-300 dark:bg-green-950 dark:text-green-300 dark:border-green-700'
                      : 'bg-red-50 text-red-600 border-red-300 dark:bg-red-950 dark:text-red-300 dark:border-red-700'
                  }`}>
                    {config?.hasApiKey ? '已配置' : '未配置'}
                  </span>
                )}
              </div>
            </FormField>
          </div>
        </fieldset>

        {/* 能力与开关 */}
        <fieldset className="border border-border rounded-lg p-4">
          <legend className="text-sm font-semibold text-foreground px-2">能力与开关</legend>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex items-center gap-2">
              <input type="checkbox" id="isActive" checked={form.isActive === true} onChange={setCheckField('isActive')} className="w-4 h-4 rounded border-border" />
              <label htmlFor="isActive" className="text-sm text-foreground cursor-pointer">激活</label>
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" id="isEnabled" checked={form.isEnabled === true} onChange={setCheckField('isEnabled')} className="w-4 h-4 rounded border-border" />
              <label htmlFor="isEnabled" className="text-sm text-foreground cursor-pointer">启用</label>
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" id="supportsThinking" checked={form.supportsThinking === true} onChange={setCheckField('supportsThinking')} className="w-4 h-4 rounded border-border" />
              <label htmlFor="supportsThinking" className="text-sm text-foreground cursor-pointer">深度思考</label>
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" id="supportsVision" checked={form.supportsVision === true} onChange={setCheckField('supportsVision')} className="w-4 h-4 rounded border-border" />
              <label htmlFor="supportsVision" className="text-sm text-foreground cursor-pointer">视觉理解</label>
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" id="supportsTools" checked={form.supportsTools === true} onChange={setCheckField('supportsTools')} className="w-4 h-4 rounded border-border" />
              <label htmlFor="supportsTools" className="text-sm text-foreground cursor-pointer">函数调用</label>
            </div>
            <div className="flex items-center gap-2">
              <input type="checkbox" id="supportsJson" checked={form.supportsJson === true} onChange={setCheckField('supportsJson')} className="w-4 h-4 rounded border-border" />
              <label htmlFor="supportsJson" className="text-sm text-foreground cursor-pointer">JSON输出</label>
            </div>
          </div>
        </fieldset>

        {/* 参数配置 */}
        <fieldset className="border border-border rounded-lg p-4">
          <legend className="text-sm font-semibold text-foreground px-2">模型参数</legend>
          <div className="grid grid-cols-2 gap-3">
            <FormField label="上下文窗口 (tokens)">
              <input type="number" value={form.contextWindow} onChange={setNumField('contextWindow')} min={0} className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50" />
            </FormField>
            <FormField label="最大输出 (tokens)">
              <input type="number" value={form.maxTokens} onChange={setNumField('maxTokens')} min={0} className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50" />
            </FormField>
            <FormField label="Temperature">
              <input type="number" value={form.temperature ?? ''} onChange={setNumField('temperature')} min={0} max={2} step={0.01} className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50" />
            </FormField>
            <FormField label="Top P">
              <input type="number" value={form.topP ?? ''} onChange={setNumField('topP')} min={0} max={1} step={0.01} className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50" />
            </FormField>
          </div>
        </fieldset>
      </div>

      {/* 验证结果 */}
      {mode === 'edit' && (verifyResponse || verifyError) && (
        <div className={`mt-4 p-4 rounded border text-sm ${
          verifyError
            ? 'border-destructive/50 bg-destructive/10 text-destructive'
            : 'border-green-500/50 bg-green-50 text-green-800 dark:bg-green-950 dark:text-green-200'
        }`}>
          {verifyError ? (
            <p>{verifyError}</p>
          ) : (
            <>
              <p className="font-medium mb-1">✓ 模型验证通过</p>
              <p className="whitespace-pre-wrap">{verifyResponse}</p>
            </>
          )}
        </div>
      )}

      <div className="flex items-center justify-between mt-6">
        <div className="flex items-center gap-3">
          {mode === 'edit' && (
            <>
              {form.isActive ? (
                <button
                  onClick={() => handleVerify(false)}
                  disabled={verifying}
                  className="px-4 py-2 rounded text-sm border border-blue-500 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950 disabled:opacity-50 transition-colors cursor-pointer"
                >
                  {verifying ? '验证中...' : '验证'}
                </button>
              ) : (
                <>
                  <button
                    onClick={() => handleVerify(false)}
                    disabled={verifying}
                    className="px-4 py-2 rounded text-sm border border-blue-500 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950 disabled:opacity-50 transition-colors cursor-pointer"
                  >
                    {verifying ? '验证中...' : '验证'}
                  </button>
                  <button
                    onClick={() => handleVerify(true)}
                    disabled={verifying}
                    className="px-4 py-2 rounded text-sm border border-green-500 text-green-600 hover:bg-green-50 dark:hover:bg-green-950 disabled:opacity-50 transition-colors cursor-pointer"
                  >
                    {verifying ? '验证中...' : '验证并激活'}
                  </button>
                </>
              )}
              <button
                onClick={handleDelete}
                className="px-4 py-2 rounded text-sm text-destructive border border-destructive hover:bg-destructive/10 transition-colors cursor-pointer"
              >
                删除模型
              </button>
            </>
          )}
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={onCancel}
            className="px-4 py-2 rounded text-sm text-muted-foreground border border-border hover:bg-accent/50 transition-colors cursor-pointer"
          >
            取消
          </button>
          <button
            onClick={handleSubmit}
            disabled={saving}
            className="px-5 py-2 rounded text-sm bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 transition-colors cursor-pointer"
          >
            {saving ? '保存中...' : '保存'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ====== 表单字段 ======

function FormField({ label, required, children }: {
  label: string
  required?: boolean
  children: React.ReactNode
}) {
  return (
    <label className="block">
      <span className="text-sm font-medium text-foreground">
        {label}
        {required && <span className="text-destructive ml-0.5">*</span>}
      </span>
      <div className="mt-1.5">{children}</div>
    </label>
  )
}
