import { createFileRoute } from '@tanstack/react-router'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState, useEffect } from 'react'
import { listSopMiddlewares, createSopMiddleware, updateSopMiddleware, deleteSopMiddleware } from '../api/middleware'
import type { SopMiddleware, SopMiddlewareCreate } from '../schemas'

export const Route = createFileRoute('/_app/settings/middleware')({
  component: MiddlewareSettingsPage,
})

function MiddlewareSettingsPage() {
  const queryClient = useQueryClient()
  const [selected, setSelected] = useState<SopMiddleware | null>(null)
  const [isNew, setIsNew] = useState(false)
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null)

  const { data: list, isLoading, error } = useQuery({
    queryKey: ['sopMiddlewares'],
    queryFn: listSopMiddlewares,
  })

  useEffect(() => {
    if (message) {
      const timer = setTimeout(() => setMessage(null), 5000)
      return () => clearTimeout(timer)
    }
  }, [message])

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* 左侧：中间件列表 */}
      <div className="w-64 border-r border-border shrink-0 flex flex-col">
        <div className="p-3 border-b border-border flex items-center justify-between">
          <h3 className="text-sm font-semibold text-foreground">中间件列表</h3>
          <button
            onClick={() => { setSelected(null); setIsNew(true) }}
            className="text-xs px-2 py-1 rounded bg-primary text-primary-foreground hover:bg-primary/90 transition-colors cursor-pointer"
          >
            + 新建
          </button>
        </div>
        <div className="flex-1 overflow-auto">
          {isLoading && <p className="p-3 text-xs text-muted-foreground">加载中...</p>}
          {error && <p className="p-3 text-xs text-destructive">加载失败: {error.message}</p>}
          {list?.length === 0 && <p className="p-3 text-xs text-muted-foreground">暂无中间件</p>}
          {list?.map((item) => {
            const isActive = item.id === selected?.id
            return (
              <button
                key={item.id}
                onClick={() => { setSelected(item); setIsNew(false) }}
                className={`w-full text-left px-3 py-2.5 text-sm transition-colors cursor-pointer border-b border-border/50 ${
                  isActive ? 'bg-accent text-accent-foreground' : 'text-foreground hover:bg-accent/50'
                }`}
              >
                <div className="font-medium truncate">{item.appName}</div>
                <div className="text-xs text-muted-foreground truncate">{item.appDesc}</div>
              </button>
            )
          })}
        </div>
      </div>

      {/* 右侧：明细 */}
      <div className="flex-1 overflow-auto">
        {message && (
          <div className="fixed top-4 right-4 z-50 px-4 py-3 rounded shadow-lg text-sm border"
            style={{
              background: message.type === 'success' ? 'rgb(220 252 231)' : 'rgb(254 226 226)',
              color: message.type === 'success' ? 'rgb(22 101 52)' : 'rgb(153 27 27)',
              borderColor: message.type === 'success' ? 'rgb(187 247 208)' : 'rgb(254 202 202)',
            }}
          >
            {message.text}
          </div>
        )}

        {isNew ? (
          <MiddlewareForm
            mode="create"
            onSaved={() => {
              setIsNew(false)
              setMessage({ type: 'success', text: '保存成功' })
              queryClient.invalidateQueries({ queryKey: ['sopMiddlewares'] })
            }}
            onCancel={() => setIsNew(false)}
            onError={(err) => setMessage({ type: 'error', text: err })}
          />
        ) : selected ? (
          <MiddlewareForm
            key={selected.id}
            mode="edit"
            data={selected}
            onSaved={() => {
              setSelected(null)
              setMessage({ type: 'success', text: '保存成功' })
              queryClient.invalidateQueries({ queryKey: ['sopMiddlewares'] })
            }}
            onDeleted={() => {
              setSelected(null)
              setMessage({ type: 'success', text: '中间件已删除' })
              queryClient.invalidateQueries({ queryKey: ['sopMiddlewares'] })
            }}
            onCancel={() => setSelected(null)}
            onError={(err) => setMessage({ type: 'error', text: err })}
          />
        ) : (
          <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
            请选择左侧中间件或创建新中间件
          </div>
        )}
      </div>
    </div>
  )
}

// ====== 中间件表单 ======

interface MiddlewareFormProps {
  mode: 'create' | 'edit'
  data?: SopMiddleware
  onSaved: () => void
  onCancel: () => void
  onDeleted?: () => void
  onError: (err: string) => void
}

function MiddlewareForm({ mode, data, onSaved, onCancel, onDeleted, onError }: MiddlewareFormProps) {
  const [form, setForm] = useState<SopMiddlewareCreate>({
    appName: data?.appName ?? '',
    appDesc: data?.appDesc ?? '',
    primaryPost: data?.primaryPost ?? '',
    backupPost: data?.backupPost ?? '',
  })
  const [saving, setSaving] = useState(false)

  const createMutation = useMutation({
    mutationFn: (formData: SopMiddlewareCreate) => createSopMiddleware(formData),
  })

  const updateMutation = useMutation({
    mutationFn: (formData: SopMiddlewareCreate) => updateSopMiddleware(data!.id, formData),
  })

  const deleteMutation = useMutation({
    mutationFn: () => deleteSopMiddleware(data!.id),
  })

  const handleSubmit = async () => {
    setSaving(true)
    try {
      if (mode === 'create') {
        await createMutation.mutateAsync(form)
      } else {
        await updateMutation.mutateAsync(form)
      }
      onSaved()
    } catch (err) {
      onError(err instanceof Error ? err.message : '保存失败')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async () => {
    if (!confirm('确定要删除该中间件吗？')) return
    try {
      await deleteMutation.mutateAsync()
      onDeleted?.()
    } catch (err) {
      onError(err instanceof Error ? err.message : '删除失败')
    }
  }

  const setField = (field: keyof SopMiddlewareCreate) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }))
  }

  return (
    <div className="p-6 max-w-xl">
      <h3 className="text-lg font-bold text-foreground mb-6">
        {mode === 'create' ? '新建中间件' : '编辑中间件'}
      </h3>

      <div className="space-y-4">
        <FormField label="应用名称" required>
          <input value={form.appName} onChange={setField('appName')} placeholder="如 Redis、Kafka" className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50" />
        </FormField>
        <FormField label="应用描述" required>
          <input value={form.appDesc} onChange={setField('appDesc')} placeholder="简要描述该中间件的用途" className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50" />
        </FormField>
        <FormField label="主岗" required>
          <input value={form.primaryPost} onChange={setField('primaryPost')} placeholder="员工账号" className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50" />
        </FormField>
        <FormField label="备岗" required>
          <input value={form.backupPost} onChange={setField('backupPost')} placeholder="员工账号" className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50" />
        </FormField>
      </div>

      <div className="flex items-center justify-between mt-6">
        <div>
          {mode === 'edit' && (
            <button
              onClick={handleDelete}
              className="px-4 py-2 rounded text-sm text-destructive border border-destructive hover:bg-destructive/10 transition-colors cursor-pointer"
            >
              删除
            </button>
          )}
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={onCancel}
            className="px-4 py-2 rounded text-sm text-muted-foreground border border-border hover:bg-accent/50 transition-colors cursor-pointer"
          >
            取消
          </button>
          <button
            onClick={handleSubmit}
            disabled={saving}
            className="px-5 py-2 rounded text-sm bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 transition-colors cursor-pointer"
          >
            {saving ? '保存中...' : '保存'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ====== 表单字段 ======

function FormField({ label, required, children }: {
  label: string
  required?: boolean
  children: React.ReactNode
}) {
  return (
    <label className="block">
      <span className="text-sm font-medium text-foreground">
        {label}
        {required && <span className="text-destructive ml-0.5">*</span>}
      </span>
      <div className="mt-1.5">{children}</div>
    </label>
  )
}
