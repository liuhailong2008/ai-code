import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/_app/ops/fault-drill')({
  component: FaultDrillPage,
})

function FaultDrillPage() {
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold text-foreground">故障演练</h2>
      <p className="text-muted-foreground mt-4">故障演练列表加载中...</p>
    </div>
  )
}
