import { createFileRoute } from '@tanstack/react-router'
import { useQuery } from '@tanstack/react-query'
import { useState } from 'react'
import { listDutySchedules } from '../api/duty'
import type { DutySchedule } from '../schemas'

export const Route = createFileRoute('/_app/settings/duty')({
  component: DutySettingsPage,
})

function DutySettingsPage() {
  const now = new Date()
  const [year, setYear] = useState(now.getFullYear())
  const [month, setMonth] = useState(now.getMonth() + 1)
  const [selectedDay, setSelectedDay] = useState<number | null>(null)

  const { data: schedules = [], isLoading, error } = useQuery({
    queryKey: ['dutySchedules', year, month],
    queryFn: () => listDutySchedules(year, month),
  })

  const scheduleMap = new Map<string, DutySchedule>()
  schedules.forEach((s) => scheduleMap.set(s.scheduleDate, s))

  const daysInMonth = new Date(year, month, 0).getDate()
  const firstDayOfWeek = new Date(year, month - 1, 1).getDay()
  const startOffset = firstDayOfWeek === 0 ? 6 : firstDayOfWeek - 1

  const prevMonth = () => {
    if (month === 1) { setYear(year - 1); setMonth(12) }
    else setMonth(month - 1)
    setSelectedDay(null)
  }
  const nextMonth = () => {
    if (month === 12) { setYear(year + 1); setMonth(1) }
    else setMonth(month + 1)
    setSelectedDay(null)
  }

  const dayStr = (d: number) =>
    `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`

  return (
    <div className="flex-1 flex overflow-hidden bg-background">
      {/* ====== 左侧日历 ====== */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* 头部 */}
        <div className="flex items-center justify-between px-5 py-4 border-b shrink-0 bg-card/30">
          <div className="flex items-center gap-4">
            <button
              onClick={prevMonth}
              className="p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <h2 className="text-base font-semibold tracking-tight text-foreground">
              {year}年{month}月
            </h2>
            <button
              onClick={nextMonth}
              className="p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>

        {/* 星期标题 */}
        <div className="grid grid-cols-7 shrink-0 bg-muted/20 border-b">
          {['一', '二', '三', '四', '五', '六', '日'].map((name, i) => (
            <div
              key={name}
              className={`py-2.5 text-center text-xs tracking-wider ${
                i >= 5
                  ? 'text-muted-foreground/70 font-medium'
                  : 'text-muted-foreground font-medium'
              }`}
            >
              {name}
            </div>
          ))}
        </div>

        {/* 日历格子 */}
        <div className="grid grid-cols-7 auto-rows-fr flex-1 overflow-hidden">
          {isLoading ? (
            <div className="col-span-7 flex items-center justify-center text-sm text-muted-foreground">
              加载中...
            </div>
          ) : error ? (
            <div className="col-span-7 flex items-center justify-center text-sm text-destructive/80">
              加载失败: {error.message}
            </div>
          ) : (
            <>
              {Array.from({ length: startOffset }).map((_, i) => (
                <div key={`empty-${i}`} className="border-r border-b border-border/40 bg-muted/5" />
              ))}
              {Array.from({ length: daysInMonth }).map((_, i) => {
                const d = i + 1
                const dateKey = dayStr(d)
                const schedule = scheduleMap.get(dateKey)
                const dayOfWeek = (startOffset + d - 1) % 7
                const isWeekend = dayOfWeek >= 5
                const isToday =
                  d === now.getDate() &&
                  month === now.getMonth() + 1 &&
                  year === now.getFullYear()
                const isSelected = selectedDay === d
                const gridIdx = startOffset + d - 1
                const isChessLight = gridIdx % 2 === 0

                return (
                  <button
                    key={d}
                    onClick={() => setSelectedDay(d)}
                    className={`relative flex flex-col items-stretch border-r border-b border-border/40 p-2 text-left transition-colors overflow-hidden ${
                      isChessLight ? 'bg-muted/[0.08]' : ''
                    } ${
                      isSelected
                        ? 'bg-primary/[0.06] ring-1 ring-primary/30'
                        : 'hover:bg-accent/30'
                    }`}
                  >
                    {/* 日期数字 */}
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span
                        className={`inline-flex items-center justify-center w-7 h-7 rounded-full text-sm font-semibold shrink-0 ${
                          isToday
                            ? 'bg-primary text-primary-foreground'
                            : isWeekend
                              ? 'text-muted-foreground/60'
                              : 'text-foreground/80'
                        }`}
                      >
                        {d}
                      </span>
                      {isToday && (
                        <span className="text-[10px] text-primary/70 font-medium">今天</span>
                      )}
                    </div>

                    {/* 值班信息 */}
                    {schedule ? (
                      <div className="flex-1 flex flex-col justify-center gap-0.5 min-w-0">
                        <div className="truncate text-[11px] text-foreground/85 leading-relaxed">
                          <span className="text-muted-foreground/60 text-[10px] mr-1">主</span>
                          {schedule.primaryUser}
                        </div>
                        <div className="truncate text-[11px] text-muted-foreground/70 leading-relaxed">
                          <span className="text-muted-foreground/40 text-[10px] mr-1">备</span>
                          {schedule.backupUser}
                        </div>
                      </div>
                    ) : (
                      <div className="flex-1 flex items-center justify-center">
                        <span className="text-[11px] text-muted-foreground/30">-</span>
                      </div>
                    )}
                  </button>
                )
              })}
            </>
          )}
        </div>
      </div>

      {/* ====== 右侧查看面板 ====== */}
      <div className="w-80 border-l shrink-0 overflow-auto bg-card/30 flex flex-col">
        {selectedDay ? (
          <DutyDetail
            dateStr={dayStr(selectedDay)}
            schedule={scheduleMap.get(dayStr(selectedDay))}
          />
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center gap-3 text-muted-foreground/60">
            <svg className="w-10 h-10 opacity-30" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            <p className="text-sm">点击左侧日期查看值班详情</p>
          </div>
        )}
      </div>
    </div>
  )
}

// ====== 值班详情面板 ======

function DutyDetail({ dateStr, schedule }: { dateStr: string; schedule?: DutySchedule }) {
  if (!schedule) {
    return (
      <div className="p-5">
        <div className="flex items-center gap-2 mb-5">
          <svg className="w-4 h-4 text-muted-foreground/60" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
          <h3 className="text-sm font-semibold text-foreground">{dateStr}</h3>
        </div>
        <p className="text-sm text-muted-foreground/70">该日暂无值班安排</p>
      </div>
    )
  }

  return (
    <div className="p-5">
      <div className="flex items-center gap-2 mb-5">
        <svg className="w-4 h-4 text-primary/70" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
        <h3 className="text-sm font-semibold text-foreground">{dateStr}</h3>
      </div>

      <div className="space-y-3">
        <DetailField label="部门" value={schedule.department} />
        <DetailField label="岗位" value={schedule.positionName} />
        <div className="grid grid-cols-2 gap-3">
          <DetailField label="主岗" value={schedule.primaryUser} />
          <DetailField label="备岗" value={schedule.backupUser} />
        </div>
      </div>
    </div>
  )
}

function DetailField({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <span className="text-[11px] font-medium text-muted-foreground/70 tracking-wide">
        {label}
      </span>
      <div className="mt-1 px-3 py-2 rounded-lg border border-border/60 bg-background text-sm text-foreground/85">
        {value}
      </div>
    </div>
  )
}
