import { createFileRoute, Link, useNavigate, Outlet } from '@tanstack/react-router'
import { useQuery } from '@tanstack/react-query'
import { listSops, type SopDefinition } from '../api/sops'
import { useLocation } from '@tanstack/react-router'

export const Route = createFileRoute('/_app/sop')({
  component: SOPLayout,
})

function SOPLayout() {
  const location = useLocation()
  const isListPage = location.pathname === '/sop'

  if (!isListPage) {
    return <Outlet />
  }

  return <SOPListPage />
}

const COMPOSE_LABELS: Record<string, string> = {
  chain: 'Chain',
  graph: 'Graph',
  workflow: 'Workflow',
}

const STATUS_LABELS: Record<string, string> = {
  draft: '草稿',
  published: '已发布',
  deprecated: '已废弃',
}

function SOPListPage() {
  const navigate = useNavigate()
  const { data: sops, isLoading } = useQuery({
    queryKey: ['sops'],
    queryFn: () => listSops(),
  })

  return (
    <div className="flex-1 overflow-auto p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-foreground">SOP 管理</h2>
        <button
          onClick={() => navigate({ to: '/sop/new' })}
          className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors cursor-pointer"
        >
          + 新增 SOP
        </button>
      </div>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">加载中...</p>
      ) : (
        <div className="border border-border rounded overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted">
              <tr>
                <th className="text-left px-4 py-2 font-medium">编码</th>
                <th className="text-left px-4 py-2 font-medium">名称</th>
                <th className="text-left px-4 py-2 font-medium">分类</th>
                <th className="text-left px-4 py-2 font-medium">编排类型</th>
                <th className="text-left px-4 py-2 font-medium">状态</th>
                <th className="text-left px-4 py-2 font-medium">操作</th>
              </tr>
            </thead>
            <tbody>
              {(sops && sops.length > 0) ? sops.map((sop: SopDefinition) => (
                <tr key={sop.id} className="border-t border-border hover:bg-accent/30">
                  <td className="px-4 py-2 font-mono text-xs">{sop.sopCode}</td>
                  <td className="px-4 py-2">{sop.sopName}</td>
                  <td className="px-4 py-2">{sop.sopCategory}</td>
                  <td className="px-4 py-2">
                    <span className={`text-xs px-1.5 py-0.5 rounded ${
                      sop.composeType === 'graph' ? 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300' :
                      sop.composeType === 'workflow' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300' :
                      'bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-300'
                    }`}>
                      {COMPOSE_LABELS[sop.composeType] || sop.composeType}
                    </span>
                  </td>
                  <td className="px-4 py-2">
                    <span className={`text-xs px-1.5 py-0.5 rounded ${
                      sop.status === 'published' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300' :
                      sop.status === 'draft' ? 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-300' :
                      'bg-muted text-muted-foreground'
                    }`}>
                      {STATUS_LABELS[sop.status] || sop.status}
                    </span>
                  </td>
                  <td className="px-4 py-2">
                    <div className="flex gap-2">
                      <Link
                        to="/sop/$id"
                        params={{ id: String(sop.id) }}
                        className="text-xs text-primary hover:underline cursor-pointer"
                      >
                        查看
                      </Link>
                      <Link
                        to="/sop/$id/edit"
                        params={{ id: String(sop.id) }}
                        className="text-xs text-primary hover:underline cursor-pointer"
                      >
                        编辑
                      </Link>
                    </div>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-muted-foreground">
                    暂无 SOP，点击"新增 SOP"创建
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}