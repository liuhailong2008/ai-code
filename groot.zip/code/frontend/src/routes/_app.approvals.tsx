import { createFileRoute } from '@tanstack/react-router'
import { useQuery } from '@tanstack/react-query'
import { listApprovals } from '../api/approvals'
import { ApprovalCard } from '../components/approval/ApprovalCard'

export const Route = createFileRoute('/_app/approvals')({
  component: ApprovalsPage,
})

function ApprovalsPage() {
  const { data: approvals, isLoading, error } = useQuery({
    queryKey: ['approvals'],
    queryFn: listApprovals,
  })

  return (
    <main className="flex-1 overflow-auto p-6">
      <h2 className="text-xl font-bold mb-4 text-foreground">待审批</h2>

        {isLoading && <p className="text-muted-foreground">加载中...</p>}

        {error && (
          <div className="p-4 border border-destructive rounded bg-destructive/10 text-destructive">
            加载失败: {(error as Error).message}
          </div>
        )}

        {approvals && approvals.length === 0 && (
          <p className="text-muted-foreground">暂无待审批项</p>
        )}

        <div className="space-y-3 max-w-lg">
          {approvals?.map((approval) => (
            <ApprovalCard key={approval.id} approval={approval} />
          ))}
        </div>
    </main>
  )
}