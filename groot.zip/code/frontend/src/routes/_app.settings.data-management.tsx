import { createFileRoute } from '@tanstack/react-router'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState, useEffect, type FormEvent } from 'react'
import { listTables, getTableData, insertRow, updateRow, deleteRow, type TableInfo, type TableData } from '../api/data-management'

export const Route = createFileRoute('/_app/settings/data-management')({
  component: DataManagementPage,
})

function DataManagementPage() {
  const [selectedTable, setSelectedTable] = useState<string | null>(null)
  const [page, setPage] = useState(1)
  const [editingRow, setEditingRow] = useState<Record<string, unknown> | null>(null)
  const [showInsertForm, setShowInsertForm] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const queryClient = useQueryClient()
  const pageSize = 15

  const { data: tables, isLoading, error } = useQuery({
    queryKey: ['dm-tables'],
    queryFn: listTables,
  })

  const { data: tableData, isLoading: dataLoading } = useQuery({
    queryKey: ['dm-table-data', selectedTable, page],
    queryFn: () => getTableData(selectedTable!, page, pageSize),
    enabled: !!selectedTable,
  })

  const insertMutation = useMutation({
    mutationFn: (data: Record<string, unknown>) => insertRow(selectedTable!, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dm-tables'] })
      queryClient.invalidateQueries({ queryKey: ['dm-table-data', selectedTable] })
      setShowInsertForm(false)
      setErrorMessage(null)
    },
    onError: (err: Error) => setErrorMessage(err.message),
  })

  const updateMutation = useMutation({
    mutationFn: ({ rowId, data }: { rowId: number; data: Record<string, unknown> }) =>
      updateRow(selectedTable!, rowId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dm-tables'] })
      queryClient.invalidateQueries({ queryKey: ['dm-table-data', selectedTable] })
      setEditingRow(null)
      setErrorMessage(null)
    },
    onError: (err: Error) => setErrorMessage(err.message),
  })

  const deleteMutation = useMutation({
    mutationFn: (rowId: number) => deleteRow(selectedTable!, rowId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dm-tables'] })
      queryClient.invalidateQueries({ queryKey: ['dm-table-data', selectedTable] })
      setErrorMessage(null)
    },
    onError: (err: Error) => setErrorMessage(err.message),
  })

  const totalPages = tableData ? Math.ceil(tableData.total / pageSize) : 0

  const handleSelectTable = (name: string) => {
    setSelectedTable(name)
    setPage(1)
    setEditingRow(null)
    setShowInsertForm(false)
  }

  // 错误提示 5 秒自动消失
  useEffect(() => {
    if (!errorMessage) return
    const timer = setTimeout(() => setErrorMessage(null), 5000)
    return () => clearTimeout(timer)
  }, [errorMessage])

  return (
    <div className="flex-1 flex overflow-hidden">
      <TableList tables={tables} isLoading={isLoading} error={error} selectedTable={selectedTable} onSelect={handleSelectTable} />

      <div className="flex-1 flex flex-col overflow-hidden">
        {selectedTable ? (
          <>
            {errorMessage && (
              <div className="fixed top-16 left-1/2 -translate-x-1/2 z-[60] max-w-lg p-3 text-sm text-destructive bg-destructive/10 border border-destructive/30 rounded-lg shadow-lg flex items-center justify-between gap-3 animate-in fade-in slide-in-from-top-2">
                <span>{errorMessage}</span>
                <button onClick={() => setErrorMessage(null)} className="text-destructive hover:opacity-70 shrink-0 text-base leading-none">&times;</button>
              </div>
            )}
            <div className="p-3 border-b border-border flex items-center justify-between shrink-0">
              <h3 className="text-lg font-bold text-foreground">
                {selectedTable}
                {tableData && <span className="text-sm font-normal text-muted-foreground ml-2">共 {tableData.total} 行</span>}
              </h3>
              <button
                onClick={() => setShowInsertForm(true)}
                className="px-3 py-1.5 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90"
              >
                + 新增
              </button>
            </div>

            {showInsertForm && tableData && (
              <EditModal
                title="新增数据"
                columns={(tableData?.columns ?? []).filter((c) => c !== 'id')}
                initialValues={{}}
                onSave={(data) => insertMutation.mutate(data)}
                onCancel={() => setShowInsertForm(false)}
                isSaving={insertMutation.isPending}
              />
            )}

            {editingRow && tableData && (
              <EditModal
                title="编辑数据"
                columns={(tableData?.columns ?? []).filter((c) => c !== 'id')}
                initialValues={editingRow}
                onSave={(data) => updateMutation.mutate({ rowId: editingRow.id as number, data })}
                onCancel={() => setEditingRow(null)}
                isSaving={updateMutation.isPending}
              />
            )}

            <div className="flex-1 overflow-auto">
              {dataLoading ? (
                <p className="p-4 text-sm text-muted-foreground">加载中...</p>
              ) : tableData ? (
                <DataTable
                  data={tableData}
                  onEdit={(row) => setEditingRow(row)}
                  onDelete={(rowId) => {
                    if (confirm('确认删除此行？')) deleteMutation.mutate(rowId)
                  }}
                />
              ) : null}
            </div>

            {totalPages > 1 && (
              <Pagination page={page} totalPages={totalPages} onPageChange={setPage} />
            )}
          </>
        ) : (
          <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
            请选择左侧表名查看数据
          </div>
        )}
      </div>
    </div>
  )
}

// ====== 左侧表名列表 ======

interface TableListProps {
  tables?: TableInfo[]
  isLoading: boolean
  error: Error | null
  selectedTable: string | null
  onSelect: (tableName: string) => void
}

function TableList({ tables, isLoading, error, selectedTable, onSelect }: TableListProps) {
  return (
    <div className="w-60 border-r border-border shrink-0 flex flex-col">
      <div className="p-3 border-b border-border">
        <h3 className="text-sm font-semibold text-foreground">数据表</h3>
      </div>
      <div className="flex-1 overflow-auto">
        {isLoading && <p className="p-3 text-xs text-muted-foreground">加载中...</p>}
        {error && <p className="p-3 text-xs text-destructive">加载失败: {error.message}</p>}
        {tables?.length === 0 && <p className="p-3 text-xs text-muted-foreground">暂无表</p>}
        {tables?.map((table) => {
          const isActive = table.name === selectedTable
          return (
            <button
              key={table.name}
              onClick={() => onSelect(table.name)}
              className={`w-full text-left px-3 py-2.5 text-sm transition-colors cursor-pointer border-b border-border/50 ${
                isActive ? 'bg-accent text-accent-foreground' : 'text-foreground hover:bg-accent/50'
              }`}
            >
              <div className="font-medium truncate">{table.name}</div>
              <div className="text-xs text-muted-foreground">{table.rowCount} 行</div>
            </button>
          )
        })}
      </div>
    </div>
  )
}

// ====== 数据表格 ======

interface DataTableProps {
  data: TableData
  onEdit: (row: Record<string, unknown>) => void
  onDelete: (rowId: number) => void
}

function DataTable({ data, onEdit, onDelete }: DataTableProps) {
  const { columns, rows } = data
  const visibleColumns = columns.filter((c) => c !== 'id')

  return (
    <div className="overflow-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="bg-muted/50">
            <th className="text-left px-3 py-2 font-medium text-foreground border-b border-border whitespace-nowrap">#</th>
            {visibleColumns.map((col) => (
              <th key={col} className="text-left px-3 py-2 font-medium text-foreground border-b border-border whitespace-nowrap">
                {col}
              </th>
            ))}
            <th className="text-left px-3 py-2 font-medium text-foreground border-b border-border whitespace-nowrap">操作</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row, idx) => (
            <tr key={idx} className="border-b border-border/50 hover:bg-accent/30 transition-colors">
              <td className="px-3 py-2 text-muted-foreground">{(data.page - 1) * data.pageSize + idx + 1}</td>
              {visibleColumns.map((col) => (
                <td key={col} className="px-3 py-2 text-foreground max-w-[200px] truncate" title={renderValue(row[col])}>
                  {renderValue(row[col])}
                </td>
              ))}
              <td className="px-3 py-2 whitespace-nowrap">
                <button onClick={() => onEdit(row)} className="text-xs text-primary hover:underline mr-2">编辑</button>
                <button onClick={() => onDelete(row.id as number)} className="text-xs text-destructive hover:underline">删除</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

// ====== 编辑/新增弹窗 ======

interface EditModalProps {
  title: string
  columns: string[]
  initialValues: Record<string, unknown>
  onSave: (data: Record<string, unknown>) => void
  onCancel: () => void
  isSaving: boolean
}

function EditModal({ title, columns, initialValues, onSave, onCancel, isSaving }: EditModalProps) {
  const [values, setValues] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {}
    for (const col of columns) {
      const v = initialValues[col]
      if (v === null || v === undefined) {
        init[col] = ''
      } else if (typeof v === 'object') {
        init[col] = JSON.stringify(v)
      } else {
        init[col] = String(v)
      }
    }
    return init
  })

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    const data: Record<string, unknown> = {}
    for (const col of columns) {
      const v = (values[col] ?? '').trim()
      if (v === '') {
        data[col] = null
      } else {
        // 保持原始类型：数字字符串尝试转为数字
        const orig = initialValues[col]
        if (typeof orig === 'number' && /^-?\d+(\.\d+)?$/.test(v)) {
          data[col] = Number(v)
        } else {
          data[col] = v
        }
      }
    }
    onSave(data)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-card border border-border rounded-lg shadow-lg w-[560px] max-h-[80vh] flex flex-col">
        <div className="p-4 border-b border-border flex items-center justify-between">
          <h3 className="text-base font-semibold text-foreground">{title}</h3>
          <button onClick={onCancel} className="text-muted-foreground hover:text-foreground text-lg leading-none">&times;</button>
        </div>
        <form onSubmit={handleSubmit} className="p-4 overflow-auto flex-1">
          <div className="space-y-3">
            {columns.map((col) => (
              <div key={col} className="flex flex-col gap-1">
                <label className="text-xs font-medium text-muted-foreground">
                  {col}
                  {initialValues[col] === null && <span className="text-destructive ml-1">(NULL)</span>}
                </label>
                <input
                  type="text"
                  value={values[col]}
                  onChange={(e) => setValues({ ...values, [col]: e.target.value })}
                  className="w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                  placeholder="留空保存为 NULL"
                />
              </div>
            ))}
          </div>
          <div className="flex justify-end gap-2 mt-6">
            <button type="button" onClick={onCancel} className="px-4 py-2 text-sm border border-border rounded text-foreground hover:bg-accent">
              取消
            </button>
            <button type="submit" disabled={isSaving} className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90 disabled:opacity-50">
              {isSaving ? '保存中...' : '保存'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

// ====== 分页 ======

interface PaginationProps {
  page: number
  totalPages: number
  onPageChange: (page: number) => void
}

function Pagination({ page, totalPages, onPageChange }: PaginationProps) {
  return (
    <div className="p-3 border-t border-border flex items-center justify-center gap-1 shrink-0">
      <button onClick={() => onPageChange(1)} disabled={page === 1} className="px-2 py-1 text-xs border border-border rounded disabled:opacity-30 hover:bg-accent">
        首页
      </button>
      <button onClick={() => onPageChange(page - 1)} disabled={page === 1} className="px-2 py-1 text-xs border border-border rounded disabled:opacity-30 hover:bg-accent">
        上一页
      </button>
      <span className="px-3 py-1 text-xs text-muted-foreground">
        第 {page} / {totalPages} 页
      </span>
      <button onClick={() => onPageChange(page + 1)} disabled={page === totalPages} className="px-2 py-1 text-xs border border-border rounded disabled:opacity-30 hover:bg-accent">
        下一页
      </button>
      <button onClick={() => onPageChange(totalPages)} disabled={page === totalPages} className="px-2 py-1 text-xs border border-border rounded disabled:opacity-30 hover:bg-accent">
        末页
      </button>
    </div>
  )
}

// ====== helpers ======

function renderValue(value: unknown): string {
  if (value === null || value === undefined) return '-'
  if (typeof value === 'object') return JSON.stringify(value)
  return String(value)
}
