import { createFileRoute } from '@tanstack/react-router'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState, useRef, useEffect } from 'react'
import { listTeams, createTeam, updateTeam, deleteTeam } from '../api/teams'
import { listTeamMembers, addTeamMember, removeTeamMember, searchUsers } from '../api/members'
import type { Team, TeamCreate, TeamUpdate, User } from '../schemas'
import type { TeamMember } from '../api/members'

export const Route = createFileRoute('/_app/settings/team')({
  component: TeamSettingsPage,
})

function TeamSettingsPage() {
  const queryClient = useQueryClient()
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null)
  const [activeTab, setActiveTab] = useState<'info' | 'members'>('info')
  const [isNew, setIsNew] = useState(false)

  const { data: teams, isLoading, error } = useQuery({
    queryKey: ['teams'],
    queryFn: listTeams,
  })

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* 左侧：团队列表 */}
      <TeamList
        teams={teams}
        isLoading={isLoading}
        error={error}
        selectedId={selectedTeam?.id ?? null}
        activeTab={activeTab}
        onSelect={(team) => {
          setSelectedTeam(team)
          setIsNew(false)
        }}
        onNew={() => {
          setSelectedTeam(null)
          setIsNew(true)
          setActiveTab('info')
        }}
      />

      {/* 右侧：明细 */}
      <div className="flex-1 overflow-auto">
        {isNew ? (
          <TeamForm
            mode="create"
            onSaved={(newTeam) => {
              setSelectedTeam(newTeam)
              setIsNew(false)
              setActiveTab('info')
              queryClient.invalidateQueries({ queryKey: ['teams'] })
            }}
            onCancel={() => setIsNew(false)}
          />
        ) : selectedTeam ? (
          <TeamDetail
            team={selectedTeam}
            activeTab={activeTab}
            onTabChange={setActiveTab}
            onDeleted={() => {
              setSelectedTeam(null)
              queryClient.invalidateQueries({ queryKey: ['teams'] })
            }}
            onSaved={(updated) => {
              setSelectedTeam(updated)
              queryClient.invalidateQueries({ queryKey: ['teams'] })
            }}
            onCancel={() => setSelectedTeam(null)}
          />
        ) : (
          <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
            请选择左侧团队或创建新团队
          </div>
        )}
      </div>
    </div>
  )
}

// ====== 左侧团队列表 ======

interface TeamListProps {
  teams?: Team[]
  isLoading: boolean
  error: Error | null
  selectedId: number | null
  activeTab: string
  onSelect: (team: Team) => void
  onNew: () => void
}

function TeamList({ teams, isLoading, error, selectedId, onSelect, onNew }: TeamListProps) {
  return (
    <div className="w-56 border-r border-border shrink-0 flex flex-col">
      <div className="p-3 border-b border-border flex items-center justify-between">
        <h3 className="text-sm font-semibold text-foreground">团队列表</h3>
        <button
          onClick={onNew}
          className="text-xs px-2 py-1 rounded bg-primary text-primary-foreground hover:bg-primary/90 transition-colors cursor-pointer"
        >
          + 新建
        </button>
      </div>
      <div className="flex-1 overflow-auto">
        {isLoading && (
          <p className="p-3 text-xs text-muted-foreground">加载中...</p>
        )}
        {error && (
          <p className="p-3 text-xs text-destructive">加载失败: {error.message}</p>
        )}
        {teams?.length === 0 && (
          <p className="p-3 text-xs text-muted-foreground">暂无团队</p>
        )}
        {teams?.map((team) => {
          const isActive = team.id === selectedId
          return (
            <button
              key={team.id}
              onClick={() => onSelect(team)}
              className={`w-full text-left px-3 py-2.5 text-sm transition-colors cursor-pointer border-b border-border/50 ${
                isActive
                  ? 'bg-accent text-accent-foreground'
                  : 'text-foreground hover:bg-accent/50'
              }`}
            >
              <div className="font-medium truncate">{team.name}</div>
              <div className="text-xs text-muted-foreground truncate">{team.code}</div>
            </button>
          )
        })}
      </div>
    </div>
  )
}

// ====== 右侧详情（标签切换） ======

interface TeamDetailProps {
  team: Team
  activeTab: string
  onTabChange: (tab: 'info' | 'members') => void
  onSaved: (team: Team) => void
  onCancel: () => void
  onDeleted: () => void
}

function TeamDetail({ team, activeTab, onTabChange, onSaved, onCancel, onDeleted }: TeamDetailProps) {
  return (
    <div className="flex flex-col h-full">
      {/* 标签栏 */}
      <div className="flex border-b border-border px-6 pt-4 gap-4">
        <button
          onClick={() => onTabChange('info')}
          className={`pb-2 text-sm border-b-2 transition-colors cursor-pointer ${
            activeTab === 'info'
              ? 'border-primary text-primary font-medium'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          基本信息
        </button>
        <button
          onClick={() => onTabChange('members')}
          className={`pb-2 text-sm border-b-2 transition-colors cursor-pointer ${
            activeTab === 'members'
              ? 'border-primary text-primary font-medium'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          团队成员
        </button>
      </div>

      {/* 内容区 */}
      <div className="flex-1 overflow-auto">
        {activeTab === 'info' ? (
          <TeamForm
            mode="edit"
            team={team}
            onSaved={onSaved}
            onCancel={onCancel}
            onDeleted={onDeleted}
          />
        ) : (
          <TeamMembersPanel teamId={team.id} />
        )}
      </div>
    </div>
  )
}

// ====== 团队成员面板 ======

function TeamMembersPanel({ teamId }: { teamId: number }) {
  const queryClient = useQueryClient()

  const { data: members, isLoading, error } = useQuery({
    queryKey: ['teamMembers', teamId],
    queryFn: () => listTeamMembers(teamId),
  })

  const removeMutation = useMutation({
    mutationFn: (userId: number) => removeTeamMember(teamId, userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['teamMembers', teamId] })
    },
  })

  return (
    <div className="p-6 max-w-2xl">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-foreground">
          团队成员 ({members?.length ?? 0})
        </h3>
      </div>

      <AddMemberInput teamId={teamId} members={members || []} />

      <div className="mt-4 space-y-1">
        {isLoading && <p className="text-sm text-muted-foreground">加载中...</p>}
        {error && <p className="text-sm text-destructive">加载失败: {error.message}</p>}
        {members?.length === 0 && (
          <p className="text-sm text-muted-foreground">暂无成员</p>
        )}
        {members?.map((m) => (
          <div
            key={m.id}
            className="flex items-center justify-between px-3 py-2.5 rounded border border-border bg-card"
          >
            <div>
              <span className="text-sm text-foreground font-medium">{m.displayName}</span>
              <span className="text-xs text-muted-foreground ml-2">@{m.username}</span>
              <span className="text-xs text-muted-foreground ml-2">
                {m.role === 'admin' ? '管理员' : m.role === 'operator' ? '操作员' : '观察者'}
              </span>
            </div>
            <button
              onClick={() => {
                if (confirm(`确定要移除 ${m.displayName} 吗？`)) {
                  removeMutation.mutate(m.userId)
                }
              }}
              className="text-xs text-destructive hover:underline cursor-pointer"
            >
              移除
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

// ====== 添加成员（自动提示） ======

function AddMemberInput({ teamId, members }: { teamId: number; members: TeamMember[] }) {
  const queryClient = useQueryClient()
  const [keyword, setKeyword] = useState('')
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [selectedIndex, setSelectedIndex] = useState(-1)
  const inputRef = useRef<HTMLInputElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)

  const { data: suggestions } = useQuery({
    queryKey: ['userSearch', keyword],
    queryFn: () => searchUsers(keyword),
    enabled: keyword.length >= 1,
  })

  const addMutation = useMutation({
    mutationFn: (userId: number) => addTeamMember(teamId, userId),
    onSuccess: () => {
      setKeyword('')
      setShowSuggestions(false)
      setSelectedIndex(-1)
      queryClient.invalidateQueries({ queryKey: ['teamMembers', teamId] })
    },
  })

  const filtered = (suggestions || []).filter(
    (u) => !members.some((m) => m.userId === u.id)
  )

  const handleSelect = (user: User) => {
    if (!members.some((m) => m.userId === user.id)) {
      addMutation.mutate(user.id)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!showSuggestions || filtered.length === 0) return
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setSelectedIndex((prev) => (prev < filtered.length - 1 ? prev + 1 : 0))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setSelectedIndex((prev) => (prev > 0 ? prev - 1 : filtered.length - 1))
    } else if (e.key === 'Enter') {
      e.preventDefault()
      const idx = selectedIndex >= 0 ? selectedIndex : 0
      if (filtered[idx]) handleSelect(filtered[idx])
    } else if (e.key === 'Escape') {
      setShowSuggestions(false)
      setSelectedIndex(-1)
    }
  }

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowSuggestions(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  return (
    <div ref={containerRef} className="relative">
      <input
        ref={inputRef}
        value={keyword}
        onChange={(e) => {
          setKeyword(e.target.value)
          setShowSuggestions(true)
          setSelectedIndex(-1)
        }}
        onFocus={() => keyword.length >= 1 && setShowSuggestions(true)}
        onKeyDown={handleKeyDown}
        placeholder="输入用户名或显示名搜索添加..."
        className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
      />

      {showSuggestions && keyword.length >= 1 && (
        <div className="absolute top-full mt-1 left-0 right-0 bg-card border border-border rounded shadow-lg z-10 max-h-48 overflow-auto">
          {filtered.length === 0 ? (
            <div className="px-3 py-2 text-xs text-muted-foreground">
              {suggestions ? '无匹配用户' : '搜索中...'}
            </div>
          ) : (
            filtered.map((user, idx) => (
              <button
                key={user.id}
                onClick={() => handleSelect(user)}
                onMouseEnter={() => setSelectedIndex(idx)}
                className={`w-full text-left px-3 py-2 text-sm transition-colors cursor-pointer ${
                  idx === selectedIndex ? 'bg-accent' : 'hover:bg-accent/50'
                }`}
              >
                <span className="font-medium text-foreground">{user.displayName}</span>
                <span className="text-xs text-muted-foreground ml-2">@{user.username}</span>
                <span className="text-xs text-muted-foreground ml-1">
                  ({user.role === 'admin' ? '管理员' : user.role === 'operator' ? '操作员' : '观察者'})
                </span>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  )
}

// ====== 团队表单 ======

interface TeamFormProps {
  mode: 'create' | 'edit'
  team?: Team
  onSaved: (team: Team) => void
  onCancel: () => void
  onDeleted?: () => void
}

function TeamForm({ mode, team, onSaved, onCancel, onDeleted }: TeamFormProps) {
  const [form, setForm] = useState<TeamCreate>({
    code: team?.code ?? '',
    name: team?.name ?? '',
    description: team?.description ?? '',
    wechatId: team?.wechatId ?? '',
    teamEmail: team?.teamEmail ?? '',
    techLeader: team?.techLeader ?? '',
    teamLeader: team?.teamLeader ?? '',
  })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const createMutation = useMutation({
    mutationFn: (data: TeamCreate) => createTeam(data),
  })

  const updateMutation = useMutation({
    mutationFn: (data: TeamUpdate) => updateTeam(team!.id, data),
  })

  const deleteMutation = useMutation({
    mutationFn: () => deleteTeam(team!.id),
  })

  const handleSubmit = async () => {
    setError(null)
    setSaving(true)
    try {
      if (mode === 'create') {
        const result = await createMutation.mutateAsync(form)
        onSaved(result)
      } else {
        const changed: Record<string, unknown> = {}
        const fields: (keyof TeamCreate)[] = ['code', 'name', 'description', 'wechatId', 'teamEmail', 'techLeader', 'teamLeader']
        for (const f of fields) {
          const newVal = form[f]
          const oldVal = (team as Team)[f]
          if (newVal !== (oldVal ?? '')) {
            changed[f] = newVal || null
          }
        }
        if (Object.keys(changed).length === 0) {
          onCancel()
          return
        }
        const result = await updateMutation.mutateAsync(changed as TeamUpdate)
        onSaved(result)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : '保存失败')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async () => {
    if (!confirm('确定要删除该团队吗？')) return
    try {
      await deleteMutation.mutateAsync()
      onDeleted?.()
    } catch (err) {
      setError(err instanceof Error ? err.message : '删除失败')
    }
  }

  const setField = (field: keyof TeamCreate) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((prev) => ({ ...prev, [field]: e.target.value }))
  }

  return (
    <div className="p-6 max-w-xl">
      <h3 className="text-lg font-bold text-foreground mb-6">
        {mode === 'create' ? '新建团队' : '编辑团队'}
      </h3>

      {error && (
        <div className="mb-4 p-3 border border-destructive rounded bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      <div className="space-y-4">
        <FormField label="团队编码" required>
          <input
            value={form.code}
            onChange={setField('code')}
            placeholder="请输入团队编码"
            className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </FormField>

        <FormField label="团队名称" required>
          <input
            value={form.name}
            onChange={setField('name')}
            placeholder="请输入团队名称"
            className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </FormField>

        <FormField label="团队介绍">
          <textarea
            value={form.description ?? ''}
            onChange={setField('description')}
            placeholder="请输入团队介绍"
            rows={3}
            className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
          />
        </FormField>

        <FormField label="企业微信群编码">
          <input
            value={form.wechatId ?? ''}
            onChange={setField('wechatId')}
            placeholder="请输入企业微信群编码"
            className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </FormField>

        <FormField label="团队邮箱">
          <input
            value={form.teamEmail ?? ''}
            onChange={setField('teamEmail')}
            placeholder="请输入团队邮箱"
            className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </FormField>

        <div className="grid grid-cols-2 gap-4">
          <FormField label="专业负责人">
            <input
              value={form.techLeader ?? ''}
              onChange={setField('techLeader')}
              placeholder="员工账号"
              className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          </FormField>
          <FormField label="团队负责人">
            <input
              value={form.teamLeader ?? ''}
              onChange={setField('teamLeader')}
              placeholder="员工账号"
              className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          </FormField>
        </div>
      </div>

      <div className="flex items-center justify-between mt-6">
        <div>
          {mode === 'edit' && (
            <button
              onClick={handleDelete}
              className="px-4 py-2 rounded text-sm text-destructive border border-destructive hover:bg-destructive/10 transition-colors cursor-pointer"
            >
              删除团队
            </button>
          )}
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={onCancel}
            className="px-4 py-2 rounded text-sm text-muted-foreground border border-border hover:bg-accent/50 transition-colors cursor-pointer"
          >
            取消
          </button>
          <button
            onClick={handleSubmit}
            disabled={saving}
            className="px-5 py-2 rounded text-sm bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 transition-colors cursor-pointer"
          >
            {saving ? '保存中...' : '保存'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ====== 表单字段 ======

function FormField({ label, required, children }: {
  label: string
  required?: boolean
  children: React.ReactNode
}) {
  return (
    <label className="block">
      <span className="text-sm font-medium text-foreground">
        {label}
        {required && <span className="text-destructive ml-0.5">*</span>}
      </span>
      <div className="mt-1.5">{children}</div>
    </label>
  )
}