import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/_app/settings/system')({
  component: SystemSettingsPage,
})

function SystemSettingsPage() {
  return (
    <div className="flex-1 overflow-auto p-6">
      <h2 className="text-xl font-bold text-foreground mb-4">系统设置</h2>
      <div className="space-y-4">
        <div className="p-4 border border-border rounded bg-card">
          <h3 className="font-medium text-foreground mb-2">系统配置</h3>
          <p className="text-sm text-muted-foreground">系统级别的配置项加载中...</p>
        </div>
      </div>
    </div>
  )
}