import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { useQuery } from '@tanstack/react-query'
import { useState } from 'react'
import { getSop, updateSop } from '../api/sops'
import { SopBasicForm } from './_app.sop.new'

export const Route = createFileRoute('/_app/sop/$id')({
  component: SOPDetailPage,
})

// Simple SVG graph renderer for nodes and edges visualization
function GraphPreview({ nodes, edges }: { nodes: any[]; edges: any[] }) {
  const nodeRadius = 30
  const padding = 50
  const spacing = 120
  const cols = Math.max(3, Math.min(5, Math.ceil(Math.sqrt(nodes.length))))
  const rows = Math.ceil(nodes.length / cols)
  const width = cols * spacing + padding * 2
  const height = Math.max(200, rows * spacing + padding * 2)

  const positions = nodes.map((_: any, i: number) => {
    const col = i % cols
    const row = Math.floor(i / cols)
    return {
      x: padding + col * spacing,
      y: padding + row * spacing,
    }
  })

  // Build edge lines
  const edgeLines: { x1: number; y1: number; x2: number; y2: number; label?: string }[] = []
  edges.forEach((edge: any) => {
    const fromIdx = nodes.findIndex((n: any) => n.nodeKey === edge.fromNode || n.nodeKey === edge.from_node)
    const toIdx = nodes.findIndex((n: any) => n.nodeKey === edge.toNode || n.nodeKey === edge.to_node)
    if (fromIdx >= 0 && toIdx >= 0) {
      edgeLines.push({
        x1: positions[fromIdx].x,
        y1: positions[fromIdx].y + nodeRadius,
        x2: positions[toIdx].x,
        y2: positions[toIdx].y - nodeRadius,
        label: edge.edgeType || edge.edge_type,
      })
    }
  })

  const nodeTypes: Record<string, string> = {
    tool: '#3b82f6',
    llm: '#8b5cf6',
    prompt: '#f59e0b',
    lambda: '#10b981',
    condition: '#ef4444',
    sub_sop: '#ec4899',
  }

  return (
    <svg width={width} height={height} className="max-w-full" style={{ fontFamily: 'system-ui, -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif' }}>
      {/* Edges */}
      {edgeLines.map((line, i) => (
        <g key={`edge-${i}`}>
          <defs>
            <marker id={`arrow-${i}`} viewBox="0 0 10 10" refX="10" refY="5" markerWidth="6" markerHeight="6" orient="auto">
              <path d="M 0 0 L 10 5 L 0 10 Z" fill="#94a3b8" />
            </marker>
          </defs>
          <line
            x1={line.x1} y1={line.y1} x2={line.x2} y2={line.y2}
            stroke="#94a3b8" strokeWidth="1.5"
            markerEnd={`url(#arrow-${i})`}
          />
          {line.label && line.label !== 'both' && (
            <text x={(line.x1 + line.x2) / 2} y={(line.y1 + line.y2) / 2 - 4} textAnchor="middle" fontSize="10" fill="#94a3b8">
              {line.label}
            </text>
          )}
        </g>
      ))}
      {/* Nodes */}
      {nodes.map((node: any, i: number) => {
        const pos = positions[i]
        const fill = nodeTypes[node.nodeType || node.node_type] || '#64748b'
        const label = node.nodeName || node.node_name || '?'
        return (
          <g key={`node-${i}`}>
            <circle cx={pos.x} cy={pos.y} r={nodeRadius} fill={fill} opacity="0.2" />
            <circle cx={pos.x} cy={pos.y} r={nodeRadius} fill="none" stroke={fill} strokeWidth="2" />
            <text x={pos.x} y={pos.y - 4} textAnchor="middle" fontSize="11" fontWeight="bold" fill={fill}>
              {node.nodeType || node.node_type}
            </text>
            <text x={pos.x} y={pos.y + 12} textAnchor="middle" fontSize="9" fill="currentColor">
              {label.length > 8 ? label.slice(0, 7) + '…' : label}
            </text>
          </g>
        )
      })}
    </svg>
  )
}

function SOPDetailPage() {
  const navigate = useNavigate()
  const { id } = Route.useParams()
  const sopId = parseInt(id, 10)

  const { data: sop, isLoading } = useQuery({
    queryKey: ['sop', sopId],
    queryFn: () => getSop(sopId),
    enabled: !isNaN(sopId),
  })

  const [editing, setEditing] = useState(false)
  const [nodesJson, setNodesJson] = useState('[]')
  const [edgesJson, setEdgesJson] = useState('[]')
  const [saving, setSaving] = useState(false)
  const [saveMsg, setSaveMsg] = useState('')

  const initEditor = () => {
    setEditing(true)
    // Load nodes/edges from schema if available
    try {
      const inputSchema = sop?.inputSchema ? JSON.parse(sop.inputSchema) : {}
      setNodesJson(JSON.stringify(inputSchema.nodes || [], null, 2))
      setEdgesJson(JSON.stringify(inputSchema.edges || [], null, 2))
    } catch {
      setNodesJson('[]')
      setEdgesJson('[]')
    }
  }

  const handleSaveGraph = async () => {
    setSaving(true)
    setSaveMsg('')
    try {
      const nodes = JSON.parse(nodesJson)
      const edges = JSON.parse(edgesJson)
      await updateSop(sopId, {
        inputSchema: JSON.stringify({ nodes, edges }),
      })
      setSaveMsg('保存成功')
    } catch (e: any) {
      if (e instanceof SyntaxError) {
        setSaveMsg('JSON 格式错误')
      } else {
        setSaveMsg(e?.message || '保存失败')
      }
    } finally {
      setSaving(false)
    }
  }

  const parsedNodes = (() => { try { return JSON.parse(nodesJson) } catch { return [] } })()
  const parsedEdges = (() => { try { return JSON.parse(edgesJson) } catch { return [] } })()

  if (isLoading) {
    return (
      <div className="flex-1 overflow-auto p-6">
        <p className="text-sm text-muted-foreground">加载中...</p>
      </div>
    )
  }

  if (!sop) {
    return (
      <div className="flex-1 overflow-auto p-6">
        <p className="text-sm text-muted-foreground">SOP 不存在</p>
      </div>
    )
  }

  return (
    <div className="flex-1 flex flex-col h-full">
      {/* Header with back button */}
      <div className="flex items-center gap-3 px-6 py-3 border-b border-border bg-card/50 sticky top-0 z-10">
        <button
          onClick={() => navigate({ to: '/sop' })}
          className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          返回
        </button>
        <div className="flex-1">
          <h2 className="text-lg font-bold text-foreground">{sop.sopName}</h2>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => editing ? setEditing(false) : initEditor()}
            className="px-3 py-1.5 rounded border border-border text-sm hover:bg-accent cursor-pointer"
          >
            {editing ? '取消编辑' : '编辑编排'}
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6">
      <p className="text-xs text-muted-foreground mb-4">
        编码: {sop.sopCode} · 版本: {sop.version} · {editing ? '编辑模式' : '查看模式'}
      </p>

      {editing ? (
        /* Graph Editor Mode */
        <div className="grid grid-cols-2 gap-4">
          {/* Nodes Editor */}
          <div>
            <h3 className="text-sm font-medium text-foreground mb-2">节点 (Nodes)</h3>
            <textarea
              value={nodesJson}
              onChange={(e) => setNodesJson(e.target.value)}
              className="w-full h-[300px] px-3 py-2 rounded border border-border bg-background text-xs font-mono focus:outline-none focus:ring-2 focus:ring-primary/30 resize-none"
              placeholder='[{"nodeKey":"step1","nodeName":"检查状态","nodeType":"tool","toolCode":"check_status"}]'
            />
          </div>
          {/* Edges Editor */}
          <div>
            <h3 className="text-sm font-medium text-foreground mb-2">边 (Edges)</h3>
            <textarea
              value={edgesJson}
              onChange={(e) => setEdgesJson(e.target.value)}
              className="w-full h-[300px] px-3 py-2 rounded border border-border bg-background text-xs font-mono focus:outline-none focus:ring-2 focus:ring-primary/30 resize-none"
              placeholder='[{"fromNode":"START","toNode":"step1"},{"fromNode":"step1","toNode":"END"}]'
            />
          </div>
          {/* Graph Preview */}
          <div className="col-span-2">
            {(parsedNodes.length > 0 || parsedEdges.length > 0) && (
              <div className="mt-4 p-4 border border-border rounded bg-card overflow-auto">
                <h3 className="text-sm font-medium text-foreground mb-2">图形预览</h3>
                <GraphPreview nodes={parsedNodes} edges={parsedEdges} />
              </div>
            )}
            <div className="flex items-center gap-3 mt-3">
              <button
                onClick={handleSaveGraph}
                disabled={saving}
                className="px-4 py-2 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-50 cursor-pointer"
              >
                {saving ? '保存中...' : '保存编排'}
              </button>
              {saveMsg && (
                <span className={`text-xs ${saveMsg.includes('成功') ? 'text-green-600' : 'text-red-500'}`}>
                  {saveMsg}
                </span>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* View Mode */
        <div className="space-y-4">
          {/* Basic Info */}
          <div className="p-4 border border-border rounded bg-card">
            <h3 className="text-sm font-medium text-foreground mb-2">基本信息</h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div><span className="text-muted-foreground">编码:</span> {sop.sopCode}</div>
              <div><span className="text-muted-foreground">分类:</span> {sop.sopCategory}</div>
              <div><span className="text-muted-foreground">编排类型:</span> {sop.composeType}</div>
              <div><span className="text-muted-foreground">状态:</span> {sop.status}</div>
              <div className="col-span-2"><span className="text-muted-foreground">描述:</span> {sop.sopDesc || '-'}</div>
            </div>
          </div>

          {/* Graph Visualization */}
          {(() => {
            try {
              const schema = sop.inputSchema ? JSON.parse(sop.inputSchema) : null
              if (schema?.nodes?.length > 0) {
                return (
                  <div className="p-4 border border-border rounded bg-card">
                    <h3 className="text-sm font-medium text-foreground mb-2">编排流程图</h3>
                    <GraphPreview nodes={schema.nodes} edges={schema.edges || []} />
                  </div>
                )
              }
            } catch { /* ignore */ }
            return (
              <div className="p-4 border border-border rounded bg-card">
                <h3 className="text-sm font-medium text-foreground mb-2">编排流程图</h3>
                <p className="text-xs text-muted-foreground">暂未配置编排，点击"编辑编排"开始</p>
              </div>
            )
          })()}
        </div>
      )}
      </div>
    </div>
  )
}
