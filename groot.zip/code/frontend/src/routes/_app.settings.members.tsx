import { createFileRoute } from '@tanstack/react-router'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState, useEffect, type FormEvent } from 'react'
import { listUsers, createUser, updateUser, deleteUser } from '../api/members'
import type { User } from '../schemas/user'

const ROLE_LABELS: Record<string, string> = {
  admin: '管理员',
  operator: '运维人员',
  viewer: '审计用户',
}

export const Route = createFileRoute('/_app/settings/members')({
  component: MembersSettingsPage,
})

function MembersSettingsPage() {
  const queryClient = useQueryClient()
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [isNew, setIsNew] = useState(false)
  const [newFormKey, setNewFormKey] = useState(0)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [successMessage, setSuccessMessage] = useState<string | null>(null)

  const { data: users, isLoading, error } = useQuery({
    queryKey: ['members'],
    queryFn: listUsers,
  })

  const createMutation = useMutation({
    mutationFn: createUser,
    onSuccess: (newUser) => {
      queryClient.invalidateQueries({ queryKey: ['members'] })
      setSelectedUser(newUser)
      setIsNew(false)
      setErrorMessage(null)
      setSuccessMessage('创建成功')
    },
    onError: (err: Error) => setErrorMessage(err.message),
  })

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Record<string, string> }) => {
      // Only send non-empty fields
      const payload: Record<string, string> = {}
      for (const [k, v] of Object.entries(data)) {
        if (v !== '') payload[k] = v
      }
      return updateUser(id, payload)
    },
    onSuccess: (updated) => {
      queryClient.invalidateQueries({ queryKey: ['members'] })
      setSelectedUser(updated)
      setErrorMessage(null)
      setSuccessMessage('保存成功')
    },
    onError: (err: Error) => setErrorMessage(err.message),
  })

  const deleteMutation = useMutation({
    mutationFn: deleteUser,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['members'] })
      setSelectedUser(null)
      setErrorMessage(null)
    },
    onError: (err: Error) => setErrorMessage(err.message),
  })

  useEffect(() => {
    if (!errorMessage) return
    const timer = setTimeout(() => setErrorMessage(null), 5000)
    return () => clearTimeout(timer)
  }, [errorMessage])

  useEffect(() => {
    if (!successMessage) return
    const timer = setTimeout(() => setSuccessMessage(null), 5000)
    return () => clearTimeout(timer)
  }, [successMessage])

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* 左侧：用户列表 */}
      <UserList
        users={users}
        isLoading={isLoading}
        error={error}
        selectedId={selectedUser?.id ?? null}
        onSelect={(u) => {
          setSelectedUser(u)
          setIsNew(false)
        }}
        onNew={() => {
          setSelectedUser(null)
          setIsNew(true)
          setNewFormKey(k => k + 1)
        }}
      />

      {/* 右侧：明细编辑 */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {successMessage && (
          <div className="fixed top-16 left-1/2 -translate-x-1/2 z-[60] px-4 py-2 text-sm text-green-800 bg-green-50 border border-green-300 rounded-lg shadow-lg flex items-center gap-3">
            <span>{successMessage}</span>
            <button onClick={() => setSuccessMessage(null)} className="hover:opacity-70">&times;</button>
          </div>
        )}
        {errorMessage && (
          <div className="fixed top-16 left-1/2 -translate-x-1/2 z-[60] max-w-lg p-3 text-sm text-destructive bg-destructive/10 border border-destructive/30 rounded-lg shadow-lg flex items-center justify-between gap-3">
            <span>{errorMessage}</span>
            <button onClick={() => setErrorMessage(null)} className="text-destructive hover:opacity-70 shrink-0 text-base leading-none">&times;</button>
          </div>
        )}
        {isNew ? (
          <UserForm
            key={newFormKey}
            mode="create"
            onSave={(data: any) => createMutation.mutate(data)}
            onCancel={() => setIsNew(false)}
            isSaving={createMutation.isPending}
          />
        ) : selectedUser ? (
          <UserForm
            key={selectedUser.id}
            mode="edit"
            user={selectedUser}
            onSave={(data) => updateMutation.mutate({ id: selectedUser.id, data })}
            onCancel={() => setSelectedUser(null)}
            onDelete={() => {
              if (confirm('确认删除此用户？')) deleteMutation.mutate(selectedUser.id)
            }}
            isSaving={updateMutation.isPending}
            isDeleting={deleteMutation.isPending}
          />
        ) : (
          <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
            请选择左侧用户或创建新用户
          </div>
        )}
      </div>
    </div>
  )
}

// ====== 左侧用户列表 ======

interface UserListProps {
  users?: User[]
  isLoading: boolean
  error: Error | null
  selectedId: number | null
  onSelect: (user: User) => void
  onNew: () => void
}

function UserList({ users, isLoading, error, selectedId, onSelect, onNew }: UserListProps) {
  return (
    <div className="w-60 border-r border-border shrink-0 flex flex-col">
      <div className="p-3 border-b border-border flex items-center justify-between">
        <h3 className="text-sm font-semibold text-foreground">用户列表</h3>
        <button onClick={onNew} className="text-xs px-2 py-1 bg-primary text-primary-foreground rounded hover:bg-primary/90">
          + 新建
        </button>
      </div>
      <div className="flex-1 overflow-auto">
        {isLoading && <p className="p-3 text-xs text-muted-foreground">加载中...</p>}
        {error && <p className="p-3 text-xs text-destructive">加载失败: {error.message}</p>}
        {users?.length === 0 && <p className="p-3 text-xs text-muted-foreground">暂无用户</p>}
        {users?.map((user) => {
          const isActive = user.id === selectedId
          return (
            <button
              key={user.id}
              onClick={() => onSelect(user)}
              className={`w-full text-left px-3 py-2.5 text-sm transition-colors cursor-pointer border-b border-border/50 ${
                isActive ? 'bg-accent text-accent-foreground' : 'text-foreground hover:bg-accent/50'
              }`}
            >
              <div className="font-medium truncate">{user.displayName}</div>
              <div className="text-xs text-muted-foreground">{user.username} · {ROLE_LABELS[user.role] || user.role}</div>
            </button>
          )
        })}
      </div>
    </div>
  )
}

// ====== 右侧用户表单 (新建/编辑) ======

interface UserFormProps {
  mode: 'create' | 'edit'
  user?: User
  onSave: (data: Record<string, string>) => void
  onCancel: () => void
  onDelete?: () => void
  isSaving: boolean
  isDeleting?: boolean
}

function UserForm({ mode, user, onSave, onCancel, onDelete, isSaving, isDeleting }: UserFormProps) {
  const [values, setValues] = useState<Record<string, string>>({
    username: user?.username ?? '',
    mobile: user?.mobile ?? '',
    password: '',
    displayName: user?.displayName ?? '',
    role: user?.role ?? 'viewer',
  })

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    onSave(values)
  }

  const title = mode === 'create' ? '新建用户' : '编辑用户'

  return (
    <div className="overflow-auto">
      <div className="p-4 border-b border-border flex items-center justify-between">
        <h3 className="text-lg font-bold text-foreground">{title}</h3>
        <div className="flex gap-2">
          {mode === 'edit' && onDelete && (
            <button onClick={onDelete} disabled={isDeleting} className="px-3 py-1.5 text-sm text-destructive border border-destructive/30 rounded hover:bg-destructive/10 disabled:opacity-50">
              {isDeleting ? '删除中...' : '删除'}
            </button>
          )}
        </div>
      </div>

      <form onSubmit={handleSubmit} className="p-4 max-w-lg space-y-4">
        <FormField label="用户名" required>
          <input
            type="text"
            value={values.username}
            onChange={(e) => setValues({ ...values, username: e.target.value })}
            className="w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            required
          />
        </FormField>

        <FormField label="显示名称" required>
          <input
            type="text"
            value={values.displayName}
            onChange={(e) => setValues({ ...values, displayName: e.target.value })}
            className="w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            required
          />
        </FormField>

        <FormField label={mode === 'create' ? '密码' : '密码（留空不修改）'} required={mode === 'create'}>
          <input
            type="password"
            value={values.password}
            onChange={(e) => setValues({ ...values, password: e.target.value })}
            className="w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            placeholder={mode === 'edit' ? '留空则不修改密码' : ''}
            required={mode === 'create'}
          />
        </FormField>

        <FormField label="手机号码">
          <input
            type="text"
            value={values.mobile}
            onChange={(e) => setValues({ ...values, mobile: e.target.value })}
            className="w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            placeholder="选填"
          />
        </FormField>

        <FormField label="角色" required>
          <select
            value={values.role}
            onChange={(e) => setValues({ ...values, role: e.target.value })}
            className="w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="viewer">审计用户</option>
            <option value="operator">运维人员</option>
            <option value="admin">管理员</option>
          </select>
        </FormField>

        {user && (
          <div className="text-xs text-muted-foreground space-y-0.5 pt-2 border-t border-border">
            <div>创建时间: {new Date(user.createdAt).toLocaleString('zh-CN')}</div>
            <div>更新时间: {new Date(user.updatedAt).toLocaleString('zh-CN')}</div>
          </div>
        )}

        <div className="flex justify-end gap-2 pt-2">
          <button type="button" onClick={onCancel} className="px-4 py-2 text-sm border border-border rounded text-foreground hover:bg-accent">
            取消
          </button>
          <button type="submit" disabled={isSaving} className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90 disabled:opacity-50">
            {isSaving ? '保存中...' : '保存'}
          </button>
        </div>
      </form>
    </div>
  )
}

// ====== 表单字段 ======

interface FormFieldProps {
  label: string
  required?: boolean
  children: React.ReactNode
}

function FormField({ label, required, children }: FormFieldProps) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-sm font-medium text-foreground">
        {label}
        {required && <span className="text-destructive ml-0.5">*</span>}
      </label>
      {children}
    </div>
  )
}
