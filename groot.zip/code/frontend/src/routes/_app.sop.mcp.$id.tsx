import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { getMcp, createMcp, updateMcp, listMcpTools, updateMcpTool, debugMcp, type DiscoveredTool, type McpTool } from '../api/mcps'

export const Route = createFileRoute('/_app/sop/mcp/$id')({
  component: MCPEditorPage,
})

function MCPEditorPage() {
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const { id } = Route.useParams()
  const isNew = id === 'new'
  const mcpId = isNew ? 0 : parseInt(id, 10)

  const { data: mcp, isLoading } = useQuery({
    queryKey: ['mcp', mcpId],
    queryFn: () => getMcp(mcpId),
    enabled: !isNew,
  })

  const { data: tools, isLoading: toolsLoading } = useQuery({
    queryKey: ['mcp-tools', mcpId],
    queryFn: () => listMcpTools(mcpId),
    enabled: !isNew,
    retry: 3,
    retryDelay: 1000,
  })

  const [form, setForm] = useState({
    mcpName: '',
    mcpCode: '',
    mcpType: 'sse',
    baseUrl: '',
    apiKey: '',
    timeoutMs: 30000,
    description: '',
    isEnabled: true,
  })

  const [discoveredTools, setDiscoveredTools] = useState<DiscoveredTool[]>([])
  const [debugMsg, setDebugMsg] = useState('')
  const [debugging, setDebugging] = useState(false)
  const [saving, setSaving] = useState(false)
  const [saveMsg, setSaveMsg] = useState('')

  // Load existing data into form
  const loaded = !!mcp || isNew
  const effectiveForm = mcp ? {
    mcpName: mcp.mcpName,
    mcpCode: mcp.mcpCode,
    mcpType: mcp.mcpType,
    baseUrl: mcp.baseUrl,
    apiKey: mcp.apiKey || '',
    timeoutMs: mcp.timeoutMs,
    description: mcp.description || '',
    isEnabled: mcp.isEnabled,
  } : form

  const handleDebug = async () => {
    setDebugging(true)
    setDebugMsg('')
    try {
      const result = await debugMcp({
        mcpName: effectiveForm.mcpName,
        mcpType: effectiveForm.mcpType,
        baseUrl: effectiveForm.baseUrl,
        apiKey: effectiveForm.apiKey,
        mcpId: isNew ? 0 : mcpId,
      })
      setDebugMsg(result.message)
      if (result.success && result.tools) {
        setDiscoveredTools(result.tools)
        // Save tools to DB if editing existing MCP
        if (!isNew) {
          queryClient.invalidateQueries({ queryKey: ['mcp-tools', mcpId] })
        }
      }
    } catch (e: any) {
      setDebugMsg(e?.message || '调试失败')
    } finally {
      setDebugging(false)
    }
  }

  const handleSave = async () => {
    if (!effectiveForm.mcpName || !effectiveForm.baseUrl) {
      setSaveMsg('名称和地址不能为空')
      return
    }
    setSaving(true)
    setSaveMsg('')
    try {
      if (isNew) {
        const created = await createMcp(effectiveForm)
        // Save discovered tools
        if (discoveredTools.length > 0) {
          await debugMcp({
            mcpName: effectiveForm.mcpName,
            mcpType: effectiveForm.mcpType,
            baseUrl: effectiveForm.baseUrl,
            apiKey: effectiveForm.apiKey,
            mcpId: created.id,
          })
        }
        navigate({ to: '/sop/mcp' })
      } else {
        await updateMcp(mcpId, effectiveForm)
        setSaveMsg('保存成功')
      }
    } catch (e: any) {
      setSaveMsg(e?.message || '保存失败')
    } finally {
      setSaving(false)
    }
  }

  const handleUpdateTool = async (toolId: number, data: { toolDesc?: string; outputDesc?: string }) => {
    try {
      await updateMcpTool(mcpId, toolId, data)
      queryClient.invalidateQueries({ queryKey: ['mcp-tools', mcpId] })
    } catch (e: any) {
      console.error('Update tool failed:', e)
    }
  }

  if (!isNew && isLoading) {
    return (
      <div className="flex-1 overflow-auto p-6">
        <p className="text-sm text-muted-foreground">加载中...</p>
      </div>
    )
  }

  const displayedTools = !isNew && tools ? tools : []

  return (
    <div className="flex-1 flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-3 px-6 py-3 border-b border-border bg-card/50 sticky top-0 z-10">
        <button
          onClick={() => navigate({ to: '/sop/mcp' })}
          className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          返回
        </button>
        <div className="flex-1">
          <h2 className="text-lg font-bold text-foreground">
            {isNew ? '新增 MCP' : mcp?.mcpName || '编辑 MCP'}
          </h2>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6 space-y-6">
        {/* Basic Config */}
        <div className="border border-border rounded bg-card p-4">
          <h3 className="text-sm font-medium text-foreground mb-3">基本配置</h3>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <label className="block text-xs text-muted-foreground mb-1">名称 *</label>
              <input type="text" value={effectiveForm.mcpName}
                onChange={(e) => setForm({ ...effectiveForm, mcpName: e.target.value })}
                className="w-full px-2 py-1.5 rounded border border-border bg-background text-sm focus:outline-none focus:ring-1 focus:ring-primary/30"
              />
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1">编码</label>
              <input type="text" value={effectiveForm.mcpCode}
                onChange={(e) => setForm({ ...effectiveForm, mcpCode: e.target.value })}
                className="w-full px-2 py-1.5 rounded border border-border bg-background text-sm focus:outline-none focus:ring-1 focus:ring-primary/30 font-mono"
              />
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1">类型</label>
              <select value={effectiveForm.mcpType}
                onChange={(e) => setForm({ ...effectiveForm, mcpType: e.target.value })}
                className="w-full px-2 py-1.5 rounded border border-border bg-background text-sm focus:outline-none focus:ring-1 focus:ring-primary/30"
              >
                <option value="sse">SSE</option>
                <option value="streamable">Streamable HTTP</option>
                <option value="stdio">Stdio</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-muted-foreground mb-1">API Key</label>
              <input type="text" value={effectiveForm.apiKey}
                onChange={(e) => setForm({ ...effectiveForm, apiKey: e.target.value })}
                className="w-full px-2 py-1.5 rounded border border-border bg-background text-sm focus:outline-none focus:ring-1 focus:ring-primary/30 font-mono"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-xs text-muted-foreground mb-1">地址 *</label>
              <input type="text" value={effectiveForm.baseUrl}
                onChange={(e) => setForm({ ...effectiveForm, baseUrl: e.target.value })}
                placeholder="如 https://example.com/mcp"
                className="w-full px-2 py-1.5 rounded border border-border bg-background text-sm focus:outline-none focus:ring-1 focus:ring-primary/30 font-mono"
              />
            </div>
            <div className="col-span-2">
              <label className="block text-xs text-muted-foreground mb-1">描述</label>
              <textarea value={effectiveForm.description}
                onChange={(e) => setForm({ ...effectiveForm, description: e.target.value })}
                rows={2} className="w-full px-2 py-1.5 rounded border border-border bg-background text-sm focus:outline-none focus:ring-1 focus:ring-primary/30 resize-none"
              />
            </div>
          </div>

          <div className="flex items-center gap-3 mt-4">
            <button onClick={handleSave} disabled={saving}
              className="px-4 py-2 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-50 cursor-pointer"
            >
              {saving ? '保存中...' : '保存'}
            </button>
            <button onClick={handleDebug} disabled={debugging}
              className="px-4 py-2 rounded border border-primary text-primary text-sm hover:bg-primary/10 transition-colors disabled:opacity-50 cursor-pointer"
            >
              {debugging ? '连接中...' : '调试连接'}
            </button>
            {saveMsg && <span className={`text-xs ${saveMsg.includes('成功') ? 'text-green-600' : 'text-red-500'}`}>{saveMsg}</span>}
            {debugMsg && <span className={`text-xs ${debugMsg.includes('成功') ? 'text-green-600' : 'text-red-500'}`}>{debugMsg}</span>}
          </div>
        </div>

        {/* Discovered Tools */}
        {!isNew && (
          <div className="border border-border rounded bg-card p-4">
            <h3 className="text-sm font-medium text-foreground mb-3">
              工具列表 ({discoveredTools.length || displayedTools.length})
            </h3>
            {toolsLoading ? (
              <p className="text-xs text-muted-foreground">加载中...</p>
            ) : (displayedTools.length > 0 || discoveredTools.length > 0) ? (
              <div className="space-y-2">
                {(discoveredTools.length > 0 ? discoveredTools : displayedTools).map((tool: any, i: number) => {
                  const dbTool = displayedTools.find((t: McpTool) => t.toolName === tool.name)
                  return (
                  <div key={tool.name || i} className="border border-border rounded p-3">
                    <div>
                      <div className="font-medium text-sm text-foreground">{tool.name}</div>
                      {dbTool ? (
                        <>
                          <input
                            type="text"
                            defaultValue={dbTool.toolDesc || ''}
                            placeholder="工具描述"
                            onBlur={(e) => handleUpdateTool(dbTool.id, { toolDesc: e.target.value })}
                            className="w-full mt-1.5 px-2 py-1 text-xs rounded border border-border bg-background focus:outline-none focus:ring-1 focus:ring-primary/30"
                          />
                          {tool.inputSchema && (
                            <details className="mt-1.5">
                              <summary className="text-xs text-primary cursor-pointer">输入参数</summary>
                              <pre className="text-xs mt-1 p-2 bg-muted rounded overflow-auto max-h-32">
                                {JSON.stringify(tool.inputSchema, null, 2)}
                              </pre>
                            </details>
                          )}
                          <input
                            type="text"
                            defaultValue={dbTool.outputDesc || ''}
                            placeholder="输出描述"
                            onBlur={(e) => handleUpdateTool(dbTool.id, { outputDesc: e.target.value })}
                            className="w-full mt-1.5 px-2 py-1 text-xs rounded border border-border bg-background focus:outline-none focus:ring-1 focus:ring-primary/30"
                          />
                        </>
                      ) : (
                        <>
                          <div className="text-xs text-muted-foreground mt-0.5">{tool.description || '-'}</div>
                          {tool.inputSchema && (
                            <details className="mt-1.5">
                              <summary className="text-xs text-primary cursor-pointer">输入参数</summary>
                              <pre className="text-xs mt-1 p-2 bg-muted rounded overflow-auto max-h-32">
                                {JSON.stringify(tool.inputSchema, null, 2)}
                              </pre>
                            </details>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
            ) : (
              <p className="text-xs text-muted-foreground">尚未发现工具，请点击"调试连接"发现工具</p>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
