import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { useState } from 'react'
import { createSop, type CreateSopRequest } from '../api/sops'

export const Route = createFileRoute('/_app/sop/new')({
  component: NewSOPPage,
})

function NewSOPPage() {
  const navigate = useNavigate()
  const [form, setForm] = useState<CreateSopRequest>({
    sopName: '',
    sopCode: '',
    sopCategory: 'middleware',
    composeType: 'workflow',
  })
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async () => {
    if (!form.sopName || !form.sopCode) {
      setError('名称和编码不能为空')
      return
    }
    setSaving(true)
    setError('')
    try {
      const sop = await createSop(form)
      navigate({ to: '/sop/$id', params: { id: String(sop.id) } })
    } catch (e: any) {
      setError(e?.message || '创建失败')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="flex-1 overflow-auto p-6">
      <div className="max-w-2xl">
        <h2 className="text-xl font-bold text-foreground mb-4">新增 SOP</h2>
        <SopBasicForm form={form} setForm={setForm} />
        {error && <p className="text-sm text-red-500 mt-2">{error}</p>}
        <div className="flex gap-3 mt-4">
          <button
            onClick={handleSubmit}
            disabled={saving}
            className="px-4 py-2 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-50 cursor-pointer"
          >
            {saving ? '保存中...' : '保存'}
          </button>
          <button
            onClick={() => navigate({ to: '/sop' })}
            className="px-4 py-2 rounded border border-border text-sm hover:bg-accent cursor-pointer"
          >
            取消
          </button>
        </div>
      </div>
    </div>
  )
}

export function SopBasicForm({
  form,
  setForm,
}: {
  form: CreateSopRequest
  setForm: (f: CreateSopRequest) => void
}) {
  return (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">SOP 编码</label>
        <input
          type="text"
          value={form.sopCode}
          onChange={(e) => setForm({ ...form, sopCode: e.target.value })}
          placeholder="如 SOP-1-MW-COM1"
          className="w-full px-3 py-2 rounded border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">SOP 名称</label>
        <input
          type="text"
          value={form.sopName}
          onChange={(e) => setForm({ ...form, sopName: e.target.value })}
          placeholder="如 组件节点故障，不影响组件服务"
          className="w-full px-3 py-2 rounded border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
        />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-1">分类</label>
          <select
            value={form.sopCategory}
            onChange={(e) => setForm({ ...form, sopCategory: e.target.value })}
            className="w-full px-3 py-2 rounded border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
          >
            <option value="middleware">中间件</option>
            <option value="disk">磁盘</option>
            <option value="network">网络</option>
            <option value="system">系统</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1">编排类型</label>
          <select
            value={form.composeType}
            onChange={(e) => setForm({ ...form, composeType: e.target.value as any })}
            className="w-full px-3 py-2 rounded border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
          >
            <option value="workflow">Workflow（字段映射）</option>
            <option value="graph">Graph（支持循环）</option>
            <option value="chain">Chain（纯线性）</option>
          </select>
        </div>
      </div>
      <div>
        <label className="block text-sm font-medium text-foreground mb-1">描述</label>
        <textarea
          value={form.sopDesc || ''}
          onChange={(e) => setForm({ ...form, sopDesc: e.target.value || undefined })}
          placeholder="描述这个 SOP 的用途"
          rows={3}
          className="w-full px-3 py-2 rounded border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 resize-none"
        />
      </div>
    </div>
  )
}
