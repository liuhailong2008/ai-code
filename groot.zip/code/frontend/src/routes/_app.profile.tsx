import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { useMutation } from '@tanstack/react-query'
import { useState, useEffect, type FormEvent } from 'react'
import { useAuthStore } from '../stores/auth'
import { updateProfile } from '../api/auth'

export const Route = createFileRoute('/_app/profile')({
  component: ProfilePage,
})

function ProfilePage() {
  const { user, setUser } = useAuthStore()
  const navigate = useNavigate()
  const [successMessage, setSuccessMessage] = useState<string | null>(null)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  const [values, setValues] = useState({
    displayName: user?.displayName ?? '',
    mobile: user?.mobile ?? '',
    password: '',
  })

  const saveMutation = useMutation({
    mutationFn: () => {
      const payload: Record<string, string> = {}
      if (values.displayName) payload.displayName = values.displayName
      if (values.mobile) payload.mobile = values.mobile
      if (values.password) payload.password = values.password
      return updateProfile(payload)
    },
    onSuccess: (updated) => {
      setUser(updated)
      setValues({ ...values, password: '' })
      setSuccessMessage('保存成功')
      setErrorMessage(null)
    },
    onError: (err: Error) => {
      setErrorMessage(err.message)
      setSuccessMessage(null)
    },
  })

  // 成功提示 5 秒后自动消失
  useEffect(() => {
    if (!successMessage) return
    const t = setTimeout(() => setSuccessMessage(null), 5000)
    return () => clearTimeout(t)
  }, [successMessage])

  // 错误提示 5 秒后自动消失
  useEffect(() => {
    if (!errorMessage) return
    const t = setTimeout(() => setErrorMessage(null), 5000)
    return () => clearTimeout(t)
  }, [errorMessage])

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    saveMutation.mutate()
  }

  if (!user) return null

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {successMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-[60] px-4 py-2 text-sm text-green-800 bg-green-50 border border-green-300 rounded-lg shadow-lg flex items-center gap-3">
          <span>{successMessage}</span>
          <button onClick={() => setSuccessMessage(null)} className="hover:opacity-70">&times;</button>
        </div>
      )}
      {errorMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-[60] max-w-lg p-3 text-sm text-destructive bg-destructive/10 border border-destructive/30 rounded-lg shadow-lg flex items-center justify-between gap-3">
          <span>{errorMessage}</span>
          <button onClick={() => setErrorMessage(null)} className="text-destructive hover:opacity-70 shrink-0 text-base leading-none">&times;</button>
        </div>
      )}

      <div className="flex-1 overflow-auto">
        <div className="p-4 border-b border-border">
          <h3 className="text-lg font-bold text-foreground">个人信息</h3>
        </div>

        <form onSubmit={handleSubmit} className="p-4 max-w-lg space-y-4">
          <div className="flex items-center gap-3 pb-4 border-b border-border">
            <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-primary text-lg font-bold">
              {user.displayName.charAt(0)}
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">{user.displayName}</p>
              <p className="text-xs text-muted-foreground">@{user.username} · {user.role}</p>
            </div>
          </div>

          <FormField label="用户名">
            <input
              type="text"
              value={user.username}
              disabled
              className="w-full px-3 py-2 text-sm border border-border rounded bg-muted text-muted-foreground"
            />
          </FormField>

          <FormField label="显示名称" required>
            <input
              type="text"
              value={values.displayName}
              onChange={(e) => setValues({ ...values, displayName: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              required
            />
          </FormField>

          <FormField label="手机号码">
            <input
              type="text"
              value={values.mobile}
              onChange={(e) => setValues({ ...values, mobile: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="选填"
            />
          </FormField>

          <FormField label="新密码（留空不修改）">
            <input
              type="password"
              value={values.password}
              onChange={(e) => setValues({ ...values, password: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-border rounded bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="留空则不修改密码"
            />
          </FormField>

          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={() => navigate({ to: '/events' })}
              className="px-4 py-2 text-sm border border-border rounded text-foreground hover:bg-accent"
            >
              返回
            </button>
            <button
              type="submit"
              disabled={saveMutation.isPending}
              className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded hover:bg-primary/90 disabled:opacity-50"
            >
              {saveMutation.isPending ? '保存中...' : '保存'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

interface FormFieldProps {
  label: string
  required?: boolean
  children: React.ReactNode
}

function FormField({ label, required, children }: FormFieldProps) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-sm font-medium text-foreground">
        {label}
        {required && <span className="text-destructive ml-0.5">*</span>}
      </label>
      {children}
    </div>
  )
}
