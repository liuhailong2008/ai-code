import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/_app/history')({
  component: HistoryPage,
})

function HistoryPage() {
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold text-foreground">历史事件</h2>
      <p className="text-muted-foreground mt-4">历史事件列表加载中...</p>
    </div>
  )
}