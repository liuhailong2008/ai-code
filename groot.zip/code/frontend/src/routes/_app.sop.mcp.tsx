import { createFileRoute, Link, useNavigate, Outlet, useLocation } from '@tanstack/react-router'
import { useQuery } from '@tanstack/react-query'
import { listMcps, type McpConfig } from '../api/mcps'

export const Route = createFileRoute('/_app/sop/mcp')({
  component: MCPLayout,
})

function MCPLayout() {
  const location = useLocation()
  const isListPage = location.pathname === '/sop/mcp'

  if (!isListPage) {
    return <Outlet />
  }

  return <MCPListPage />
}

const TYPE_LABELS: Record<string, string> = {
  sse: 'SSE',
  stdio: 'Stdio',
  streamable: 'Streamable',
}

function MCPListPage() {
  const navigate = useNavigate()
  const { data: mcps, isLoading } = useQuery({
    queryKey: ['mcps'],
    queryFn: () => listMcps(),
  })

  return (
    <div className="flex-1 overflow-auto p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-foreground">MCP 管理</h2>
        <button
          onClick={() => navigate({ to: '/sop/mcp/new' })}
          className="px-3 py-1.5 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors cursor-pointer"
        >
          + 新增 MCP
        </button>
      </div>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">加载中...</p>
      ) : (
        <div className="border border-border rounded overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted">
              <tr>
                <th className="text-left px-4 py-2 font-medium">名称</th>
                <th className="text-left px-4 py-2 font-medium">类型</th>
                <th className="text-left px-4 py-2 font-medium">地址</th>
                <th className="text-left px-4 py-2 font-medium">状态</th>
                <th className="text-left px-4 py-2 font-medium">操作</th>
              </tr>
            </thead>
            <tbody>
              {(mcps && mcps.length > 0) ? mcps.map((mcp: McpConfig) => (
                <tr key={mcp.id} className="border-t border-border hover:bg-accent/30">
                  <td className="px-4 py-2 font-medium">{mcp.mcpName}</td>
                  <td className="px-4 py-2">
                    <span className="text-xs px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                      {TYPE_LABELS[mcp.mcpType] || mcp.mcpType}
                    </span>
                  </td>
                  <td className="px-4 py-2 text-xs font-mono text-muted-foreground truncate max-w-[200px]">
                    {mcp.baseUrl}
                  </td>
                  <td className="px-4 py-2">
                    <span className={`text-xs px-1.5 py-0.5 rounded ${
                      mcp.isEnabled
                        ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300'
                        : 'bg-muted text-muted-foreground'
                    }`}>
                      {mcp.isEnabled ? '已启用' : '已禁用'}
                    </span>
                  </td>
                  <td className="px-4 py-2">
                    <Link
                      to="/sop/mcp/$id"
                      params={{ id: String(mcp.id) }}
                      className="text-xs text-primary hover:underline cursor-pointer"
                    >
                      编辑
                    </Link>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-muted-foreground">
                    暂无 MCP 配置，点击"新增 MCP"创建
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
