import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/_app/reports')({
  component: ReportsPage,
})

function ReportsPage() {
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold text-foreground">报表</h2>
      <p className="text-muted-foreground mt-4">报表列表加载中...</p>
    </div>
  )
}