import { request } from './client'

export interface McpConfig {
  id: number
  mcpName: string
  mcpCode: string
  mcpType: 'sse' | 'stdio' | 'streamable'
  baseUrl: string
  apiKey: string | null
  headers: string | null
  timeoutMs: number
  description: string | null
  isEnabled: boolean
  createdBy: string
  updatedBy: string | null
  createdAt: string
  updatedAt: string
}

export interface McpTool {
  id: number
  mcpId: number
  toolName: string
  toolDesc: string | null
  inputSchema: string | null
  outputDesc: string | null
  isEnabled: boolean
  createdAt: string
  updatedAt: string
}

export interface DiscoveredTool {
  name: string
  description: string
  inputSchema: any
}

export interface DebugResult {
  success: boolean
  message: string
  tools: DiscoveredTool[]
}

export function listMcps(): Promise<McpConfig[]> {
  return request('/system-setting/mcps')
}

export function getMcp(id: number): Promise<McpConfig> {
  return request(`/system-setting/mcps/${id}`)
}

export function createMcp(data: Partial<McpConfig>): Promise<McpConfig> {
  return request('/system-setting/mcps', {
    method: 'POST',
    body: JSON.stringify(data),
  })
}

export function updateMcp(id: number, data: Partial<McpConfig>): Promise<McpConfig> {
  return request(`/system-setting/mcps/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
}

export function listMcpTools(mcpId: number): Promise<McpTool[]> {
  return request(`/system-setting/mcps/${mcpId}/tools`)
}

export function updateMcpTool(mcpId: number, toolId: number, data: { toolDesc?: string; outputDesc?: string }): Promise<McpTool> {
  return request(`/system-setting/mcps/${mcpId}/tools/${toolId}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
}

export function debugMcp(data: {
  mcpName: string
  mcpType: string
  baseUrl: string
  apiKey: string
  mcpId: number
}): Promise<DebugResult> {
  return request('/system-setting/mcps/debug', {
    method: 'POST',
    body: JSON.stringify(data),
  })
}
