import { request } from './client'
import type { Team, TeamCreate, TeamUpdate } from '../schemas'

export async function listTeams(): Promise<Team[]> {
  return request<Team[]>('/system-setting/teams')
}

export async function getTeam(id: number): Promise<Team> {
  return request<Team>(`/system-setting/teams/${id}`)
}

export async function createTeam(data: TeamCreate): Promise<Team> {
  return request<Team>('/system-setting/teams', {
    method: 'POST',
    body: JSON.stringify(data),
  })
}

export async function updateTeam(id: number, data: TeamUpdate): Promise<Team> {
  return request<Team>(`/system-setting/teams/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
}

export async function getUserTeams(userId: number): Promise<Team[]> {
  return request<Team[]>(`/system-setting/users/${userId}/teams`)
}

export async function deleteTeam(id: number): Promise<void> {
  return request<void>(`/system-setting/teams/${id}`, {
    method: 'DELETE',
  })
}
