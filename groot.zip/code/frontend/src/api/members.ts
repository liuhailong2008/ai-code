import { request } from './client'
import type { User } from '../schemas/user'

export interface CreateUserRequest {
  username: string
  mobile?: string
  password: string
  displayName: string
  role: string
}

export interface UpdateUserRequest {
  username?: string
  mobile?: string
  password?: string
  displayName?: string
  role?: string
}

export async function listUsers(): Promise<User[]> {
  return request<User[]>('/system-setting/members')
}

export async function getUser(id: number): Promise<User> {
  return request<User>(`/system-setting/members/${id}`)
}

export async function createUser(data: CreateUserRequest): Promise<User> {
  return request<User>('/system-setting/members', {
    method: 'POST',
    body: JSON.stringify(data),
  })
}

export async function updateUser(id: number, data: UpdateUserRequest): Promise<User> {
  return request<User>(`/system-setting/members/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
}

export async function deleteUser(id: number): Promise<void> {
  return request<void>(`/system-setting/members/${id}`, {
    method: 'DELETE',
  })
}

export interface TeamMember {
  id: number
  userId: number
  teamId: number
  username: string
  displayName: string
  role: string
  createdAt: string
  updatedAt: string
}

export async function listTeamMembers(teamId: number): Promise<TeamMember[]> {
  return request<TeamMember[]>(`/system-setting/teams/${teamId}/members`)
}

export async function addTeamMember(teamId: number, userId: number): Promise<TeamMember> {
  return request<TeamMember>(`/system-setting/teams/${teamId}/members`, {
    method: 'POST',
    body: JSON.stringify({ userId }),
  })
}

export async function removeTeamMember(teamId: number, userId: number): Promise<void> {
  return request<void>(`/system-setting/teams/${teamId}/members/${userId}`, {
    method: 'DELETE',
  })
}

export async function searchUsers(keyword: string): Promise<User[]> {
  return request<User[]>(`/system-setting/users/search?q=${encodeURIComponent(keyword)}`)
}
