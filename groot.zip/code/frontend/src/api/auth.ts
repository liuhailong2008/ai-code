import { request } from './client'
import type { User, UserPreferences } from '../schemas/user'

export interface LoginResponse {
  token: string
  user: User
}

export async function login(username: string, password: string): Promise<LoginResponse> {
  return request<LoginResponse>('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ username, password }),
  })
}

export async function getMe(): Promise<User> {
  return request<User>('/auth/me')
}

export async function logout(): Promise<void> {
  return request<void>('/auth/logout', {
    method: 'POST',
  })
}

export async function getPreferences(): Promise<UserPreferences> {
  return request<UserPreferences>('/auth/preferences')
}

export async function updatePreferences(
  preferences: Partial<UserPreferences>,
): Promise<UserPreferences> {
  return request<UserPreferences>('/auth/preferences', {
    method: 'PATCH',
    body: JSON.stringify(preferences),
  })
}

export interface UpdateProfileRequest {
  displayName?: string
  mobile?: string
  password?: string
}

export async function updateProfile(data: UpdateProfileRequest): Promise<User> {
  return request<User>('/auth/profile', {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
}
