import { request } from './client'

// ============================================================
// 台账域类型
// ============================================================

export interface Idc {
  id: number
  envCode: string
  idcCode: string
  idcName: string
  isXinchuang: string
  idcStatus: string
  idcRemark: string | null
  createdBy: string
  updatedBy: string | null
  createdAt: string
  updatedAt: string
}

export interface Host {
  id: number
  envCode: string
  idcCode: string
  clusterCode: string
  componentTreeId: number | null
  hostIp: string
  leafCode: string
  rackCode: string
  cpuCores: number | null
  memoryGb: number | null
  diskGb: number | null
  cpuModel: string | null
  osName: string | null
  sshPort: number | null
  sshUser: string | null
  createdBy: string
  updatedBy: string | null
  createdAt: string
  updatedAt: string
}

export interface Domain {
  id: number
  envCode: string
  idcCode: string
  domainType: string
  domainName: string
  targetHost: string | null
  createdBy: string
  updatedBy: string | null
  createdAt: string
  updatedAt: string
}

export interface CmdbSyncDiff {
  id: number
  batchCode: string
  envCode: string
  idcCode: string
  diffType: string
  hostIp: string
  diffStatus: string
  syncRemark: string | null
  createdBy: string
  updatedBy: string | null
  createdAt: string
  updatedAt: string
}

export interface AcceptanceStandard {
  id: number
  parentId: number
  standardCode: string
  standardName: string
  nodeType: string
  collectType: string | null
  collectMethod: string | null
  collectParams: string | null
  judgeCriteria: string | null
  orderIdx: number
  standardStatus: string
  createdBy: string
  updatedBy: string | null
  createdAt: string
  updatedAt: string
}

// ============================================================
// IDC台账
// ============================================================

export async function listIdcs(params?: { envCode?: string; idcCode?: string; idcStatus?: string }): Promise<Idc[]> {
  const qs = new URLSearchParams()
  if (params?.envCode) qs.set('envCode', params.envCode)
  if (params?.idcCode) qs.set('idcCode', params.idcCode)
  if (params?.idcStatus) qs.set('idcStatus', params.idcStatus)
  const suffix = qs.toString() ? `?${qs.toString()}` : ''
  return request<Idc[]>(`/ruok/idcs${suffix}`)
}

export async function getIdc(id: number): Promise<Idc> {
  return request<Idc>(`/ruok/idcs/${id}`)
}

export async function createIdc(data: Record<string, unknown>): Promise<Idc> {
  return request<Idc>('/ruok/idcs', { method: 'POST', body: JSON.stringify(data) })
}

export async function updateIdc(id: number, data: Record<string, unknown>): Promise<Idc> {
  return request<Idc>(`/ruok/idcs/${id}`, { method: 'PATCH', body: JSON.stringify(data) })
}

export async function deleteIdc(id: number): Promise<void> {
  return request<void>(`/ruok/idcs/${id}`, { method: 'DELETE' })
}

// ============================================================
// 主机台账
// ============================================================

export async function listHosts(params?: { envCode?: string; idcCode?: string; clusterCode?: string; hostIp?: string; componentTreeId?: number }): Promise<Host[]> {
  const qs = new URLSearchParams()
  if (params?.envCode) qs.set('envCode', params.envCode)
  if (params?.idcCode) qs.set('idcCode', params.idcCode)
  if (params?.clusterCode) qs.set('clusterCode', params.clusterCode)
  if (params?.hostIp) qs.set('hostIp', params.hostIp)
  if (params?.componentTreeId != null) qs.set('componentTreeId', String(params.componentTreeId))
  const suffix = qs.toString() ? `?${qs.toString()}` : ''
  return request<Host[]>(`/ruok/hosts${suffix}`)
}

export async function createHost(data: Record<string, unknown>): Promise<Host> {
  return request<Host>('/ruok/hosts', { method: 'POST', body: JSON.stringify(data) })
}

export async function updateHost(id: number, data: Record<string, unknown>): Promise<Host> {
  return request<Host>(`/ruok/hosts/${id}`, { method: 'PATCH', body: JSON.stringify(data) })
}

export async function deleteHost(id: number): Promise<void> {
  return request<void>(`/ruok/hosts/${id}`, { method: 'DELETE' })
}

// ============================================================
// 域名台账
// ============================================================

export async function listDomains(params?: { envCode?: string; idcCode?: string; domainType?: string }): Promise<Domain[]> {
  const qs = new URLSearchParams()
  if (params?.envCode) qs.set('envCode', params.envCode)
  if (params?.idcCode) qs.set('idcCode', params.idcCode)
  if (params?.domainType) qs.set('domainType', params.domainType)
  const suffix = qs.toString() ? `?${qs.toString()}` : ''
  return request<Domain[]>(`/ruok/domains${suffix}`)
}

export async function createDomain(data: Record<string, unknown>): Promise<Domain> {
  return request<Domain>('/ruok/domains', { method: 'POST', body: JSON.stringify(data) })
}

export async function updateDomain(id: number, data: Record<string, unknown>): Promise<Domain> {
  return request<Domain>(`/ruok/domains/${id}`, { method: 'PATCH', body: JSON.stringify(data) })
}

export async function deleteDomain(id: number): Promise<void> {
  return request<void>(`/ruok/domains/${id}`, { method: 'DELETE' })
}

// ============================================================
// CMDB同步差异
// ============================================================

export async function listCmdbSyncDiffs(params?: { batchCode?: string; idcCode?: string; diffStatus?: string }): Promise<CmdbSyncDiff[]> {
  const qs = new URLSearchParams()
  if (params?.batchCode) qs.set('batchCode', params.batchCode)
  if (params?.idcCode) qs.set('idcCode', params.idcCode)
  if (params?.diffStatus) qs.set('diffStatus', params.diffStatus)
  const suffix = qs.toString() ? `?${qs.toString()}` : ''
  return request<CmdbSyncDiff[]>(`/ruok/cmdb-sync-diffs${suffix}`)
}

// ============================================================
// 验收标准
// ============================================================

export async function listStandards(): Promise<AcceptanceStandard[]> {
  return request<AcceptanceStandard[]>('/ruok/standards')
}

export async function createStandard(data: Record<string, unknown>): Promise<AcceptanceStandard> {
  return request<AcceptanceStandard>('/ruok/standards', { method: 'POST', body: JSON.stringify(data) })
}

export async function updateStandard(id: number, data: Record<string, unknown>): Promise<AcceptanceStandard> {
  return request<AcceptanceStandard>(`/ruok/standards/${id}`, { method: 'PATCH', body: JSON.stringify(data) })
}

export async function deleteStandard(id: number): Promise<void> {
  return request<void>(`/ruok/standards/${id}`, { method: 'DELETE' })
}

export async function moveStandard(id: number, parentId: number, orderIdx: number): Promise<void> {
  return request<void>(`/ruok/standards/${id}/move`, { method: 'PATCH', body: JSON.stringify({ parentId, orderIdx }) })
}

// ============================================================
// 组件树
// ============================================================

export interface ComponentTreeNode {
  id: number
  parentId: number
  nodeType: string
  nodeCode: string
  nodeName: string
  nodeIdx: number
  nodeRemark: string | null
  accessMethod: string | null
  accessPort: number | null
  accessPassword: string | null
  createdBy: string
  updatedBy: string | null
  createdAt: string
  updatedAt: string
}

export async function listComponentTree(): Promise<ComponentTreeNode[]> {
  return request<ComponentTreeNode[]>('/ruok/component-tree')
}

export async function createComponentTreeNode(data: Record<string, unknown>): Promise<ComponentTreeNode> {
  return request<ComponentTreeNode>('/ruok/component-tree', { method: 'POST', body: JSON.stringify(data) })
}

export async function updateComponentTreeNode(id: number, data: Record<string, unknown>): Promise<ComponentTreeNode> {
  return request<ComponentTreeNode>(`/ruok/component-tree/${id}`, { method: 'PATCH', body: JSON.stringify(data) })
}

export async function deleteComponentTreeNode(id: number): Promise<void> {
  return request<void>(`/ruok/component-tree/${id}`, { method: 'DELETE' })
}

export async function moveComponentTreeNode(id: number, parentId: number, nodeIdx: number): Promise<void> {
  return request<void>(`/ruok/component-tree/${id}/move`, { method: 'PATCH', body: JSON.stringify({ parentId, nodeIdx }) })
}
