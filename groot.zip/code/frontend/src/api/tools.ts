import { request } from './client'

export interface Tool {
  id: number
  toolName: string
  displayName: string
  description: string | null
  toolCategory: string
  implementationClass: string
  inputSchema: string | null
  outputSchema: string | null
  isEnabled: boolean
  createdBy: string
  updatedBy: string | null
  createdAt: string
  updatedAt: string
}

export interface ScanResult {
  discovered: string[]
  inserted: string[]
}

export interface DebugResult {
  success: boolean
  output?: string
  error?: string
}

export function listTools(): Promise<Tool[]> {
  return request('/system-setting/tools')
}

export function getTool(id: number): Promise<Tool> {
  return request(`/system-setting/tools/${id}`)
}

export function updateTool(
  id: number,
  data: {
    displayName?: string
    description?: string
    toolCategory?: string
    inputSchema?: string
    outputSchema?: string
    isEnabled?: boolean
  }
): Promise<Tool> {
  return request(`/system-setting/tools/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
}

export function scanTools(): Promise<ScanResult> {
  return request('/system-setting/tools/scan', { method: 'POST' })
}

export function debugTool(id: number, input: string): Promise<DebugResult> {
  return request(`/system-setting/tools/${id}/debug`, {
    method: 'POST',
    body: JSON.stringify({ input }),
  })
}
