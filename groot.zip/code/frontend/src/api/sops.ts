import { request } from './client'

export interface SopDefinition {
  id: number
  sopName: string
  sopCode: string
  sopCategory: string
  sopDesc: string | null
  composeType: 'chain' | 'graph' | 'workflow'
  inputSchema: string | null
  outputSchema: string | null
  status: 'draft' | 'published' | 'deprecated'
  version: number
  createdBy: string
  updatedBy: string | null
  createdAt: string
  updatedAt: string
}

export interface CreateSopRequest {
  sopName: string
  sopCode: string
  sopCategory: string
  sopDesc?: string
  composeType: 'chain' | 'graph' | 'workflow'
  inputSchema?: string
  outputSchema?: string
}

export interface UpdateSopRequest {
  sopName?: string
  sopCode?: string
  sopCategory?: string
  sopDesc?: string
  composeType?: string
  inputSchema?: string
  outputSchema?: string
  status?: string
}

export function listSops(): Promise<SopDefinition[]> {
  return request('/system-setting/sops')
}

export function getSop(id: number): Promise<SopDefinition> {
  return request(`/system-setting/sops/${id}`)
}

export function createSop(data: CreateSopRequest): Promise<SopDefinition> {
  return request('/system-setting/sops', {
    method: 'POST',
    body: JSON.stringify(data),
  })
}

export function updateSop(id: number, data: UpdateSopRequest): Promise<SopDefinition> {
  return request(`/system-setting/sops/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
}
