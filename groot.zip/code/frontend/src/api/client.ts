export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public data?: unknown,
  ) {
    super(message)
    this.name = 'ApiError'
  }
}

const BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api'

export async function request<T>(
  endpoint: string,
  options: RequestInit = {},
): Promise<T> {
  const url = `${BASE_URL}${endpoint}`

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  }

  // 附带 JWT token
  try {
    const { useAuthStore } = await import('../stores/auth')
    const token = useAuthStore.getState().token
    if (token) {
      headers['Authorization'] = `Bearer ${token}`
    }
  } catch {
    // auth store 不可用时忽略
  }

  const response = await fetch(url, {
    ...options,
    headers,
  })

  if (!response.ok) {
    // 优先使用后端返回的具体错误信息
    let errorMessage = ''
    let extraInfo = ''
    try {
      const cloned = response.clone()
      const body = await cloned.json()
      if (body && typeof body === 'object' && 'error' in body) {
        errorMessage = String(body.error)
        if (typeof body.response === 'string' && body.response) {
          extraInfo = '\n' + body.response
        }
      }
    } catch {
      // 无法解析为 JSON
    }

    // 无后端具体信息时，用状态码兜底
    if (!errorMessage) {
      if (response.status === 401) {
        errorMessage = '未登录或登录已过期，请重新登录'
      } else if (response.status === 403) {
        errorMessage = '没有权限执行此操作'
      } else if (response.status === 404) {
        errorMessage = '请求的资源不存在'
      } else if (response.status >= 500) {
        errorMessage = '服务器内部错误，请稍后重试'
      } else {
        errorMessage = `请求失败 (${response.status})`
      }
    }

    throw new ApiError(errorMessage + extraInfo, response.status)
  }

  // 204 No Content
  if (response.status === 204) {
    return undefined as T
  }

  return response.json()
}
