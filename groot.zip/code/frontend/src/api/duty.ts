import { request } from './client'
import type { DutySchedule, DutyScheduleCreate, DutyScheduleUpdate } from '../schemas'

export async function listDutySchedules(year: number, month: number): Promise<DutySchedule[]> {
  return request<DutySchedule[]>(`/system-setting/duty-schedules?year=${year}&month=${month}`)
}

export async function getDutySchedule(id: number): Promise<DutySchedule> {
  return request<DutySchedule>(`/system-setting/duty-schedules/${id}`)
}

export async function createDutySchedule(data: DutyScheduleCreate): Promise<DutySchedule> {
  return request<DutySchedule>('/system-setting/duty-schedules', {
    method: 'POST',
    body: JSON.stringify(data),
  })
}

export async function updateDutySchedule(id: number, data: DutyScheduleUpdate): Promise<DutySchedule> {
  return request<DutySchedule>(`/system-setting/duty-schedules/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
}

export async function deleteDutySchedule(id: number): Promise<void> {
  return request<void>(`/system-setting/duty-schedules/${id}`, {
    method: 'DELETE',
  })
}
