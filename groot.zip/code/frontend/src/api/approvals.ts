import { request } from './client'
import type { Approval } from '../schemas'

export async function listApprovals(): Promise<Approval[]> {
  return request<Approval[]>('/approvals')
}

export async function getApproval(id: string): Promise<Approval> {
  return request<Approval>(`/approvals/${id}`)
}

export async function approveApproval(
  id: string,
  comment?: string,
): Promise<Approval> {
  return request<Approval>(`/approvals/${id}/approve`, {
    method: 'POST',
    body: JSON.stringify({ comment }),
  })
}

export async function rejectApproval(
  id: string,
  reason: string,
): Promise<Approval> {
  return request<Approval>(`/approvals/${id}/reject`, {
    method: 'POST',
    body: JSON.stringify({ reason }),
  })
}