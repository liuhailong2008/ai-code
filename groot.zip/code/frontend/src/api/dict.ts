import { request } from './client'

export interface SysDict {
  id: number
  parentId: number
  dictKey: string
  dictValue: string
  dictSn: number
  createdAt: string
  updatedAt: string
}

export async function listDicts(): Promise<SysDict[]> {
  return request<SysDict[]>('/system-setting/dicts')
}

export async function getDict(id: number): Promise<SysDict> {
  return request<SysDict>(`/system-setting/dicts/${id}`)
}

export async function createDict(data: Record<string, unknown>): Promise<SysDict> {
  return request<SysDict>('/system-setting/dicts', { method: 'POST', body: JSON.stringify(data) })
}

export async function updateDict(id: number, data: Record<string, unknown>): Promise<SysDict> {
  return request<SysDict>(`/system-setting/dicts/${id}`, { method: 'PATCH', body: JSON.stringify(data) })
}

export async function deleteDict(id: number): Promise<void> {
  return request<void>(`/system-setting/dicts/${id}`, { method: 'DELETE' })
}
