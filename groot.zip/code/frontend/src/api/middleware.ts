import { request } from './client'
import type { SopMiddleware, SopMiddlewareCreate, SopMiddlewareUpdate } from '../schemas'

export async function listSopMiddlewares(): Promise<SopMiddleware[]> {
  return request<SopMiddleware[]>('/system-setting/middlewares')
}

export async function getSopMiddleware(id: number): Promise<SopMiddleware> {
  return request<SopMiddleware>(`/system-setting/middlewares/${id}`)
}

export async function createSopMiddleware(data: SopMiddlewareCreate): Promise<SopMiddleware> {
  return request<SopMiddleware>('/system-setting/middlewares', {
    method: 'POST',
    body: JSON.stringify(data),
  })
}

export async function updateSopMiddleware(id: number, data: SopMiddlewareUpdate): Promise<SopMiddleware> {
  return request<SopMiddleware>(`/system-setting/middlewares/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
}

export async function deleteSopMiddleware(id: number): Promise<void> {
  return request<void>(`/system-setting/middlewares/${id}`, {
    method: 'DELETE',
  })
}
