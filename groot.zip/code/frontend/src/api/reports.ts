import { request } from './client'
import type { Report } from '../schemas'

export async function listReports(): Promise<Report[]> {
  return request<Report[]>('/reports')
}

export async function getReport(id: string): Promise<Report> {
  return request<Report>(`/reports/${id}`)
}