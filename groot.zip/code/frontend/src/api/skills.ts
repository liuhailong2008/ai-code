import { request } from './client'

export interface Skill {
  id: number
  skillName: string
  skillCode: string
  description: string | null
  version: string | null
  filePath: string
  isEnabled: boolean
  createdBy: string
  updatedBy: string | null
  createdAt: string
  updatedAt: string
}

export interface SkillTreeNode {
  name: string
  path: string
  type: 'file' | 'dir'
  children?: SkillTreeNode[]
}

export interface SkillTreeResponse {
  skillId: number
  skillName: string
  tree: SkillTreeNode[]
}

export interface SkillFileContent {
  path: string
  content: string
}

export interface CreateSkillRequest {
  skillName: string
  skillCode: string
  description?: string
  version?: string
}

export interface UpdateSkillRequest {
  skillName?: string
  skillCode?: string
  description?: string
  version?: string
  isEnabled?: boolean
}

// --- Skills CRUD ---

export async function listSkills(): Promise<Skill[]> {
  return request<Skill[]>('/skills')
}

export async function getSkill(id: number): Promise<Skill> {
  return request<Skill>(`/skills/${id}`)
}

export async function createSkill(data: CreateSkillRequest): Promise<Skill> {
  return request<Skill>('/skills', {
    method: 'POST',
    body: JSON.stringify(data),
  })
}

export async function uploadSkill(file: File, skillCode?: string): Promise<Skill> {
  const formData = new FormData()
  formData.append('file', file)
  if (skillCode) {
    formData.append('skillCode', skillCode)
  }

  const url = `${import.meta.env.VITE_API_BASE_URL || '/api'}/skills/upload`

  // 从 auth store 获取 token
  let token = ''
  try {
    const { useAuthStore } = await import('../stores/auth')
    token = useAuthStore.getState().token || ''
  } catch { /* ignore */ }

  const response = await fetch(url, {
    method: 'POST',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData,
  })

  if (!response.ok) {
    const body = await response.json().catch(() => ({}))
    throw new Error((body as any).error || '上传失败')
  }

  return response.json()
}

export async function updateSkill(id: number, data: UpdateSkillRequest): Promise<Skill> {
  return request<Skill>(`/skills/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
}

export async function deleteSkill(id: number): Promise<void> {
  return request<void>(`/skills/${id}`, { method: 'DELETE' })
}

// --- File Operations ---

export async function getSkillTree(id: number): Promise<SkillTreeResponse> {
  return request<SkillTreeResponse>(`/skills/${id}/tree`)
}

export async function getSkillFile(id: number, path: string): Promise<SkillFileContent> {
  return request<SkillFileContent>(`/skills/${id}/file?path=${encodeURIComponent(path)}`)
}

export async function saveSkillFile(id: number, path: string, content: string): Promise<void> {
  return request<void>(`/skills/${id}/file?path=${encodeURIComponent(path)}`, {
    method: 'PUT',
    body: JSON.stringify({ content }),
  })
}

export async function createSkillFile(id: number, path: string, content: string): Promise<void> {
  return request<void>(`/skills/${id}/file?path=${encodeURIComponent(path)}`, {
    method: 'POST',
    body: JSON.stringify({ content }),
  })
}

export async function deleteSkillFile(id: number, path: string): Promise<void> {
  return request<void>(`/skills/${id}/file?path=${encodeURIComponent(path)}`, {
    method: 'DELETE',
  })
}
