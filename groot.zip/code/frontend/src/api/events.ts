import { request } from './client'
import type { Event, Message, UIBlock } from '../schemas'

export interface ListEventsParams {
  status?: Event['status']
  limit?: number
  offset?: number
}

export async function listEvents(
  params?: ListEventsParams,
): Promise<Event[]> {
  const searchParams = new URLSearchParams()
  if (params?.status) searchParams.set('status', params.status)
  if (params?.limit) searchParams.set('limit', params.limit.toString())
  if (params?.offset) searchParams.set('offset', params.offset.toString())

  const qs = searchParams.toString()
  return request<Event[]>(`/events${qs ? `?${qs}` : ''}`)
}

export async function getEvent(id: number): Promise<Event> {
  return request<Event>(`/events/${id}`)
}

export async function createEvent(data: {
  teamId: number
  title: string
  description?: string
  category: string
  severity?: string
  appName?: string
  clusterName?: string
  idcName?: string
  source?: string
  uniNo?: string
}): Promise<Event> {
  return request<Event>('/events', {
    method: 'POST',
    body: JSON.stringify(data),
  })
}

export async function updateEventState(
  id: number,
  status: Event['status'],
): Promise<Event> {
  return request<Event>(`/events/${id}/state`, {
    method: 'PATCH',
    body: JSON.stringify({ status }),
  })
}

export async function getMessages(eventId: number): Promise<Message[]> {
  return request<Message[]>(`/events/${eventId}/messages`)
}

export async function postMessage(
  eventId: number,
  content: string,
  mentions?: string[],
  modelCode?: string | null,
): Promise<Message> {
  return request<Message>(`/events/${eventId}/messages`, {
    method: 'POST',
    body: JSON.stringify({ content, mentions: mentions ?? [], modelCode: modelCode ?? null }),
  })
}

export async function markMessagesRead(
  eventId: number,
  lastReadMessageId: number,
): Promise<void> {
  return request<void>(`/events/${eventId}/messages/read`, {
    method: 'POST',
    body: JSON.stringify({ lastReadMessageId }),
  })
}

export interface EventUnread {
  eventId: number
  unreadTotal: number
  unreadMention: number
}

export async function getEventUnread(eventId: number): Promise<EventUnread> {
  return request<EventUnread>(`/events/${eventId}/unread`)
}

export async function listMyUnread(): Promise<EventUnread[]> {
  return request<EventUnread[]>(`/me/unread`)
}

export async function getUIBlocks(eventId: number): Promise<UIBlock[]> {
  return request<UIBlock[]>(`/events/${eventId}/uiblocks`)
}

export function getStreamUrl(eventId: number, modelCode?: string | null): string {
  const baseUrl = import.meta.env.VITE_API_BASE_URL || '/api'
  const params = new URLSearchParams()
  if (modelCode) params.set('modelCode', modelCode)
  const qs = params.toString()
  return `${baseUrl}/events/${eventId}/stream${qs ? `?${qs}` : ''}`
}

export interface PresenceUser {
  userId: number
  userName: string
  lastSeenAt: string
}

export async function reportPresence(
  eventId: number,
  userId: number,
  userName: string,
): Promise<void> {
  return request<void>(`/events/${eventId}/presence`, {
    method: 'POST',
    body: JSON.stringify({ userId, userName }),
  })
}

export async function getOnlineUsers(eventId: number): Promise<PresenceUser[]> {
  return request<PresenceUser[]>(`/events/${eventId}/presence`)
}

export interface StaffMember {
  username: string
  displayName: string
}

export interface EventStaffing {
  appName: string
  appDesc: string
  primaryPost: StaffMember
  backupPost: StaffMember
  hasMiddleware: boolean
  dutyDate: string
  department: string
  positionName: string
  dutyPrimaryUser: StaffMember
  dutyBackupUser: StaffMember
  hasDuty: boolean
}

export async function getEventStaffing(eventId: number): Promise<EventStaffing> {
  return request<EventStaffing>(`/events/${eventId}/staffing`)
}
