import { request } from './client'

export interface TableInfo {
  name: string
  rowCount: number
}

export interface TableData {
  columns: string[]
  rows: Record<string, unknown>[]
  total: number
  page: number
  pageSize: number
}

export async function listTables(): Promise<TableInfo[]> {
  return request<TableInfo[]>('/system-setting/data-management/tables')
}

export async function getTableData(tableName: string, page = 1, pageSize = 20): Promise<TableData> {
  return request<TableData>(`/system-setting/data-management/tables/${tableName}?page=${page}&pageSize=${pageSize}`)
}

export async function insertRow(tableName: string, data: Record<string, unknown>): Promise<{ id: number }> {
  return request<{ id: number }>(`/system-setting/data-management/tables/${tableName}/rows`, {
    method: 'POST',
    body: JSON.stringify(data),
  })
}

export async function updateRow(tableName: string, rowId: number, data: Record<string, unknown>): Promise<void> {
  return request<void>(`/system-setting/data-management/tables/${tableName}/rows/${rowId}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
}

export async function deleteRow(tableName: string, rowId: number): Promise<void> {
  return request<void>(`/system-setting/data-management/tables/${tableName}/rows/${rowId}`, {
    method: 'DELETE',
  })
}
