import { request } from './client'
import type { ModelConfig, ModelConfigCreate, ModelConfigUpdate } from '../schemas'

export async function listModelConfigs(): Promise<ModelConfig[]> {
  return request<ModelConfig[]>('/system-setting/model-configs')
}

export async function listActiveModels(purpose = 'chat'): Promise<ModelConfig[]> {
  return request<ModelConfig[]>(`/models/active?purpose=${encodeURIComponent(purpose)}`)
}

export async function getModelConfig(id: number): Promise<ModelConfig> {
  return request<ModelConfig>(`/system-setting/model-configs/${id}`)
}

export async function createModelConfig(data: ModelConfigCreate): Promise<ModelConfig> {
  return request<ModelConfig>('/system-setting/model-configs', {
    method: 'POST',
    body: JSON.stringify(data),
  })
}

export async function updateModelConfig(id: number, data: ModelConfigUpdate): Promise<ModelConfig> {
  return request<ModelConfig>(`/system-setting/model-configs/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
}

export async function deleteModelConfig(id: number): Promise<void> {
  return request<void>(`/system-setting/model-configs/${id}`, {
    method: 'DELETE',
  })
}

export interface VerifyResult {
  success: boolean
  content: string
}

export async function verifyModelConfig(id: number, overrides?: {
  apiKey?: string
  baseUrl?: string
  code?: string
  temperature?: number | null
}): Promise<VerifyResult> {
  return request<VerifyResult>(`/system-setting/model-configs/${id}/verify`, {
    method: 'POST',
    body: overrides ? JSON.stringify(overrides) : undefined,
  })
}
