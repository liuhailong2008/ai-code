import { request } from './client'
import type { Doc } from '../schemas'

export async function listDocs(): Promise<Doc[]> {
  return request<Doc[]>('/docs')
}

export async function getDoc(id: string): Promise<Doc> {
  return request<Doc>(`/docs/${id}`)
}