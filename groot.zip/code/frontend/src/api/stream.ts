export type StreamEvent =
  | { type: 'token'; content: string }
  | { type: 'done' }
  | { type: 'error'; error: string }
  | { type: 'approval_required'; approvalId: string }
  | { type: 'uiblock'; block: unknown }

export async function* streamMessages(
  url: string,
  signal?: AbortSignal,
): AsyncGenerator<StreamEvent> {
  const headers: Record<string, string> = {}
  try {
    const { useAuthStore } = await import('../stores/auth')
    const token = useAuthStore.getState().token
    if (token) {
      headers['Authorization'] = `Bearer ${token}`
    }
  } catch { /* ignore */ }

  const response = await fetch(url, {
    signal,
    headers,
  })

  if (!response.ok) {
    throw new Error(`Stream failed: ${response.statusText}`)
  }

  const reader = response.body?.getReader()
  if (!reader) {
    throw new Error('Response body is not readable')
  }

  const decoder = new TextDecoder()
  let buffer = ''

  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) break

      buffer += decoder.decode(value, { stream: true })

      const lines = buffer.split('\n')
      buffer = lines.pop() || ''

      for (const line of lines) {
        if (line.trim() === '') continue
        if (line.startsWith('data: ')) {
          const data = line.slice(6)
          try {
            const event = JSON.parse(data) as StreamEvent
            yield event
          } catch (e) {
            console.error('Failed to parse SSE event:', e)
          }
        }
      }
    }
  } finally {
    reader.releaseLock()
  }
}

export async function connectWithRetry(
  url: string,
  onEvent: (event: StreamEvent) => void,
  onError?: (error: Error) => void,
  maxRetries = 3,
): Promise<() => void> {
  let retryCount = 0
  let abortController: AbortController | null = null

  const connect = async (): Promise<void> => {
    abortController = new AbortController()

    try {
      for await (const event of streamMessages(url, abortController.signal)) {
        if (event.type === 'error') {
          throw new Error(event.error)
        }
        onEvent(event)
        if (event.type === 'done') {
          break
        }
      }
    } catch (error) {
      if (abortController.signal.aborted) return

      if (retryCount < maxRetries) {
        retryCount++
        await new Promise((resolve) => setTimeout(resolve, 1000 * retryCount))
        await connect()
      } else {
        onError?.(error as Error)
      }
    }
  }

  await connect()

  return () => {
    abortController?.abort()
  }
}