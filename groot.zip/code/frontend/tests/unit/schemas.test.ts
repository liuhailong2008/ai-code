import { describe, it, expect } from 'vitest'
import { UserSchema, EventSchema, UIBlockSchema } from '../../src/schemas'

describe('UserSchema', () => {
  it('should parse valid user', () => {
    const user = UserSchema.parse({
      id: 1,
      username: 'test',
      displayName: 'Test User',
      role: 'admin',
      updatedAt: '2024-01-01T00:00:00Z',
      createdAt: '2024-01-01T00:00:00Z',
      preferences: { theme: 'shadcn-dark', notifications: true, language: 'zh-CN' },
    })
    expect(user.id).toBe(1)
  })

  it('should reject missing required fields', () => {
    expect(() => UserSchema.parse({
      id: 1,
    })).toThrow()
  })
})

describe('EventSchema', () => {
  it('should parse valid event', () => {
    const event = EventSchema.parse({
      id: 1,
      teamId: 1,
      title: 'Test',
      description: '',
      status: 'open',
      severity: 'high',
      category: 'test',
      idcName: '',
      appName: '',
      clusterName: '',
      source: 'manual',
      createdBy: 'user-1',
      uniNo: '',
      extTicketId: '',
      metadata: '',
      openedAt: '2024-01-01 00:00:00',
      closedAt: '',
      createdAt: '2024-01-01 00:00:00',
      updatedAt: '2024-01-01 00:00:00',
      participants: [],
    })
    expect(event.title).toBe('Test')
  })
})

describe('UIBlockSchema', () => {
  it('should parse dashboard block', () => {
    const block = UIBlockSchema.parse({
      id: 'b1',
      type: 'dashboard',
      orderIdx: 0,
      data: {
        title: 'Test',
        metrics: [{ label: 'CPU', value: 80, unit: '%' }],
        chart: { type: 'line', data: [[0, 50], [1, 80]] },
      },
    })
    expect(block.type).toBe('dashboard')
  })
})