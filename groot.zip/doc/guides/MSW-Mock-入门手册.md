# MSW（Mock Service Worker）新手手册

> 给项目同学的 Mock 工具入门手册。读完即可用 MSW 给前端写假后端。

---

## 1. MSW 是什么

**MSW（Mock Service Worker）**，由社区维护、行业事实标准（GitHub 16k+ star，被 Vercel、Stripe、Shopify、Microsoft 等广泛使用）。

它的核心思想：**用 Service Worker 在浏览器层拦截 HTTP/SSE 请求，返回你定义的假数据**。

### 为什么不直接 hack `fetch` / 在代码里写 `if (mock)` 分支？

| 方式 | 缺点 |
|---|---|
| 在业务代码里写 if/else | 真假代码混杂、上线前要清理 |
| Hack 全局 `fetch` | 第三方库（axios、ky、TanStack Query）不一定走全局 fetch |
| 起一个 Express mock server | 需要单独进程、CORS 麻烦、CI 难跑 |
| **MSW**（推荐） | **业务代码完全不知道在 mock；同一份 mock 可服务于浏览器、Vitest、Playwright** |

---

## 2. MSW 的两种运行模式

| 模式 | 何时用 | 工作位置 |
|---|---|---|
| **Browser 模式** | 浏览器里开发、E2E 测试 | Service Worker 在浏览器内拦截 |
| **Node 模式** | Vitest/Jest 单测、Node 集成测试 | 拦截 Node 的 http 模块 |

两种模式**共享同一份 handlers**（请求处理函数）。这是它最大的工程价值。

---

## 3. 快速上手（5 分钟跑通）

### 3.1 安装

```bash
pnpm add -D msw
# 生成 service worker 文件
npx msw init public/ --save
```

### 3.2 写第一个 handler

```ts
// src/mocks/handlers.ts
import { http, HttpResponse } from 'msw'

export const handlers = [
  // GET /api/events?status=open
  http.get('/api/events', ({ request }) => {
    const url = new URL(request.url)
    const status = url.searchParams.get('status')
    
    if (status === 'open') {
      return HttpResponse.json([
        { id: 1, title: 'Kafka broker-3 卡顿', severity: 'high' },
        { id: 2, title: 'Redis 集群扩容', severity: 'mid' },
      ])
    }
    return HttpResponse.json([])
  }),

  // POST /api/events
  http.post('/api/events', async ({ request }) => {
    const body = await request.json() as { title: string }
    return HttpResponse.json({ id: 999, title: body.title }, { status: 201 })
  }),
]
```

### 3.3 启动 MSW（仅在 dev 环境）

```ts
// src/mocks/browser.ts
import { setupWorker } from 'msw/browser'
import { handlers } from './handlers'

export const worker = setupWorker(...handlers)
```

```ts
// src/main.tsx
async function enableMocking() {
  if (import.meta.env.DEV) {
    const { worker } = await import('./mocks/browser')
    await worker.start({ onUnhandledRequest: 'warn' })
  }
}

enableMocking().then(() => {
  ReactDOM.createRoot(document.getElementById('root')!).render(<App />)
})
```

### 3.4 在业务代码里"正常"调 API

```ts
// src/api/events.ts
export async function listEvents(status: 'open' | 'closed') {
  const res = await fetch(`/api/events?status=${status}`)
  return res.json()
}
```

业务代码**完全不知道在 mock**。打开 DevTools → Network，会看到正常的请求/响应，唯一区别是请求源标记为 "from service worker"。

---

## 4. 进阶能力（项目用得到的）

### 4.1 SSE 流式 mock（对话流必备）

```ts
http.get('/api/events/:id/stream', () => {
  const stream = new ReadableStream({
    start(controller) {
      const encoder = new TextEncoder()
      let i = 0
      const tokens = ['正在', '分析', '中', '...']
      
      const timer = setInterval(() => {
        if (i >= tokens.length) {
          controller.close()
          clearInterval(timer)
          return
        }
        controller.enqueue(encoder.encode(`data: ${JSON.stringify({ token: tokens[i] })}\n\n`))
        i++
      }, 200)
    },
  })
  
  return new HttpResponse(stream, {
    headers: { 'Content-Type': 'text/event-stream' },
  })
})
```

这样前端的 SSE 监听代码完全不用改。**这是为什么我推荐 MSW 而不是 vite-plugin-mock**——后者对 SSE 支持差。

### 4.2 状态化 Mock（批准后状态变化）

```ts
// 内存 store
const approvals = new Map([
  [1, { id: 1, status: 'pending', tool: 'broker.restart' }],
])

http.post('/api/approvals/:id/approve', ({ params }) => {
  const id = Number(params.id)
  const approval = approvals.get(id)
  if (!approval) return new HttpResponse(null, { status: 404 })
  
  approval.status = 'approved'  // 状态变化
  return HttpResponse.json(approval)
})

http.get('/api/approvals/:id', ({ params }) => {
  return HttpResponse.json(approvals.get(Number(params.id)))
})
```

### 4.3 模拟错误 / 延迟 / 限流

```ts
http.get('/api/slow', async () => {
  await new Promise(r => setTimeout(r, 2000))   // 模拟慢
  return HttpResponse.json({})
})

http.get('/api/fail', () => {
  return new HttpResponse('Internal Error', { status: 500 })
})

http.get('/api/maybe-fail', () => {
  if (Math.random() < 0.3) {
    return new HttpResponse(null, { status: 503 })
  }
  return HttpResponse.json({ ok: true })
})
```

这是测试 Loading / Error / Retry 三态的关键能力。

### 4.4 使用 fixtures（推荐组织方式）

```ts
// src/mocks/fixtures/events/list-open.json
[
  { "id": 1234, "title": "Kafka broker-3 卡顿", "status": "open" }
]

// src/mocks/handlers/events.ts
import openEvents from '../fixtures/events/list-open.json'

export const eventsHandlers = [
  http.get('/api/events', ({ request }) => {
    const status = new URL(request.url).searchParams.get('status')
    if (status === 'open') return HttpResponse.json(openEvents)
    return HttpResponse.json([])
  }),
]
```

把"数据"和"逻辑"分开：fixtures 是 JSON、handlers 是 TS。

---

## 5. 在测试中复用同一份 handlers

### Vitest 单测

```ts
// src/mocks/server.ts
import { setupServer } from 'msw/node'
import { handlers } from './handlers'
export const server = setupServer(...handlers)

// vitest.setup.ts
import { server } from './src/mocks/server'
beforeAll(() => server.listen())
afterEach(() => server.resetHandlers())
afterAll(() => server.close())
```

### Playwright E2E

直接用 Browser 模式即可，已经在 dev 环境启动。

---

## 6. 常见坑 & FAQ

| 问题 | 解决 |
|---|---|
| Service Worker 没生效 | 检查 `public/mockServiceWorker.js` 是否存在；浏览器 DevTools → Application → Service Workers 确认已注册 |
| 生产环境误启 | `if (import.meta.env.DEV)` 守卫，只在 dev 启动 |
| 请求没被拦截 | 路径要对（`/api/events` 不要写成 `/events`）；可设 `onUnhandledRequest: 'warn'` 看哪些没拦到 |
| TypeScript 类型 | 配合 zod 校验 fixtures 不漏字段；handlers 写返回类型注解 |

---

## 7. 学习路径

1. **入门**：本文档 + 跑一个 5 分钟 demo
2. **官方文档**：https://mswjs.io —— 中英都全，质量很高
3. **进阶**：看 GitHub Discussions / 著名项目的用法（如 [TanStack Query 的 examples](https://github.com/TanStack/query/tree/main/examples)）
4. **大师**：自己造一个 stateful mock 行为引擎

---

## 8. 在本项目里的角色

```
开发期：
  浏览器 → 业务代码 → fetch /api/events
                       ↓
                       MSW Service Worker 拦截 → 返回 fixtures
  
真后端就绪后：
  浏览器 → 业务代码 → fetch /api/events
                       ↓
                       直接打到真后端（关闭 MSW）
```

业务代码**完全不变**，仅靠环境变量切换：

```ts
if (import.meta.env.VITE_USE_MOCK === 'true') {
  await worker.start()
}
```

这就是它最大的工程价值。

---

— 完 —
