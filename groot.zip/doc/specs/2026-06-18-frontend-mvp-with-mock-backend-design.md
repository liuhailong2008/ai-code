# 中间件运维智能体平台 — 前端 MVP（Mock 后端）设计规格书

- 文档版本：v1.0
- 创建日期：2026-06-18
- 文档状态：Draft（待 Review）
- **父 Spec**：[2026-06-18-中间件运维智能体平台-design.md](./2026-06-18-中间件运维智能体平台-design.md)
- 关联流程：brainstorming → **本文档（子 spec）** → writing-plans

---

## 0. 背景与定位

母 spec 描述了"中间件运维智能体平台"的完整目标态。本子项目是其**第一阶段独立可交付物**：

> **只开发前端 + Mock 后端**，让"主界面三栏 + 流式对话 + 8 类 UIBlock + 4 套主题 + 审批双通道 + 4 核心场景"先以高保真形态跑通，验证设计与交互。

**为什么先做前端**：
1. 前端是用户感知度最高的部分——交互定型早，后续不返工
2. Mock 让前后端解耦并行开发
3. 母 spec 中的"UIBlock 协议"、"激活协议"、"主题系统"等关键设计都需要在前端先验证
4. API 契约一旦在前端用 TypeScript types 定型，**就是未来后端实现的强约束**

**不在本子项目范围**（继承自母 spec 但本期不做）：
- ❌ 真实 LLM / eino 集成
- ❌ MCP / Executor 通信
- ❌ MySQL / Redis / Qdrant / MinIO
- ❌ CAS 真实对接
- ❌ Connector Hub 真实集成
- ❌ K8s helm 部署

---

## 1. 关键决策汇总（已与用户确认）

| # | 项 | 决策 |
|---|---|---|
| 1 | 子项目模式 | A — 母 spec 不动；本子 spec 独立 |
| 2 | Mock 工具 | **MSW (Mock Service Worker)**，浏览器 + Node 双模式共享 handlers |
| 3 | 仓库形态 | **同仓库 monorepo**，目录结构 `frontend/`、未来加 `backend/`、`executor/` |
| 4 | CAS 登录 | **完全 mock**：`/login` 页面提供"模拟登录"按钮，无真 CAS 交互 |
| 5 | 部署形态 | **本地 dev + 构建静态资源**（任意 nginx 可托管），不做 Docker/Helm |
| 6 | Mock 控制面板 | **要做**：开发者抽屉，可一键切换 fixtures 场景（空、压测、慢、错误、审批拒绝等） |
| 7 | Fixtures 修改方式 | AI 先造；提供清晰目录 + Zod schema 校验，用户按 README 修改 |

---

## 2. 验收标准（DoD · Definition of Done）

| # | 项 | 通过标准 |
|---|---|---|
| 1 | **三栏布局** | 左菜单 / 中对话 / 右 UIBlock 都按母 spec 设计完成；可拖动/折叠 |
| 2 | **左菜单 5 入口** | `[+新事件] / 处理中事件 / 待我审批 / 历史事件 / 资料库 / 统计报表` 全部可访问；徽章计数实时 |
| 3 | **流式对话** | SSE 流式渲染（mock）；Token-by-token 出现；可中断 |
| 4 | **4 套主题** | `shadcn-dark`（默认）/ `shadcn-light` / `cyberpunk-terminal` / `cyberpunk-neon` 全可切换；用户偏好持久化 localStorage |
| 5 | **8 类 UIBlock 渲染器** | dashboard / plan / diff / topology / form / log / approve / report 全部有 demo |
| 6 | **审批双通道** | 对话内 ApprovalCard + 独立"待我审批"页面；操作后两侧实时同步 |
| 7 | **4 核心场景演示** | 母 spec §5 的 4 个场景每个都能完整演示 |
| 8 | **三态覆盖** | Loading / Error / Empty 在所有列表/详情/流式场景齐全 |
| 9 | **Mock 控制面板** | 至少 5 个场景可一键切换 |
| 10 | **E2E 测试** | Playwright 用例覆盖核心交互（登录 → 看事件 → 发消息 → 触发审批 → 切主题） |
| 11 | **可构建静态资源** | `pnpm build` 输出 `dist/` 目录可由任意 nginx 直接托管 |

---

## 3. 技术栈

| 层 | 选型 | 备注 |
|---|---|---|
| 框架 | React 18 + Vite + TypeScript（严格模式） | |
| 路由 | TanStack Router | 类型安全的路由 |
| 服务端状态 | TanStack Query | 缓存/重试/SSE |
| 本地状态 | Zustand | 轻量、无 Provider 地狱 |
| 表单 | React Hook Form + Zod | 表单 + schema 校验 |
| 样式 | Tailwind CSS（v3 / v4 任一） | |
| 组件 | shadcn/ui | 复制源码进项目，可改 |
| 图表 | Recharts | UIBlock dashboard 用 |
| 拓扑图 | React Flow | UIBlock topology 用 |
| 代码高亮 | Shiki | UIBlock log/diff 用 |
| 图标 | Lucide React | |
| 工具 | clsx, tailwind-merge, date-fns, ts-pattern | |
| Mock | MSW (Mock Service Worker) | |
| 单测 | Vitest + Testing Library | |
| E2E | Playwright | |
| 包管理 | pnpm | |
| Lint/Format | ESLint + Prettier | |
| Git Hook | husky + lint-staged | |
| Schema 校验 | Zod | API 类型 + fixtures 校验 |

---

## 4. 目录结构

```
groot/                                  # monorepo 根
├── doc/                                # 既有
│   ├── specs/
│   └── guides/                         # MSW 入门手册等
├── try/                                # 既有 eino 试验
├── frontend/                           # ← 本子项目
│   ├── public/
│   │   └── mockServiceWorker.js        # MSW init 生成
│   ├── src/
│   │   ├── main.tsx
│   │   ├── App.tsx
│   │   ├── routes/                     # TanStack Router 路由树
│   │   │   ├── __root.tsx
│   │   │   ├── login.tsx
│   │   │   ├── _app.tsx                # 三栏布局根
│   │   │   ├── _app.events.tsx        # 处理中事件列表
│   │   │   ├── _app.events.$id.tsx    # 事件详情（中+右栏）
│   │   │   ├── _app.approvals.tsx     # 待我审批
│   │   │   ├── _app.history.tsx       # 历史事件
│   │   │   ├── _app.docs.tsx          # 资料库
│   │   │   └── _app.reports.tsx       # 报表
│   │   ├── components/
│   │   │   ├── layout/
│   │   │   │   ├── Sidebar.tsx
│   │   │   │   ├── ChatPane.tsx
│   │   │   │   └── UIBlockPane.tsx
│   │   │   ├── chat/
│   │   │   │   ├── MessageList.tsx
│   │   │   │   ├── MessageBubble.tsx
│   │   │   │   ├── StreamingMessage.tsx
│   │   │   │   └── ChatInput.tsx
│   │   │   ├── uiblocks/               # 8 类渲染器（注册式）
│   │   │   │   ├── registry.ts
│   │   │   │   ├── DashboardBlock.tsx
│   │   │   │   ├── PlanBlock.tsx
│   │   │   │   ├── DiffBlock.tsx
│   │   │   │   ├── TopologyBlock.tsx
│   │   │   │   ├── FormBlock.tsx
│   │   │   │   ├── LogBlock.tsx
│   │   │   │   ├── ApprovalBlock.tsx
│   │   │   │   └── ReportBlock.tsx
│   │   │   ├── approval/
│   │   │   │   └── ApprovalCard.tsx
│   │   │   ├── theme/
│   │   │   │   ├── ThemeProvider.tsx
│   │   │   │   ├── ThemeToggle.tsx
│   │   │   │   └── themes.ts           # 4 套主题定义
│   │   │   ├── devpanel/               # Mock 控制面板
│   │   │   │   └── DevPanel.tsx
│   │   │   └── ui/                     # shadcn 组件（复制源码）
│   │   ├── api/                        # API 客户端层（业务代码用）
│   │   │   ├── client.ts               # 基础 fetch 封装
│   │   │   ├── events.ts
│   │   │   ├── messages.ts
│   │   │   ├── approvals.ts
│   │   │   ├── docs.ts
│   │   │   ├── reports.ts
│   │   │   ├── auth.ts
│   │   │   └── stream.ts               # SSE
│   │   ├── schemas/                    # Zod schemas + TS 类型
│   │   │   ├── event.ts
│   │   │   ├── message.ts
│   │   │   ├── uiblock.ts              # 8 类 UIBlock discriminated union
│   │   │   ├── approval.ts
│   │   │   ├── doc.ts
│   │   │   ├── report.ts
│   │   │   └── user.ts
│   │   ├── stores/                     # Zustand
│   │   │   ├── auth.ts
│   │   │   ├── theme.ts
│   │   │   ├── devPanel.ts
│   │   │   └── ui.ts                   # 折叠/选中等
│   │   ├── hooks/
│   │   │   ├── useStreamMessage.ts
│   │   │   ├── useTheme.ts
│   │   │   └── useEventList.ts
│   │   ├── lib/
│   │   │   ├── cn.ts
│   │   │   └── format.ts
│   │   ├── styles/
│   │   │   ├── globals.css             # Tailwind directives + CSS 变量
│   │   │   └── themes/                 # 4 套主题的 CSS 变量
│   │   │       ├── shadcn-dark.css
│   │   │       ├── shadcn-light.css
│   │   │       ├── cyberpunk-terminal.css
│   │   │       └── cyberpunk-neon.css
│   │   └── mocks/                      # ★ MSW
│   │       ├── browser.ts
│   │       ├── server.ts               # for vitest
│   │       ├── handlers/
│   │       │   ├── index.ts
│   │       │   ├── auth.ts
│   │       │   ├── events.ts
│   │       │   ├── messages.ts         # 含 SSE 流
│   │       │   ├── approvals.ts
│   │       │   ├── docs.ts
│   │       │   └── reports.ts
│   │       ├── fixtures/               # ★ 用户主要修改的地方
│   │       │   ├── README.md           # 修改指南
│   │       │   ├── users.json
│   │       │   ├── events/
│   │       │   │   ├── _index.json
│   │       │   │   ├── 1234.json
│   │       │   │   ├── 1234.messages.json
│   │       │   │   ├── 1234.uiblocks.json
│   │       │   │   ├── 1235.json
│   │       │   │   └── ... 更多事件
│   │       │   ├── approvals.json
│   │       │   ├── docs.json
│   │       │   ├── reports/
│   │       │   │   ├── periodic.json
│   │       │   │   └── adhoc.json
│   │       │   └── tools.json
│   │       └── scenarios.ts            # Mock 场景预设（empty/load/slow/error...）
│   ├── tests/
│   │   ├── unit/
│   │   └── e2e/
│   │       └── *.spec.ts
│   ├── index.html
│   ├── vite.config.ts
│   ├── tailwind.config.ts
│   ├── tsconfig.json
│   ├── playwright.config.ts
│   ├── vitest.config.ts
│   ├── package.json
│   └── README.md
└── package.json                        # monorepo 根（pnpm workspace）
```

---

## 5. API 契约（前端定义 → 未来后端遵守）

> 全部用 Zod 定义，TypeScript 类型由 Zod 推断。这是**未来后端 OpenAPI 规范的源头**。

### 5.1 路径规约

- 全部前缀 `/api`
- 资源用复数：`/api/events`, `/api/approvals`, `/api/docs`
- 流式：`/api/events/:id/stream`（SSE）
- 错误统一：`{ error: { code, message, traceId } }`

### 5.2 核心端点

| Method | Path | 说明 |
|---|---|---|
| `GET` | `/api/auth/me` | 当前登录用户 |
| `POST` | `/api/auth/mock-login` | 模拟登录（MVP 用） |
| `POST` | `/api/auth/logout` | 退出 |
| `GET` | `/api/events?status=open\|closed&page=&size=` | 事件列表 |
| `POST` | `/api/events` | 创建事件 |
| `GET` | `/api/events/:id` | 事件详情 |
| `PATCH` | `/api/events/:id/state` | 改状态 |
| `GET` | `/api/events/:id/messages?cursor=` | 消息分页 |
| `POST` | `/api/events/:id/messages` | 发消息（普通 / @agent） |
| `GET` | `/api/events/:id/stream` | SSE 流（订阅事件 token / UIBlock） |
| `GET` | `/api/events/:id/uiblocks` | UIBlock 历史 |
| `GET` | `/api/approvals?role=mine&status=pending` | 我的待审批 |
| `GET` | `/api/approvals/:id` | 审批详情 |
| `POST` | `/api/approvals/:id/approve` | 批准 |
| `POST` | `/api/approvals/:id/reject` | 拒绝（带理由） |
| `GET` | `/api/docs?team=&query=` | 资料库列表 |
| `GET` | `/api/docs/:id` | 文档详情 |
| `GET` | `/api/reports?type=periodic\|adhoc\|dialog` | 报表列表 |
| `GET` | `/api/reports/:id` | 报表详情 |
| `GET` | `/api/user/preferences` | 用户偏好（含主题） |
| `PATCH` | `/api/user/preferences` | 更新偏好 |

### 5.3 SSE 事件类型

```ts
type StreamEvent =
  | { type: 'token', delta: string, msgId: string }
  | { type: 'uiblock', block: UIBlock, msgId: string }
  | { type: 'approval_required', approvalId: string }
  | { type: 'tool_start', toolName: string, traceId: string }
  | { type: 'tool_end', toolName: string, ok: boolean, traceId: string }
  | { type: 'done', msgId: string }
  | { type: 'error', message: string, code: string }
```

---

## 6. UIBlock 协议（前端最终敲定，后端遵守）

```ts
// schemas/uiblock.ts
const BaseBlock = z.object({
  id: z.string(),
  msgId: z.string(),
  orderIdx: z.number(),
  createdAt: z.string().datetime(),
})

const DashboardBlock = BaseBlock.extend({
  type: z.literal('dashboard'),
  payload: z.object({
    title: z.string(),
    series: z.array(z.object({
      name: z.string(),
      points: z.array(z.tuple([z.number(), z.number()])),
      unit: z.string().optional(),
      threshold: z.number().optional(),
    })),
    timeRange: z.tuple([z.string(), z.string()]),
  }),
})

const PlanBlock = BaseBlock.extend({
  type: z.literal('plan'),
  payload: z.object({
    title: z.string(),
    risk: z.enum(['low', 'mid', 'high']),
    steps: z.array(z.object({
      idx: z.number(),
      desc: z.string(),
      status: z.enum(['pending', 'running', 'done', 'failed']),
    })),
    impact: z.string().optional(),
    rollback: z.string().optional(),
  }),
})

// ... DiffBlock / TopologyBlock / FormBlock / LogBlock / ApprovalBlock / ReportBlock

export const UIBlock = z.discriminatedUnion('type', [
  DashboardBlock, PlanBlock, DiffBlock, TopologyBlock,
  FormBlock, LogBlock, ApprovalBlock, ReportBlock,
])
export type UIBlock = z.infer<typeof UIBlock>
```

**渲染器注册**：

```ts
// uiblocks/registry.ts
export const renderers: Record<UIBlock['type'], React.FC<{ block: UIBlock }>> = {
  dashboard: DashboardBlock,
  plan: PlanBlock,
  diff: DiffBlock,
  topology: TopologyBlock,
  form: FormBlock,
  log: LogBlock,
  approve: ApprovalBlock,
  report: ReportBlock,
}
```

---

## 7. 主题系统

### 7.1 4 套预置主题

| ID | 显示名 | 默认 |
|---|---|---|
| `shadcn-dark` | 暗色（专业）| ⭐ |
| `shadcn-light` | 浅色（专业）| |
| `cyberpunk-terminal` | Hacker 终端 | |
| `cyberpunk-neon` | Neon Tokyo | |

### 7.2 实现机制

```css
/* styles/themes/shadcn-dark.css */
:root[data-theme="shadcn-dark"] {
  --background: 0 0% 4%;
  --foreground: 0 0% 98%;
  --primary: 0 0% 98%;
  --border: 240 4% 16%;
  --destructive: 0 72% 51%;
  --font-sans: 'Inter', ...;
  --font-mono: 'JetBrains Mono', ...;
  /* 以上为关键变量示意。实施时需覆盖 shadcn/ui 完整 design tokens（~30 个变量），
     含 --card / --popover / --muted / --accent / --ring / --radius 等，
     按 shadcn 官方主题变量清单补全。 */
}

:root[data-theme="cyberpunk-terminal"] {
  --background: 0 0% 0%;
  --foreground: 130 100% 50%;
  --primary: 130 100% 50%;
  --border: 130 100% 25%;
  --destructive: 348 100% 50%;
  --font-sans: 'JetBrains Mono', monospace;  /* 全等宽 */
  --font-mono: 'JetBrains Mono', monospace;
}
```

切换：`document.documentElement.dataset.theme = 'cyberpunk-terminal'`，即时生效。

### 7.3 持久化

- 用户登录后从 `/api/user/preferences` 拉取
- 落地到 `localStorage.theme` 兜底
- 切换时 `PATCH /api/user/preferences` 同步

### 7.4 UIBlock 主题感知

8 类渲染器**禁止写死颜色**——所有颜色走 CSS 变量。Recharts/React Flow 等图表库通过 Tailwind 工具类或 inline style 用 CSS 变量。

---

## 8. Mock 设计

### 8.1 Handlers 组织

按资源拆分文件，每个 handler 接 fixtures + 必要的状态化逻辑。

```ts
// mocks/handlers/events.ts
import openEvents from '../fixtures/events/_index.json'

export const eventsHandlers = [
  http.get('/api/events', ({ request }) => {
    const status = new URL(request.url).searchParams.get('status')
    // ...过滤 + 分页
    return HttpResponse.json(filtered)
  }),

  http.get('/api/events/:id/stream', () => {
    return mockSseStream(/* 按场景生成 token/uiblock/approval_required */)
  }),
]
```

### 8.2 Stateful Mock（必须的状态化）

| 资源 | 为什么需要状态 |
|---|---|
| `approvals` | 批准 → 状态变 approved；要影响事件状态机 |
| `events` | 状态：open → in_progress → closed |
| `messages` | 用户发消息 → 出现在历史 |
| `user_preferences` | 切主题 → 同步 |

用一个**内存 store**（每次刷新页面重置）：

```ts
// mocks/store.ts
class MockStore {
  events = new Map<string, Event>()
  approvals = new Map<string, Approval>()
  preferences: UserPreferences = { theme: 'shadcn-dark', ... }
  flags = {
    delay: 0,          // 全局请求延迟（ms），如 2000
    errorRate: 0,      // 随机错误概率（0~1），如 0.3
  }
  eventMeta: Map<string, { simulatedApproval?: 'rejected' }> = new Map()
  reset() { /* 清空 events/approvals/flags，从 fixtures 重新加载 */ }
  // ...
}
export const store = new MockStore()
```

启动时从 fixtures 初始化，运行时变更。

### 8.3 Mock 控制面板（DevPanel）

仅 dev 环境出现的悬浮抽屉（如右下角"🛠"按钮）：

```
┌──────────────────────────────────┐
│  Mock Dev Panel       [×]        │
├──────────────────────────────────┤
│  场景预设：                       │
│  ◉ 正常态                         │
│  ○ 空状态（无事件 / 无审批）      │
│  ○ 大量数据（100 事件压测）       │
│  ○ 慢网络（每个请求 +2s）         │
│  ○ 错误注入（30% 概率 5xx）       │
│  ○ 审批被拒                       │
│                                  │
│  快速操作：                       │
│  [触发新告警事件]                 │
│  [推送一条流式 Agent 消息]        │
│  [重置 store]                    │
│                                  │
│  当前主题：shadcn-dark           │
│  [切换 ▼]                        │
└──────────────────────────────────┘
```

实现位置：`components/devpanel/DevPanel.tsx`，由 Zustand store 控制场景。

### 8.4 SSE 流 Mock（关键）

```ts
function mockSseStream(events: StreamEvent[], intervalMs = 100) {
  return new HttpResponse(
    new ReadableStream({
      async start(controller) {
        const enc = new TextEncoder()
        for (const ev of events) {
          await sleep(intervalMs)
          controller.enqueue(enc.encode(`data: ${JSON.stringify(ev)}\n\n`))
        }
        controller.close()
      },
    }),
    { headers: { 'Content-Type': 'text/event-stream' } }
  )
}
```

按 4 核心场景预录"剧本"：每个场景一个 `StreamEvent[]` 数组，DevPanel 切换即可重放。

---

## 9. Fixtures 修改指南（README 内容草案）

放到 `src/mocks/fixtures/README.md`：

```markdown
# Fixtures 修改指南

## 文件结构

每个 .json 都对应一个 API 返回。修改它就是修改"假后端的数据"。

## 改 1 条事件
打开 `events/<id>.json`：
{
  "id": 1234,
  "title": "Kafka broker-3 卡顿",  // 标题
  "severity": "high",                // low | mid | high
  "status": "open",                  // open | in_progress | closed
  "source": "alert",                 // human | alert | inspect | ticket
  "openedAt": "2026-06-18T14:32:00Z"
}

## 加一个新事件
1. 复制 `events/1234.json` → `events/5678.json`，改字段
2. 在 `events/_index.json` 数组里加 5678
3. 可选：建 `events/5678.messages.json` 和 `events/5678.uiblocks.json`

## 注意
启动时会用 Zod schema 校验所有 fixtures，
改坏了控制台会精确指出哪个字段不对。
```

---

## 10. 路由设计

```
/login                                    模拟登录
/                                         默认重定向到 /events
/events                                   处理中事件列表（左菜单第一项）
/events/:id                               单事件视图（中+右栏）
/approvals                                待我审批
/approvals/:id                            单审批详情（专门页面）
/history                                  历史事件
/docs                                     资料库
/docs/:id                                 文档详情
/reports                                  报表列表
/reports/:id                              报表详情
/settings/preferences                     用户偏好（主题切换在这里也有入口）
```

所有 `/` 后路径在 `_app.tsx` 三栏布局里渲染。`/login` 独立全屏布局。

**"+新事件" 按钮交互**：
1. 用户点击左菜单顶部 `[+新事件]` 按钮
2. 前端 `POST /api/events { title: "新事件", source: "human" }`
3. 收到 `201 Created { id }` → 跳转 `/events/{id}`
4. 事件详情页自动弹出输入框（居中聚焦），等待用户输入第一句话

---

## 11. 4 核心场景 Demo（继承自母 spec §5）

| 场景 | DevPanel 触发方式 | 期望表现 |
|---|---|---|
| §5.1 告警自动建事件 | 点 [触发新告警事件] | 左菜单出现新事件（红点徽章）；点进去看到 Agent 已自动分析 + dashboard UIBlock |
| §5.2 高风险变更 + HITL | 在事件里 @agent 说"重启 broker-3" | Agent 流式输出 → 出现 ApprovalCard → 用户点"批准" → 流式继续 |
| §5.3 Go 脚本生成报告 | 在事件里 @agent 说"生成上周周报发邮箱" | 流式输出 → ReportBlock 显示下载链接 |
| §5.4 多人协同 + @ 激活 | DevPanel 模拟另一用户发消息 | 多 actor 显示；未 @ Agent 不响应；@ 后正常激活 |

---

## 12. 错误处理

- API 错误统一拦截：`api/client.ts` 抛标准 `ApiError(code, message, traceId)`
- TanStack Query 默认 3 次重试 + 指数退避
- SSE 断线自动重连（最多 5 次）
- 每个页面有 ErrorBoundary 兜底
- DevPanel "错误注入" 场景验证三态展现

---

## 13. 测试策略

| 层 | 范围 | 工具 |
|---|---|---|
| 单元测试 | hooks / utils / Zod schemas / UIBlock 渲染快照 | Vitest + Testing Library |
| 集成测试 | 业务流程在 Node MSW 下跑（如发消息→审批→执行） | Vitest + MSW node |
| E2E | 4 核心场景全链路 | Playwright |
| 视觉回归 | 4 套主题 × 8 类 UIBlock 截图 | Playwright snapshot |

---

## 14. 关键质量门

- TypeScript 严格模式（`strict: true`，`noUncheckedIndexedAccess: true`）
- ESLint 0 error
- 测试通过率 100%
- E2E 4 个核心场景必过
- 所有 fixtures Zod 校验通过
- Bundle 大小 < 1.5MB（gzip < 500KB）
- 首屏 LCP < 2s（本地 mock）

---

## 15. 切换到真后端的迁移路径

1. 后端按 `src/schemas/*` 实现 OpenAPI/RESTful endpoints
2. `.env.production` 设 `VITE_USE_MOCK=false`
3. `main.tsx` 守卫已有 `if (DEV) startMSW()`
4. 业务代码零改动
5. SSE / 错误格式 / 字段命名后端必须严格对齐 schemas（Zod 校验在前端会再次兜底）

---

## 附录 A · DevPanel 场景剧本预设

每个场景在 `mocks/scenarios.ts` 是一个对象：

```ts
export const scenarios = {
  normal: {
    label: '正常态',
    setup: () => store.reset(),
  },
  empty: {
    label: '空状态',
    setup: () => { store.reset(); store.events.clear(); },
  },
  bulk: {
    label: '100 事件压测',
    setup: () => bulkLoad(100),
  },
  slow: {
    label: '慢网络',
    setup: () => store.flags.delay = 2000,
  },
  errorRate: {
    label: '错误注入 30%',
    setup: () => store.flags.errorRate = 0.3,
  },
  rejected: {
    label: '审批被拒',
    setup: () => store.eventMeta.set(1234, { simulatedApproval: 'rejected' }),
  },
}
```

---

## 附录 B · 待 writing-plans 阶段决策

- 任务粒度拆分（建议分组：基础设施 / 路由布局 / Sidebar / Chat / UIBlock 8 类 / Approval / 主题 / Mock / 测试）
- 单人 vs 多人开发分工
- 实施次序与并行度
- 每个里程碑的 demo 内容

—— 文档完 ——
