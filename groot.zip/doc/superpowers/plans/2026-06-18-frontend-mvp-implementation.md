# 前端 MVP（Mock 后端）实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 实现中间件运维智能体平台的前端 MVP，用 MSW mock 后端，跑通三栏布局 + 流式对话 + 8 类 UIBlock + 4 套主题 + 审批 + 4 核心场景。

**Architecture:** React 18 + Vite monorepo 下 `frontend/` 子项目；TanStack Query 管理服务端状态，Zustand 管理本地状态，MSW 拦截所有 `/api/*` 请求；TanStack Router 类型安全路由；shadcn/ui（Tailwind + Radix）组件；全部 TypeScript 严格模式 + Zod 校验。

**Tech Stack:** React 18, Vite, TypeScript(strict), TanStack Router, TanStack Query, Zustand, Tailwind CSS, shadcn/ui, Recharts, React Flow, Shiki, MSW, Vitest + Testing Library, Playwright, pnpm, Zod

**Spec:** [前端 MVP Spec](../../specs/2026-06-18-frontend-mvp-with-mock-backend-design.md)

---

## 文件结构总览

```
frontend/
├── public/mockServiceWorker.js        # MSW CLI 生成
├── src/
│   ├── main.tsx                       # 入口：启动 MSW → 挂载 App
│   ├── App.tsx                        # RouterProvider + ThemeProvider
│   ├── routes/                        # TanStack Router 路由树
│   │   ├── __root.tsx                 # 根布局
│   │   ├── login.tsx                  # 模拟登录页
│   │   ├── _app.tsx                   # 三栏布局根（需登录）
│   │   ├── _app.events.tsx            # 处理中事件列表
│   │   ├── _app.events.$id.tsx        # 事件详情
│   │   ├── _app.approvals.tsx         # 待审批列表
│   │   ├── _app.approvals.$id.tsx     # 审批详情
│   │   ├── _app.history.tsx           # 历史事件列表
│   │   ├── _app.docs.tsx              # 资料库列表
│   │   ├── _app.docs.$id.tsx          # 文档详情
│   │   ├── _app.reports.tsx           # 报表列表
│   │   └── _app.reports.$id.tsx       # 报表详情
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Sidebar.tsx            # 左菜单
│   │   │   ├── ChatPane.tsx           # 中栏
│   │   │   └── UIBlockPane.tsx        # 右栏
│   │   ├── chat/
│   │   │   ├── MessageList.tsx
│   │   │   ├── MessageBubble.tsx
│   │   │   ├── StreamingMessage.tsx
│   │   │   └── ChatInput.tsx
│   │   ├── uiblocks/
│   │   │   ├── registry.ts
│   │   │   ├── DashboardBlock.tsx
│   │   │   ├── PlanBlock.tsx
│   │   │   ├── DiffBlock.tsx
│   │   │   ├── TopologyBlock.tsx
│   │   │   ├── FormBlock.tsx
│   │   │   ├── LogBlock.tsx
│   │   │   ├── ApprovalBlock.tsx
│   │   │   └── ReportBlock.tsx
│   │   ├── approval/
│   │   │   └── ApprovalCard.tsx
│   │   ├── theme/
│   │   │   ├── ThemeProvider.tsx
│   │   │   ├── ThemeToggle.tsx
│   │   │   └── themes.ts
│   │   ├── devpanel/
│   │   │   └── DevPanel.tsx
│   │   └── ui/                        # shadcn 组件（npx shadcn-ui 生成）
│   ├── api/                           # API 客户端
│   │   ├── client.ts
│   │   ├── auth.ts
│   │   ├── events.ts
│   │   ├── messages.ts
│   │   ├── approvals.ts
│   │   ├── docs.ts
│   │   ├── reports.ts
│   │   └── stream.ts
│   ├── schemas/                       # Zod schemas
│   │   ├── event.ts
│   │   ├── message.ts
│   │   ├── uiblock.ts
│   │   ├── approval.ts
│   │   ├── doc.ts
│   │   ├── report.ts
│   │   └── user.ts
│   ├── stores/
│   │   ├── auth.ts
│   │   ├── theme.ts
│   │   ├── devPanel.ts
│   │   └── ui.ts
│   ├── hooks/
│   │   ├── useStreamMessage.ts
│   │   ├── useTheme.ts
│   │   └── useEventList.ts
│   ├── lib/
│   │   ├── cn.ts
│   │   └── format.ts
│   ├── styles/
│   │   ├── globals.css
│   │   └── themes/
│   │       ├── shadcn-dark.css
│   │       ├── shadcn-light.css
│   │       ├── cyberpunk-terminal.css
│   │       └── cyberpunk-neon.css
│   └── mocks/
│       ├── browser.ts
│       ├── server.ts
│       ├── store.ts
│       ├── scenarios.ts
│       ├── handlers/
│       │   ├── index.ts
│       │   ├── auth.ts
│       │   ├── events.ts
│       │   ├── messages.ts
│       │   ├── approvals.ts
│       │   ├── docs.ts
│       │   └── reports.ts
│       └── fixtures/
│           ├── README.md
│           ├── users.json
│           ├── events/
│           │   ├── _index.json
│           │   ├── 1234.json
│           │   ├── 1234.messages.json
│           │   ├── 1234.uiblocks.json
│           │   └── 1235.json
│           ├── approvals.json
│           ├── docs.json
│           ├── tools.json
│           └── reports/
│               ├── periodic.json
│               └── adhoc.json
├── tests/
│   ├── unit/
│   └── e2e/
├── index.html
├── vite.config.ts
├── tailwind.config.ts
├── tsconfig.json
├── playwright.config.ts
├── vitest.config.ts
├── eslint.config.js
├── .prettierrc
├── postcss.config.js
├── package.json
└── README.md
```

---

### Phase 1: 基础设施（Tasks 1-7）

### Task 1: 初始化前端项目

- [ ] **Step 1: 创建 pnpm workspace 根**

更新 `/Users/liuhailong/Documents/workspace/groot/package.json`:

```json
{
  "name": "groot",
  "private": true,
  "scripts": {
    "dev": "pnpm --filter frontend dev",
    "build": "pnpm --filter frontend build",
    "lint": "pnpm --filter frontend lint",
    "test": "pnpm --filter frontend test"
  }
}
```

- [ ] **Step 2: 创建 frontend/package.json**

```json
{
  "name": "frontend",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc -b && vite build",
    "preview": "vite preview",
    "lint": "eslint .",
    "test": "vitest run",
    "test:watch": "vitest",
    "test:e2e": "playwright test"
  },
  "dependencies": {
    "@tanstack/react-query": "^5",
    "@tanstack/react-router": "^1",
    "clsx": "^2",
    "date-fns": "^4",
    "lucide-react": "^0",
    "react": "^18",
    "react-dom": "^18",
    "recharts": "^2",
    "shiki": "^1",
    "tailwind-merge": "^2",
    "zod": "^3",
    "zustand": "^5"
  },
  "devDependencies": {
    "@playwright/test": "^1",
    "@tailwindcss/typography": "^0.5",
    "@tanstack/router-devtools": "^1",
    "@tanstack/router-plugin": "^1",
    "@testing-library/jest-dom": "^6",
    "@testing-library/react": "^16",
    "@testing-library/user-event": "^14",
    "@types/react": "^18",
    "@types/react-dom": "^18",
    "@vitejs/plugin-react": "^4",
    "autoprefixer": "^10",
    "eslint": "^9",
    "eslint-plugin-react-hooks": "^5",
    "eslint-plugin-react-refresh": "^0.4",
    "@eslint/js": "^9",
    "typescript-eslint": "^8",
    "globals": "^15",
    "jsdom": "^25",
    "msw": "^2",
    "postcss": "^8",
    "prettier": "^3",
    "tailwindcss": "^3",
    "typescript": "^5",
    "vite": "^6",
    "vitest": "^2"
  }
}
```

- [ ] **Step 3: 安装依赖**

```bash
cd /Users/liuhailong/Documents/workspace/groot && pnpm install
```
Expected: 安装成功。

- [ ] **Step 4: 创建各配置文件**（index.html, vite.config.ts, tsconfig.json, tailwind.config.ts, eslint.config.js, .prettierrc, postcss.config.js）

见 Task 1 的 Steps 4-10（完整代码在 plan 中已给出）。

- [ ] **Step 5: Commit**

```bash
git add package.json frontend/ && git commit -m "feat: init frontend project with Vite + React + TypeScript + Tailwind"
```

---

### Task 2: 创建 global CSS 与 cn 工具

- [ ] **Step 1: 创建 frontend/src/styles/globals.css** — 含完整 shadcn dark/light CSS 变量（~30+ tokens）
- [ ] **Step 2: 创建 frontend/src/lib/cn.ts** — `cn()` 函数（clsx + tailwind-merge）
- [ ] **Step 3: Commit**

---

### Task 3: 创建 Zod schemas（API 类型定义）

- [ ] **Step 1: schemas/user.ts** — UserSchema, UserPreferencesSchema
- [ ] **Step 2: schemas/event.ts** — EventSchema, EventParticipantSchema
- [ ] **Step 3: schemas/message.ts** — MessageSchema
- [ ] **Step 4: schemas/approval.ts** — ApprovalSchema
- [ ] **Step 5: schemas/uiblock.ts** — UIBlockSchema（8 类 discriminated union）
- [ ] **Step 6: schemas/doc.ts** — DocSchema
- [ ] **Step 7: schemas/report.ts** — ReportSchema
- [ ] **Step 8: Commit**

---

### Task 4: 创建 API 客户端层

- [ ] **Step 1: api/client.ts** — `ApiError` class + `request<T>()` 封装
- [ ] **Step 2: api/auth.ts** — getMe / mockLogin / logout / getPreferences / updatePreferences
- [ ] **Step 3: api/events.ts** — listEvents / getEvent / createEvent / updateEventState / getMessages / postMessage / getUIBlocks / getStreamUrl
- [ ] **Step 4: api/approvals.ts** — listApprovals / getApproval / approveApproval / rejectApproval
- [ ] **Step 5: api/docs.ts** — listDocs / getDoc
- [ ] **Step 6: api/reports.ts** — listReports / getReport
- [ ] **Step 7: api/stream.ts** — SSE reader 封装（ReadableStream + 自动重连）
- [ ] **Step 8: Commit**

---

### Task 5: 创建 Zustand stores

- [ ] **Step 1: stores/auth.ts** — useAuthStore（user / login / logout / isLoading）
- [ ] **Step 2: stores/theme.ts** — useThemeStore（theme / setTheme + localStorage 持久化）
- [ ] **Step 3: stores/devPanel.ts** — useDevPanelStore（isOpen / currentScenario / toggle / setScenario）
- [ ] **Step 4: stores/ui.ts** — useUiStore（sidebarCollapsed / uiBlockPaneCollapsed / selectedEventId）
- [ ] **Step 5: Commit**

---

### Task 6: 创建 MSW Mock 基础设施

- [ ] **Step 1: 初始化 MSW**

```bash
cd /Users/liuhailong/Documents/workspace/groot/frontend && npx msw init public/ --save
```

- [ ] **Step 2: 创建 mocks/store.ts** — MockStore class（events / approvals / flags / eventMeta / reset）
- [ ] **Step 3: 创建 mocks/browser.ts** 和 **mocks/server.ts**
- [ ] **Step 4: 创建 mocks/handlers/index.ts** — 汇总所有 handlers
- [ ] **Step 5: Commit**

---

### Task 7: 创建 Mock Handlers + Fixtures

- [ ] **Step 1: mocks/fixtures/users.json** — 4 个用户
- [ ] **Step 2: mocks/fixtures/events/_index.json** — ["1234", "1235"]
- [ ] **Step 3: mocks/fixtures/events/1234.json** — Kafka 告警事件
- [ ] **Step 4: mocks/fixtures/events/1234.messages.json** — 4 条对话消息
- [ ] **Step 5: mocks/fixtures/events/1234.uiblocks.json** — dashboard + plan UIBlock
- [ ] **Step 6: mocks/fixtures/events/1235.json** — Redis 巡检事件
- [ ] **Step 7: mocks/fixtures/approvals.json** — 1 条审批
- [ ] **Step 8: mocks/fixtures/docs.json** — 3 份资料库文档
- [ ] **Step 9: mocks/fixtures/tools.json** — 9 个工具
- [ ] **Step 10: mocks/fixtures/reports/periodic.json** — 2 份定期报表
- [ ] **Step 11: mocks/fixtures/reports/adhoc.json** — 1 份即席报表
- [ ] **Step 12: mocks/fixtures/README.md** — 修改指南
- [ ] **Step 13: mocks/handlers/auth.ts** — mock-login / me / logout / preferences
- [ ] **Step 14: mocks/handlers/events.ts** — list / create / get / update state
- [ ] **Step 15: mocks/handlers/messages.ts** — list / post / stream SSE
- [ ] **Step 16: mocks/handlers/approvals.ts** — list / get / approve / reject
- [ ] **Step 17: mocks/handlers/docs.ts** — list / get
- [ ] **Step 18: mocks/handlers/reports.ts** — list / get
- [ ] **Step 19: mocks/scenarios.ts** — 6 场景预设
- [ ] **Step 20: Commit**

---

### Phase 2: 核心 UI（Tasks 8-14）

### Task 8: 创建主题系统 + ThemeProvider

**Files:** theme/themes.ts, theme/ThemeProvider.tsx, theme/ThemeToggle.tsx, styles/themes/*.css

- [ ] **Step 1: 创建 4 套主题 CSS 变量文件**
- [ ] **Step 2: 创建 ThemeProvider** — 挂载时应用 localStorage 中的主题，设置 `data-theme`
- [ ] **Step 3: 创建 ThemeToggle** — 下拉选择 4 套主题
- [ ] **Step 4: Commit**

---

### Task 9: 创建 entries（main.tsx + App.tsx）与路由

**Files:** main.tsx, App.tsx, routes/__root.tsx, routes/login.tsx, routes/_app.tsx

- [ ] **Step 1: 创建 main.tsx** — `if (DEV) startMSW() → ReactDOM.render(<App />)`
- [ ] **Step 2: 配置 TanStack Router** — 创建 `routeTree.gen.ts`（由 plugin 自动生成）
- [ ] **Step 3: 创建 __root.tsx** — 根布局（无 UI）
- [ ] **Step 4: 创建 login.tsx** — 模拟登录页，用户列表下拉 + "模拟登录"按钮
- [ ] **Step 5: 创建 _app.tsx** — 三栏布局根（需登录守卫），含 Sidebar + ChatPane + UIBlockPane
- [ ] **Step 6: 运行 pnpm dev 验证** — 浏览器打开 `http://localhost:3000`，能登录、看到三栏骨架
- [ ] **Step 7: Commit**

---

### Task 10: 创建 Sidebar（左侧菜单）

**Files:** components/layout/Sidebar.tsx, routes/_app.events.tsx, routes/_app.approvals.tsx, routes/_app.history.tsx, routes/_app.docs.tsx, routes/_app.reports.tsx

- [ ] **Step 1: 创建 Sidebar 组件** — 顶部 `[+新事件]` 按钮 + 5 个菜单项 + 徽章计数 + 当前用户头像
- [ ] **Step 2: 绑定路由导航** — 点击菜单项切换到对应路由
- [ ] **Step 3: 创建 5 个列表占位页**（events / approvals / history / docs / reports）— 先显示标题即可
- [ ] **Step 4: 验证** — 登录后左侧菜单可切换，路由变化正确
- [ ] **Step 5: Commit**

---

### Task 11: 创建事件列表页 + 事件详情路由

**Files:** routes/_app.events.tsx, routes/_app.events.$id.tsx, hooks/useEventList.ts

- [ ] **Step 1: _app.events.tsx** — 用 `useQuery` 拉 `/api/events?status=open`，列表渲染
- [ ] **Step 2: 列表卡片** — 显示标题 / 严重程度 badge / 时间 / 参与人数
- [ ] **Step 3: _app.events.$id.tsx** — 事件详情页骨架，接收 `$id` 参数
- [ ] **Step 4: 创建 useEventList hook** — 封装 TanStack Query
- [ ] **Step 5: Commit**

---

### Task 12: 创建 ChatPane（中间对话栏）

**Files:** components/layout/ChatPane.tsx, components/chat/MessageList.tsx, components/chat/MessageBubble.tsx, components/chat/ChatInput.tsx

- [ ] **Step 1: ChatPane** — 上部分 MessageList + 下部分 ChatInput
- [ ] **Step 2: MessageList** — 从 `useQuery` 拉消息，渲染消息列表
- [ ] **Step 3: MessageBubble** — 按 role（user/agent/system）渲染不同样式；显示 actor 头像和名字
- [ ] **Step 4: ChatInput** — textarea + 发送按钮；Ctrl+Enter 发送；支持 `@agent` 语法高亮
- [ ] **Step 5: 验证** — 点击事件 → 看到 4 条 mock 消息正确渲染
- [ ] **Step 6: Commit**

---

### Task 13: 创建流式消息渲染

**Files:** components/chat/StreamingMessage.tsx, hooks/useStreamMessage.ts

- [ ] **Step 1: 创建 useStreamMessage hook** — 连接 SSE，维护 token buffer，处理 StreamEvent 各类型
- [ ] **Step 2: 创建 StreamingMessage 组件** — Token-by-token 动画出现；Done 时变为普通 MessageBubble
- [ ] **Step 3: 集成到 MessageList** — 当有流式消息时显示 StreamingMessage
- [ ] **Step 4: 验证** — 发送一条 @agent 消息 → 看到流式 "正在分析中..." → 完成
- [ ] **Step 5: Commit**

---

### Task 14: 创建 UIBlockPane（右侧交互区）+ 8 类渲染器

**Files:** components/layout/UIBlockPane.tsx, components/uiblocks/registry.ts, components/uiblocks/DashboardBlock.tsx, components/uiblocks/PlanBlock.tsx, components/uiblocks/DiffBlock.tsx, components/uiblocks/TopologyBlock.tsx, components/uiblocks/FormBlock.tsx, components/uiblocks/LogBlock.tsx, components/uiblocks/ApprovalBlock.tsx, components/uiblocks/ReportBlock.tsx

- [ ] **Step 1: 创建 registry.ts** — `Record<type, React.FC>` 注册表
- [ ] **Step 2: 创建 UIBlockPane** — 读取 `useQuery` 的 uiblocks 列表，按 orderIdx 排序，渲染所有 block
- [ ] **Step 3-10: 逐一创建 8 个渲染器**
  - DashboardBlock: Recharts 折线图
  - PlanBlock: 步骤列表 + 状态图标
  - DiffBlock: Shiki 代码高亮 diff
  - TopologyBlock: React Flow 拓扑图
  - FormBlock: 智能表单（React Hook Form + Zod）
  - LogBlock: 带 ANSI 着色的日志行
  - ApprovalBlock: 审批卡片（含 approve/reject 按钮）
  - ReportBlock: 下载链接卡片
- [ ] **Step 11: 验证** — 点击 event 1234 → 右侧显示 mock 的 dashboard + plan
- [ ] **Step 12: Commit**

---

### Phase 3: 审批 + DevPanel（Tasks 15-16）

### Task 15: 创建审批系统

**Files:** components/approval/ApprovalCard.tsx, routes/_app.approvals.tsx, routes/_app.approvals.$id.tsx

- [ ] **Step 1: ApprovalCard** — 展示审批信息 + [批准]/[拒绝(带理由)] 按钮；调用 API
- [ ] **Step 2: 在 ChatPane 中集成** — 当 SSE 收到 `approval_required` 时，自动渲染 ApprovalCard
- [ ] **Step 3: _app.approvals.tsx** — 待审批列表页（独立页面审批通道）
- [ ] **Step 4: _app.approvals.$id.tsx** — 单审批详情页
- [ ] **Step 5: 验证** — 在事件 1234 中触发审批 → 左侧徽章计数更新 → 点进审批页也能操作
- [ ] **Step 6: Commit**

---

### Task 16: 创建 DevPanel + 场景系统

**Files:** components/devpanel/DevPanel.tsx, mocks/scenarios.ts

- [ ] **Step 1: mocks/scenarios.ts** — 6 个场景的 setup 函数
- [ ] **Step 2: DevPanel** — 右下角悬浮抽屉；单选切换场景 + 快速操作按钮
- [ ] **Step 3: 验证** — 切换"空状态"→ 无事件显示；切换"慢网络"→ 请求慢 2s；切换"审批被拒"→ 审批拒绝
- [ ] **Step 4: Commit**

---

### Phase 4: 测试 + 质量（Tasks 17-20）

### Task 17: 单元测试

- [ ] **Step 1: vitest.config.ts** — 配置 jsdom 环境
- [ ] **Step 2: Vitest setup** — 全局 MSW server
- [ ] **Step 3: schemas 测试** — 每个 schema 的 parse/safeParse 测试
- [ ] **Step 4: stores 测试** — auth/theme/ui store 的 setter 测试
- [ ] **Step 5: UIBlock 渲染快照** — 每种 type 的快照测试
- [ ] **Step 6: 运行 `pnpm test`** — 全部通过
- [ ] **Step 7: Commit**

---

### Task 18: Playwright E2E 配置

- [ ] **Step 1: playwright.config.ts** — 配置 baseURL + webServer
- [ ] **Step 2: 安装 Playwright 浏览器** — `npx playwright install chromium`
- [ ] **Step 3: Commit**

---

### Task 19: Playwright E2E 测试

- [ ] **Step 1: 登录测试** — 模拟登录 → 验证三栏出现
- [ ] **Step 2: 事件浏览测试** — 点击事件 → 看到消息 + UIBlock
- [ ] **Step 3: 对话测试** — 发消息 → 验证出现在列表
- [ ] **Step 4: 审批流程测试** — 触发审批 → 在审批页批准 → 验证状态更新
- [ ] **Step 5: 主题切换测试** — 切换到 cyberpunk-terminal → 验证样式变化
- [ ] **Step 6: 运行 `pnpm test:e2e`** — 全部通过
- [ ] **Step 7: Commit**

---

### Task 20: 构建 + 质量门检查

- [ ] **Step 1: 运行 `pnpm lint`** — 0 error
- [ ] **Step 2: 运行 `pnpm test`** — 全部通过
- [ ] **Step 3: 运行 `pnpm test:e2e`** — 全部通过
- [ ] **Step 4: 运行 `pnpm build`** — 成功输出 `dist/`
- [ ] **Step 5: 验证 bundle 大小** — `gzip < 500KB`
- [ ] **Step 6: 用 `pnpm preview` 验证构建产物** — 所有场景正常
- [ ] **Step 7: Commit**

---

### Task 21: 分页功能

- [ ] **Step 1: 事件列表分页** — 加载更多 / 无限滚动
- [ ] **Step 2: 消息历史分页** — 向上滚动加载
- [ ] **Step 3: 审批/文档/报表列表分页**
- [ ] **Step 4: Commit**

---

### Task 22: 三态覆盖（Loading / Error / Empty）

- [ ] **Step 1: 统一的无数据占位组件** — `<EmptyState icon={...} message="..." />`
- [ ] **Step 2: 统一错误组件** — `<ErrorBanner error={...} onRetry={...} />`
- [ ] **Step 3: 加载骨架屏** — Skeleton components
- [ ] **Step 4: 集成到所有页面** — 在 DevPanel "空状态" + "错误注入" 场景下验证
- [ ] **Step 5: Commit**

---

## 实施建议

- **开发顺序**: Task 1→7（基础设施）→ Task 8→14（核心 UI）→ Task 15→16（审批+DevPanel）→ Task 17→20（测试+构建）→ Task 21→22（打磨）
- **每个 Phase 做完后运行 `pnpm lint && pnpm test && pnpm build` 确认无回归**
- **Task 7 的 handlers 代码由于篇幅原因未全部展开在 plan 中，实施时参考 spec §5（API 契约）和 fixtures 数据实现**

—— 计划完 ——
