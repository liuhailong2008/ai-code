# Skill Management Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a complete Agent skill knowledge pack management system with backend API (Go/Gin) and frontend UI (React/TanStack), supporting zip upload, directory tree browsing, and online Markdown file editing.

**Architecture:** Backend follows existing pattern: model → repo → service → handler → router. Skills files stored on disk at `code/skills/`, metadata indexed in MySQL. Frontend follows existing page/component patterns with left-list + right-detail layout.

**Tech Stack:** Go 1.26.3, Gin, MySQL, React 18, TanStack Router, TanStack Query, Tailwind CSS, shiki (already in frontend).

---

### Task 1: Database DDL

**Files:**
- Create: `code/sql/012_create_skill_tables.sql`

- [ ] **Step 1: Write the SQL DDL file**

```sql
-- 技能管理相关表
-- 创建日期: 2026-06-24

-- ============================================================
-- 1. 技能表
-- ============================================================
CREATE TABLE IF NOT EXISTS `skills` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `skill_name`        VARCHAR(128)     NOT NULL                 COMMENT '技能名称',
  `skill_code`        VARCHAR(64)      NOT NULL                 COMMENT '技能编码',
  `description`       VARCHAR(512)     DEFAULT NULL             COMMENT '技能描述',
  `version`           VARCHAR(32)      DEFAULT NULL             COMMENT '版本号',
  `file_path`         VARCHAR(254)     NOT NULL                 COMMENT '技能文件相对路径',
  `is_enabled`        TINYINT(1)       NOT NULL DEFAULT 1       COMMENT '是否启用',
  `created_by`        VARCHAR(64)      NOT NULL                 COMMENT '创建人',
  `updated_by`        VARCHAR(64)      DEFAULT NULL             COMMENT '修改人',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_skill_code` (`skill_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='技能表';

-- ============================================================
-- 2. 技能文件索引表
-- ============================================================
CREATE TABLE IF NOT EXISTS `skill_files` (
  `id`                BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT  COMMENT '主键ID',
  `skill_id`          BIGINT UNSIGNED  NOT NULL                 COMMENT '所属技能ID',
  `file_name`         VARCHAR(254)     NOT NULL                 COMMENT '文件名',
  `file_path`         VARCHAR(254)     NOT NULL                 COMMENT '文件相对路径（相对于技能根目录）',
  `file_type`         VARCHAR(16)      NOT NULL DEFAULT 'file'  COMMENT '类型: file/dir',
  `parent_path`       VARCHAR(254)     DEFAULT ''               COMMENT '父目录路径',
  `created_at`        DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_skill_id` (`skill_id`),
  KEY `idx_parent_path` (`skill_id`, `parent_path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='技能文件索引表';
```

- [ ] **Step 2: Review DDL against project conventions**
  - All VARCHAR lengths ≤ 254 ✓
  - No keywords/reserved words ✓
  - No TEXT/JSON/BLOB fields ✓
  - BIGINT UNSIGNED primary keys ✓
  - created_at/updated_at timestamps ✓

---

### Task 2: Backend Config - Add SkillsDir

**Files:**
- Modify: `code/backend/internal/config/config.go`

- [ ] **Step 1: Add SkillsDir field and load from env**

Replace the `Config` struct and `Load` function in `code/backend/internal/config/config.go`:

```go
package config

import (
	"crypto/sha256"
	"os"
	"path/filepath"
)

type Config struct {
	ServerPort    string
	DBHost        string
	DBPort        string
	DBUser        string
	DBPassword    string
	DBName        string
	JWTSecret     string
	EncryptionKey string
	SkillsDir     string
}

func Load() *Config {
	return &Config{
		ServerPort:    getEnv("SERVER_PORT", "8080"),
		DBHost:        getEnv("DB_HOST", "127.0.0.1"),
		DBPort:        getEnv("DB_PORT", "3307"),
		DBUser:        getEnv("DB_USER", "groot"),
		DBPassword:    getEnv("DB_PASSWORD", "groot123"),
		DBName:        getEnv("DB_NAME", "groot"),
		JWTSecret:     getEnv("JWT_SECRET", "groot-jwt-secret-key"),
		EncryptionKey: getEnv("ENCRYPTION_KEY", "groot-aes-256-key!!"),
		SkillsDir:     resolveSkillsDir(),
	}
}

func resolveSkillsDir() string {
	if dir := os.Getenv("SKILLS_DIR"); dir != "" {
		return dir
	}
	// 默认：程序同级目录的 ../skills/
	execPath, err := os.Executable()
	if err != nil {
		return "../skills"
	}
	return filepath.Join(filepath.Dir(execPath), "..", "skills")
}
```

*No other functions in config.go are modified.*

---

### Task 3: Backend Model

**Files:**
- Create: `code/backend/internal/model/skill.go`

- [ ] **Step 1: Write model file**

```go
package model

import "time"

// --- Skill ---

type Skill struct {
	ID          int64     `json:"id"`
	SkillName   string    `json:"skillName"`
	SkillCode   string    `json:"skillCode"`
	Description *string   `json:"description"`
	Version     *string   `json:"version"`
	FilePath    string    `json:"filePath"`
	IsEnabled   bool      `json:"isEnabled"`
	CreatedBy   string    `json:"createdBy"`
	UpdatedBy   *string   `json:"updatedBy"`
	CreatedAt   time.Time `json:"createdAt"`
	UpdatedAt   time.Time `json:"updatedAt"`
}

// --- SkillFile ---

type SkillFile struct {
	ID         int64     `json:"id"`
	SkillID    int64     `json:"skillId"`
	FileName   string    `json:"fileName"`
	FilePath   string    `json:"filePath"`
	FileType   string    `json:"fileType"`
	ParentPath string    `json:"parentPath"`
	CreatedAt  time.Time `json:"createdAt"`
}

// --- Tree Node (for directory structure) ---

type SkillTreeNode struct {
	Name     string            `json:"name"`
	Path     string            `json:"path"`
	Type     string            `json:"type"` // "file" or "dir"
	Children []*SkillTreeNode  `json:"children,omitempty"`
}

type SkillTreeResponse struct {
	SkillID   int64             `json:"skillId"`
	SkillName string            `json:"skillName"`
	Tree      []*SkillTreeNode  `json:"tree"`
}

// --- Requests ---

type CreateSkillRequest struct {
	SkillName   string  `json:"skillName"`
	SkillCode   string  `json:"skillCode"`
	Description *string `json:"description"`
	Version     *string `json:"version"`
}

type UpdateSkillRequest struct {
	SkillName   *string `json:"skillName"`
	SkillCode   *string `json:"skillCode"`
	Description *string `json:"description"`
	Version     *string `json:"version"`
	IsEnabled   *bool   `json:"isEnabled"`
}

type SaveFileRequest struct {
	Content string `json:"content"`
}

// --- SKILL.md frontmatter (parsed from uploaded skills) ---

type SkillFrontmatter struct {
	Name        string `yaml:"name"`
	Description string `yaml:"description"`
}
```

---

### Task 4: Backend Repo

**Files:**
- Create: `code/backend/internal/repo/skill.go`

- [ ] **Step 1: Write repo file**

```go
package repo

import (
	"groot-backend/internal/db"
	"groot-backend/internal/model"
)

// --- Skills ---

func ListSkills() ([]model.Skill, error) {
	rows, err := db.DB.Query(
		`SELECT id, skill_name, skill_code, description, version, file_path,
		        is_enabled, created_by, updated_by, created_at, updated_at
		 FROM skills ORDER BY id DESC`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.Skill
	for rows.Next() {
		var s model.Skill
		if err := rows.Scan(&s.ID, &s.SkillName, &s.SkillCode, &s.Description, &s.Version,
			&s.FilePath, &s.IsEnabled, &s.CreatedBy, &s.UpdatedBy, &s.CreatedAt, &s.UpdatedAt); err != nil {
			return nil, err
		}
		list = append(list, s)
	}
	return list, nil
}

func GetSkill(id int64) (*model.Skill, error) {
	var s model.Skill
	err := db.DB.QueryRow(
		`SELECT id, skill_name, skill_code, description, version, file_path,
		        is_enabled, created_by, updated_by, created_at, updated_at
		 FROM skills WHERE id = ?`, id).Scan(
		&s.ID, &s.SkillName, &s.SkillCode, &s.Description, &s.Version,
		&s.FilePath, &s.IsEnabled, &s.CreatedBy, &s.UpdatedBy, &s.CreatedAt, &s.UpdatedAt)
	if err != nil {
		return nil, err
	}
	return &s, nil
}

func GetSkillByCode(code string) (*model.Skill, error) {
	var s model.Skill
	err := db.DB.QueryRow(
		`SELECT id, skill_name, skill_code, description, version, file_path,
		        is_enabled, created_by, updated_by, created_at, updated_at
		 FROM skills WHERE skill_code = ?`, code).Scan(
		&s.ID, &s.SkillName, &s.SkillCode, &s.Description, &s.Version,
		&s.FilePath, &s.IsEnabled, &s.CreatedBy, &s.UpdatedBy, &s.CreatedAt, &s.UpdatedAt)
	if err != nil {
		return nil, err
	}
	return &s, nil
}

func CreateSkill(skill *model.Skill) (int64, error) {
	result, err := db.DB.Exec(
		`INSERT INTO skills (skill_name, skill_code, description, version, file_path, created_by)
		 VALUES (?, ?, ?, ?, ?, ?)`,
		skill.SkillName, skill.SkillCode, skill.Description, skill.Version, skill.FilePath, skill.CreatedBy)
	if err != nil {
		return 0, err
	}
	return result.LastInsertId()
}

func UpdateSkill(id int64, req *model.UpdateSkillRequest, updatedBy string) error {
	_, err := db.DB.Exec(
		`UPDATE skills SET
			skill_name  = COALESCE(NULLIF(?, ''), skill_name),
			skill_code  = COALESCE(NULLIF(?, ''), skill_code),
			description = COALESCE(NULLIF(?, ''), description),
			version     = COALESCE(NULLIF(?, ''), version),
			is_enabled  = COALESCE(?, is_enabled),
			updated_by  = ?
		 WHERE id = ?`,
		req.SkillName, req.SkillCode, req.Description, req.Version, req.IsEnabled, updatedBy, id)
	return err
}

func DeleteSkill(id int64) error {
	_, err := db.DB.Exec(`DELETE FROM skills WHERE id = ?`, id)
	return err
}

// --- Skill Files ---

func ListSkillFiles(skillID int64) ([]model.SkillFile, error) {
	rows, err := db.DB.Query(
		`SELECT id, skill_id, file_name, file_path, file_type, parent_path, created_at
		 FROM skill_files WHERE skill_id = ? ORDER BY file_type, file_path`, skillID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []model.SkillFile
	for rows.Next() {
		var f model.SkillFile
		if err := rows.Scan(&f.ID, &f.SkillID, &f.FileName, &f.FilePath, &f.FileType, &f.ParentPath, &f.CreatedAt); err != nil {
			return nil, err
		}
		list = append(list, f)
	}
	return list, nil
}

func InsertSkillFile(f *model.SkillFile) error {
	_, err := db.DB.Exec(
		`INSERT INTO skill_files (skill_id, file_name, file_path, file_type, parent_path)
		 VALUES (?, ?, ?, ?, ?)`,
		f.SkillID, f.FileName, f.FilePath, f.FileType, f.ParentPath)
	return err
}

func DeleteSkillFiles(skillID int64) error {
	_, err := db.DB.Exec(`DELETE FROM skill_files WHERE skill_id = ?`, skillID)
	return err
}

func DeleteSkillFileByPath(skillID int64, filePath string) error {
	_, err := db.DB.Exec(`DELETE FROM skill_files WHERE skill_id = ? AND file_path = ?`, skillID, filePath)
	return err
}
```

---

### Task 5: Backend Service (Business Logic)

**Files:**
- Create: `code/backend/internal/service/skill.go`

- [ ] **Step 1: Write service file**

```go
package service

import (
	"archive/zip"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"gopkg.in/yaml.v3"
	"groot-backend/internal/model"
	"groot-backend/internal/repo"
)

// ExtractSkillFromZip 解压 zip 并返回技能元数据和文件列表
func ExtractSkillFromZip(zipPath, destDir string) (*model.SkillFrontmatter, []model.SkillFile, error) {
	reader, err := zip.OpenReader(zipPath)
	if err != nil {
		return nil, nil, fmt.Errorf("无法打开 zip 文件: %w", err)
	}
	defer reader.Close()

	// 创建目标目录
	if err := os.MkdirAll(destDir, 0755); err != nil {
		return nil, nil, fmt.Errorf("无法创建目标目录: %w", err)
	}

	var frontmatter *model.SkillFrontmatter
	var files []model.SkillFile

	for _, f := range reader.File {
		// 安全检查：防止路径穿越
		cleanPath := filepath.Clean(f.Name)
		if strings.HasPrefix(cleanPath, "..") || filepath.IsAbs(cleanPath) {
			continue
		}

		destPath := filepath.Join(destDir, cleanPath)

		if f.FileInfo().IsDir() {
			if err := os.MkdirAll(destPath, 0755); err != nil {
				return nil, nil, fmt.Errorf("创建目录失败 %s: %w", cleanPath, err)
			}
			files = append(files, model.SkillFile{
				FileName:   filepath.Base(cleanPath),
				FilePath:   cleanPath,
				FileType:   "dir",
				ParentPath: filepath.Dir(cleanPath),
			})
			continue
		}

		// 确保父目录存在
		if err := os.MkdirAll(filepath.Dir(destPath), 0755); err != nil {
			return nil, nil, fmt.Errorf("创建父目录失败: %w", err)
		}

		// 解压文件
		srcFile, err := f.Open()
		if err != nil {
			return nil, nil, fmt.Errorf("打开压缩文件失败 %s: %w", cleanPath, err)
		}

		dstFile, err := os.Create(destPath)
		if err != nil {
			srcFile.Close()
			return nil, nil, fmt.Errorf("创建文件失败 %s: %w", cleanPath, err)
		}

		_, err = io.Copy(dstFile, srcFile)
		srcFile.Close()
		dstFile.Close()
		if err != nil {
			return nil, nil, fmt.Errorf("写入文件失败 %s: %w", cleanPath, err)
		}

		files = append(files, model.SkillFile{
			FileName:   filepath.Base(cleanPath),
			FilePath:   cleanPath,
			FileType:   "file",
			ParentPath: filepath.Dir(cleanPath),
		})

		// 解析 SKILL.md
		if filepath.Base(cleanPath) == "SKILL.md" && filepath.Dir(cleanPath) == "." {
			fm, err := parseSkillMD(destPath)
			if err == nil {
				frontmatter = fm
			}
		}
	}

	if frontmatter == nil {
		return nil, nil, fmt.Errorf("技能包中未找到有效的 SKILL.md")
	}

	return frontmatter, files, nil
}

// parseSkillMD 解析 SKILL.md 的 YAML frontmatter
func parseSkillMD(filePath string) (*model.SkillFrontmatter, error) {
	data, err := os.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	content := string(data)
	// 查找 YAML frontmatter: 以 --- 开头和结束
	if !strings.HasPrefix(content, "---\n") {
		return nil, fmt.Errorf("SKILL.md 缺少 YAML frontmatter")
	}

	// 找到第二个 ---
	endIdx := strings.Index(content[4:], "\n---")
	if endIdx == -1 {
		return nil, fmt.Errorf("SKILL.md YAML frontmatter 格式不正确")
	}

	yamlContent := content[4 : 4+endIdx]

	var fm model.SkillFrontmatter
	if err := yaml.Unmarshal([]byte(yamlContent), &fm); err != nil {
		return nil, fmt.Errorf("解析 YAML frontmatter 失败: %w", err)
	}

	return &fm, nil
}

// BuildSkillTree 从文件列表构建树形结构
func BuildSkillTree(files []model.SkillFile) []*model.SkillTreeNode {
	nodeMap := make(map[string]*model.SkillTreeNode)
	var roots []*model.SkillTreeNode

	// 先创建所有节点
	for _, f := range files {
		node := &model.SkillTreeNode{
			Name: f.FileName,
			Path: f.FilePath,
			Type: f.FileType,
		}
		nodeMap[f.FilePath] = node
	}

	// 建立父子关系
	for _, f := range files {
		node := nodeMap[f.FilePath]
		if f.ParentPath == "" || f.ParentPath == "." {
			roots = append(roots, node)
		} else {
			parent, ok := nodeMap[f.ParentPath]
			if ok && parent.Type == "dir" {
				parent.Children = append(parent.Children, node)
			} else {
				roots = append(roots, node)
			}
		}
	}

	return roots
}

// ValidatePath 校验文件路径在技能目录内，防止路径穿越
func ValidatePath(skillDir, reqPath string) (string, error) {
	cleanPath := filepath.Clean(reqPath)
	if strings.HasPrefix(cleanPath, "..") || filepath.IsAbs(cleanPath) {
		return "", fmt.Errorf("非法路径: %s", reqPath)
	}

	fullPath := filepath.Join(skillDir, cleanPath)
	absFull, err := filepath.Abs(fullPath)
	if err != nil {
		return "", fmt.Errorf("路径解析失败: %w", err)
	}

	absBase, err := filepath.Abs(skillDir)
	if err != nil {
		return "", fmt.Errorf("基准路径解析失败: %w", err)
	}

	if !strings.HasPrefix(absFull, absBase+string(filepath.Separator)) && absFull != absBase {
		return "", fmt.Errorf("路径超出允许范围")
	}

	return absFull, nil
}

// SaveSkillFromZip 完整的上传处理流程：解压 → 入库 → 返回 skill
func SaveSkillFromZip(zipPath, skillsDir, skillCode, username string) (*model.Skill, error) {
	destDir := filepath.Join(skillsDir, skillCode)

	// 如果已存在同名技能，先清理
	if _, err := os.Stat(destDir); err == nil {
		existing, err := repo.GetSkillByCode(skillCode)
		if err == nil {
			// 删除旧文件和旧数据库记录
			os.RemoveAll(destDir)
			repo.DeleteSkillFiles(existing.ID)
			repo.DeleteSkill(existing.ID)
		}
	}

	frontmatter, files, err := ExtractSkillFromZip(zipPath, destDir)
	if err != nil {
		return nil, err
	}

	skillName := frontmatter.Name
	if skillName == "" {
		skillName = skillCode
	}

	description := frontmatter.Description
	filePath := skillCode

	skill := &model.Skill{
		SkillName:   skillName,
		SkillCode:   skillCode,
		Description: &description,
		FilePath:    filePath,
		CreatedBy:   username,
	}

	id, err := repo.CreateSkill(skill)
	if err != nil {
		os.RemoveAll(destDir)
		return nil, fmt.Errorf("创建技能记录失败: %w", err)
	}

	for i := range files {
		files[i].SkillID = id
		if err := repo.InsertSkillFile(&files[i]); err != nil {
			// 回滚
			repo.DeleteSkillFiles(id)
			repo.DeleteSkill(id)
			os.RemoveAll(destDir)
			return nil, fmt.Errorf("保存文件索引失败: %w", err)
		}
	}

	return repo.GetSkill(id)
}
```

---

### Task 6: Backend Handler

**Files:**
- Create: `code/backend/internal/handler/skill.go`

- [ ] **Step 1: Write handler file**

```go
package handler

import (
	"database/sql"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/gin-gonic/gin"
	"groot-backend/internal/config"
	"groot-backend/internal/model"
	"groot-backend/internal/repo"
	"groot-backend/internal/service"
)

var skillsDir string

func InitSkillsDir(cfg *config.Config) {
	skillsDir = cfg.SkillsDir
}

// --- Skill CRUD Handlers ---

func ListSkills(c *gin.Context) {
	list, err := repo.ListSkills()
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	if list == nil {
		list = []model.Skill{}
	}
	c.JSON(http.StatusOK, list)
}

func GetSkill(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}
	skill, err := repo.GetSkill(id)
	if err != nil {
		if err == sql.ErrNoRows {
			c.JSON(http.StatusNotFound, gin.H{"error": "skill not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, skill)
}

func CreateSkill(c *gin.Context) {
	var req model.CreateSkillRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	username := c.GetString("username")
	filePath := req.SkillCode

	skill := &model.Skill{
		SkillName:   req.SkillName,
		SkillCode:   req.SkillCode,
		Description: req.Description,
		Version:     req.Version,
		FilePath:    filePath,
		CreatedBy:   username,
	}

	id, err := repo.CreateSkill(skill)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// 确保技能目录存在
	destDir := filepath.Join(skillsDir, req.SkillCode)
	os.MkdirAll(destDir, 0755)

	created, _ := repo.GetSkill(id)
	c.JSON(http.StatusCreated, created)
}

func UpdateSkill(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	var req model.UpdateSkillRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	username := c.GetString("username")
	if err := repo.UpdateSkill(id, &req, username); err != nil {
		if err == sql.ErrNoRows {
			c.JSON(http.StatusNotFound, gin.H{"error": "skill not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	skill, _ := repo.GetSkill(id)
	c.JSON(http.StatusOK, skill)
}

func DeleteSkill(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	skill, err := repo.GetSkill(id)
	if err != nil {
		if err == sql.ErrNoRows {
			c.JSON(http.StatusNotFound, gin.H{"error": "skill not found"})
			return
		}
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// 删除文件系统中的技能目录
	destDir := filepath.Join(skillsDir, skill.FilePath)
	os.RemoveAll(destDir)

	// 删除数据库中的文件索引
	repo.DeleteSkillFiles(id)

	// 删除技能记录
	repo.DeleteSkill(id)

	c.JSON(http.StatusNoContent, nil)
}

// --- Upload Handler ---

func UploadSkill(c *gin.Context) {
	file, err := c.FormFile("file")
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "请上传 zip 文件"})
		return
	}

	// 技能编码：优先用表单字段，否则用文件名（去掉 .zip 后缀）
	skillCode := c.PostForm("skillCode")
	if skillCode == "" {
		ext := filepath.Ext(file.Filename)
		skillCode = file.Filename[:len(file.Filename)-len(ext)]
	}

	// 保存临时 zip 文件
	tmpPath := filepath.Join(os.TempDir(), file.Filename)
	if err := c.SaveUploadedFile(file, tmpPath); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "保存上传文件失败: " + err.Error()})
		return
	}
	defer os.Remove(tmpPath)

	username := c.GetString("username")
	skill, err := service.SaveSkillFromZip(tmpPath, skillsDir, skillCode, username)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusCreated, skill)
}

// --- File Browsing & Editing Handlers ---

func GetSkillTree(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	skill, err := repo.GetSkill(id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "skill not found"})
		return
	}

	files, err := repo.ListSkillFiles(id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	tree := service.BuildSkillTree(files)
	c.JSON(http.StatusOK, model.SkillTreeResponse{
		SkillID:   skill.ID,
		SkillName: skill.SkillName,
		Tree:      tree,
	})
}

func GetSkillFile(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	filePath := c.Query("path")
	if filePath == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "path is required"})
		return
	}

	skill, err := repo.GetSkill(id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "skill not found"})
		return
	}

	skillDir := filepath.Join(skillsDir, skill.FilePath)
	fullPath, err := service.ValidatePath(skillDir, filePath)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	data, err := os.ReadFile(fullPath)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "文件不存在"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"path":    filePath,
		"content": string(data),
	})
}

func SaveSkillFile(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	filePath := c.Query("path")
	if filePath == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "path is required"})
		return
	}

	var req model.SaveFileRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	skill, err := repo.GetSkill(id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "skill not found"})
		return
	}

	skillDir := filepath.Join(skillsDir, skill.FilePath)
	fullPath, err := service.ValidatePath(skillDir, filePath)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	if err := os.WriteFile(fullPath, []byte(req.Content), 0644); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "保存文件失败: " + err.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"success": true})
}

func CreateSkillFile(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	filePath := c.Query("path")
	if filePath == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "path is required"})
		return
	}

	var req model.SaveFileRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	skill, err := repo.GetSkill(id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "skill not found"})
		return
	}

	skillDir := filepath.Join(skillsDir, skill.FilePath)
	fullPath, err := service.ValidatePath(skillDir, filePath)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// 确保父目录存在
	if err := os.MkdirAll(filepath.Dir(fullPath), 0755); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "创建目录失败: " + err.Error()})
		return
	}

	// 检查文件是否已存在
	if _, err := os.Stat(fullPath); err == nil {
		c.JSON(http.StatusConflict, gin.H{"error": "文件已存在"})
		return
	}

	if err := os.WriteFile(fullPath, []byte(req.Content), 0644); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "创建文件失败: " + err.Error()})
		return
	}

	// 同时更新数据库索引（如果是目录下的文件）
	if strings.HasSuffix(filePath, ".md") {
		repo.InsertSkillFile(&model.SkillFile{
			SkillID:    id,
			FileName:   filepath.Base(filePath),
			FilePath:   filePath,
			FileType:   "file",
			ParentPath: filepath.Dir(filePath),
		})
	}

	c.JSON(http.StatusCreated, gin.H{"success": true, "path": filePath})
}

func DeleteSkillFile(c *gin.Context) {
	id, err := strconv.ParseInt(c.Param("id"), 10, 64)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	filePath := c.Query("path")
	if filePath == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "path is required"})
		return
	}

	skill, err := repo.GetSkill(id)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "skill not found"})
		return
	}

	skillDir := filepath.Join(skillsDir, skill.FilePath)
	fullPath, err := service.ValidatePath(skillDir, filePath)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	if err := os.Remove(fullPath); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "删除文件失败: " + err.Error()})
		return
	}

	// 从数据库索引中删除
	repo.DeleteSkillFileByPath(id, filePath)

	c.JSON(http.StatusNoContent, nil)
}
```

---

### Task 7: Backend Router Update

**Files:**
- Modify: `code/backend/internal/router/router.go`

- [ ] **Step 1: Add skills routes**

In the `Setup` function, add the skills route group after the system-setting block (before the closing `}` of Setup):

```go
	// 技能管理（需要鉴权）
	skills := api.Group("/skills", middleware.AuthRequired())
	{
		skills.GET("", handler.ListSkills)
		skills.GET("/:id", handler.GetSkill)
		skills.POST("", handler.CreateSkill)
		skills.POST("/upload", handler.UploadSkill)
		skills.PATCH("/:id", handler.UpdateSkill)
		skills.DELETE("/:id", handler.DeleteSkill)
		skills.GET("/:id/tree", handler.GetSkillTree)
		skills.GET("/:id/file", handler.GetSkillFile)
		skills.PUT("/:id/file", handler.SaveSkillFile)
		skills.POST("/:id/file", handler.CreateSkillFile)
		skills.DELETE("/:id/file", handler.DeleteSkillFile)
	}
```

Insert this block right before the closing `}` of the `Setup` function, after the system-setting block ends.

---

### Task 8: Backend main.go - Init SkillsDir

**Files:**
- Modify: `code/backend/cmd/server/main.go`

- [ ] **Step 1: Add InitSkillsDir call**

Read `code/backend/cmd/server/main.go` first, then add after the `middleware.InitJWT(cfg)` line:

```go
	handler.InitSkillsDir(cfg)
```

---

### Task 9: go.mod - Make yaml.v3 Direct Dependency

**Files:**
- Modify: `code/backend/go.mod`

- [ ] **Step 1: Add yaml.v3 as direct dependency**

Since `gopkg.in/yaml.v3` is already present as an indirect dependency, we need to add it to the `require` block and run `go mod tidy`. The simplest approach:

Run:
```bash
cd code/backend && go get gopkg.in/yaml.v3 && go mod tidy
```

---

### Task 10: Frontend API Module

**Files:**
- Create: `code/frontend/src/api/skills.ts`

- [ ] **Step 1: Write API module**

```typescript
import { request } from './client'

export interface Skill {
  id: number
  skillName: string
  skillCode: string
  description: string | null
  version: string | null
  filePath: string
  isEnabled: boolean
  createdBy: string
  updatedBy: string | null
  createdAt: string
  updatedAt: string
}

export interface SkillTreeNode {
  name: string
  path: string
  type: 'file' | 'dir'
  children?: SkillTreeNode[]
}

export interface SkillTreeResponse {
  skillId: number
  skillName: string
  tree: SkillTreeNode[]
}

export interface SkillFileContent {
  path: string
  content: string
}

export interface CreateSkillRequest {
  skillName: string
  skillCode: string
  description?: string
  version?: string
}

export interface UpdateSkillRequest {
  skillName?: string
  skillCode?: string
  description?: string
  version?: string
  isEnabled?: boolean
}

// --- Skills CRUD ---

export async function listSkills(): Promise<Skill[]> {
  return request<Skill[]>('/skills')
}

export async function getSkill(id: number): Promise<Skill> {
  return request<Skill>(`/skills/${id}`)
}

export async function createSkill(data: CreateSkillRequest): Promise<Skill> {
  return request<Skill>('/skills', {
    method: 'POST',
    body: JSON.stringify(data),
  })
}

export async function uploadSkill(file: File, skillCode?: string): Promise<Skill> {
  const formData = new FormData()
  formData.append('file', file)
  if (skillCode) {
    formData.append('skillCode', skillCode)
  }

  const url = `${import.meta.env.VITE_API_BASE_URL || '/api'}/skills/upload`

  // 从 auth store 获取 token
  let token = ''
  try {
    const { useAuthStore } = await import('../stores/auth')
    token = useAuthStore.getState().token || ''
  } catch { /* ignore */ }

  const response = await fetch(url, {
    method: 'POST',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData,
  })

  if (!response.ok) {
    const body = await response.json().catch(() => ({}))
    throw new Error((body as any).error || '上传失败')
  }

  return response.json()
}

export async function updateSkill(id: number, data: UpdateSkillRequest): Promise<Skill> {
  return request<Skill>(`/skills/${id}`, {
    method: 'PATCH',
    body: JSON.stringify(data),
  })
}

export async function deleteSkill(id: number): Promise<void> {
  return request<void>(`/skills/${id}`, { method: 'DELETE' })
}

// --- File Operations ---

export async function getSkillTree(id: number): Promise<SkillTreeResponse> {
  return request<SkillTreeResponse>(`/skills/${id}/tree`)
}

export async function getSkillFile(id: number, path: string): Promise<SkillFileContent> {
  return request<SkillFileContent>(`/skills/${id}/file?path=${encodeURIComponent(path)}`)
}

export async function saveSkillFile(id: number, path: string, content: string): Promise<void> {
  return request<void>(`/skills/${id}/file?path=${encodeURIComponent(path)}`, {
    method: 'PUT',
    body: JSON.stringify({ content }),
  })
}

export async function createSkillFile(id: number, path: string, content: string): Promise<void> {
  return request<void>(`/skills/${id}/file?path=${encodeURIComponent(path)}`, {
    method: 'POST',
    body: JSON.stringify({ content }),
  })
}

export async function deleteSkillFile(id: number, path: string): Promise<void> {
  return request<void>(`/skills/${id}/file?path=${encodeURIComponent(path)}`, {
    method: 'DELETE',
  })
}
```

---

### Task 11: Frontend Route Page

**Files:**
- Create: `code/frontend/src/routes/_app.skills.tsx`

This is the main page. It's a complex file with multiple sub-components following the project's pattern (e.g., `_app.settings.team.tsx`). Let me write a complete page.

- [ ] **Step 1: Write the page file**

```tsx
import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useState, useRef } from 'react'
import {
  listSkills, getSkill, uploadSkill, updateSkill, deleteSkill,
  getSkillTree, getSkillFile, saveSkillFile, createSkillFile,
  type Skill, type SkillTreeNode, type SkillFileContent,
} from '../api/skills'

export const Route = createFileRoute('/_app/skills')({
  component: SkillsPage,
})

function SkillsPage() {
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [activeTab, setActiveTab] = useState<'info' | 'files'>('info')

  return (
    <main className="flex-1 flex overflow-hidden">
      {/* 左侧技能列表 */}
      <SkillListPanel
        selectedId={selectedId}
        onSelect={(id) => { setSelectedId(id); setActiveTab('info') }}
      />
      {/* 右侧详情 */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {selectedId ? (
          <SkillDetailPanel
            skillId={selectedId}
            activeTab={activeTab}
            onTabChange={setActiveTab}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center text-muted-foreground">
            请选择一个技能查看详情
          </div>
        )}
      </div>
    </main>
  )
}

// ==================== 左侧技能列表 ====================

function SkillListPanel({ selectedId, onSelect }: {
  selectedId: number | null
  onSelect: (id: number) => void
}) {
  const queryClient = useQueryClient()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [search, setSearch] = useState('')
  const [uploading, setUploading] = useState(false)
  const [uploadError, setUploadError] = useState('')

  const { data: skills, isLoading } = useQuery({
    queryKey: ['skills'],
    queryFn: () => listSkills(),
  })

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploading(true)
    setUploadError('')
    try {
      await uploadSkill(file)
      queryClient.invalidateQueries({ queryKey: ['skills'] })
    } catch (err: any) {
      setUploadError(err.message || '上传失败')
    } finally {
      setUploading(false)
      if (fileInputRef.current) fileInputRef.current.value = ''
    }
  }

  const filtered = skills?.filter(s =>
    s.skillName.toLowerCase().includes(search.toLowerCase()) ||
    s.skillCode.toLowerCase().includes(search.toLowerCase())
  ) ?? []

  return (
    <div className="w-80 border-r border-border bg-card flex flex-col shrink-0">
      <div className="p-3 space-y-2">
        <div className="flex items-center gap-2">
          <input
            type="text"
            placeholder="搜索技能..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 px-2 py-1.5 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
          <label className={`px-2 py-1.5 rounded text-xs font-medium cursor-pointer transition-colors ${
            uploading ? 'bg-muted text-muted-foreground' : 'bg-primary text-primary-foreground hover:bg-primary/90'
          }`}>
            {uploading ? '上传中...' : '+ 上传'}
            <input
              ref={fileInputRef}
              type="file"
              accept=".zip"
              onChange={handleUpload}
              className="hidden"
              disabled={uploading}
            />
          </label>
        </div>
        {uploadError && (
          <p className="text-xs text-destructive">{uploadError}</p>
        )}
      </div>

      <div className="flex-1 overflow-auto">
        {isLoading ? (
          <p className="p-3 text-sm text-muted-foreground">加载中...</p>
        ) : filtered.length === 0 ? (
          <p className="p-3 text-sm text-muted-foreground">暂无技能</p>
        ) : (
          filtered.map((skill) => (
            <SkillCard
              key={skill.id}
              skill={skill}
              isSelected={skill.id === selectedId}
              onClick={() => onSelect(skill.id)}
              onDeleted={() => {
                if (skill.id === selectedId) onSelect(0)
                queryClient.invalidateQueries({ queryKey: ['skills'] })
              }}
            />
          ))
        )}
      </div>
    </div>
  )
}

function SkillCard({ skill, isSelected, onClick, onDeleted }: {
  skill: Skill
  isSelected: boolean
  onClick: () => void
  onDeleted: () => void
}) {
  const queryClient = useQueryClient()
  const deleteMutation = useMutation({
    mutationFn: () => deleteSkill(skill.id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skills'] })
      onDeleted()
    },
  })

  const toggleMutation = useMutation({
    mutationFn: () => updateSkill(skill.id, { isEnabled: !skill.isEnabled }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['skills'] }),
  })

  return (
    <div
      onClick={onClick}
      className={`p-3 border-b border-border cursor-pointer transition-colors ${
        isSelected ? 'bg-accent' : 'hover:bg-accent/50'
      }`}
    >
      <div className="flex items-center justify-between">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full shrink-0 ${skill.isEnabled ? 'bg-green-500' : 'bg-gray-400'}`} />
            <span className="font-medium text-sm text-foreground truncate">{skill.skillName}</span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5 truncate">{skill.skillCode}</p>
          {skill.description && (
            <p className="text-xs text-muted-foreground mt-0.5 truncate">{skill.description}</p>
          )}
        </div>
        <div className="flex items-center gap-1 shrink-0 ml-2">
          <button
            onClick={(e) => { e.stopPropagation(); toggleMutation.mutate() }}
            className="text-xs px-1.5 py-0.5 rounded hover:bg-muted transition-colors"
            title={skill.isEnabled ? '禁用' : '启用'}
          >
            {skill.isEnabled ? '禁用' : '启用'}
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); if (confirm('确定删除此技能？')) deleteMutation.mutate() }}
            className="text-xs px-1.5 py-0.5 rounded hover:bg-red-100 text-red-600 transition-colors"
            title="删除"
          >
            删除
          </button>
        </div>
      </div>
    </div>
  )
}

// ==================== 右侧详情面板 ====================

function SkillDetailPanel({ skillId, activeTab, onTabChange }: {
  skillId: number
  activeTab: 'info' | 'files'
  onTabChange: (tab: 'info' | 'files') => void
}) {
  return (
    <>
      {/* Tab 切换 */}
      <div className="flex border-b border-border px-4">
        <button
          onClick={() => onTabChange('info')}
          className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
            activeTab === 'info'
              ? 'border-primary text-primary'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          基本信息
        </button>
        <button
          onClick={() => onTabChange('files')}
          className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
            activeTab === 'files'
              ? 'border-primary text-primary'
              : 'border-transparent text-muted-foreground hover:text-foreground'
          }`}
        >
          文件浏览
        </button>
      </div>

      {/* Tab 内容 */}
      <div className="flex-1 overflow-auto">
        {activeTab === 'info' ? (
          <SkillInfoTab skillId={skillId} />
        ) : (
          <SkillFilesTab skillId={skillId} />
        )}
      </div>
    </>
  )
}

// ==================== 基本信息 Tab ====================

function SkillInfoTab({ skillId }: { skillId: number }) {
  const queryClient = useQueryClient()
  const { data: skill, isLoading } = useQuery({
    queryKey: ['skill', skillId],
    queryFn: () => getSkill(skillId),
  })

  const [editMode, setEditMode] = useState(false)
  const [form, setForm] = useState({ skillName: '', description: '', version: '' })

  const updateMutation = useMutation({
    mutationFn: (data: { skillName?: string; description?: string; version?: string }) =>
      updateSkill(skillId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['skill', skillId] })
      queryClient.invalidateQueries({ queryKey: ['skills'] })
      setEditMode(false)
    },
  })

  if (isLoading) return <p className="p-4 text-sm text-muted-foreground">加载中...</p>
  if (!skill) return <p className="p-4 text-sm text-destructive">技能不存在</p>

  const startEdit = () => {
    setForm({
      skillName: skill.skillName,
      description: skill.description || '',
      version: skill.version || '',
    })
    setEditMode(true)
  }

  const handleSave = () => {
    updateMutation.mutate({
      skillName: form.skillName || undefined,
      description: form.description || undefined,
      version: form.version || undefined,
    })
  }

  return (
    <div className="p-6 max-w-lg">
      <div className="space-y-4">
        <FormField label="技能名称">
          {editMode ? (
            <input
              value={form.skillName}
              onChange={(e) => setForm({ ...form, skillName: e.target.value })}
              className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          ) : (
            <p className="text-foreground">{skill.skillName}</p>
          )}
        </FormField>

        <FormField label="技能编码">
          <p className="text-foreground">{skill.skillCode}</p>
        </FormField>

        <FormField label="描述">
          {editMode ? (
            <textarea
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              rows={3}
              className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
            />
          ) : (
            <p className="text-foreground">{skill.description || '-'}</p>
          )}
        </FormField>

        <FormField label="版本">
          {editMode ? (
            <input
              value={form.version}
              onChange={(e) => setForm({ ...form, version: e.target.value })}
              className="w-full px-3 py-2 rounded border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          ) : (
            <p className="text-foreground">{skill.version || '-'}</p>
          )}
        </FormField>

        <FormField label="状态">
          <span className={`text-sm ${skill.isEnabled ? 'text-green-600' : 'text-gray-500'}`}>
            {skill.isEnabled ? '已启用' : '已禁用'}
          </span>
        </FormField>

        <FormField label="创建人">
          <span className="text-sm text-muted-foreground">{skill.createdBy}</span>
        </FormField>

        <FormField label="创建时间">
          <span className="text-sm text-muted-foreground">
            {new Date(skill.createdAt).toLocaleString('zh-CN')}
          </span>
        </FormField>

        <div className="flex gap-2 pt-2">
          {editMode ? (
            <>
              <button
                onClick={handleSave}
                disabled={updateMutation.isPending}
                className="px-4 py-1.5 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 disabled:opacity-50"
              >
                {updateMutation.isPending ? '保存中...' : '保存'}
              </button>
              <button
                onClick={() => setEditMode(false)}
                className="px-4 py-1.5 rounded border border-border text-sm hover:bg-muted"
              >
                取消
              </button>
            </>
          ) : (
            <button
              onClick={startEdit}
              className="px-4 py-1.5 rounded border border-border text-sm hover:bg-muted"
            >
              编辑
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

function FormField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs text-muted-foreground mb-1">{label}</label>
      {children}
    </div>
  )
}

// ==================== 文件浏览 Tab ====================

function SkillFilesTab({ skillId }: { skillId: number }) {
  const { data: treeData, isLoading } = useQuery({
    queryKey: ['skillTree', skillId],
    queryFn: () => getSkillTree(skillId),
  })

  const [selectedPath, setSelectedPath] = useState<string | null>(null)
  const [editMode, setEditMode] = useState(false)
  const [editContent, setEditContent] = useState('')
  const [isNewFile, setIsNewFile] = useState(false)
  const [newFileName, setNewFileName] = useState('')

  const queryClient = useQueryClient()

  const { data: fileData, isLoading: fileLoading } = useQuery({
    queryKey: ['skillFile', skillId, selectedPath],
    queryFn: () => getSkillFile(skillId, selectedPath!),
    enabled: !!selectedPath && !isNewFile,
  })

  const saveMutation = useMutation({
    mutationFn: ({ path, content }: { path: string; content: string }) =>
      saveSkillFile(skillId, path, content),
    onSuccess: () => {
      setEditMode(false)
      queryClient.invalidateQueries({ queryKey: ['skillFile', skillId, selectedPath] })
    },
  })

  const createMutation = useMutation({
    mutationFn: ({ path, content }: { path: string; content: string }) =>
      createSkillFile(skillId, path, content),
    onSuccess: () => {
      setIsNewFile(false)
      setNewFileName('')
      queryClient.invalidateQueries({ queryKey: ['skillTree', skillId] })
    },
  })

  const handleFileClick = (path: string) => {
    setSelectedPath(path)
    setEditMode(false)
    setIsNewFile(false)
  }

  const handleStartEdit = () => {
    if (fileData?.content != null) {
      setEditContent(fileData.content)
    }
    setEditMode(true)
  }

  const handleCancelEdit = () => {
    setEditMode(false)
    if (isNewFile) {
      setIsNewFile(false)
      setNewFileName('')
    }
  }

  const handleStartNewFile = () => {
    setIsNewFile(true)
    setEditContent('')
    setNewFileName('')
    setEditMode(true)
  }

  const handleSave = () => {
    if (isNewFile) {
      if (!newFileName) return
      const dir = selectedPath && treeData?.tree.find(n =>
        n.type === 'dir' && selectedPath.startsWith(n.path)
      ) ? selectedPath : ''
      const fullPath = dir ? `${dir}/${newFileName}` : newFileName
      createMutation.mutate({ path: fullPath, content: editContent })
    } else if (selectedPath) {
      saveMutation.mutate({ path: selectedPath, content: editContent })
    }
  }

  if (isLoading) return <p className="p-4 text-sm text-muted-foreground">加载中...</p>

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* 目录树 */}
      <div className="w-56 border-r border-border overflow-auto p-2 shrink-0">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-medium text-muted-foreground">目录结构</span>
          <button
            onClick={handleStartNewFile}
            className="text-xs px-1.5 py-0.5 rounded bg-primary text-primary-foreground hover:bg-primary/90"
          >
            + 新建
          </button>
        </div>
        {treeData?.tree.map((node, i) => (
          <TreeNode
            key={i}
            node={node}
            selectedPath={selectedPath}
            onSelect={handleFileClick}
            depth={0}
          />
        ))}
      </div>

      {/* 文件内容区 */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {!selectedPath && !isNewFile ? (
          <div className="flex-1 flex items-center justify-center text-sm text-muted-foreground">
            请选择文件查看
          </div>
        ) : editMode ? (
          /* 编辑模式 */
          <div className="flex-1 flex flex-col">
            {isNewFile && (
              <div className="px-3 py-2 border-b border-border flex items-center gap-2">
                <input
                  value={newFileName}
                  onChange={(e) => setNewFileName(e.target.value)}
                  placeholder="文件名 (如 example.md)"
                  className="flex-1 px-2 py-1 rounded border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
              </div>
            )}
            <textarea
              value={editContent}
              onChange={(e) => setEditContent(e.target.value)}
              className="flex-1 p-4 bg-background text-sm text-foreground font-mono resize-none focus:outline-none"
              placeholder="输入 Markdown 内容..."
            />
            <div className="flex gap-2 p-3 border-t border-border">
              <button
                onClick={handleSave}
                disabled={saveMutation.isPending || createMutation.isPending}
                className="px-4 py-1.5 rounded bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 disabled:opacity-50"
              >
                {saveMutation.isPending || createMutation.isPending ? '保存中...' : '保存'}
              </button>
              <button
                onClick={handleCancelEdit}
                className="px-4 py-1.5 rounded border border-border text-sm hover:bg-muted"
              >
                取消
              </button>
            </div>
          </div>
        ) : (
          /* 阅读模式 */
          <>
            <div className="flex items-center justify-between px-4 py-2 border-b border-border">
              <span className="text-sm text-muted-foreground">{selectedPath}</span>
              <button
                onClick={handleStartEdit}
                className="text-xs px-3 py-1 rounded border border-border hover:bg-muted transition-colors"
              >
                编辑
              </button>
            </div>
            <div className="flex-1 overflow-auto p-4">
              {fileLoading ? (
                <p className="text-sm text-muted-foreground">加载中...</p>
              ) : fileData ? (
                <pre className="text-sm text-foreground whitespace-pre-wrap font-mono leading-relaxed">
                  {fileData.content}
                </pre>
              ) : (
                <p className="text-sm text-muted-foreground">无法加载文件内容</p>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  )
}

function TreeNode({ node, selectedPath, onSelect, depth }: {
  node: SkillTreeNode
  selectedPath: string | null
  onSelect: (path: string) => void
  depth: number
}) {
  const [expanded, setExpanded] = useState(depth < 1)
  const isDir = node.type === 'dir'
  const isSelected = node.path === selectedPath

  return (
    <div>
      <div
        onClick={() => {
          if (isDir) {
            setExpanded(!expanded)
          } else {
            onSelect(node.path)
          }
        }}
        className={`flex items-center gap-1 px-1 py-1 rounded text-sm cursor-pointer transition-colors ${
          isSelected ? 'bg-accent text-accent-foreground' : 'text-foreground hover:bg-accent/50'
        }`}
        style={{ paddingLeft: `${depth * 16 + 4}px` }}
      >
        {isDir ? (
          <svg className={`w-3 h-3 transition-transform ${expanded ? 'rotate-90' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        ) : (
          <svg className="w-3 h-3 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-3-3v6" />
          </svg>
        )}
        <span className="truncate text-xs">{node.name}</span>
      </div>
      {isDir && expanded && node.children?.map((child, i) => (
        <TreeNode
          key={i}
          node={child}
          selectedPath={selectedPath}
          onSelect={onSelect}
          depth={depth + 1}
        />
      ))}
    </div>
  )
}
```

---

### Task 12: Sidebar Update

**Files:**
- Modify: `code/frontend/src/components/layout/Sidebar.tsx`

- [ ] **Step 1: Add "技能管理" menu item**

In `Sidebar.tsx`, add a new menu item to the static `menuItems` array:

Change:
```typescript
const menuItems = [
  { path: '/approvals', label: '我的审批' },
  { path: '/history', label: '历史事件' },
  { path: '/reports', label: '报表' },
  { path: '/docs', label: '资料库' },
  { path: '/settings/duty', label: '值班信息' },
]
```

To:
```typescript
const menuItems = [
  { path: '/approvals', label: '我的审批' },
  { path: '/history', label: '历史事件' },
  { path: '/reports', label: '报表' },
  { path: '/docs', label: '资料库' },
  { path: '/skills', label: '技能管理' },
  { path: '/settings/duty', label: '值班信息' },
]
```

Also add the `/skills` active detection in the component. Currently there's `isEventsActive`, `isSettingsActive`, `isSopActive`. Add:

```typescript
const isSkillsActive = location.pathname.startsWith('/skills')
```

---

### Task 13: Build & Verify

- [ ] **Step 1: Build backend**

```bash
cd code/backend && go build ./cmd/server/
```

- [ ] **Step 2: Build frontend**

```bash
cd code/frontend && npm run build
```

- [ ] **Step 3: Verify no build errors**
