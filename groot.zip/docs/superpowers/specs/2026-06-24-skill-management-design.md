# 技能管理功能设计文档

**日期:** 2026-06-24
**状态:** 待审查

---

## 1. 概述

为 Agent 提供可复用的技能知识包（Skill）管理功能。技能遵循 Eino 的 [`SKILL.md` + `reference/*.md`] 规范，可被 Agent 运行时通过 skill 中间件动态加载使用。

### 核心功能
- 技能元数据管理（创建、编辑、删除、启用/禁用）
- zip 包上传解压，自动解析技能目录结构
- 技能文件在线浏览（目录树 + Markdown 阅读）
- 技能文件在线编辑（创建文件、编辑 Markdown 文件）

### 参考资源
- [Eino Skill Console 文档](https://www.cloudwego.io/zh/docs/eino/quick_start/chapter_09_skill_console/)
- 技能示例目录: `eino-ext/skills/` (eino-guide, eino-component, eino-compose, eino-agent)

---

## 2. 技能文件结构规范

每个技能是一个独立目录，包含：

```
<skill_code>/
├── SKILL.md          # 技能主文件（YAML frontmatter + Markdown 内容）
└── reference/        # 参考文档目录（可选）
    ├── topic-a.md
    └── topic-b.md
```

`SKILL.md` frontmatter 示例：
```yaml
---
name: eino-guide
description: Eino 框架学习入口与导航
---
```

---

## 3. 数据库设计

新建文件: `code/sql/012_create_skill_tables.sql`

### 3.1 `skills` 表 - 技能元数据

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT UNSIGNED AUTO_INCREMENT | 主键 |
| skill_name | VARCHAR(128) NOT NULL | 技能名称 |
| skill_code | VARCHAR(64) NOT NULL UNIQUE | 技能编码（唯一标识，对应目录名） |
| description | VARCHAR(512) DEFAULT NULL | 技能描述 |
| version | VARCHAR(32) DEFAULT NULL | 版本号 |
| file_path | VARCHAR(254) NOT NULL | 技能在 skills/ 下的相对目录路径 |
| is_enabled | TINYINT(1) NOT NULL DEFAULT 1 | 是否启用 |
| created_by | VARCHAR(64) NOT NULL | 创建人 |
| updated_by | VARCHAR(64) DEFAULT NULL | 更新人 |
| created_at | DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP | 创建时间 |
| updated_at | DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP | 更新时间 |

### 3.2 `skill_files` 表 - 技能文件索引

用于快速查询目录结构和文件列表，避免频繁遍历文件系统。

| 字段 | 类型 | 说明 |
|------|------|------|
| id | BIGINT UNSIGNED AUTO_INCREMENT | 主键 |
| skill_id | BIGINT UNSIGNED NOT NULL | 所属技能ID |
| file_name | VARCHAR(254) NOT NULL | 文件名 |
| file_path | VARCHAR(254) NOT NULL | 相对于技能根目录的路径 |
| file_type | VARCHAR(16) NOT NULL DEFAULT 'file' | 类型: file / dir |
| parent_path | VARCHAR(254) DEFAULT '' | 父目录路径 |
| created_at | DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP | 创建时间 |

---

## 4. 文件存储

- **存储路径:** `code/skills/<skill_code>/`（与 `code/backend/` 同级）
- 环境变量 `SKILLS_DIR` 可覆盖默认路径，默认值为程序运行目录的 `../skills/`
- 上传 zip 后自动解压到对应技能目录
- 删除技能时同时清理文件系统和数据库记录

---

## 5. API 设计

路由前缀: `/api/skills`（独立顶级模块，auth 保护）

### 5.1 技能管理

| 方法 | 路径 | Handler | 说明 |
|------|------|---------|------|
| GET | `/api/skills` | `ListSkills` | 技能列表 |
| GET | `/api/skills/:id` | `GetSkill` | 技能详情 |
| POST | `/api/skills` | `CreateSkill` | 创建技能元数据（JSON） |
| POST | `/api/skills/upload` | `UploadSkill` | 上传 zip 包（multipart/form-data） |
| PATCH | `/api/skills/:id` | `UpdateSkill` | 更新技能元数据 |
| DELETE | `/api/skills/:id` | `DeleteSkill` | 删除技能（含文件） |

### 5.2 文件浏览与编辑

| 方法 | 路径 | Handler | 说明 |
|------|------|---------|------|
| GET | `/api/skills/:id/tree` | `GetSkillTree` | 获取技能目录树 |
| GET | `/api/skills/:id/file` | `GetSkillFile` | 读取文件内容 (query: `?path=xxx`) |
| PUT | `/api/skills/:id/file` | `SaveSkillFile` | 保存/编辑文件 (query: `?path=xxx`) |
| POST | `/api/skills/:id/file` | `CreateSkillFile` | 创建新文件 (query: `?path=xxx`) |
| DELETE | `/api/skills/:id/file` | `DeleteSkillFile` | 删除文件 (query: `?path=xxx`) |

### 5.3 请求/响应说明

**POST /api/skills/upload**
- Content-Type: `multipart/form-data`
- 字段: `file` (zip), `skillCode` (可选，用于更新已有技能)
- 自动解压 zip 包，遍历目录结构，解析 `SKILL.md` frontmatter 提取 `name`/`description`，写入 `skills` 和 `skill_files` 表

**GET /api/skills/:id/tree**
- 返回树形结构:
```json
{
  "skillId": 1,
  "skillName": "eino-guide",
  "tree": [
    {
      "name": "SKILL.md",
      "path": "SKILL.md",
      "type": "file"
    },
    {
      "name": "reference",
      "path": "reference",
      "type": "dir",
      "children": [
        { "name": "quick-start.md", "path": "reference/quick-start.md", "type": "file" }
      ]
    }
  ]
}
```

**PUT /api/skills/:id/file?path=reference/xxx.md**
- 请求体: `{ "content": "markdown content..." }`
- 更新文件系统中的实际文件

**POST /api/skills/:id/file?path=reference/newfile.md**
- 请求体: `{ "content": "..." }`
- 在指定路径创建新文件，自动创建父目录

---

## 6. 后端实现方案

### 6.1 文件结构

```
code/backend/internal/
├── model/skill.go      # Skill, SkillFile, 请求/响应结构体
├── repo/skill.go       # 数据库操作
├── handler/skill.go    # HTTP handlers
└── service/skill.go    # 业务逻辑（zip解压、文件操作、SKILL.md解析）
```

### 6.2 关键实现细节

- **zip 上传流程:**
  1. 接收 multipart form 中的 zip 文件
  2. 解压到临时目录
  3. 校验必须包含 `SKILL.md`
  4. 解析 `SKILL.md` frontmatter（YAML）获取 `name` 和 `description`
  5. 写入 `skills` 表获取 `skill_id`
  6. 遍历解压后目录，写入 `skill_files` 表
  7. 移动文件到目标 `skills/<skill_code>/` 目录
  8. 清理临时目录

- **文件操作安全性:**
  - 所有文件路径操作必须限制在技能目录内（防止路径穿越）
  - 调用 `filepath.Clean` + `filepath.Abs` 做路径校验
  - 只允许 `.md` 文件编辑（或可配置扩展名白名单）

- **SKILL.md 解析:**
  - 前端 YAML frontmatter（`---\n...\n---`）
  - 提取 `name` 和 `description` 字段

### 6.3 依赖

- Go 标准库 `archive/zip` 解压
- `gopkg.in/yaml.v3` 解析 YAML frontmatter（go.mod 中需要添加）

---

## 7. 前端实现方案

### 7.1 路由

| 路由文件 | URL | 说明 |
|----------|-----|------|
| `_app.skills.tsx` | `/skills` | 技能管理布局（左侧列表 + 右侧详情） |

### 7.2 页面结构

```
+-------------------------------------------------------------+
| Header (h-12)                                                |
+-------------------------------------------------------------+
| Sidebar (现有菜单: 新增"技能管理" -> /skills)                   |
+-------------------------------------------------------------+
| 技能列表 (w-80)         | 详情区 (flex-1)                     |
|                         |                                    |
| [+ 上传技能] 按钮        | [基本信息 tab] [文件浏览 tab]        |
|                         |                                    |
| 技能卡片列表:            | 基本信息:                           |
|  - 名称 + code          |  - 技能名称、编码、描述、版本        |
|  - 描述（截断）          |  - 启用/禁用开关                     |
|  - 启用状态              |  - 编辑 / 删除 按钮                  |
|                         |                                    |
| 点击选中 -> 显示详情      | 文件浏览:                           |
|                         |  - 左侧目录树（tree 组件）           |
|                         |  - 右侧 Markdown 渲染阅读            |
|                         |  - 编辑模式切换到 Markdown 编辑器    |
|                         |  - 新建文件 / 保存 按钮              |
+-------------------------------------------------------------+
```

### 7.3 组件分解

| 组件 | 说明 |
|------|------|
| `SkillList` | 左侧技能卡片列表，支持搜索过滤 |
| `SkillDetail` | 右侧详情面板，管理 tabs 切换 |
| `SkillInfoTab` | 基本信息展示与编辑 |
| `SkillFilesTab` | 文件浏览 tab |
| `SkillTree` | 目录树组件（基于 skill_files 数据渲染） |
| `MarkdownViewer` | Markdown 阅读器（可复用 shiki 做代码高亮） |
| `MarkdownEditor` | Markdown 编辑器（textarea 或可引入 CodeMirror） |
| `UploadSkillDialog` | zip 上传对话框 |

### 7.4 API 模块

新建 `src/api/skills.ts`:

```ts
- listSkills() -> Skill[]
- getSkill(id) -> Skill
- createSkill(data) -> Skill
- uploadSkill(formData) -> Skill
- updateSkill(id, data) -> Skill
- deleteSkill(id) -> void
- getSkillTree(id) -> SkillTree
- getSkillFile(id, path) -> SkillFile
- saveSkillFile(id, path, content) -> void
- createSkillFile(id, path, content) -> void
- deleteSkillFile(id, path) -> void
```

### 7.5 侧边栏修改

在 `Sidebar.tsx` 的"预案管理"区域，将现有的 `/sop/skills` 链接改为 `/skills`，或新增独立菜单项。

**决定:** 由于用户选择了"独立顶级模块"，应在侧边栏新增独立菜单项"技能管理"，链接到 `/skills`。现有的 `/sop/skills` 保留不动（如果需要可后续移除）。

---

## 8. 数据库迁移

- 文件: `code/sql/012_create_skill_tables.sql`
- 需经用户审核后手动执行

---

## 9. 开发顺序

1. 数据库 DDL 设计与审核
2. 后端 model → repo → service → handler → router
3. 前端 API 模块 → 路由页面 → 组件
4. 集成测试
